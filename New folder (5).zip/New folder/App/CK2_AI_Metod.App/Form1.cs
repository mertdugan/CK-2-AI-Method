﻿using System;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CK2_AI_Metod.Core.Models;
using CK2_AI_Metod.Core.Repositories;
using CK2_AI_Metod.Core.Services;

namespace CK2_AI_Metod.App
{
    public partial class Form1 : Form
    {
        private TextBox txtModelNo;
        private NumericUpDown numWorkingHours;
        private NumericUpDown numTargetQty;
        private NumericUpDown numMaxSaturation;
        private TextBox txtCycleTime;
        private Button btnAnalyze;
        private Button btnBuildDataset;
        private Button btnTrainAI;
        private Button btnGenerateMethod;
        private Label lblModelStatus;
        private TextBox lblModelInfo;
        private Label lblPhysicalStations;
        private Label lblOperators;
        private Label lblStationSaturation;
        private Label lblEngineState;
        private Label lblSystemState;
        private Label lblProgressState;
        private Label lblProgressValue;
        private Label lblResultContext;
        private ProgressBar operationProgress;
        private bool uiBusy;
        private bool operationFailed;
        private PictureBox haierLogo;
        private PictureBox mdLogo;
        private static readonly Color Navy = Color.FromArgb(15, 23, 42);
        private static readonly Color Ink = Color.FromArgb(25, 50, 83);
        private static readonly Color Blue = Color.FromArgb(33, 65, 184);
        private static readonly Color Purple = Color.FromArgb(94, 65, 147);
        private static readonly Color Muted = Color.FromArgb(103, 122, 150);

        private readonly string _configPath;

        public Form1()
        {
            InitializeComponent();

            // Her zaman EXE'nin bulunduğu klasördeki Data\MODEL_Config.xlsx kullanılır.
            // Visual Studio'da: bin\Debug\Data\MODEL_Config.xlsx
            _configPath = Path.Combine(
                Application.StartupPath,
                "Data",
                "MODEL_Config.xlsx");

            BuildInterface();
        }

        private void BuildInterface()
        {
            SuspendLayout();
            Controls.Clear();
            Text = "HAIER | CK-2 AI METOD";
            StartPosition = FormStartPosition.CenterScreen;
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96F, 96F);
            MinimumSize = new Size(1080, 720);
            ClientSize = new Size(1260, 760);
            Rectangle workArea = Screen.FromControl(this).WorkingArea;
            Size = new Size(Math.Min(1276, Math.Max(1080, workArea.Width - 24)),
                            Math.Min(799, Math.Max(720, workArea.Height - 24)));
            Font = new Font("Segoe UI", 10F);
            BackColor = Color.FromArgb(244, 247, 251);
            ForeColor = Ink;
            DoubleBuffered = true;

            TableLayoutPanel shell = new TableLayoutPanel();
            shell.Dock = DockStyle.Fill;
            shell.Margin = Padding.Empty;
            shell.Padding = Padding.Empty;
            shell.ColumnCount = 1;
            shell.RowCount = 3;
            shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            shell.RowStyles.Add(new RowStyle(SizeType.Absolute, 86));
            shell.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            shell.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
            Controls.Add(shell);

            Panel header = new Panel();
            header.Dock = DockStyle.Fill;
            header.Margin = Padding.Empty;
            header.BackColor = Navy;
            shell.Controls.Add(header, 0, 0);
            Label title = MakeLabel("HAIER | CK-2 AI METOD", 18F, Color.White);
            title.Location = new Point(38, 17);
            title.Size = new Size(580, 30);
            header.Controls.Add(title);
            Label subtitle = MakeLabel("Fırın üretim hattı · Metot planlama ve hat dengeleme", 9.5F,
                                       Color.FromArgb(160, 180, 209));
            subtitle.Location = new Point(39, 51);
            subtitle.Size = new Size(630, 22);
            header.Controls.Add(subtitle);
            lblEngineState = MakeLabel("● AI modeli bekleniyor", 9F, Color.FromArgb(250, 204, 95));
            lblEngineState.TextAlign = ContentAlignment.MiddleRight;
            lblEngineState.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblEngineState.Location = new Point(850, 28);
            lblEngineState.Size = new Size(215, 30);
            header.Controls.Add(lblEngineState);
            lblSystemState = MakeLabel("● Sistem kontrol ediliyor", 9F, Color.FromArgb(250, 204, 95));
            lblSystemState.TextAlign = ContentAlignment.MiddleRight;
            lblSystemState.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblSystemState.Location = new Point(1075, 28);
            lblSystemState.Size = new Size(145, 30);
            header.Controls.Add(lblSystemState);
            header.Resize += delegate {
                lblSystemState.Left = header.ClientSize.Width - 185;
                lblEngineState.Left = lblSystemState.Left - 235;
            };

            TableLayoutPanel body = new TableLayoutPanel();
            body.Dock = DockStyle.Fill;
            body.Margin = Padding.Empty;
            body.Padding = new Padding(30, 25, 30, 17);
            body.ColumnCount = 1;
            body.RowCount = 2;
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            body.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            body.RowStyles.Add(new RowStyle(SizeType.Absolute, 140));
            shell.Controls.Add(body, 0, 1);

            BorderCard results = new BorderCard();
            results.Dock = DockStyle.Fill;
            results.Margin = new Padding(0, 0, 0, 22);
            results.Padding = new Padding(20, 15, 20, 12);
            body.Controls.Add(results, 0, 0);
            TableLayoutPanel content = new TableLayoutPanel();
            content.Dock = DockStyle.Fill;
            content.Margin = Padding.Empty;
            content.ColumnCount = 1;
            content.RowCount = 5;
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            content.RowStyles.Add(new RowStyle(SizeType.Absolute, 29));
            content.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
            content.RowStyles.Add(new RowStyle(SizeType.Absolute, 83));
            content.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            results.Controls.Add(content);
            Label sectionTitle = MakeLabel("Metot Planlama / Analiz Sonuçları", 11F, Ink);
            sectionTitle.Dock = DockStyle.Fill;
            sectionTitle.Margin = new Padding(8, 0, 0, 0);
            content.Controls.Add(sectionTitle, 0, 0);

            TableLayoutPanel inputs = new TableLayoutPanel();
            inputs.Dock = DockStyle.Fill;
            inputs.Margin = new Padding(0, 3, 0, 6);
            inputs.ColumnCount = 4;
            inputs.RowCount = 1;
            for (int i = 0; i < 4; i++)
                inputs.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            content.Controls.Add(inputs, 0, 1);
            txtModelNo = new TextBox();
            txtModelNo.Name = "txtModelNo";
            txtModelNo.Text = "33704238";
            txtModelNo.BorderStyle = BorderStyle.FixedSingle;
            txtModelNo.Font = new Font("Segoe UI", 11F);
            numWorkingHours = MakeNumber(3, 0.001M, 24M, 8.875M, 0.125M);
            numTargetQty = MakeNumber(0, 1M, 10000M, 1065M, 1M);
            numMaxSaturation = MakeNumber(1, 50M, 100M, 95M, 1M);
            AddInput(inputs, 0, "MODEL NO", txtModelNo);
            AddInput(inputs, 1, "NET ÇALIŞMA SAATİ", numWorkingHours);
            AddInput(inputs, 2, "HEDEF ÜRETİM ADEDİ", numTargetQty);
            AddInput(inputs, 3, "MAKS. HEDEF SATURASYON (%)", numMaxSaturation);

            TableLayoutPanel metrics = new TableLayoutPanel();
            metrics.Dock = DockStyle.Fill;
            metrics.Margin = new Padding(0, 2, 0, 7);
            metrics.ColumnCount = 4;
            metrics.RowCount = 1;
            for (int i = 0; i < 4; i++)
                metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
            content.Controls.Add(metrics, 0, 2);
            txtCycleTime = new TextBox();
            txtCycleTime.ReadOnly = true;
            txtCycleTime.TabStop = false;
            txtCycleTime.BorderStyle = BorderStyle.None;
            txtCycleTime.BackColor = Color.FromArgb(247, 249, 252);
            txtCycleTime.ForeColor = Ink;
            txtCycleTime.Font = new Font("Segoe UI", 18F);
            AddMetric(metrics, 0, "HEDEF ÇEVRİM SÜRESİ", txtCycleTime);
            lblPhysicalStations = MakeLabel("—", 18F, Ink);
            AddMetric(metrics, 1, "FİZİKSEL İSTASYON", lblPhysicalStations);
            lblOperators = MakeLabel("—", 18F, Ink);
            AddMetric(metrics, 2, "OPERATÖR SAYISI", lblOperators);
            lblStationSaturation = MakeLabel("—", 18F, Ink);
            AddMetric(metrics, 3, "ORT. İSTASYON SATURASYONU", lblStationSaturation);

            TableLayoutPanel resultHeading = new TableLayoutPanel();
            resultHeading.Dock = DockStyle.Fill;
            resultHeading.Margin = new Padding(8, 2, 8, 0);
            resultHeading.ColumnCount = 2;
            resultHeading.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
            resultHeading.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));
            content.Controls.Add(resultHeading, 0, 3);
            lblModelStatus = MakeLabel("Model bekleniyor...", 10F, Ink);
            lblModelStatus.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblModelStatus.Dock = DockStyle.Fill;
            resultHeading.Controls.Add(lblModelStatus, 0, 0);
            lblResultContext = MakeLabel("AI Hat Dengeleme", 9F, Muted);
            lblResultContext.TextAlign = ContentAlignment.MiddleRight;
            lblResultContext.Dock = DockStyle.Fill;
            resultHeading.Controls.Add(lblResultContext, 1, 0);
            lblModelInfo = new ResultTextBox();
            lblModelInfo.Dock = DockStyle.Fill;
            lblModelInfo.Margin = new Padding(8, 0, 8, 0);
            lblModelInfo.BorderStyle = BorderStyle.None;
            lblModelInfo.BackColor = Color.White;
            lblModelInfo.ForeColor = Ink;
            lblModelInfo.Font = new Font("Consolas", 9.5F);
            lblModelInfo.ReadOnly = true;
            lblModelInfo.Multiline = true;
            lblModelInfo.ScrollBars = ScrollBars.Vertical;
            lblModelInfo.Text = "Model numarasını ve üretim hedefini girerek ANALİZ ET ile başlayın.";
            content.Controls.Add(lblModelInfo, 0, 4);

            BorderCard actions = new BorderCard();
            actions.Dock = DockStyle.Fill;
            actions.Margin = Padding.Empty;
            actions.Padding = new Padding(24, 13, 24, 17);
            body.Controls.Add(actions, 0, 1);
            Panel actionHeading = new Panel();
            actionHeading.Dock = DockStyle.Top;
            actionHeading.Height = 35;
            actions.Controls.Add(actionHeading);
            Label actionTitle = MakeLabel("Veri İşlemleri", 10F, Ink);
            actionTitle.Location = new Point(4, 0);
            actionTitle.Size = new Size(200, 23);
            actionHeading.Controls.Add(actionTitle);
            Panel progressArea = new Panel();
            progressArea.Dock = DockStyle.Right;
            progressArea.Width = 320;
            actionHeading.Controls.Add(progressArea);
            lblProgressState = MakeLabel("İşlem bekleniyor", 9F, Ink);
            lblProgressState.SetBounds(0, 0, 245, 20);
            progressArea.Controls.Add(lblProgressState);
            lblProgressValue = MakeLabel("0%", 9F, Ink);
            lblProgressValue.TextAlign = ContentAlignment.TopRight;
            lblProgressValue.SetBounds(255, 0, 65, 20);
            progressArea.Controls.Add(lblProgressValue);
            operationProgress = new ProgressBar();
            operationProgress.SetBounds(0, 23, 320, 8);
            operationProgress.Style = ProgressBarStyle.Continuous;
            progressArea.Controls.Add(operationProgress);

            TableLayoutPanel buttons = new TableLayoutPanel();
            buttons.Dock = DockStyle.Bottom;
            buttons.Height = 48;
            buttons.Margin = Padding.Empty;
            buttons.ColumnCount = 5;
            for (int i = 0; i < 4; i++)
                buttons.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 182));
            buttons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            actions.Controls.Add(buttons);
            btnAnalyze = MakeButton("1 - ANALİZ ET", Blue);
            btnBuildDataset = MakeButton("2 - VERİ SETİ OLUŞTUR", Blue);
            btnTrainAI = MakeButton("3 - AI MODELİNİ EĞİT", Blue);
            btnGenerateMethod = MakeButton("4 - AI METOD OLUŞTUR", Purple);
            buttons.Controls.Add(btnAnalyze, 0, 0);
            buttons.Controls.Add(btnBuildDataset, 1, 0);
            buttons.Controls.Add(btnTrainAI, 2, 0);
            buttons.Controls.Add(btnGenerateMethod, 3, 0);
            btnAnalyze.Click += BtnAnalyze_Click;
            btnBuildDataset.Click += BtnBuildDataset_Click;
            btnTrainAI.Click += BtnTrainAI_Click;
            btnGenerateMethod.Click += BtnGenerateMethod_Click;

            Panel footer = new Panel();
            footer.Dock = DockStyle.Fill;
            footer.Margin = Padding.Empty;
            footer.BackColor = Color.White;
            shell.Controls.Add(footer, 0, 2);
            haierLogo = new PictureBox();
            haierLogo.SizeMode = PictureBoxSizeMode.Zoom;
            haierLogo.SetBounds(26, 8, 485, 56);
            haierLogo.Image = LoadBrandImage("haier_logo.png");
            footer.Controls.Add(haierLogo);
            if (haierLogo.Image == null)
            {
                Label brand = MakeLabel("Haier Europe", 24F, Ink);
                brand.SetBounds(36, 15, 450, 46);
                footer.Controls.Add(brand);
            }
            Label signature = MakeLabel("HAIER | Manufacturing Method Analytics", 8.5F, Muted);
            signature.SetBounds(548, 27, 420, 24);
            footer.Controls.Add(signature);
            mdLogo = new PictureBox();
            mdLogo.SizeMode = PictureBoxSizeMode.Zoom;
            mdLogo.SetBounds(1150, 9, 76, 56);
            mdLogo.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            mdLogo.Image = LoadBrandImage("MD_Logo.jpg");
            footer.Controls.Add(mdLogo);
            footer.Resize += delegate { mdLogo.Left = footer.ClientSize.Width - 110; };
            Disposed += delegate {
                if (haierLogo.Image != null) haierLogo.Image.Dispose();
                if (mdLogo.Image != null) mdLogo.Image.Dispose();
            };

            txtModelNo.TabIndex = 0;
            numWorkingHours.TabIndex = 1;
            numTargetQty.TabIndex = 2;
            numMaxSaturation.TabIndex = 3;
            AcceptButton = btnAnalyze;
            txtModelNo.TextChanged += delegate { ScenarioChanged(); };
            numWorkingHours.ValueChanged += delegate { ScenarioChanged(); };
            numTargetQty.ValueChanged += delegate { ScenarioChanged(); };
            numMaxSaturation.ValueChanged += delegate { ScenarioChanged(); };
            lblModelStatus.TextChanged += delegate { RefreshOperationStatus(); };
            RefreshCycleTime();
            RefreshSystemStatus();
            ResumeLayout(true);
        }

        private static Label MakeLabel(string text, float size, Color color)
        {
            return new Label
            {
                Text = text,
                Font = new Font("Segoe UI", size),
                ForeColor = color,
                AutoEllipsis = true,
                BackColor = Color.Transparent
            };
        }

        private static NumericUpDown MakeNumber(int decimals, decimal minimum,
            decimal maximum, decimal value, decimal increment)
        {
            return new NumericUpDown
            {
                DecimalPlaces = decimals,
                Minimum = minimum,
                Maximum = maximum,
                Value = value,
                Increment = increment,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 11F)
            };
        }

        private static void AddInput(TableLayoutPanel parent, int column, string title, Control input)
        {
            Panel box = new Panel { Dock = DockStyle.Fill, Margin = new Padding(8, 0, 8, 0) };
            Label label = MakeLabel(title, 8F, Muted);
            label.SetBounds(0, 0, 280, 20);
            label.Dock = DockStyle.Top;
            input.SetBounds(0, 25, 270, 29);
            input.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
            box.Resize += delegate { input.Width = box.ClientSize.Width; };
            box.Controls.Add(input);
            box.Controls.Add(label);
            parent.Controls.Add(box, column, 0);
        }

        private static void AddMetric(TableLayoutPanel parent, int column, string title, Control value)
        {
            Panel card = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(247, 249, 252),
                Margin = new Padding(8, 0, 2, 0)
            };
            Label label = MakeLabel(title, 8F, Muted);
            label.SetBounds(15, 9, 270, 19);
            value.SetBounds(15, 30, 250, 36);
            value.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
            card.Resize += delegate {
                value.Width = Math.Max(20, card.ClientSize.Width - 30);
                label.Width = Math.Max(20, card.ClientSize.Width - 25);
            };
            card.Controls.Add(label);
            card.Controls.Add(value);
            parent.Controls.Add(card, column, 0);
        }

        private static Button MakeButton(string title, Color color)
        {
            Button button = new Button
            {
                Text = title,
                Dock = DockStyle.Fill,
                Margin = new Padding(0, 0, 12, 0),
                BackColor = color,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                Font = new Font("Segoe UI", 9F),
                UseVisualStyleBackColor = false
            };
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(color, .12F);
            button.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(color, .1F);
            button.EnabledChanged += delegate {
                button.BackColor = button.Enabled ? color : Color.FromArgb(226, 232, 240);
                button.ForeColor = button.Enabled ? Color.White : Muted;
                button.Cursor = button.Enabled ? Cursors.Hand : Cursors.Default;
            };
            return button;
        }

        private static Image LoadBrandImage(string name)
        {
            string[] candidates = { Path.Combine(Application.StartupPath, name),
                Path.Combine(Application.StartupPath, "..", "..", name) };
            foreach (string path in candidates)
            {
                if (!File.Exists(path)) continue;
                try { using (Image image = Image.FromFile(path)) return new Bitmap(image); }
                catch (ArgumentException) { }
                catch (IOException) { }
            }
            return null;
        }

        private void RefreshCycleTime()
        {
            txtCycleTime.Text = ((double)numWorkingHours.Value * 3600.0 /
                (double)numTargetQty.Value).ToString("0.000") + " sn";
        }

        private void ScenarioChanged()
        {
            if (uiBusy) return;
            RefreshCycleTime();
            lblPhysicalStations.Text = "—";
            lblOperators.Text = "—";
            lblStationSaturation.Text = "—";
            lblResultContext.Text = "AI Hat Dengeleme";
            lblModelStatus.Text = "Yeni senaryo";
            lblModelInfo.Text = "Parametreler güncellendi. Modeli analiz edin veya yeni metot oluşturun.";
            operationFailed = false;
            operationProgress.Value = 0;
            lblProgressValue.Text = "0%";
            lblProgressState.Text = "Yeni senaryo hazır";
        }

        private void RefreshSystemStatus()
        {
            bool configReady = File.Exists(_configPath);
            lblSystemState.Text = configReady ? "● Sistem hazır" : "● Config eksik";
            lblSystemState.ForeColor = configReady ? Color.FromArgb(74, 222, 128) : Color.FromArgb(250, 204, 95);
            string dataRoot = Path.GetDirectoryName(_configPath);
            string models = Path.Combine(dataRoot, "AI", "Models");
            bool modelReady = false;
            string production = Path.Combine(models, "production.json");
            if (File.Exists(production))
            {
                try
                {
                    string json = File.ReadAllText(production);
                    Match match = Regex.Match(json, "\"(?:version|Version)\"\\s*:\\s*\"([^\"]+)\"");
                    if (match.Success)
                        modelReady = File.Exists(Path.Combine(models, match.Groups[1].Value, "model_bundle.joblib"));
                }
                catch (IOException) { }
            }
            lblEngineState.Text = modelReady ? "● AI modeli hazır" : "● AI modeli bekleniyor";
            lblEngineState.ForeColor = modelReady ? Color.FromArgb(74, 222, 128) : Color.FromArgb(250, 204, 95);
        }

        private void RefreshOperationStatus()
        {
            string status = lblModelStatus.Text;
            operationFailed = status.IndexOf("HATA", StringComparison.OrdinalIgnoreCase) >= 0
                || status.IndexOf("BULUNAMADI", StringComparison.OrdinalIgnoreCase) >= 0;
            lblModelStatus.ForeColor = operationFailed ? Color.FromArgb(185, 55, 55) : Ink;
            if (uiBusy)
            {
                lblProgressState.Text = status;
                return;
            }
            lblProgressState.Text = operationFailed ? "İşlem tamamlanamadı" : status;
        }

        private void UpdatePredictionCards(AIEngineResult result)
        {
            string output = result.Output ?? "";
            lblPhysicalStations.Text = EngineValue(output, "STATION_COUNT", "—");
            lblOperators.Text = EngineValue(output, "OPERATOR_COUNT", "—");
            string saturation = EngineValue(output, "ACTUAL_AVG_SATURATION", "");
            double number;
            lblStationSaturation.Text = double.TryParse(saturation, NumberStyles.Any,
                CultureInfo.InvariantCulture, out number) ? "%" + number.ToString("0.00") : "—";
            lblResultContext.Text = "Model " + txtModelNo.Text.Trim() + "  ·  " +
                EngineValue(output, "VERSION", "AI Hat Dengeleme");
        }

        private string BuildPredictionSummary(AIEngineResult result, string outputPath)
        {
            string output = result.Output ?? "";
            string review = EngineValue(output, "AI_QUALITY_STATUS", "");
            return "Model              : " + txtModelNo.Text.Trim() + Environment.NewLine +
                "Üretim hedefi      : " + numTargetQty.Value.ToString("0") + " adet" + Environment.NewLine +
                "Operasyon sayısı   : " + EngineValue(output, "OPERATION_COUNT", "—") + Environment.NewLine +
                "Fiziksel istasyon  : " + lblPhysicalStations.Text + Environment.NewLine +
                "Operatör sayısı    : " + lblOperators.Text + Environment.NewLine +
                "Durum             : " + (review == "REVIEW_REQUIRED" ?
                    "Mühendislik incelemesi gerekli" : "Metot oluşturuldu; saha kontrolüne hazır") +
                Environment.NewLine + Environment.NewLine + "Excel dosyası:" + Environment.NewLine + outputPath;
        }

        private static string EngineValue(string output, string key, string fallback)
        {
            Match match = Regex.Match(output, "(?m)^\\s*" + Regex.Escape(key) + "=([^\\r\\n]+)");
            return match.Success ? match.Groups[1].Value.Trim() : fallback;
        }

        private sealed class ResultTextBox : TextBox
        {
            public override string Text
            {
                get { return base.Text; }
                set
                {
                    base.Text = (value ?? "").Replace("\r\n", "\n")
                    .Replace("\r", "\n").Replace("\n", Environment.NewLine);
                }
            }
        }

        private sealed class BorderCard : Panel
        {
            public BorderCard() { BackColor = Color.White; DoubleBuffered = true; }
            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                using (Pen pen = new Pen(Color.FromArgb(142, 150, 161)))
                    e.Graphics.DrawRectangle(pen, 0, 0, Math.Max(0, Width - 1), Math.Max(0, Height - 1));
            }
        }

        private void BtnAnalyze_Click(
            object sender,
            EventArgs e)
        {
            AnalyzeCurrentModel(true);
        }

        private void AnalyzeCurrentModel(
            bool allowNewModelDialog)
        {
            try
            {
                string modelNo =
                    txtModelNo.Text.Trim();

                if (string.IsNullOrWhiteSpace(
                    modelNo))
                {
                    MessageBox.Show(
                        "Model numarası giriniz.",
                        "CK-2 AI Metod",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    txtModelNo.Focus();

                    return;
                }

                double workingHours =
                    Convert.ToDouble(
                        numWorkingHours.Value);

                int targetProduction =
                    Convert.ToInt32(
                        numTargetQty.Value);

                double maxSaturation =
                    Convert.ToDouble(
                        numMaxSaturation.Value);

                string balanceMode = "AI Hat Dengeleme";

                CycleTimeService
                    cycleTimeService =
                    new CycleTimeService();

                double cycleTime =
                    cycleTimeService.Calculate(
                        workingHours,
                        targetProduction);

                txtCycleTime.Text =
                    cycleTime.ToString(
                        "0.000") +
                    " sn";

                if (!File.Exists(
                    _configPath))
                {
                    MessageBox.Show(
                        "MODEL_Config.xlsx bulunamadı.",
                        "CK-2 AI Metod",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    return;
                }

                ModelConfigRepository
                    repository =
                    new ModelConfigRepository(
                        _configPath);

                ProductConfiguration model =
                    repository.GetModel(
                        modelNo);

                if (model == null)
                {
                    lblModelStatus.Text =
                        "MODEL CONFIG DOSYASINDA BULUNAMADI";

                    lblModelInfo.Text =
                        "Model No: " +
                        modelNo +
                        Environment.NewLine +
                        Environment.NewLine +
                        "Bu model MODEL_Config.xlsx dosyasında bulunamadı.";

                    if (!allowNewModelDialog)
                        return;

                    DialogResult answer =
                        MessageBox.Show(
                            modelNo +
                            " modeli config dosyasında bulunamadı." +
                            Environment.NewLine +
                            Environment.NewLine +
                            "Yeni model oluşturmak ister misiniz?",
                            "Yeni Model",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question);

                    if (answer ==
                        DialogResult.Yes)
                    {
                        using (
                            NewModelForm
                                newModelForm =
                                new NewModelForm(
                                    modelNo,
                                    _configPath))
                        {
                            if (
                                newModelForm
                                    .ShowDialog(this) ==
                                DialogResult.OK)
                            {
                                AnalyzeCurrentModel(
                                    false);
                            }
                        }
                    }

                    return;
                }

                lblModelStatus.Text =
                    "MODEL BULUNDU";

                lblModelInfo.Text =
                    BuildModelInformation(
                        model,
                        workingHours,
                        targetProduction,
                        cycleTime,
                        maxSaturation,
                        balanceMode);
            }
            catch (Exception ex)
            {
                lblModelStatus.Text = "MODEL ANALİZ HATASI";
                lblModelInfo.Text = ex.Message;
                MessageBox.Show(
                    ex.ToString(),
                    "CK-2 AI Metod - Hata",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private async void BtnBuildDataset_Click(
            object sender,
            EventArgs e)
        {
            try
            {
                string dataFolder =
                    Path.Combine(
                        Application.StartupPath,
                        "Data");

                string methodsFolder =
                    Path.Combine(
                        dataFolder,
                        "Methods");

                string trainingFolder =
                    Path.Combine(
                        dataFolder,
                        "Training");

                if (!Directory.Exists(methodsFolder))
                {
                    Directory.CreateDirectory(
                        methodsFolder);

                    MessageBox.Show(
                        "Methods klasörü oluşturuldu." +
                        Environment.NewLine +
                        Environment.NewLine +
                        "Metod Excel dosyalarını buraya kopyalayın:" +
                        Environment.NewLine +
                        methodsFolder +
                        Environment.NewLine +
                        Environment.NewLine +
                        "Sonra tekrar VERİ SETİNİ OLUŞTUR butonuna basın.",
                        "CK-2 AI Metod",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    return;
                }

                if (!Directory.Exists(trainingFolder))
                {
                    Directory.CreateDirectory(
                        trainingFolder);
                }

                string outputPath =
                    Path.Combine(
                        trainingFolder,
                        "CK2_AI_Metod_TrainingDataset.xlsx");

                MethodDatasetService service =
                    new MethodDatasetService();

                SetAIButtonsEnabled(false);
                lblModelStatus.Text = "VERİ SETİ OLUŞTURULUYOR...";
                MethodDatasetBuildResult result = await Task.Run(() =>
                    service.BuildCataFanAssistedDataset(
                        _configPath,
                        methodsFolder,
                        outputPath));

                string message =
                    "VERİ SETİ OLUŞTURULDU" +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Taranan Excel       : " +
                    result.ScannedFileCount +
                    Environment.NewLine +
                    "Aileye Dahil        : " +
                    result.IncludedFileCount +
                    Environment.NewLine +
                    "Diğer Aile          : " +
                    result.SkippedFileCount +
                    Environment.NewLine +
                    "Hatalı Dosya        : " +
                    result.ErrorFileCount +
                    Environment.NewLine +
                    "Operasyon            : " +
                    result.OperationCount +
                    Environment.NewLine +
                    "İstasyon             : " +
                    result.StationCount +
                    Environment.NewLine +
                    "QC Uyarılı İstasyon : " +
                    result.WarningCount +
                    Environment.NewLine +
                    "Metodu Eksik Model   : " +
                    result.MissingMethodCount +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Çıktı:" +
                    Environment.NewLine +
                    result.OutputPath;

                lblModelStatus.Text = "VERİ SETİ OLUŞTURULDU";
                lblModelInfo.Text = message;
                MessageBox.Show(
                    message,
                    "CK-2 AI Metod",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblModelStatus.Text = "VERİ SETİ HATASI";
                lblModelInfo.Text = ex.Message;
                MessageBox.Show(
                    ex.ToString(),
                    "CK-2 AI Metod - Dataset Hatası",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                if (uiBusy) SetAIButtonsEnabled(true);
            }
        }

        private async void BtnTrainAI_Click(
            object sender,
            EventArgs e)
        {
            string datasetPath =
                Path.Combine(
                    Application.StartupPath,
                    "Data",
                    "Training",
                    "CK2_AI_Metod_TrainingDataset.xlsx");

            string modelsRoot =
                Path.Combine(
                    Application.StartupPath,
                    "Data",
                    "AI",
                    "Models");

            if (!File.Exists(datasetPath))
            {
                MessageBox.Show(
                    "Training dataset bulunamadı." +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Önce VERİ SETİNİ OLUŞTUR butonuna basın.",
                    "CK-2 AI Metod",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            SetAIButtonsEnabled(false);

            lblModelStatus.Text =
                "AI MODELİ EĞİTİLİYOR...";

            lblModelInfo.Text =
                "Python AI Engine çalışıyor." +
                Environment.NewLine +
                Environment.NewLine +
                "Operasyon var/yok modeli" +
                Environment.NewLine +
                "Operasyon tekrar sayısı" +
                Environment.NewLine +
                "Operasyon süre modeli" +
                Environment.NewLine +
                "Sequence / precedence modeli" +
                Environment.NewLine +
                "Station position / type modeli" +
                Environment.NewLine +
                Environment.NewLine +
                "Eğitim tamamlanınca sonuç burada gösterilecek.";

            try
            {
                AIEngineService service =
                    new AIEngineService(
                        Application.StartupPath);

                AIEngineResult result =
                    await service.TrainAsync(
                        datasetPath,
                        modelsRoot);

                if (!result.Success)
                {
                    lblModelStatus.Text =
                        "AI EĞİTİM HATASI";

                    lblModelInfo.Text =
                        result.DisplayMessage;

                    MessageBox.Show(
                        result.DisplayMessage,
                        "CK-2 AI Metod - AI Eğitim Hatası",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    return;
                }

                lblModelStatus.Text =
                    "AI MODELİ HAZIR";

                lblModelInfo.Text =
                    result.DisplayMessage;

                MessageBox.Show(
                    "AI modeli başarıyla eğitildi." +
                    Environment.NewLine +
                    Environment.NewLine +
                    result.DisplayMessage,
                    "CK-2 AI Metod",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblModelStatus.Text =
                    "AI EĞİTİM HATASI";
                lblModelInfo.Text = ex.Message;

                MessageBox.Show(
                    ex.ToString(),
                    "CK-2 AI Metod - AI Eğitim Hatası",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                SetAIButtonsEnabled(true);
            }
        }

        private async void BtnGenerateMethod_Click(
            object sender,
            EventArgs e)
        {
            string modelNo =
                txtModelNo.Text.Trim();

            if (string.IsNullOrWhiteSpace(
                modelNo))
            {
                MessageBox.Show(
                    "Model numarası giriniz.",
                    "CK-2 AI Metod",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            if (!File.Exists(_configPath))
            {
                MessageBox.Show(
                    "MODEL_Config.xlsx bulunamadı.",
                    "CK-2 AI Metod",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return;
            }

            ModelConfigRepository repository =
                new ModelConfigRepository(
                    _configPath);

            ProductConfiguration model =
                repository.GetModel(
                    modelNo);

            if (model == null)
            {
                MessageBox.Show(
                    "Model config içinde bulunamadı." +
                    Environment.NewLine +
                    "Önce modeli config'e ekleyin.",
                    "CK-2 AI Metod",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            double workingHours =
                Convert.ToDouble(
                    numWorkingHours.Value);

            int targetProduction =
                Convert.ToInt32(
                    numTargetQty.Value);

            double maxSaturation =
                Convert.ToDouble(
                    numMaxSaturation.Value);

            // Kullanici artik mod secmez: tek otomatik AI dengeleme.
            string balanceMode = "auto";
            string balanceModeDisplay = "AI Hat Dengeleme";

            CycleTimeService cycleTimeService =
                new CycleTimeService();

            double cycleTime =
                cycleTimeService.Calculate(
                    workingHours,
                    targetProduction);

            txtCycleTime.Text =
                cycleTime.ToString(
                    "0.000") +
                " sn";

            string modelsRoot =
                Path.Combine(
                    Application.StartupPath,
                    "Data",
                    "AI",
                    "Models");

            string predictionFolder =
                Path.Combine(
                    Application.StartupPath,
                    "Data",
                    "Predictions");

            Directory.CreateDirectory(
                predictionFolder);

            string outputPath =
                Path.Combine(
                    predictionFolder,
                    modelNo +
                    "_AI_Method_" +
                    DateTime.Now.ToString(
                        "yyyyMMdd_HHmmss") +
                    ".xlsx");

            SetAIButtonsEnabled(false);

            lblModelStatus.Text =
                "AI METOD OLUŞTURUYOR...";

            lblModelInfo.Text =
                "Model: " +
                modelNo +
                Environment.NewLine +
                "Target CT: " +
                cycleTime.ToString(
                    "0.000") +
                " sn" +
                Environment.NewLine +
                "Maks. Hedef Saturasyon: %" +
                maxSaturation.ToString(
                    "0.0") +
                Environment.NewLine +
                "Dengeleme Yöntemi: " +
                balanceModeDisplay +
                Environment.NewLine +
                "Maks. İstasyon İş Yükü: " +
                (
                    cycleTime *
                    maxSaturation /
                    100.0
                ).ToString(
                    "0.000") +
                " sn" +
                Environment.NewLine +
                Environment.NewLine +
                "AI gerekli operasyonları, tekrar sayılarını, süreleri, " +
                "proses sırasını ve istasyon eğilimlerini tahmin ediyor." +
                Environment.NewLine +
                "Ardından hedef CT için hat dengelemesi yapılıyor.";

            try
            {
                AIEngineService service =
                    new AIEngineService(
                        Application.StartupPath);

                AIEngineResult result =
                    await service.PredictAsync(
                        _configPath,
                        modelNo,
                        workingHours,
                        targetProduction,
                        maxSaturation,
                        balanceMode,
                        modelsRoot,
                        outputPath);

                if (!result.Success)
                {
                    lblModelStatus.Text =
                        "AI METOD HATASI";

                    lblModelInfo.Text =
                        result.DisplayMessage;

                    MessageBox.Show(
                        result.DisplayMessage,
                        "CK-2 AI Metod - Tahmin Hatası",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    return;
                }

                lblModelStatus.Text =
                    "AI METOD OLUŞTURULDU";

                UpdatePredictionCards(result);
                lblModelInfo.Text = BuildPredictionSummary(result, outputPath);

                MessageBox.Show(
                    "AI metod başarıyla oluşturuldu." +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Dosya:" +
                    Environment.NewLine +
                    outputPath,
                    "CK-2 AI Metod",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                TryOpenFile(
                    outputPath);
            }
            catch (Exception ex)
            {
                lblModelStatus.Text =
                    "AI METOD HATASI";
                lblModelInfo.Text = ex.Message;

                MessageBox.Show(
                    ex.ToString(),
                    "CK-2 AI Metod - Tahmin Hatası",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                SetAIButtonsEnabled(true);
            }
        }

        private void SetAIButtonsEnabled(bool enabled)
        {
            uiBusy = !enabled;
            btnAnalyze.Enabled = enabled;
            btnBuildDataset.Enabled = enabled;
            btnTrainAI.Enabled = enabled;
            btnGenerateMethod.Enabled = enabled;
            txtModelNo.Enabled = enabled;
            numWorkingHours.Enabled = enabled;
            numTargetQty.Enabled = enabled;
            numMaxSaturation.Enabled = enabled;
            UseWaitCursor = !enabled;
            if (!enabled)
            {
                lblPhysicalStations.Text = "—";
                lblOperators.Text = "—";
                lblStationSaturation.Text = "—";
                lblResultContext.Text = "AI Hat Dengeleme";
                operationProgress.Style = ProgressBarStyle.Marquee;
                operationProgress.MarqueeAnimationSpeed = 30;
                lblProgressValue.Text = "Çalışıyor";
                lblProgressState.Text = "İşlem sürüyor...";
            }
            else
            {
                operationProgress.MarqueeAnimationSpeed = 0;
                operationProgress.Style = ProgressBarStyle.Continuous;
                operationProgress.Value = operationFailed ? 0 : 100;
                lblProgressValue.Text = operationFailed ? "0%" : "100%";
                lblProgressState.Text = operationFailed ? "İşlem tamamlanamadı" : "İşlem tamamlandı";
                RefreshSystemStatus();
            }
        }

        private void TryOpenFile(
            string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                    return;

                ProcessStartInfo startInfo =
                    new ProcessStartInfo();

                startInfo.FileName =
                    filePath;

                startInfo.UseShellExecute =
                    true;

                Process.Start(
                    startInfo);
            }
            catch
            {
                // Excel/associated application cannot be opened.
                // The generated file itself remains valid.
            }
        }

        private string BuildModelInformation(
            ProductConfiguration model,
            double workingHours,
            int targetProduction,
            double cycleTime,
            double maxSaturation,
            string balanceMode)
        {
            return
                "MODEL BİLGİLERİ" +
                Environment.NewLine +

                "------------------------------------------------------------" +
                Environment.NewLine +

                "Model No           : " +
                model.ModelNo +
                Environment.NewLine +

                "Ürün Grubu         : " +
                model.CataPyro +
                Environment.NewLine +

                "Model Tipi         : " +
                model.ModelType +
                Environment.NewLine +

                "Timer Tipi         : " +
                model.TimerType +
                Environment.NewLine +

                "Cehennemlik Tipi   : " +
                model.CehennemlikType +
                Environment.NewLine +

                "Travers / Snap     : " +
                model.TraversSnap +
                Environment.NewLine +

                "Astar Cam          : " +
                NullableToText(
                    model.AstarCam) +
                Environment.NewLine +

                "Testaporta         : " +
                model.Testaporta +
                Environment.NewLine +

                "TCO Braket         : " +
                model.TcoBraket +
                Environment.NewLine +

                "Limitör            : " +
                NullableToText(
                    model.Limitor) +
                Environment.NewLine +

                "Tepsi              : " +
                NullableToText(
                    model.Tepsi) +
                Environment.NewLine +

                "Izgara             : " +
                NullableToText(
                    model.Izgara) +
                Environment.NewLine +

                "Airfry             : " +
                model.Airfry +
                Environment.NewLine +

                "Ray                : " +
                model.Ray +
                Environment.NewLine +

                "Fan Carton         : " +
                model.FanCarton +
                Environment.NewLine +

                "Kapı Etiketi       : " +
                model.KapiEtiketi +
                Environment.NewLine +

                "Config Çalışan     : " +
                NullableToText(
                    model.CalisanSayisi) +
                Environment.NewLine +

                "Config Tempo       : " +
                NullableToText(
                    model.Tempo) +
                Environment.NewLine +

                "Not                : " +
                model.Not +
                Environment.NewLine +
                Environment.NewLine +

                "ÜRETİM SENARYOSU" +
                Environment.NewLine +

                "------------------------------------------------------------" +
                Environment.NewLine +

                "Net Çalışma Saati  : " +
                workingHours.ToString(
                    "0.###") +
                " saat" +
                Environment.NewLine +

                "Hedef Üretim       : " +
                targetProduction +
                " adet" +
                Environment.NewLine +

                "Hedef Cycle Time   : " +
                cycleTime.ToString(
                    "0.000") +
                " sn" +
                Environment.NewLine +

                "Maks. Saturasyon     : %" +
                maxSaturation.ToString(
                    "0.0") +
                Environment.NewLine +

                "Dengeleme Yöntemi    : " +
                balanceMode +
                Environment.NewLine +

                "Maks. İstasyon Yükü : " +
                (
                    cycleTime *
                    maxSaturation /
                    100.0
                ).ToString(
                    "0.000") +
                " sn";
        }

        private string NullableToText(
            int? value)
        {
            return value.HasValue
                ? value.Value.ToString()
                : "-";
        }
    }
}
