﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CK2_AI_Metod.Core.Models;
using CK2_AI_Metod.Core.Repositories;

namespace CK2_AI_Metod.App
{
    public class NewModelForm : Form
    {
        private readonly ModelConfigRepository _repository;
        private readonly string _modelNo;

        private TextBox txtModelNo;
        private ComboBox cmbCataPyro;
        private ComboBox cmbModelType;
        private ComboBox cmbTimerType;
        private ComboBox cmbCehennemlik;
        private ComboBox cmbTraversSnap;
        private ComboBox cmbTestaporta;
        private ComboBox cmbTcoBraket;
        private ComboBox cmbAirfry;
        private ComboBox cmbRay;
        private ComboBox cmbFanCarton;
        private ComboBox cmbKapiEtiketi;

        private NumericUpDown numAstarCam;
        private NumericUpDown numLimitor;
        private NumericUpDown numTepsi;
        private NumericUpDown numIzgara;
        private NumericUpDown numCalisanSayisi;
        private NumericUpDown numTempo;

        private TextBox txtNot;
        private Button btnSave;
        private Button btnCancel;

        private List<ProductConfiguration> _existingModels;

        public ProductConfiguration SavedModel { get; private set; }

        public NewModelForm(string modelNo, string configPath)
        {
            _modelNo = modelNo == null
                ? string.Empty
                : modelNo.Trim();

            _repository = new ModelConfigRepository(configPath);

            LoadExistingModels();
            BuildInterface();
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);

            // Popup başlığında ana formdaki ikon/logo kullanılır.
            // ShowDialog(this) ile açıldığı için Owner ana Form1 olur.
            if (Owner != null && Owner.Icon != null)
            {
                Icon = Owner.Icon;
            }
            else
            {
                try
                {
                    Icon appIcon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);

                    if (appIcon != null)
                        Icon = appIcon;
                }
                catch
                {
                }
            }
        }

        private void LoadExistingModels()
        {
            try
            {
                _existingModels = _repository.GetAllModels();
            }
            catch
            {
                _existingModels = new List<ProductConfiguration>();
            }
        }

        private void BuildInterface()
        {
            Text = "CK-2 AI Metod - Yeni Model";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(760, 820);
            MinimumSize = new Size(760, 820);
            Font = new Font("Segoe UI", 10F);
            AutoScroll = true;
            ShowIcon = true;

            Label title = new Label
            {
                Text = "YENİ MODEL KONFİGÜRASYONU",
                Font = new Font("Segoe UI", 18F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(30, 25)
            };
            Controls.Add(title);

            Label info = new Label
            {
                Text =
                    "Listede olmayan yeni bir değeri elle yazabilirsiniz. " +
                    "Kaydedildiğinde sonraki kullanımlarda seçim listesine otomatik eklenecektir.",
                AutoSize = false,
                Size = new Size(670, 45),
                Location = new Point(33, 65)
            };
            Controls.Add(info);

            int y = 125;
            int leftLabel = 35;
            int leftInput = 250;
            int width = 410;
            int gap = 42;

            txtModelNo = AddTextBox(
                "Model No", _modelNo, y,
                leftLabel, leftInput, width, true);
            y += gap;

            cmbCataPyro = AddDynamicCombo(
                "Cata / Pyro",
                GetExistingValues(x => x.CataPyro),
                new string[] { "Cata", "Pyro" },
                "Cata", y, leftLabel, leftInput, width);
            y += gap;

            cmbModelType = AddDynamicCombo(
                "Model Tipi",
                GetExistingValues(x => x.ModelType),
                new string[]
                {
                    "Fan asisted",
                    "Multifunction",
                    "Statik",
                    "Statik Cooling Fan",
                    "Fan Oven"
                },
                "Fan asisted", y, leftLabel, leftInput, width);
            y += gap;

            cmbTimerType = AddDynamicCombo(
                "Timer Tipi",
                GetExistingValues(x => x.TimerType),
                new string[]
                {
                    "60 timer",
                    "Touch",
                    "Push Pull",
                    "Mekanik",
                    "Digital"
                },
                "60 timer", y, leftLabel, leftInput, width);
            y += gap;

            cmbCehennemlik = AddDynamicCombo(
                "Cehennemlik Tipi",
                GetExistingValues(x => x.CehennemlikType),
                new string[] { "emboos", "tel raf" },
                "emboos", y, leftLabel, leftInput, width);
            y += gap;

            cmbTraversSnap = AddDynamicCombo(
                "Travers / Snap",
                GetExistingValues(x => x.TraversSnap),
                new string[] { "snap", "travers", "yok" },
                "snap", y, leftLabel, leftInput, width);
            y += gap;

            numAstarCam = AddNumber(
                "Astar Cam", 0, 10, 0,
                y, leftLabel, leftInput, width);
            y += gap;

            cmbTestaporta = AddDynamicCombo(
                "Testaporta",
                GetExistingValues(x => x.Testaporta),
                new string[] { "metal", "plastik", "yok" },
                "metal", y, leftLabel, leftInput, width);
            y += gap;

            cmbTcoBraket = AddDynamicCombo(
                "TCO Braket",
                GetExistingValues(x => x.TcoBraket),
                new string[] { "var", "yok" },
                "yok", y, leftLabel, leftInput, width);
            y += gap;

            numLimitor = AddNumber(
                "Limitör", 0, 10, 1,
                y, leftLabel, leftInput, width);
            y += gap;

            numTepsi = AddNumber(
                "Tepsi", 0, 10, 1,
                y, leftLabel, leftInput, width);
            y += gap;

            numIzgara = AddNumber(
                "Izgara", 0, 10, 1,
                y, leftLabel, leftInput, width);
            y += gap;

            cmbAirfry = AddDynamicCombo(
                "Airfry",
                GetExistingValues(x => x.Airfry),
                new string[] { "var", "yok" },
                "yok", y, leftLabel, leftInput, width);
            y += gap;

            cmbRay = AddDynamicCombo(
                "Ray",
                GetExistingValues(x => x.Ray),
                new string[] { "var", "yok" },
                "yok", y, leftLabel, leftInput, width);
            y += gap;

            cmbFanCarton = AddDynamicCombo(
                "Fan Carton",
                GetExistingValues(x => x.FanCarton),
                new string[] { "var", "yok" },
                "yok", y, leftLabel, leftInput, width);
            y += gap;

            cmbKapiEtiketi = AddDynamicCombo(
                "Kapı Etiketi",
                GetExistingValues(x => x.KapiEtiketi),
                new string[] { "var", "yok" },
                "var", y, leftLabel, leftInput, width);
            y += gap;

            numCalisanSayisi = AddNumber(
                "Çalışan Sayısı", 0, 100, 0,
                y, leftLabel, leftInput, width);
            y += gap;

            txtNot = AddTextBox(
                "Not", string.Empty, y,
                leftLabel, leftInput, width, false);
            y += gap;

            numTempo = AddNumber(
                "Tempo", 0, 10000, 0,
                y, leftLabel, leftInput, width);
            y += gap + 10;

            btnSave = new Button
            {
                Text = "KAYDET",
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                Size = new Size(170, 44),
                Location = new Point(250, y)
            };
            btnSave.Click += BtnSave_Click;
            Controls.Add(btnSave);

            btnCancel = new Button
            {
                Text = "İPTAL",
                Size = new Size(120, 44),
                Location = new Point(440, y)
            };
            btnCancel.Click += delegate
            {
                DialogResult = DialogResult.Cancel;
                Close();
            };
            Controls.Add(btnCancel);
        }

        private TextBox AddTextBox(
            string label,
            string value,
            int y,
            int leftLabel,
            int leftInput,
            int width,
            bool readOnly)
        {
            AddLabel(label, y, leftLabel);

            TextBox box = new TextBox
            {
                Text = value,
                Location = new Point(leftInput, y - 4),
                Size = new Size(width, 28),
                ReadOnly = readOnly
            };

            Controls.Add(box);
            return box;
        }

        private ComboBox AddDynamicCombo(
            string label,
            List<string> existingValues,
            string[] defaultValues,
            string defaultValue,
            int y,
            int leftLabel,
            int leftInput,
            int width)
        {
            AddLabel(label, y, leftLabel);

            ComboBox combo = new ComboBox
            {
                Location = new Point(leftInput, y - 4),
                Size = new Size(width, 28),
                DropDownStyle = ComboBoxStyle.DropDown,
                AutoCompleteMode = AutoCompleteMode.SuggestAppend,
                AutoCompleteSource = AutoCompleteSource.ListItems
            };

            List<string> values = MergeValues(
                existingValues,
                defaultValues);

            foreach (string value in values)
                combo.Items.Add(value);

            if (!string.IsNullOrWhiteSpace(defaultValue))
                combo.Text = defaultValue;

            Controls.Add(combo);
            return combo;
        }

        private NumericUpDown AddNumber(
            string label,
            decimal min,
            decimal max,
            decimal value,
            int y,
            int leftLabel,
            int leftInput,
            int width)
        {
            AddLabel(label, y, leftLabel);

            NumericUpDown number = new NumericUpDown
            {
                Location = new Point(leftInput, y - 4),
                Size = new Size(width, 28),
                Minimum = min,
                Maximum = max,
                Value = value
            };

            Controls.Add(number);
            return number;
        }

        private void AddLabel(string text, int y, int x)
        {
            Label label = new Label
            {
                Text = text,
                AutoSize = true,
                Location = new Point(x, y)
            };

            Controls.Add(label);
        }

        private List<string> GetExistingValues(
            Func<ProductConfiguration, string> selector)
        {
            List<string> values = new List<string>();

            if (_existingModels == null)
                return values;

            foreach (ProductConfiguration model in _existingModels)
            {
                string value = selector(model);

                if (string.IsNullOrWhiteSpace(value))
                    continue;

                value = value.Trim();

                bool alreadyExists = values.Any(
                    x => string.Equals(
                        x,
                        value,
                        StringComparison.CurrentCultureIgnoreCase));

                if (!alreadyExists)
                    values.Add(value);
            }

            return values;
        }

        private List<string> MergeValues(
            List<string> existingValues,
            string[] defaultValues)
        {
            List<string> result = new List<string>();

            if (existingValues != null)
            {
                foreach (string value in existingValues)
                    AddUnique(result, value);
            }

            if (defaultValues != null)
            {
                foreach (string value in defaultValues)
                    AddUnique(result, value);
            }

            return result
                .OrderBy(x => x)
                .ToList();
        }

        private void AddUnique(
            List<string> list,
            string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return;

            value = value.Trim();

            bool exists = list.Any(
                x => string.Equals(
                    x,
                    value,
                    StringComparison.CurrentCultureIgnoreCase));

            if (!exists)
                list.Add(value);
        }

        private void BtnSave_Click(
            object sender,
            EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtModelNo.Text))
                {
                    MessageBox.Show(
                        "Model numarası boş olamaz.",
                        "CK-2 AI Metod",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                ProductConfiguration model =
                    new ProductConfiguration
                    {
                        ModelNo = txtModelNo.Text.Trim(),
                        CataPyro = GetComboText(cmbCataPyro),
                        ModelType = GetComboText(cmbModelType),
                        TimerType = GetComboText(cmbTimerType),
                        CehennemlikType = GetComboText(cmbCehennemlik),
                        TraversSnap = GetComboText(cmbTraversSnap),
                        AstarCam = ToNullable(numAstarCam),
                        Testaporta = GetComboText(cmbTestaporta),
                        TcoBraket = GetComboText(cmbTcoBraket),
                        Limitor = ToNullable(numLimitor),
                        Tepsi = ToNullable(numTepsi),
                        Izgara = ToNullable(numIzgara),
                        Airfry = GetComboText(cmbAirfry),
                        Ray = GetComboText(cmbRay),
                        FanCarton = GetComboText(cmbFanCarton),
                        KapiEtiketi = GetComboText(cmbKapiEtiketi),
                        CalisanSayisi = ToNullable(numCalisanSayisi),
                        Not = txtNot.Text.Trim(),
                        Tempo = ToNullable(numTempo)
                    };

                _repository.AddOrUpdateModel(model);
                SavedModel = model;

                MessageBox.Show(
                    model.ModelNo +
                    " modeli MODEL_Config.xlsx dosyasına kaydedildi.",
                    "CK-2 AI Metod",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "CK-2 AI Metod - Hata",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private string GetComboText(ComboBox combo)
        {
            if (combo == null)
                return string.Empty;

            return combo.Text == null
                ? string.Empty
                : combo.Text.Trim();
        }

        private int? ToNullable(NumericUpDown control)
        {
            int value = Convert.ToInt32(control.Value);

            return value == 0
                ? (int?)null
                : value;
        }
    }
}
