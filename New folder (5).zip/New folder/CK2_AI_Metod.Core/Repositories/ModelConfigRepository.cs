﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using ClosedXML.Excel;
using CK2_AI_Metod.Core.Models;

namespace CK2_AI_Metod.Core.Repositories
{
    public class ModelConfigRepository
    {
        private const string SheetName = "HALİNO";
        private readonly string _filePath;

        public ModelConfigRepository(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath))
                throw new ArgumentException("MODEL_Config.xlsx dosya yolu boş olamaz.");

            _filePath = filePath;
        }

        public bool FileExists()
        {
            return File.Exists(_filePath);
        }

        public bool ModelExists(string modelNo)
        {
            return GetModel(modelNo) != null;
        }

        public ProductConfiguration GetModel(string modelNo)
        {
            if (string.IsNullOrWhiteSpace(modelNo))
                return null;

            EnsureFileExists();
            string searchModelNo = Normalize(modelNo);

            using (XLWorkbook workbook = new XLWorkbook(_filePath))
            {
                IXLWorksheet worksheet = GetMainWorksheet(workbook);
                IXLRow lastUsedRow = worksheet.LastRowUsed();

                if (lastUsedRow == null)
                    return null;

                int lastRowNumber = lastUsedRow.RowNumber();

                for (int row = 3; row <= lastRowNumber; row++)
                {
                    string excelModelNo = Normalize(GetCellText(worksheet.Cell(row, 1)));

                    if (string.IsNullOrWhiteSpace(excelModelNo))
                        continue;

                    if (excelModelNo == searchModelNo)
                        return ReadModelFromRow(worksheet, row);
                }
            }

            return null;
        }

        public List<ProductConfiguration> GetAllModels()
        {
            EnsureFileExists();
            List<ProductConfiguration> models = new List<ProductConfiguration>();

            using (XLWorkbook workbook = new XLWorkbook(_filePath))
            {
                IXLWorksheet worksheet = GetMainWorksheet(workbook);
                IXLRow lastUsedRow = worksheet.LastRowUsed();

                if (lastUsedRow == null)
                    return models;

                int lastRowNumber = lastUsedRow.RowNumber();

                for (int row = 3; row <= lastRowNumber; row++)
                {
                    string modelNo = Normalize(GetCellText(worksheet.Cell(row, 1)));

                    if (string.IsNullOrWhiteSpace(modelNo))
                        continue;

                    models.Add(ReadModelFromRow(worksheet, row));
                }
            }

            return models;
        }

        public List<ProductConfiguration> GetCataFanAssistedModels()
        {
            return GetAllModels()
                .Where(x =>
                    NormalizeForComparison(x.CataPyro).Contains("cata") &&
                    IsFanAssisted(x.ModelType))
                .ToList();
        }

        public void AddOrUpdateModel(ProductConfiguration model)
        {
            if (model == null)
                throw new ArgumentNullException("model");

            if (string.IsNullOrWhiteSpace(model.ModelNo))
                throw new ArgumentException("Model numarası boş olamaz.");

            EnsureFileExists();

            try
            {
                using (XLWorkbook workbook = new XLWorkbook(_filePath))
                {
                    IXLWorksheet worksheet = GetMainWorksheet(workbook);
                    int targetRow = FindModelRow(worksheet, model.ModelNo);

                    if (targetRow <= 0)
                    {
                        IXLRow lastUsedRow = worksheet.LastRowUsed();
                        targetRow = lastUsedRow == null ? 3 : Math.Max(3, lastUsedRow.RowNumber() + 1);

                        if (targetRow > 3)
                        {
                            // Bir önceki satırın biçimini yeni satıra kopyala.
                            worksheet.Range(targetRow - 1, 1, targetRow - 1, 19)
                                .CopyTo(worksheet.Cell(targetRow, 1));

                            // Kopyalanan değerleri temizleyip sadece biçimi koruyoruz.
                            worksheet.Range(targetRow, 1, targetRow, 19)
                                .Clear(XLClearOptions.Contents);
                        }
                    }

                    WriteModelToRow(worksheet, targetRow, model);
                    workbook.Save();
                }
            }
            catch (IOException ex)
            {
                throw new IOException(
                    "MODEL_Config.xlsx kaydedilemedi. Dosya Excel'de açıksa kapatıp tekrar deneyin.",
                    ex);
            }
        }

        private int FindModelRow(IXLWorksheet worksheet, string modelNo)
        {
            string searchModelNo = Normalize(modelNo);
            IXLRow lastUsedRow = worksheet.LastRowUsed();

            if (lastUsedRow == null)
                return -1;

            for (int row = 3; row <= lastUsedRow.RowNumber(); row++)
            {
                string currentModelNo = Normalize(GetCellText(worksheet.Cell(row, 1)));

                if (currentModelNo == searchModelNo)
                    return row;
            }

            return -1;
        }

        private void WriteModelToRow(IXLWorksheet worksheet, int row, ProductConfiguration model)
        {
            worksheet.Cell(row, 1).Value = model.ModelNo ?? string.Empty;
            worksheet.Cell(row, 2).Value = model.CataPyro ?? string.Empty;
            worksheet.Cell(row, 3).Value = model.ModelType ?? string.Empty;
            worksheet.Cell(row, 4).Value = model.TimerType ?? string.Empty;
            worksheet.Cell(row, 5).Value = model.CehennemlikType ?? string.Empty;
            worksheet.Cell(row, 6).Value = model.TraversSnap ?? string.Empty;
            SetNullableInt(worksheet.Cell(row, 7), model.AstarCam);
            worksheet.Cell(row, 8).Value = model.Testaporta ?? string.Empty;
            worksheet.Cell(row, 9).Value = model.TcoBraket ?? string.Empty;
            SetNullableInt(worksheet.Cell(row, 10), model.Limitor);
            SetNullableInt(worksheet.Cell(row, 11), model.Tepsi);
            SetNullableInt(worksheet.Cell(row, 12), model.Izgara);
            worksheet.Cell(row, 13).Value = model.Airfry ?? string.Empty;
            worksheet.Cell(row, 14).Value = model.Ray ?? string.Empty;
            worksheet.Cell(row, 15).Value = model.FanCarton ?? string.Empty;
            worksheet.Cell(row, 16).Value = model.KapiEtiketi ?? string.Empty;
            SetNullableInt(worksheet.Cell(row, 17), model.CalisanSayisi);
            worksheet.Cell(row, 18).Value = model.Not ?? string.Empty;
            SetNullableInt(worksheet.Cell(row, 19), model.Tempo);
        }

        private void SetNullableInt(IXLCell cell, int? value)
        {
            if (value.HasValue)
                cell.Value = value.Value;
            else
                cell.Clear(XLClearOptions.Contents);
        }

        private ProductConfiguration ReadModelFromRow(IXLWorksheet worksheet, int row)
        {
            return new ProductConfiguration
            {
                ModelNo = CleanText(GetCellText(worksheet.Cell(row, 1))),
                CataPyro = CleanText(GetCellText(worksheet.Cell(row, 2))),
                ModelType = CleanText(GetCellText(worksheet.Cell(row, 3))),
                TimerType = CleanText(GetCellText(worksheet.Cell(row, 4))),
                CehennemlikType = CleanText(GetCellText(worksheet.Cell(row, 5))),
                TraversSnap = CleanText(GetCellText(worksheet.Cell(row, 6))),
                AstarCam = GetNullableInt(worksheet.Cell(row, 7)),
                Testaporta = CleanText(GetCellText(worksheet.Cell(row, 8))),
                TcoBraket = CleanText(GetCellText(worksheet.Cell(row, 9))),
                Limitor = GetNullableInt(worksheet.Cell(row, 10)),
                Tepsi = GetNullableInt(worksheet.Cell(row, 11)),
                Izgara = GetNullableInt(worksheet.Cell(row, 12)),
                Airfry = CleanText(GetCellText(worksheet.Cell(row, 13))),
                Ray = CleanText(GetCellText(worksheet.Cell(row, 14))),
                FanCarton = CleanText(GetCellText(worksheet.Cell(row, 15))),
                KapiEtiketi = CleanText(GetCellText(worksheet.Cell(row, 16))),
                CalisanSayisi = GetNullableInt(worksheet.Cell(row, 17)),
                Not = CleanText(GetCellText(worksheet.Cell(row, 18))),
                Tempo = GetNullableInt(worksheet.Cell(row, 19)),
                ExcelRowNumber = row
            };
        }

        private IXLWorksheet GetMainWorksheet(XLWorkbook workbook)
        {
            IXLWorksheet worksheet = workbook.Worksheets
                .FirstOrDefault(x =>
                    NormalizeForComparison(x.Name) == NormalizeForComparison(SheetName));

            if (worksheet == null)
                throw new Exception("'" + SheetName + "' isimli çalışma sayfası bulunamadı.");

            return worksheet;
        }

        private void EnsureFileExists()
        {
            if (!File.Exists(_filePath))
                throw new FileNotFoundException("MODEL_Config.xlsx dosyası bulunamadı.", _filePath);
        }

        private string GetCellText(IXLCell cell)
        {
            if (cell == null || cell.IsEmpty())
                return string.Empty;

            return cell.GetFormattedString();
        }

        private int? GetNullableInt(IXLCell cell)
        {
            if (cell == null || cell.IsEmpty())
                return null;

            XLCellValue cellValue;

            try
            {
                // Value evaluates formulas and preserves the underlying Excel type.
                cellValue = cell.Value;
            }
            catch (Exception ex)
            {
                throw new InvalidDataException(
                    "MODEL_Config.xlsx içindeki " + cell.Address +
                    " hücresinin değeri hesaplanamadı.", ex);
            }

            if (cellValue.Type == XLDataType.Error)
            {
                throw new InvalidDataException(
                    "MODEL_Config.xlsx içindeki " + cell.Address +
                    " hücresi Excel hatası içeriyor: " + cellValue.GetError() + ".");
            }

            double numericValue;

            if (cellValue.Type == XLDataType.Number)
            {
                numericValue = cellValue.GetNumber();
            }
            else if (cellValue.Type == XLDataType.Text)
            {
                string text = cellValue.GetText().Trim();

                if (string.IsNullOrWhiteSpace(text))
                    return null;

                // Float accepts decimals and exponents, but never thousands separators.
                const NumberStyles styles = NumberStyles.Float;

                if (!double.TryParse(text, styles, CultureInfo.InvariantCulture, out numericValue) &&
                    !double.TryParse(text, styles, CultureInfo.GetCultureInfo("tr-TR"), out numericValue))
                {
                    return null;
                }
            }
            else
            {
                return null;
            }

            if (double.IsNaN(numericValue) || double.IsInfinity(numericValue))
            {
                throw new InvalidDataException(
                    "MODEL_Config.xlsx içindeki " + cell.Address +
                    " hücresi sonlu bir sayı içermelidir.");
            }

            // Keep Convert.ToInt32's midpoint-to-even rounding, including boundary values.
            double roundedValue = Math.Round(numericValue, 0, MidpointRounding.ToEven);

            if (roundedValue < int.MinValue || roundedValue > int.MaxValue)
            {
                throw new InvalidDataException(
                    "MODEL_Config.xlsx içindeki " + cell.Address +
                    " hücresinin değeri tam sayı aralığını aşıyor.");
            }

            return Convert.ToInt32(numericValue);
        }

        private string CleanText(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }

        private string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }

        private string NormalizeForComparison(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            return value
                .Trim()
                .ToLowerInvariant()
                .Replace("ı", "i")
                .Replace("İ", "i")
                .Replace("ş", "s")
                .Replace("Ş", "s")
                .Replace("ğ", "g")
                .Replace("Ğ", "g")
                .Replace("ü", "u")
                .Replace("Ü", "u")
                .Replace("ö", "o")
                .Replace("Ö", "o")
                .Replace("ç", "c")
                .Replace("Ç", "c");
        }

        private bool IsFanAssisted(string value)
        {
            string normalized = NormalizeForComparison(value);
            return normalized.Contains("fan asisted") || normalized.Contains("fan assisted");
        }
    }
}
