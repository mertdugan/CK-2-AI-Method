﻿using System;

namespace CK2_AI_Metod.Core.Models
{
    public class AIEngineResult
    {
        public bool Success { get; set; }

        public int ExitCode { get; set; }

        public string Output { get; set; }

        public string Error { get; set; }

        public string OutputFile { get; set; }

        public string EnginePath { get; set; }

        public string DisplayMessage
        {
            get
            {
                if (Success)
                {
                    if (!string.IsNullOrWhiteSpace(Output))
                        return Output.Trim();

                    return "İşlem başarıyla tamamlandı.";
                }

                if (!string.IsNullOrWhiteSpace(Error))
                    return Error.Trim();

                if (!string.IsNullOrWhiteSpace(Output))
                    return Output.Trim();

                return "AI Engine işlemi başarısız oldu.";
            }
        }
    }
}
