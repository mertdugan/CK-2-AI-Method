﻿using System;
using System.Collections.Generic;

namespace CK2_AI_Metod.Core.Models
{
    public class MethodOperation
    {
        public string ModelNo { get; set; }

        public string SourceFile { get; set; }

        public string SheetName { get; set; }

        public string StationName { get; set; }

        public string StationType { get; set; }

        public int StationSequence { get; set; }

        public int? StationNumber { get; set; }

        public int StationOperationSequence { get; set; }

        public int OperationSequence { get; set; }

        public int ExcelRow { get; set; }

        public string OperationText { get; set; }

        public string Component { get; set; }

        public double? OperationTimeSeconds { get; set; }
    }

    public class MethodStation
    {
        public string ModelNo { get; set; }

        public string SourceFile { get; set; }

        public string SheetName { get; set; }

        public string StationName { get; set; }

        public string StationType { get; set; }

        public int StationSequence { get; set; }

        public int? StationNumber { get; set; }

        public int HeaderRow { get; set; }

        public int? FormulaStartRow { get; set; }

        public int? FormulaEndRow { get; set; }

        public string ExcelFormula { get; set; }

        public double? ExcelStationCycleTimeSeconds { get; set; }

        public double RecalculatedStationCycleTimeSeconds { get; set; }

        public double EffectiveStationCycleTimeSeconds { get; set; }

        public int OperationCount { get; set; }

        public int TimedOperationCount { get; set; }

        public string Warning { get; set; }
    }

    public class MethodParseResult
    {
        public MethodParseResult()
        {
            Operations = new List<MethodOperation>();
            Stations = new List<MethodStation>();
            Warnings = new List<string>();
        }

        public bool Success { get; set; }

        public string ErrorMessage { get; set; }

        public string ModelNo { get; set; }

        public string SourceFile { get; set; }

        public string SheetName { get; set; }

        public List<MethodOperation> Operations { get; set; }

        public List<MethodStation> Stations { get; set; }

        public List<string> Warnings { get; set; }
    }
}
