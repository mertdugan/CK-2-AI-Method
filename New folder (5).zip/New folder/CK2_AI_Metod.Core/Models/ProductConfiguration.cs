﻿namespace CK2_AI_Metod.Core.Models
{
    public class ProductConfiguration
    {
        public string ModelNo { get; set; }

        public string CataPyro { get; set; }

        public string ModelType { get; set; }

        public string TimerType { get; set; }

        public string CehennemlikType { get; set; }

        public string TraversSnap { get; set; }

        public int? AstarCam { get; set; }

        public string Testaporta { get; set; }

        public string TcoBraket { get; set; }

        public int? Limitor { get; set; }

        public int? Tepsi { get; set; }

        public int? Izgara { get; set; }

        public string Airfry { get; set; }

        public string Ray { get; set; }

        public string FanCarton { get; set; }

        public string KapiEtiketi { get; set; }

        public int? CalisanSayisi { get; set; }

        public string Not { get; set; }

        // MODEL_Config.xlsx dosyasında S sütunu.
        // Başlığı boş ancak bu değer 08:00-18:00 hedef üretim temposudur.
        public int? Tempo { get; set; }

        // Excel'de bulunduğu satır.
        // Daha sonra güncelleme yaparken işimize yarayacak.
        public int ExcelRowNumber { get; set; }
    }
}