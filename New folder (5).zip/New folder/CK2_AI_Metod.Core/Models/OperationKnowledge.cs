﻿using System;

namespace CK2_AI_Metod.Core.Models
{
    public class OperationLibraryItem
    {
        public string OperationId { get; set; }

        public string NormalizedOperationText { get; set; }

        public string ExampleOperationText { get; set; }

        public int OccurrenceCount { get; set; }

        public int ModelCount { get; set; }

        public int TimedOccurrenceCount { get; set; }

        public double? AverageTimeSeconds { get; set; }

        public double? MinTimeSeconds { get; set; }

        public double? MaxTimeSeconds { get; set; }

        public string DominantStationType { get; set; }

        public string StationTypes { get; set; }

        public double AverageProcessRelativePosition { get; set; }

        public double AverageStationRelativePosition { get; set; }
    }

    public class OperationSequenceFeature
    {
        public string ModelNo { get; set; }

        public string SourceFile { get; set; }

        public string OperationId { get; set; }

        public string OperationText { get; set; }

        public double? OperationTimeSeconds { get; set; }

        public string StationName { get; set; }

        public string StationType { get; set; }

        public int StationSequence { get; set; }

        public int? StationNumber { get; set; }

        public int OperationSequence { get; set; }

        public int StationOperationSequence { get; set; }

        public double ProcessRelativePosition { get; set; }

        public double StationRelativePosition { get; set; }

        public string PreviousOperationId { get; set; }

        public string NextOperationId { get; set; }

        public string PreviousSameStationOperationId { get; set; }

        public string NextSameStationOperationId { get; set; }

        public bool IsFirstOperationOfStation { get; set; }

        public bool IsLastOperationOfStation { get; set; }
    }

    public class OperationRelationship
    {
        public string OperationAId { get; set; }

        public string OperationBId { get; set; }

        public int CoOccurrenceModelCount { get; set; }

        public int ABeforeBModelCount { get; set; }

        public int BBeforeAModelCount { get; set; }

        public int MixedOrderModelCount { get; set; }

        public int SameStationModelCount { get; set; }

        public int AdjacentStationModelCount { get; set; }

        public int ADirectlyBeforeBOccurrenceCount { get; set; }

        public int BDirectlyBeforeAOccurrenceCount { get; set; }

        public double ABeforeBConfidence { get; set; }

        public double BBeforeAConfidence { get; set; }

        public string PreferredDirection { get; set; }
    }

    public class OperationStationPreference
    {
        public string OperationId { get; set; }

        public string StationType { get; set; }

        public int OccurrenceCount { get; set; }

        public int ModelCount { get; set; }

        public double AverageStationRelativePosition { get; set; }

        public double? AverageStationNumber { get; set; }

        public double? AverageTimeSeconds { get; set; }
    }

    public class OperationKnowledgeResult
    {
        public OperationKnowledgeResult()
        {
            Library = new System.Collections.Generic.List<OperationLibraryItem>();
            SequenceFeatures = new System.Collections.Generic.List<OperationSequenceFeature>();
            Relationships = new System.Collections.Generic.List<OperationRelationship>();
            StationPreferences = new System.Collections.Generic.List<OperationStationPreference>();
        }

        public System.Collections.Generic.List<OperationLibraryItem> Library { get; set; }

        public System.Collections.Generic.List<OperationSequenceFeature> SequenceFeatures { get; set; }

        public System.Collections.Generic.List<OperationRelationship> Relationships { get; set; }

        public System.Collections.Generic.List<OperationStationPreference> StationPreferences { get; set; }
    }
}
