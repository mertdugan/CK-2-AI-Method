﻿using System;

namespace CK2_AI_Metod.Core.Services
{
    public class CycleTimeService
    {
        public double Calculate(double workingHours, int targetProduction)
        {
            if (workingHours <= 0)
                throw new ArgumentException("Çalışma süresi 0'dan büyük olmalıdır.");

            if (targetProduction <= 0)
                throw new ArgumentException("Hedef üretim adedi 0'dan büyük olmalıdır.");

            double totalSeconds = workingHours * 3600.0;

            return totalSeconds / targetProduction;
        }
    }
}