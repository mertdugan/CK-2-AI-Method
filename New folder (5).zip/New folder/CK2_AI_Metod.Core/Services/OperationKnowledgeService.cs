﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using CK2_AI_Metod.Core.Models;

namespace CK2_AI_Metod.Core.Services
{
    public class OperationKnowledgeService
    {
        private class RelationshipAccumulator
        {
            public string OperationAId { get; set; }

            public string OperationBId { get; set; }

            public int CoOccurrenceModelCount { get; set; }

            public int ABeforeBModelCount { get; set; }

            public int BBeforeAModelCount { get; set; }

            public int MixedOrderModelCount { get; set; }

            public int SameStationModelCount { get; set; }

            public int AdjacentStationModelCount { get; set; }

            public int ADirectlyBeforeBOccurrenceCount { get; set; }

            public int BDirectlyBeforeAOccurrenceCount { get; set; }
        }

        public OperationKnowledgeResult Build(
            List<MethodOperation> operations,
            List<MethodStation> stations)
        {
            OperationKnowledgeResult result =
                new OperationKnowledgeResult();

            if (operations == null ||
                operations.Count == 0)
            {
                return result;
            }

            Dictionary<string, int> totalOperationsPerModel =
                operations
                    .GroupBy(x => x.ModelNo)
                    .ToDictionary(
                        g => g.Key,
                        g => g.Count());

            Dictionary<string, int> totalStationsPerModel =
                stations == null
                    ? new Dictionary<string, int>()
                    : stations
                        .GroupBy(x => x.ModelNo)
                        .ToDictionary(
                            g => g.Key,
                            g => g.Count());

            Dictionary<MethodOperation, string> operationIds =
                new Dictionary<MethodOperation, string>();

            foreach (MethodOperation operation in operations)
            {
                string normalized =
                    NormalizeOperationText(
                        operation.OperationText);

                string operationId =
                    CreateStableOperationId(
                        normalized);

                operationIds[operation] =
                    operationId;
            }

            result.Library =
                BuildLibrary(
                    operations,
                    operationIds,
                    totalOperationsPerModel,
                    totalStationsPerModel);

            result.SequenceFeatures =
                BuildSequenceFeatures(
                    operations,
                    operationIds,
                    totalOperationsPerModel,
                    totalStationsPerModel);

            result.Relationships =
                BuildRelationships(
                    operations,
                    operationIds);

            result.StationPreferences =
                BuildStationPreferences(
                    operations,
                    operationIds,
                    totalStationsPerModel);

            return result;
        }

        private List<OperationLibraryItem> BuildLibrary(
            List<MethodOperation> operations,
            Dictionary<MethodOperation, string> operationIds,
            Dictionary<string, int> totalOperationsPerModel,
            Dictionary<string, int> totalStationsPerModel)
        {
            List<OperationLibraryItem> items =
                new List<OperationLibraryItem>();

            var groups =
                operations
                    .GroupBy(
                        x =>
                            operationIds[x])
                    .OrderBy(
                        x =>
                            x.Key);

            foreach (var group in groups)
            {
                List<MethodOperation> groupOperations =
                    group.ToList();

                List<double> timedValues =
                    groupOperations
                        .Where(
                            x =>
                                x.OperationTimeSeconds.HasValue)
                        .Select(
                            x =>
                                x.OperationTimeSeconds.Value)
                        .ToList();

                string normalized =
                    NormalizeOperationText(
                        groupOperations[0]
                            .OperationText);

                string exampleText =
                    groupOperations
                        .GroupBy(
                            x =>
                                CleanRawText(
                                    x.OperationText))
                        .OrderByDescending(
                            g =>
                                g.Count())
                        .ThenBy(
                            g =>
                                g.Key)
                        .Select(
                            g =>
                                g.Key)
                        .FirstOrDefault();

                string dominantStationType =
                    groupOperations
                        .GroupBy(
                            x =>
                                string.IsNullOrWhiteSpace(
                                    x.StationType)
                                    ? "Unknown"
                                    : x.StationType)
                        .OrderByDescending(
                            g =>
                                g.Count())
                        .ThenBy(
                            g =>
                                g.Key)
                        .Select(
                            g =>
                                g.Key)
                        .FirstOrDefault();

                string stationTypes =
                    string.Join(
                        ", ",
                        groupOperations
                            .Select(
                                x =>
                                    string.IsNullOrWhiteSpace(
                                        x.StationType)
                                        ? "Unknown"
                                        : x.StationType)
                            .Distinct()
                            .OrderBy(
                                x =>
                                    x)
                            .ToArray());

                double averageProcessRelativePosition =
                    groupOperations
                        .Average(
                            x =>
                                CalculateRelativePosition(
                                    x.OperationSequence,
                                    GetDictionaryValue(
                                        totalOperationsPerModel,
                                        x.ModelNo)));

                double averageStationRelativePosition =
                    groupOperations
                        .Average(
                            x =>
                                CalculateRelativePosition(
                                    x.StationSequence,
                                    GetDictionaryValue(
                                        totalStationsPerModel,
                                        x.ModelNo)));

                OperationLibraryItem item =
                    new OperationLibraryItem();

                item.OperationId =
                    group.Key;

                item.NormalizedOperationText =
                    normalized;

                item.ExampleOperationText =
                    exampleText;

                item.OccurrenceCount =
                    groupOperations.Count;

                item.ModelCount =
                    groupOperations
                        .Select(
                            x =>
                                x.ModelNo)
                        .Distinct()
                        .Count();

                item.TimedOccurrenceCount =
                    timedValues.Count;

                if (timedValues.Count > 0)
                {
                    item.AverageTimeSeconds =
                        timedValues.Average();

                    item.MinTimeSeconds =
                        timedValues.Min();

                    item.MaxTimeSeconds =
                        timedValues.Max();
                }

                item.DominantStationType =
                    dominantStationType;

                item.StationTypes =
                    stationTypes;

                item.AverageProcessRelativePosition =
                    averageProcessRelativePosition;

                item.AverageStationRelativePosition =
                    averageStationRelativePosition;

                items.Add(item);
            }

            return items;
        }

        private List<OperationSequenceFeature> BuildSequenceFeatures(
            List<MethodOperation> operations,
            Dictionary<MethodOperation, string> operationIds,
            Dictionary<string, int> totalOperationsPerModel,
            Dictionary<string, int> totalStationsPerModel)
        {
            List<OperationSequenceFeature> features =
                new List<OperationSequenceFeature>();

            foreach (var modelGroup in
                operations
                    .GroupBy(
                        x =>
                            x.ModelNo)
                    .OrderBy(
                        x =>
                            x.Key))
            {
                List<MethodOperation> modelOperations =
                    modelGroup
                        .OrderBy(
                            x =>
                                x.OperationSequence)
                        .ThenBy(
                            x =>
                                x.ExcelRow)
                        .ToList();

                for (
                    int index = 0;
                    index < modelOperations.Count;
                    index++)
                {
                    MethodOperation current =
                        modelOperations[index];

                    MethodOperation previous =
                        index > 0
                            ? modelOperations[index - 1]
                            : null;

                    MethodOperation next =
                        index < modelOperations.Count - 1
                            ? modelOperations[index + 1]
                            : null;

                    List<MethodOperation> sameStationOperations =
                        modelOperations
                            .Where(
                                x =>
                                    x.StationSequence ==
                                    current.StationSequence)
                            .OrderBy(
                                x =>
                                    x.StationOperationSequence)
                            .ThenBy(
                                x =>
                                    x.ExcelRow)
                            .ToList();

                    int sameStationIndex =
                        sameStationOperations
                            .FindIndex(
                                x =>
                                    object.ReferenceEquals(
                                        x,
                                        current));

                    MethodOperation previousSameStation =
                        sameStationIndex > 0
                            ? sameStationOperations[
                                sameStationIndex - 1]
                            : null;

                    MethodOperation nextSameStation =
                        sameStationIndex >= 0 &&
                        sameStationIndex <
                        sameStationOperations.Count - 1
                            ? sameStationOperations[
                                sameStationIndex + 1]
                            : null;

                    OperationSequenceFeature feature =
                        new OperationSequenceFeature();

                    feature.ModelNo =
                        current.ModelNo;

                    feature.SourceFile =
                        current.SourceFile;

                    feature.OperationId =
                        operationIds[current];

                    feature.OperationText =
                        current.OperationText;

                    feature.OperationTimeSeconds =
                        current.OperationTimeSeconds;

                    feature.StationName =
                        current.StationName;

                    feature.StationType =
                        current.StationType;

                    feature.StationSequence =
                        current.StationSequence;

                    feature.StationNumber =
                        current.StationNumber;

                    feature.OperationSequence =
                        current.OperationSequence;

                    feature.StationOperationSequence =
                        current.StationOperationSequence;

                    feature.ProcessRelativePosition =
                        CalculateRelativePosition(
                            current.OperationSequence,
                            GetDictionaryValue(
                                totalOperationsPerModel,
                                current.ModelNo));

                    feature.StationRelativePosition =
                        CalculateRelativePosition(
                            current.StationSequence,
                            GetDictionaryValue(
                                totalStationsPerModel,
                                current.ModelNo));

                    feature.PreviousOperationId =
                        previous == null
                            ? string.Empty
                            : operationIds[previous];

                    feature.NextOperationId =
                        next == null
                            ? string.Empty
                            : operationIds[next];

                    feature.PreviousSameStationOperationId =
                        previousSameStation == null
                            ? string.Empty
                            : operationIds[
                                previousSameStation];

                    feature.NextSameStationOperationId =
                        nextSameStation == null
                            ? string.Empty
                            : operationIds[
                                nextSameStation];

                    feature.IsFirstOperationOfStation =
                        sameStationIndex == 0;

                    feature.IsLastOperationOfStation =
                        sameStationIndex ==
                        sameStationOperations.Count - 1;

                    features.Add(feature);
                }
            }

            return features;
        }

        private List<OperationRelationship> BuildRelationships(
            List<MethodOperation> operations,
            Dictionary<MethodOperation, string> operationIds)
        {
            Dictionary<string, RelationshipAccumulator> accumulators =
                new Dictionary<string, RelationshipAccumulator>();

            foreach (var modelGroup in
                operations
                    .GroupBy(
                        x =>
                            x.ModelNo))
            {
                List<MethodOperation> modelOperations =
                    modelGroup
                        .OrderBy(
                            x =>
                                x.OperationSequence)
                        .ThenBy(
                            x =>
                                x.ExcelRow)
                        .ToList();

                Dictionary<string, List<MethodOperation>> byOperationId =
                    modelOperations
                        .GroupBy(
                            x =>
                                operationIds[x])
                        .ToDictionary(
                            g =>
                                g.Key,
                            g =>
                                g.ToList());

                List<string> distinctIds =
                    byOperationId.Keys
                        .OrderBy(
                            x =>
                                x,
                            StringComparer.Ordinal)
                        .ToList();

                for (
                    int firstIndex = 0;
                    firstIndex < distinctIds.Count;
                    firstIndex++)
                {
                    for (
                        int secondIndex =
                            firstIndex + 1;
                        secondIndex <
                            distinctIds.Count;
                        secondIndex++)
                    {
                        string operationAId =
                            distinctIds[firstIndex];

                        string operationBId =
                            distinctIds[secondIndex];

                        string key =
                            operationAId +
                            "|" +
                            operationBId;

                        RelationshipAccumulator accumulator;

                        if (
                            !accumulators.TryGetValue(
                                key,
                                out accumulator))
                        {
                            accumulator =
                                new RelationshipAccumulator();

                            accumulator.OperationAId =
                                operationAId;

                            accumulator.OperationBId =
                                operationBId;

                            accumulators[key] =
                                accumulator;
                        }

                        accumulator.CoOccurrenceModelCount++;

                        List<MethodOperation> aOperations =
                            byOperationId[
                                operationAId];

                        List<MethodOperation> bOperations =
                            byOperationId[
                                operationBId];

                        int minA =
                            aOperations.Min(
                                x =>
                                    x.OperationSequence);

                        int maxA =
                            aOperations.Max(
                                x =>
                                    x.OperationSequence);

                        int minB =
                            bOperations.Min(
                                x =>
                                    x.OperationSequence);

                        int maxB =
                            bOperations.Max(
                                x =>
                                    x.OperationSequence);

                        if (maxA < minB)
                        {
                            accumulator.ABeforeBModelCount++;
                        }
                        else if (maxB < minA)
                        {
                            accumulator.BBeforeAModelCount++;
                        }
                        else
                        {
                            accumulator.MixedOrderModelCount++;
                        }

                        bool sameStation =
                            aOperations.Any(
                                a =>
                                    bOperations.Any(
                                        b =>
                                            a.StationSequence ==
                                            b.StationSequence));

                        if (sameStation)
                        {
                            accumulator.SameStationModelCount++;
                        }

                        bool adjacentStation =
                            aOperations.Any(
                                a =>
                                    bOperations.Any(
                                        b =>
                                            Math.Abs(
                                                a.StationSequence -
                                                b.StationSequence) == 1));

                        if (adjacentStation)
                        {
                            accumulator.AdjacentStationModelCount++;
                        }
                    }
                }

                for (
                    int index = 0;
                    index < modelOperations.Count - 1;
                    index++)
                {
                    string firstId =
                        operationIds[
                            modelOperations[index]];

                    string secondId =
                        operationIds[
                            modelOperations[index + 1]];

                    if (
                        string.Equals(
                            firstId,
                            secondId,
                            StringComparison.Ordinal))
                    {
                        continue;
                    }

                    string operationAId =
                        string.CompareOrdinal(
                            firstId,
                            secondId) < 0
                            ? firstId
                            : secondId;

                    string operationBId =
                        string.CompareOrdinal(
                            firstId,
                            secondId) < 0
                            ? secondId
                            : firstId;

                    string key =
                        operationAId +
                        "|" +
                        operationBId;

                    RelationshipAccumulator accumulator;

                    if (
                        !accumulators.TryGetValue(
                            key,
                            out accumulator))
                    {
                        accumulator =
                            new RelationshipAccumulator();

                        accumulator.OperationAId =
                            operationAId;

                        accumulator.OperationBId =
                            operationBId;

                        accumulators[key] =
                            accumulator;
                    }

                    if (
                        firstId ==
                        operationAId)
                    {
                        accumulator
                            .ADirectlyBeforeBOccurrenceCount++;
                    }
                    else
                    {
                        accumulator
                            .BDirectlyBeforeAOccurrenceCount++;
                    }
                }
            }

            List<OperationRelationship> relationships =
                new List<OperationRelationship>();

            foreach (
                RelationshipAccumulator accumulator
                in accumulators.Values
                    .OrderBy(
                        x =>
                            x.OperationAId)
                    .ThenBy(
                        x =>
                            x.OperationBId))
            {
                OperationRelationship relationship =
                    new OperationRelationship();

                relationship.OperationAId =
                    accumulator.OperationAId;

                relationship.OperationBId =
                    accumulator.OperationBId;

                relationship.CoOccurrenceModelCount =
                    accumulator.CoOccurrenceModelCount;

                relationship.ABeforeBModelCount =
                    accumulator.ABeforeBModelCount;

                relationship.BBeforeAModelCount =
                    accumulator.BBeforeAModelCount;

                relationship.MixedOrderModelCount =
                    accumulator.MixedOrderModelCount;

                relationship.SameStationModelCount =
                    accumulator.SameStationModelCount;

                relationship.AdjacentStationModelCount =
                    accumulator.AdjacentStationModelCount;

                relationship.ADirectlyBeforeBOccurrenceCount =
                    accumulator
                        .ADirectlyBeforeBOccurrenceCount;

                relationship.BDirectlyBeforeAOccurrenceCount =
                    accumulator
                        .BDirectlyBeforeAOccurrenceCount;

                int orderedModelCount =
                    accumulator.ABeforeBModelCount +
                    accumulator.BBeforeAModelCount +
                    accumulator.MixedOrderModelCount;

                if (orderedModelCount > 0)
                {
                    relationship.ABeforeBConfidence =
                        (double)
                        accumulator.ABeforeBModelCount /
                        orderedModelCount;

                    relationship.BBeforeAConfidence =
                        (double)
                        accumulator.BBeforeAModelCount /
                        orderedModelCount;
                }

                relationship.PreferredDirection =
                    GetPreferredDirection(
                        relationship);

                relationships.Add(
                    relationship);
            }

            return relationships;
        }

        private List<OperationStationPreference> BuildStationPreferences(
            List<MethodOperation> operations,
            Dictionary<MethodOperation, string> operationIds,
            Dictionary<string, int> totalStationsPerModel)
        {
            List<OperationStationPreference> result =
                new List<OperationStationPreference>();

            var groups =
                operations
                    .GroupBy(
                        x =>
                            operationIds[x] +
                            "|" +
                            (
                                string.IsNullOrWhiteSpace(
                                    x.StationType)
                                    ? "Unknown"
                                    : x.StationType))
                    .OrderBy(
                        x =>
                            x.Key);

            foreach (var group in groups)
            {
                List<MethodOperation> items =
                    group.ToList();

                List<double> stationNumbers =
                    items
                        .Where(
                            x =>
                                x.StationNumber.HasValue)
                        .Select(
                            x =>
                                (double)
                                x.StationNumber.Value)
                        .ToList();

                List<double> times =
                    items
                        .Where(
                            x =>
                                x.OperationTimeSeconds.HasValue)
                        .Select(
                            x =>
                                x.OperationTimeSeconds.Value)
                        .ToList();

                OperationStationPreference preference =
                    new OperationStationPreference();

                preference.OperationId =
                    operationIds[
                        items[0]];

                preference.StationType =
                    string.IsNullOrWhiteSpace(
                        items[0].StationType)
                        ? "Unknown"
                        : items[0].StationType;

                preference.OccurrenceCount =
                    items.Count;

                preference.ModelCount =
                    items
                        .Select(
                            x =>
                                x.ModelNo)
                        .Distinct()
                        .Count();

                preference.AverageStationRelativePosition =
                    items
                        .Average(
                            x =>
                                CalculateRelativePosition(
                                    x.StationSequence,
                                    GetDictionaryValue(
                                        totalStationsPerModel,
                                        x.ModelNo)));

                if (stationNumbers.Count > 0)
                {
                    preference.AverageStationNumber =
                        stationNumbers.Average();
                }

                if (times.Count > 0)
                {
                    preference.AverageTimeSeconds =
                        times.Average();
                }

                result.Add(
                    preference);
            }

            return result;
        }

        private string GetPreferredDirection(
            OperationRelationship relationship)
        {
            if (
                relationship.ABeforeBConfidence >= 0.80 &&
                relationship.ABeforeBModelCount >= 2)
            {
                return "A_BEFORE_B";
            }

            if (
                relationship.BBeforeAConfidence >= 0.80 &&
                relationship.BBeforeAModelCount >= 2)
            {
                return "B_BEFORE_A";
            }

            return "MIXED_OR_UNKNOWN";
        }

        private int GetDictionaryValue(
            Dictionary<string, int> dictionary,
            string key)
        {
            int value;

            if (
                dictionary != null &&
                !string.IsNullOrWhiteSpace(key) &&
                dictionary.TryGetValue(
                    key,
                    out value))
            {
                return value;
            }

            return 0;
        }

        private double CalculateRelativePosition(
            int currentPosition,
            int totalCount)
        {
            if (totalCount <= 1)
                return 0.0;

            return
                (double)
                (currentPosition - 1) /
                (double)
                (totalCount - 1);
        }

        public string NormalizeOperationText(
            string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            string text =
                value.Trim()
                    .ToUpperInvariant();

            StringBuilder builder =
                new StringBuilder();

            foreach (char character in text)
            {
                switch (character)
                {
                    case 'İ':
                    case 'I':
                    case 'ı':
                        builder.Append('I');
                        break;

                    case 'Ş':
                    case 'ş':
                        builder.Append('S');
                        break;

                    case 'Ğ':
                    case 'ğ':
                        builder.Append('G');
                        break;

                    case 'Ü':
                    case 'ü':
                        builder.Append('U');
                        break;

                    case 'Ö':
                    case 'ö':
                        builder.Append('O');
                        break;

                    case 'Ç':
                    case 'ç':
                        builder.Append('C');
                        break;

                    default:
                        if (
                            char.IsLetterOrDigit(
                                character) ||
                            char.IsWhiteSpace(
                                character))
                        {
                            builder.Append(
                                character);
                        }
                        else
                        {
                            builder.Append(' ');
                        }

                        break;
                }
            }

            string normalized =
                Regex.Replace(
                    builder.ToString(),
                    @"\s+",
                    " ");

            return normalized.Trim();
        }

        private string CreateStableOperationId(
            string normalizedText)
        {
            if (string.IsNullOrWhiteSpace(
                normalizedText))
            {
                return "OP_EMPTY";
            }

            using (SHA1 sha1 =
                SHA1.Create())
            {
                byte[] bytes =
                    Encoding.UTF8.GetBytes(
                        normalizedText);

                byte[] hash =
                    sha1.ComputeHash(
                        bytes);

                StringBuilder builder =
                    new StringBuilder();

                for (
                    int index = 0;
                    index < 5;
                    index++)
                {
                    builder.Append(
                        hash[index]
                            .ToString("X2"));
                }

                return
                    "OP_" +
                    builder.ToString();
            }
        }

        private string CleanRawText(
            string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            return value
                .Replace("\r", " ")
                .Replace("\n", " ")
                .Trim();
        }
    }
}
