﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using CK2_AI_Metod.Core.Models;

namespace CK2_AI_Metod.Core.Services
{
    public class AIEngineService
    {
        private readonly string _applicationStartupPath;

        public AIEngineService(
            string applicationStartupPath)
        {
            if (string.IsNullOrWhiteSpace(
                applicationStartupPath))
            {
                throw new ArgumentException(
                    "ApplicationStartupPath boş olamaz.");
            }

            _applicationStartupPath =
                applicationStartupPath;
        }

        public Task<AIEngineResult> TrainAsync(
            string datasetPath,
            string modelsRoot)
        {
            if (!File.Exists(datasetPath))
            {
                throw new FileNotFoundException(
                    "Training dataset bulunamadı.",
                    datasetPath);
            }

            Directory.CreateDirectory(
                modelsRoot);

            string arguments =
                "train" +
                " --dataset " +
                Quote(datasetPath) +
                " --models-root " +
                Quote(modelsRoot);

            return RunEngineAsync(
                arguments,
                null);
        }

        public Task<AIEngineResult> PredictAsync(
            string configPath,
            string modelNo,
            double workingHours,
            int targetQuantity,
            string modelsRoot,
            string outputPath)
        {
            return PredictAsync(
                configPath,
                modelNo,
                workingHours,
                targetQuantity,
                100.0,
                "auto",
                modelsRoot,
                outputPath);
        }

        public Task<AIEngineResult> PredictAsync(
            string configPath,
            string modelNo,
            double workingHours,
            int targetQuantity,
            double maxSaturationPercent,
            string modelsRoot,
            string outputPath)
        {
            return PredictAsync(
                configPath,
                modelNo,
                workingHours,
                targetQuantity,
                maxSaturationPercent,
                "auto",
                modelsRoot,
                outputPath);
        }

        public Task<AIEngineResult> PredictAsync(
            string configPath,
            string modelNo,
            double workingHours,
            int targetQuantity,
            double maxSaturationPercent,
            string balanceMode,
            string modelsRoot,
            string outputPath)
        {
            if (!File.Exists(configPath))
            {
                throw new FileNotFoundException(
                    "MODEL_Config.xlsx bulunamadı.",
                    configPath);
            }

            Directory.CreateDirectory(
                modelsRoot);

            string outputDirectory =
                Path.GetDirectoryName(
                    outputPath);

            if (
                !string.IsNullOrWhiteSpace(
                    outputDirectory))
            {
                Directory.CreateDirectory(
                    outputDirectory);
            }

            string arguments =
                "predict" +
                " --config " +
                Quote(configPath) +
                " --model " +
                Quote(modelNo) +
                " --hours " +
                workingHours.ToString(
                    "0.########",
                    CultureInfo.InvariantCulture) +
                " --target " +
                targetQuantity.ToString(
                    CultureInfo.InvariantCulture) +
                " --max-saturation " +
                maxSaturationPercent.ToString(
                    "0.###",
                    CultureInfo.InvariantCulture) +
                // Tek yapay zeka dengeleme yontemi. Eski balanceMode parametresi
                // API uyumlulugu icin korunur; algoritma artik mod secmez.
                " --models-root " +
                Quote(modelsRoot) +
                " --output " +
                Quote(outputPath);

            return RunEngineAsync(
                arguments,
                outputPath);
        }

        private Task<AIEngineResult> RunEngineAsync(
            string commandArguments,
            string outputFile)
        {
            return Task.Run(
                () =>
                    RunEngine(
                        commandArguments,
                        outputFile));
        }

        private AIEngineResult RunEngine(
            string commandArguments,
            string outputFile)
        {
            EngineLocation engine =
                FindEngine();

            if (engine == null)
            {
                return new AIEngineResult
                {
                    Success = false,
                    ExitCode = -1,
                    Error =
                        "CK2_AI_Metod.AI bulunamadı." +
                        Environment.NewLine +
                        Environment.NewLine +
                        "Solution içinde CK2_AI_Metod.AI projesinin " +
                        "CK2_AI_Metod.App ve CK2_AI_Metod.Core ile aynı seviyede " +
                        "olduğunu kontrol edin."
                };
            }

            if (
                !engine.IsExecutable &&
                (
                    string.IsNullOrWhiteSpace(
                        engine.PythonExecutable) ||
                    !File.Exists(
                        engine.PythonExecutable)
                ))
            {
                return new AIEngineResult
                {
                    Success = false,
                    ExitCode = -1,
                    Error =
                        "CK2_AI_Metod.AI Python environment bulunamadı." +
                        Environment.NewLine +
                        Environment.NewLine +
                        "Beklenen dosya:" +
                        Environment.NewLine +
                        Path.Combine(
                            engine.WorkingDirectory,
                            ".venv",
                            "Scripts",
                            "python.exe") +
                        Environment.NewLine +
                        Environment.NewLine +
                        "Visual Studio'da CK2_AI_Metod.AI projesi altında " +
                        "Python 3.10 x64 ile .venv oluşturun."
                };
            }

            ProcessStartInfo startInfo =
                new ProcessStartInfo();

            if (engine.IsExecutable)
            {
                startInfo.FileName =
                    engine.EnginePath;

                startInfo.Arguments =
                    commandArguments;
            }
            else
            {
                startInfo.FileName =
                    engine.PythonExecutable;

                startInfo.Arguments =
                    Quote(engine.EnginePath) +
                    " " +
                    commandArguments;
            }

            startInfo.WorkingDirectory =
                engine.WorkingDirectory;

            startInfo.UseShellExecute =
                false;

            startInfo.CreateNoWindow =
                true;

            startInfo.RedirectStandardOutput =
                true;

            startInfo.RedirectStandardError =
                true;

            startInfo.StandardOutputEncoding =
                Encoding.UTF8;

            startInfo.StandardErrorEncoding =
                Encoding.UTF8;

            StringBuilder output =
                new StringBuilder();

            StringBuilder error =
                new StringBuilder();

            try
            {
                using (
                    Process process =
                    new Process())
                {
                    process.StartInfo =
                        startInfo;

                    process.OutputDataReceived +=
                        delegate (
                            object sender,
                            DataReceivedEventArgs e)
                        {
                            if (
                                !string.IsNullOrWhiteSpace(
                                    e.Data))
                            {
                                output.AppendLine(
                                    e.Data);
                            }
                        };

                    process.ErrorDataReceived +=
                        delegate (
                            object sender,
                            DataReceivedEventArgs e)
                        {
                            if (
                                !string.IsNullOrWhiteSpace(
                                    e.Data))
                            {
                                error.AppendLine(
                                    e.Data);
                            }
                        };

                    process.Start();
                    process.BeginOutputReadLine();
                    process.BeginErrorReadLine();
                    process.WaitForExit();

                    return new AIEngineResult
                    {
                        Success =
                            process.ExitCode == 0,
                        ExitCode =
                            process.ExitCode,
                        Output =
                            output.ToString(),
                        Error =
                            error.ToString(),
                        OutputFile =
                            outputFile,
                        EnginePath =
                            engine.EnginePath
                    };
                }
            }
            catch (Exception ex)
            {
                return new AIEngineResult
                {
                    Success = false,
                    ExitCode = -1,
                    Output =
                        output.ToString(),
                    Error =
                        "AI Engine başlatılamadı." +
                        Environment.NewLine +
                        ex.Message +
                        Environment.NewLine +
                        Environment.NewLine +
                        "Kullanılan Python:" +
                        Environment.NewLine +
                        (
                            engine.IsExecutable
                                ? engine.EnginePath
                                : engine.PythonExecutable
                        ),
                    OutputFile =
                        outputFile,
                    EnginePath =
                        engine.EnginePath
                };
            }
        }

        private EngineLocation FindEngine()
        {
            // 1) Deployment senaryosu:
            // App klasörü altında AIEngine\CK2_AI_Metod_AI.exe
            string packagedFolder =
                Path.Combine(
                    _applicationStartupPath,
                    "AIEngine");

            string packagedExe =
                Path.Combine(
                    packagedFolder,
                    "CK2_AI_Metod_AI.exe");

            if (File.Exists(packagedExe))
            {
                return new EngineLocation
                {
                    EnginePath =
                        packagedExe,
                    WorkingDirectory =
                        packagedFolder,
                    PythonExecutable =
                        null,
                    IsExecutable =
                        true
                };
            }

            // 2) Development senaryosu:
            // Solution içinde CK2_AI_Metod.AI klasörünü bul.
            DirectoryInfo current =
                new DirectoryInfo(
                    _applicationStartupPath);

            for (
                int level = 0;
                level < 10 &&
                current != null;
                level++)
            {
                string projectFolder =
                    Path.Combine(
                        current.FullName,
                        "CK2_AI_Metod.AI");

                string mainPy =
                    Path.Combine(
                        projectFolder,
                        "main.py");

                string venvPython =
                    Path.Combine(
                        projectFolder,
                        ".venv",
                        "Scripts",
                        "python.exe");

                if (File.Exists(mainPy))
                {
                    return new EngineLocation
                    {
                        EnginePath =
                            mainPy,
                        WorkingDirectory =
                            projectFolder,
                        PythonExecutable =
                            venvPython,
                        IsExecutable =
                            false
                    };
                }

                current =
                    current.Parent;
            }

            // 3) Alternatif development:
            // App output altına AIEngine klasörü kopyalanmış olabilir.
            string packagedPython =
                Path.Combine(
                    packagedFolder,
                    "main.py");

            string packagedVenvPython =
                Path.Combine(
                    packagedFolder,
                    ".venv",
                    "Scripts",
                    "python.exe");

            if (File.Exists(packagedPython))
            {
                return new EngineLocation
                {
                    EnginePath =
                        packagedPython,
                    WorkingDirectory =
                        packagedFolder,
                    PythonExecutable =
                        packagedVenvPython,
                    IsExecutable =
                        false
                };
            }

            return null;
        }

        private string Quote(
            string value)
        {
            if (value == null)
                return "\"\"";

            return
                "\"" +
                value.Replace(
                    "\"",
                    "\\\"") +
                "\"";
        }

        private class EngineLocation
        {
            public string EnginePath { get; set; }

            public string WorkingDirectory { get; set; }

            public string PythonExecutable { get; set; }

            public bool IsExecutable { get; set; }
        }
    }
}
