﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using ClosedXML.Excel;
using CK2_AI_Metod.Core.Models;

namespace CK2_AI_Metod.Core.Services
{
    public class MethodParser
    {
        private static readonly Regex ModelNoRegex =
            new Regex(@"(?<!\d)(\d{8})(?!\d)", RegexOptions.Compiled);

        private static readonly Regex MainStationRegex =
            new Regex(
                @"^\d+\s*\.\s*ISTASYON$",
                RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        private static readonly Regex TestStationRegex =
            new Regex(
                @"^TEST\s+ISTASYONU?\s*\d+$",
                RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        private static readonly Regex VisualStationRegex =
            new Regex(
                @"^GORSEL\s+ISTASYON\s*\d+$",
                RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        private static readonly Regex DoorStationRegex =
            new Regex(
                @"^KAPI\s+HAZIRLIK\s*\d+$",
                RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        private static readonly Regex NumberRegex =
            new Regex(@"\d+", RegexOptions.Compiled);

        private static readonly Regex SumRangeRegex =
            new Regex(
                @"^SUM\s*\(\s*\$?B\$?(\d+)\s*:\s*\$?B\$?(\d+)\s*\)$",
                RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

        private class StationContext
        {
            public MethodStation Station { get; set; }

            public List<MethodOperation> Operations { get; set; }

            public StationContext()
            {
                Operations = new List<MethodOperation>();
            }
        }

        public MethodParseResult ParseFile(string filePath)
        {
            MethodParseResult result =
                new MethodParseResult();

            result.SourceFile =
                Path.GetFileName(filePath);

            try
            {
                if (string.IsNullOrWhiteSpace(filePath))
                    throw new ArgumentException(
                        "Metod Excel dosya yolu boş olamaz.");

                if (!File.Exists(filePath))
                    throw new FileNotFoundException(
                        "Metod Excel dosyası bulunamadı.",
                        filePath);

                string modelNo =
                    ExtractModelNoFromFileName(filePath);

                using (XLWorkbook workbook =
                    new XLWorkbook(filePath))
                {
                    IXLWorksheet worksheet =
                        SelectMethodWorksheet(
                            workbook,
                            modelNo);

                    if (worksheet == null)
                    {
                        throw new Exception(
                            "Metod sayfası bulunamadı.");
                    }

                    if (string.IsNullOrWhiteSpace(modelNo))
                    {
                        modelNo =
                            ExtractModelNoFromWorksheet(
                                worksheet);
                    }

                    if (string.IsNullOrWhiteSpace(modelNo))
                    {
                        throw new Exception(
                            "Model numarası dosya adı veya Excel içinden bulunamadı.");
                    }

                    result.ModelNo = modelNo;
                    result.SheetName = worksheet.Name;

                    ParseWorksheet(
                        worksheet,
                        result);

                    result.Success = true;
                }
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
            }

            return result;
        }

        private void ParseWorksheet(
            IXLWorksheet worksheet,
            MethodParseResult result)
        {
            IXLRow lastUsedRow =
                worksheet.LastRowUsed();

            if (lastUsedRow == null)
                return;

            int lastRow =
                lastUsedRow.RowNumber();

            StationContext currentStation = null;

            int stationSequence = 0;
            int operationSequence = 0;

            for (int row = 2;
                row <= lastRow;
                row++)
            {
                IXLCell operationCell =
                    worksheet.Cell(row, 1);

                IXLCell timeCell =
                    worksheet.Cell(row, 2);

                IXLCell componentCell =
                    worksheet.Cell(row, 3);

                string text =
                    GetCellText(operationCell);

                if (string.IsNullOrWhiteSpace(text))
                    continue;

                if (IsStationHeader(text))
                {
                    if (currentStation != null)
                    {
                        FinalizeStation(
                            worksheet,
                            currentStation,
                            row,
                            result);
                    }

                    stationSequence++;

                    currentStation =
                        CreateStationContext(
                            worksheet,
                            result,
                            text,
                            timeCell,
                            row,
                            stationSequence);

                    continue;
                }

                if (currentStation == null)
                    continue;

                operationSequence++;

                MethodOperation operation =
                    new MethodOperation();

                operation.ModelNo =
                    result.ModelNo;

                operation.SourceFile =
                    result.SourceFile;

                operation.SheetName =
                    result.SheetName;

                operation.StationName =
                    currentStation.Station.StationName;

                operation.StationType =
                    currentStation.Station.StationType;

                operation.StationSequence =
                    currentStation.Station.StationSequence;

                operation.StationNumber =
                    currentStation.Station.StationNumber;

                operation.StationOperationSequence =
                    currentStation.Operations.Count + 1;

                operation.OperationSequence =
                    operationSequence;

                operation.ExcelRow =
                    row;

                operation.OperationText =
                    CleanText(text);

                operation.Component =
                    CleanText(
                        GetCellText(
                            componentCell));

                operation.OperationTimeSeconds =
                    EvaluateNumericCell(
                        worksheet,
                        timeCell,
                        new HashSet<string>());

                currentStation.Operations.Add(
                    operation);

                result.Operations.Add(
                    operation);
            }

            if (currentStation != null)
            {
                FinalizeStation(
                    worksheet,
                    currentStation,
                    lastRow + 1,
                    result);
            }
        }

        private StationContext CreateStationContext(
            IXLWorksheet worksheet,
            MethodParseResult result,
            string stationText,
            IXLCell timeCell,
            int headerRow,
            int stationSequence)
        {
            StationContext context =
                new StationContext();

            MethodStation station =
                new MethodStation();

            station.ModelNo =
                result.ModelNo;

            station.SourceFile =
                result.SourceFile;

            station.SheetName =
                result.SheetName;

            station.StationName =
                CleanText(stationText);

            station.StationType =
                GetStationType(
                    stationText);

            station.StationSequence =
                stationSequence;

            station.StationNumber =
                ExtractStationNumber(
                    stationText);

            station.HeaderRow =
                headerRow;

            station.ExcelFormula =
                GetFormula(
                    timeCell);

            int formulaStartRow;
            int formulaEndRow;

            if (TryGetFormulaRange(
                station.ExcelFormula,
                out formulaStartRow,
                out formulaEndRow))
            {
                station.FormulaStartRow =
                    formulaStartRow;

                station.FormulaEndRow =
                    formulaEndRow;
            }

            station.ExcelStationCycleTimeSeconds =
                EvaluateNumericCell(
                    worksheet,
                    timeCell,
                    new HashSet<string>());

            context.Station =
                station;

            return context;
        }

        private void FinalizeStation(
            IXLWorksheet worksheet,
            StationContext context,
            int nextHeaderRow,
            MethodParseResult result)
        {
            MethodStation station =
                context.Station;

            station.OperationCount =
                context.Operations.Count;

            station.TimedOperationCount =
                context.Operations.Count(
                    x => x.OperationTimeSeconds.HasValue);

            station.RecalculatedStationCycleTimeSeconds =
                context.Operations
                    .Where(
                        x =>
                            x.OperationTimeSeconds.HasValue)
                    .Sum(
                        x =>
                            x.OperationTimeSeconds.Value);

            if (station.TimedOperationCount > 0)
            {
                station.EffectiveStationCycleTimeSeconds =
                    station.RecalculatedStationCycleTimeSeconds;
            }
            else if (
                station.ExcelStationCycleTimeSeconds.HasValue)
            {
                station.EffectiveStationCycleTimeSeconds =
                    station.ExcelStationCycleTimeSeconds.Value;
            }
            else
            {
                station.EffectiveStationCycleTimeSeconds =
                    0.0;
            }

            List<string> warnings =
                new List<string>();

            if (
                station.FormulaStartRow.HasValue &&
                station.FormulaEndRow.HasValue)
            {
                if (
                    context.Operations.Count > 0)
                {
                    int firstOperationRow =
                        context.Operations
                            .Min(x => x.ExcelRow);

                    int lastOperationRow =
                        context.Operations
                            .Max(x => x.ExcelRow);

                    if (
                        station.FormulaStartRow.Value >
                        firstOperationRow)
                    {
                        warnings.Add(
                            "Excel SUM formülü istasyonun ilk operasyonlarını kapsamıyor.");
                    }

                    if (
                        station.FormulaEndRow.Value <
                        lastOperationRow)
                    {
                        warnings.Add(
                            "Excel SUM formülü istasyonun son operasyonlarını kapsamıyor.");
                    }
                }

                if (
                    station.FormulaEndRow.Value >=
                    nextHeaderRow)
                {
                    warnings.Add(
                        "Excel SUM formülü sonraki istasyon satırlarına taşıyor.");
                }
            }

            if (
                station.TimedOperationCount > 0 &&
                station.ExcelStationCycleTimeSeconds.HasValue)
            {
                double difference =
                    Math.Abs(
                        station.ExcelStationCycleTimeSeconds.Value -
                        station.RecalculatedStationCycleTimeSeconds);

                if (difference > 0.01)
                {
                    warnings.Add(
                        "Excel istasyon toplamı ile operasyonlardan yeniden hesaplanan toplam farklı. " +
                        "Excel=" +
                        station.ExcelStationCycleTimeSeconds.Value.ToString(
                            "0.###",
                            CultureInfo.InvariantCulture) +
                        " sn, YenidenHesap=" +
                        station.RecalculatedStationCycleTimeSeconds.ToString(
                            "0.###",
                            CultureInfo.InvariantCulture) +
                        " sn.");
                }
            }

            station.Warning =
                string.Join(
                    " | ",
                    warnings.ToArray());

            if (warnings.Count > 0)
            {
                foreach (
                    string warning
                    in warnings)
                {
                    result.Warnings.Add(
                        station.StationName +
                        ": " +
                        warning);
                }
            }

            result.Stations.Add(
                station);
        }

        private bool IsStationHeader(string text)
        {
            string normalized =
                NormalizeText(text);

            if (
                MainStationRegex.IsMatch(
                    normalized))
            {
                return true;
            }

            if (
                TestStationRegex.IsMatch(
                    normalized))
            {
                return true;
            }

            if (
                VisualStationRegex.IsMatch(
                    normalized))
            {
                return true;
            }

            if (
                DoorStationRegex.IsMatch(
                    normalized))
            {
                return true;
            }

            return false;
        }

        private string GetStationType(
            string stationName)
        {
            string normalized =
                NormalizeText(
                    stationName);

            if (
                normalized.StartsWith(
                    "KAPI HAZIRLIK"))
            {
                return "DoorPreparation";
            }

            if (
                normalized.StartsWith(
                    "TEST ISTASYON"))
            {
                return "Test";
            }

            if (
                normalized.StartsWith(
                    "GORSEL ISTASYON"))
            {
                return "Visual";
            }

            return "Main";
        }

        private int? ExtractStationNumber(
            string stationName)
        {
            string normalized =
                NormalizeText(
                    stationName);

            Match match =
                NumberRegex.Match(
                    normalized);

            if (!match.Success)
                return null;

            int value;

            if (
                int.TryParse(
                    match.Value,
                    out value))
            {
                return value;
            }

            return null;
        }

        private string ExtractModelNoFromFileName(
            string filePath)
        {
            string fileName =
                Path.GetFileNameWithoutExtension(
                    filePath);

            Match match =
                ModelNoRegex.Match(
                    fileName);

            if (match.Success)
                return match.Groups[1].Value;

            return string.Empty;
        }

        private string ExtractModelNoFromWorksheet(
            IXLWorksheet worksheet)
        {
            string firstCell =
                GetCellText(
                    worksheet.Cell(1, 1));

            Match match =
                ModelNoRegex.Match(
                    firstCell);

            if (match.Success)
                return match.Groups[1].Value;

            return string.Empty;
        }

        private IXLWorksheet SelectMethodWorksheet(
            XLWorkbook workbook,
            string modelNo)
        {
            if (
                !string.IsNullOrWhiteSpace(
                    modelNo))
            {
                IXLWorksheet exact =
                    workbook.Worksheets
                        .FirstOrDefault(
                            x =>
                                string.Equals(
                                    x.Name.Trim(),
                                    modelNo,
                                    StringComparison
                                        .CurrentCultureIgnoreCase));

                if (exact != null)
                    return exact;
            }

            IXLWorksheet nonGraph =
                workbook.Worksheets
                    .FirstOrDefault(
                        x =>
                            !NormalizeText(
                                x.Name)
                                .Contains("GRF"));

            if (nonGraph != null)
                return nonGraph;

            return workbook.Worksheets
                .FirstOrDefault();
        }

        private string GetFormula(
            IXLCell cell)
        {
            if (
                cell == null ||
                !cell.HasFormula)
            {
                return string.Empty;
            }

            string formula =
                cell.FormulaA1;

            if (string.IsNullOrWhiteSpace(
                formula))
            {
                return string.Empty;
            }

            return formula.Trim();
        }

        private bool TryGetFormulaRange(
            string formula,
            out int startRow,
            out int endRow)
        {
            startRow = 0;
            endRow = 0;

            if (string.IsNullOrWhiteSpace(
                formula))
            {
                return false;
            }

            string cleanFormula =
                formula.Trim();

            if (
                cleanFormula.StartsWith("="))
            {
                cleanFormula =
                    cleanFormula.Substring(1);
            }

            Match match =
                SumRangeRegex.Match(
                    cleanFormula);

            if (!match.Success)
                return false;

            if (
                !int.TryParse(
                    match.Groups[1].Value,
                    out startRow))
            {
                return false;
            }

            if (
                !int.TryParse(
                    match.Groups[2].Value,
                    out endRow))
            {
                return false;
            }

            return true;
        }

        private double? EvaluateNumericCell(
            IXLWorksheet worksheet,
            IXLCell cell,
            HashSet<string> stack)
        {
            if (
                cell == null ||
                cell.IsEmpty())
            {
                return null;
            }

            string address =
                cell.Address.ToString();

            if (stack.Contains(address))
                throw new InvalidDataException(
                    "Döngüsel süre formülü: " + worksheet.Name + "!" + address);

            if (!cell.HasFormula)
                return GetDirectNumericValue(cell);

            string formula =
                GetFormula(cell);

            int startRow;
            int endRow;

            stack.Add(address);
            try
            {
                // Preserve existing SUM handling for the method templates.
                // Only an entire SUM expression qualifies; SUM(...)/2 must
                // be evaluated as a whole by ClosedXML.
                if (TryGetFormulaRange(formula, out startRow, out endRow))
                {
                    double total = 0.0;
                    for (int row = Math.Min(startRow, endRow);
                        row <= Math.Max(startRow, endRow);
                        row++)
                    {
                        double? childValue = EvaluateNumericCell(
                            worksheet, worksheet.Cell(row, 2), stack);
                        if (childValue.HasValue)
                            total += childValue.Value;
                    }
                    return RequireFiniteNumber(total, cell);
                }

                XLCellValue calculated = cell.Value;
                if (calculated.Type == XLDataType.Number)
                    return RequireFiniteNumber(calculated.GetNumber(), cell);

                if (calculated.Type == XLDataType.Blank)
                    return null;

                double value;
                if (calculated.Type == XLDataType.Text)
                {
                    string text = calculated.GetText();
                    if (string.IsNullOrWhiteSpace(text))
                        return null;
                    if (TryParseNumericText(text, out value))
                        return RequireFiniteNumber(value, cell);
                }

                throw new InvalidDataException(
                    "Formül sayısal bir süre üretmedi.");
            }
            catch (Exception ex)
            {
                throw new InvalidDataException(
                    "Süre formülü hesaplanamadı: " + worksheet.Name +
                    "!" + address + " = " + formula + ". " + ex.Message, ex);
            }
            finally
            {
                stack.Remove(address);
            }
        }

        private double? GetDirectNumericValue(
            IXLCell cell)
        {
            if (
                cell == null ||
                cell.IsEmpty() ||
                cell.HasFormula)
            {
                return null;
            }

            XLCellValue rawValue = cell.Value;
            if (rawValue.Type == XLDataType.Number)
                return RequireFiniteNumber(rawValue.GetNumber(), cell);

            double value;
            if (rawValue.Type == XLDataType.Text &&
                TryParseNumericText(rawValue.GetText(), out value))
                return RequireFiniteNumber(value, cell);

            if (rawValue.Type == XLDataType.Error)
                throw new InvalidDataException(
                    "Süre hücresinde Excel hatası var: " +
                    cell.Worksheet.Name + "!" + cell.Address);

            return null;
        }

        private static bool TryParseNumericText(string text, out double value)
        {
            // Text durations accept decimal dots or commas, never grouping.
            // Genuine numeric cells never pass through this conversion.
            return double.TryParse(text, NumberStyles.Float,
                       CultureInfo.InvariantCulture, out value) ||
                   double.TryParse(text, NumberStyles.Float,
                       CultureInfo.GetCultureInfo("tr-TR"), out value);
        }

        private static double RequireFiniteNumber(double value, IXLCell cell)
        {
            if (double.IsNaN(value) || double.IsInfinity(value))
                throw new InvalidDataException(
                    "Geçersiz süre değeri: " +
                    cell.Worksheet.Name + "!" + cell.Address);
            return value;
        }

        private string GetCellText(
            IXLCell cell)
        {
            if (
                cell == null ||
                cell.IsEmpty())
            {
                return string.Empty;
            }

            return cell
                .GetFormattedString();
        }

        private string CleanText(
            string value)
        {
            if (string.IsNullOrWhiteSpace(
                value))
            {
                return string.Empty;
            }

            return value
                .Replace("\r", " ")
                .Replace("\n", " ")
                .Trim();
        }

        private string NormalizeText(
            string value)
        {
            if (string.IsNullOrWhiteSpace(
                value))
            {
                return string.Empty;
            }

            string text =
                value.Trim()
                    .ToUpperInvariant();

            StringBuilder builder =
                new StringBuilder();

            foreach (
                char character
                in text)
            {
                switch (character)
                {
                    case 'İ':
                    case 'I':
                    case 'ı':
                        builder.Append('I');
                        break;

                    case 'Ş':
                    case 'ş':
                        builder.Append('S');
                        break;

                    case 'Ğ':
                    case 'ğ':
                        builder.Append('G');
                        break;

                    case 'Ü':
                    case 'ü':
                        builder.Append('U');
                        break;

                    case 'Ö':
                    case 'ö':
                        builder.Append('O');
                        break;

                    case 'Ç':
                    case 'ç':
                        builder.Append('C');
                        break;

                    default:
                        builder.Append(character);
                        break;
                }
            }

            string normalized =
                builder.ToString();

            normalized =
                Regex.Replace(
                    normalized,
                    @"\s+",
                    " ");

            return normalized.Trim();
        }
    }
}
