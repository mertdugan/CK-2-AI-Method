# -*- coding: utf-8 -*-
"""CLI regression: trained layout selection, target-CT interpolation and safety.

Optional fixture environment: loaded from last prediction when available, but
this module's unit tests are self-contained and need no V021 model bundle.
"""
from pathlib import Path
import json
from collections import defaultdict
from tempo_layout_learning import learn_tempo_station_layout
from line_balancer import _preferred_physical_candidate_index,_ck2_ordered_min_personnel_dp


def test_mentor_selection():
    ops=[]
    hist=defaultdict(list)
    for i in range(25):
        key=f'COP_{i:04d}#1'
        ops.append({'CanonicalOperationId':f'COP_{i:04d}', 'OccurrenceIndex':1,
                    'CanonicalName':'saci al tak', 'PredictedStationType':'Main',
                    'PredictedTimeSeconds':2.0,
                    'PreferredPhysicalStationNumber':1+i//3,
                    'LearnedSameStationWithNextProbability':0.5})
        hist[key].append({'ModelNo':'33704194__T1330','StationType':'Main',
                          'StationSequence':1+i//2,'PhysicalStationNumber':1+i//2})
        if i<21:
            hist[key].append({'ModelNo':'33704217__T1065','StationType':'Main',
                              'StationSequence':1+i//4,'PhysicalStationNumber':1+i//4})
    candidates=[{'ModelNo':'33704194__T1330','Similarity':1.0,
                 'ConfigReferenceCycleTimeSeconds':24.02},
                {'ModelNo':'33704217__T1065','Similarity':0.91,
                 'ConfigReferenceCycleTimeSeconds':30.0}]
    before=[(x['PreferredPhysicalStationNumber'],x['LearnedSameStationWithNextProbability']) for x in ops]
    res=learn_tempo_station_layout(ops,30.0,candidates,hist)
    assert res['status']=='TEMPO_LAYOUT_TRANSFER_ACTIVE',res
    assert res['main_mentor_model']=='33704217__T1065',res
    assert res['matched_count']==25,res
    assert res['learned_pairs']==24,res
    assert ops[2]['TempoLayoutPreferredPhysicalStationNumber']<2,ops[2]
    assert ops[2]['LearnedSameStationWithNextProbability']>0.5,ops[2]
    # Target CT is a continuous input. It is not replaced with a selected tempo.
    test_mid=[dict(x) for x in ops]
    for x in test_mid:
        x.pop('TempoLayoutPreferredPhysicalStationNumber',None)
    middle=learn_tempo_station_layout(test_mid,27.0,candidates,hist)
    assert middle['predicted_ct']==27.0
    assert middle['mentors'][0]['model'] in {'33704194__T1330','33704217__T1065'}
    assert len(middle['mentors'])==2
    assert before[0][0]==1
    return res, middle


def test_safety():
    op={'CanonicalOperationId':'BARKOD', 'OccurrenceIndex':1,'PredictedStationType':'Main',
        'ForcedPhysicalStationNumber':1, 'IsPalletOrientationAnchor':False,
        'PredictedTimeSeconds':2, 'PreferredPhysicalStationNumber':1}
    hist={'BARKOD#1':[{'ModelNo':'33704217__T1065','StationType':'Main',
                       'StationSequence':12,'PhysicalStationNumber':44}]}
    out=learn_tempo_station_layout([op,dict(op,CanonicalOperationId='X')],30,
        [{'ModelNo':'33704217__T1065','Similarity':.95,'ConfigReferenceCycleTimeSeconds':30}],
        hist,min_shared=1,min_coverage=.3)
    assert op.get('TempoLayoutPreferredPhysicalStationNumber') is None
    turn={'CanonicalName':'paleti 180° çevir', 'IsPalletOrientationAnchor':True,
          'PalletContextPreferredStationNumber':5,
          'TempoLayoutPreferredPhysicalStationNumber':49,
          'PreferredPhysicalStationNumber':5}
    assert _preferred_physical_candidate_index(turn,[1,5,49])==1
    assert out['status']=='TEMPO_LAYOUT_TRANSFER_ACTIVE'

if __name__=='__main__':
    a,b=test_mentor_selection()
    test_safety()
    print('TEST_OK mentor 30s:',a['main_mentor_model'],
          'matched',a['matched_count'],'pairs',a['learned_pairs'])
    print('TEST_OK continuous 27s mentors:',b['mentors'])
    print('TEST_OK mandatory physical/pallet untouched')
