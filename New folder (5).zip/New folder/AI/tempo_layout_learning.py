# -*- coding: utf-8 -*-
"""Continuous tempo-aware transfer of approved CK-2 station layouts.

This module learns *where* already-selected operations tend to be grouped on
real approved lines.  It never changes the product operation inventory,
operation duration, occurrence count, rotation chronology, tooling locks or
hard physical-station rules.

The important rule is that product similarity and tempo interpolation are two
separate problems:

1. Within each observed tempo (for example T1065 and T1330), choose the most
   compatible historical product layouts using configuration similarity and
   shared-operation coverage.
2. Blend the resulting TEMPO PROFILES only from the requested continuous cycle
   time.  Product similarity is not allowed to pull a 27-second request toward
   one tempo merely because that tempo happens to contain a more similar oven.

With two reference tempos this gives true linear interpolation.  Exact known
cycle times use their own reference tempo at weight 1.0.  Requests outside the
observed range clamp to the nearest observed tempo rather than extrapolating.
All transferred values remain soft preferences for the line balancer.
"""
from __future__ import annotations

from collections import defaultdict
import math
import re


REFERENCE_SHIFT_SECONDS = 31950.0
INTERMEDIATE_CT_MARGIN = 0.25
_EPS = 1e-9


def _float(value, default=None):
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (ValueError, TypeError, OverflowError):
        return default


def _occurrence_key(row):
    operation_id = str(row.get("CanonicalOperationId") or "")
    try:
        occurrence = int(float(row.get("OccurrenceIndex") or 1))
    except (ValueError, TypeError, OverflowError):
        occurrence = 1
    return operation_id + "#" + str(max(1, occurrence))


def _tempo_from_model_key(model_key):
    match = re.search(r"__T(\d+)$", str(model_key), re.I)
    if not match:
        return None
    try:
        tempo = int(match.group(1))
        return tempo if tempo > 0 else None
    except (TypeError, ValueError, OverflowError):
        return None


def _tempo_ct(model_key, profiles):
    profile = profiles.get(str(model_key)) or {}
    value = _float(profile.get("ConfigReferenceCycleTimeSeconds"))
    if value is not None and value > 0:
        return value

    tempo = _tempo_from_model_key(model_key)
    if tempo:
        return REFERENCE_SHIFT_SECONDS / float(tempo)
    return None


def _cycle_bucket_key(cycle_time):
    """Stable key for numerically equivalent approved cycle times."""
    return round(float(cycle_time), 6)


def _normalized_weights(values, temperature=0.08):
    """Softmax weights used only *inside one tempo bucket*."""
    if not values:
        return []
    lead = max(values)
    temperature = max(0.01, float(temperature))
    raw = [math.exp((value - lead) / temperature) for value in values]
    total = sum(raw)
    if total <= 0:
        return [1.0 / len(raw)] * len(raw)
    return [value / total for value in raw]


def _tempo_blend_weights(observed_cts, target_ct):
    """Return true linear interpolation weights between adjacent CT anchors.

    CT is used directly because balancing capacity is linear in seconds.  The
    list may contain more than two learned tempos in future; interpolation then
    automatically uses the two anchors bracketing the request.
    """
    cts = sorted(set(float(value) for value in observed_cts))
    if not cts:
        return {}

    target = float(target_ct)
    for ct in cts:
        if abs(target - ct) <= 1e-6:
            return {ct: 1.0}

    if target <= cts[0]:
        return {cts[0]: 1.0}
    if target >= cts[-1]:
        return {cts[-1]: 1.0}

    lower = cts[0]
    upper = cts[-1]
    for left, right in zip(cts, cts[1:]):
        if left <= target <= right:
            lower, upper = left, right
            break

    span = upper - lower
    if span <= _EPS:
        return {lower: 1.0}

    upper_weight = (target - lower) / span
    lower_weight = 1.0 - upper_weight
    return {
        lower: max(0.0, min(1.0, lower_weight)),
        upper: max(0.0, min(1.0, upper_weight)),
    }


def _weighted_average(values):
    total_weight = sum(weight for _, weight in values)
    if total_weight <= _EPS:
        return None
    return sum(value * weight for value, weight in values) / total_weight


def learn_tempo_station_layout(
    operations,
    target_ct,
    similar_models,
    instance_history,
    *,
    min_shared=10,
    min_coverage=0.30,
    max_mentors=4,
    method_regime_model=None,
):
    """Annotate operations with continuous soft station/grouping preferences.

    ``max_mentors`` is interpreted as the maximum number of product mentors
    used *per observed tempo*.  This avoids a configuration-rich tempo from
    crowding the other reference tempo out of the candidate list.
    """
    target_ct = _float(target_ct)
    main = [
        op for op in operations
        if str(op.get("PredictedStationType", "Main")).strip().lower() == "main"
    ]
    if target_ct is None or target_ct <= 0 or len(main) < 2:
        return {
            "status": "NO_MAIN_OR_CT",
            "matched_count": 0,
            "learned_pairs": 0,
            "mentors": [],
        }

    # History is indexed by occurrence key.  Re-index it by approved
    # model+tempo observation so each real method remains coherent.
    by_model = defaultdict(dict)
    for occurrence_key, observations in (instance_history or {}).items():
        for entry in observations or ():
            model = str(entry.get("ModelNo") or "")
            if not model:
                continue
            if str(entry.get("StationType", "")).strip().lower() != "main":
                continue
            if str(occurrence_key) not in by_model[model]:
                by_model[model][str(occurrence_key)] = entry

    keys = [_occurrence_key(op) for op in main]
    keyset = set(keys)
    if not keyset:
        return {
            "status": "NO_MAIN_KEYS",
            "matched_count": 0,
            "learned_pairs": 0,
            "mentors": [],
            "predicted_ct": target_ct,
        }

    profiles = {
        str(item.get("ModelNo")): item
        for item in (similar_models or ())
        if item.get("ModelNo") is not None
    }

    # First rank compatible products WITHIN their own real tempo.  CT distance
    # is deliberately absent from this score.
    candidates_by_ct = defaultdict(list)
    for model, observations in by_model.items():
        profile = profiles.get(model)
        if profile is None:
            continue

        config_similarity = _float(profile.get("Similarity"), 0.0)
        if config_similarity < 0.65:
            continue

        ct = _tempo_ct(model, profiles)
        if ct is None or ct <= 0:
            continue

        matched = set(observations).intersection(keyset)
        coverage = len(matched) / float(len(keyset))
        if len(matched) < int(min_shared) or coverage < float(min_coverage):
            continue

        # Product compatibility only.  Coverage receives slightly more weight
        # because a layout mentor that does not contain the current operations
        # cannot teach useful station grouping even when its config is similar.
        compatibility = 0.45 * config_similarity + 0.55 * coverage
        candidates_by_ct[_cycle_bucket_key(ct)].append({
            "score": compatibility,
            "model": model,
            "ct": float(ct),
            "coverage": coverage,
            "config_similarity": config_similarity,
            "observations": observations,
        })

    if not candidates_by_ct:
        return {
            "status": "NO_COMPATIBLE_TEMPO_METHOD",
            "matched_count": 0,
            "learned_pairs": 0,
            "mentors": [],
            "predicted_ct": target_ct,
        }

    # Keep the best compatible products independently for every real tempo.
    # Each tempo then becomes one aggregate historical layout profile.
    tempo_profiles = {}
    mentor_rows = []
    for bucket_ct in sorted(candidates_by_ct):
        candidates = sorted(
            candidates_by_ct[bucket_ct],
            key=lambda item: (-item["score"], item["model"]),
        )[: max(1, int(max_mentors))]

        local_weights = _normalized_weights([item["score"] for item in candidates])
        for item, local_weight in zip(candidates, local_weights):
            item["local_weight"] = local_weight

        tempo_profiles[bucket_ct] = candidates

    # Keep layout supervision coherent with the selected chronological method
    # regime. Intermediate CT still drives station capacity, but station-layout
    # priors must not blend a T1065 chronology with T1330 station positions.
    regime_tempo = _tempo_from_model_key(method_regime_model) if method_regime_model else None
    regime_ct = (REFERENCE_SHIFT_SECONDS / float(regime_tempo)) if regime_tempo else None
    observed_cts = sorted(float(value) for value in tempo_profiles.keys())
    # Intermediate CT (for example tempo 1141 -> ~28 s) lies strictly between
    # two real anchors.  Locking the layout prior to ONE tempo there ignores the
    # requested CT completely, so interpolate linearly.  The chronology and
    # inventory still come from the coherent method (hard constraints elsewhere);
    # these station positions are soft preferences on shared physical slots.
    # Near an anchor (within INTERMEDIATE_CT_MARGIN seconds) or outside the
    # observed range the original single-regime behaviour is kept.
    intermediate = (
        len(observed_cts) >= 2
        and observed_cts[0] + INTERMEDIATE_CT_MARGIN < target_ct
        < observed_cts[-1] - INTERMEDIATE_CT_MARGIN
    )
    if regime_ct is not None and tempo_profiles and not intermediate:
        selected_bucket = min(tempo_profiles.keys(), key=lambda value: abs(float(value) - regime_ct))
        tempo_weights = {selected_bucket: 1.0}
        interpolation_mode = "COHERENT_METHOD_REGIME"
    else:
        tempo_weights = _tempo_blend_weights(tempo_profiles.keys(), target_ct)
        interpolation_mode = "LINEAR_ADJACENT_CYCLE_TIME"
    active_cts = {ct for ct, weight in tempo_weights.items() if weight > _EPS}

    # Report only mentors from the one/two active tempo anchors.  The effective
    # weight is tempo interpolation weight x within-tempo product weight.
    for bucket_ct in sorted(active_cts):
        tempo_weight = tempo_weights[bucket_ct]
        for item in tempo_profiles[bucket_ct]:
            effective = tempo_weight * item["local_weight"]
            mentor_rows.append({
                "model": item["model"],
                "ct": round(item["ct"], 4),
                "coverage": round(item["coverage"], 4),
                "config_similarity": round(item["config_similarity"], 4),
                "tempo_weight": round(tempo_weight, 4),
                "within_tempo_weight": round(item["local_weight"], 4),
                "weight": round(effective, 4),
            })

    mentor_rows.sort(key=lambda item: (-item["weight"], item["ct"], item["model"]))

    learned_position_count = 0
    for op, key in zip(main, keys):
        if op.get("ForcedPhysicalStationNumber") is not None:
            continue
        if op.get("IsPalletOrientationAnchor"):
            continue

        tempo_estimates = []
        for bucket_ct, tempo_weight in tempo_weights.items():
            if tempo_weight <= _EPS:
                continue
            observations = []
            for item in tempo_profiles[bucket_ct]:
                entry = item["observations"].get(key)
                if entry is None:
                    continue
                station = _float(entry.get("PhysicalStationNumber"))
                if station is None or station <= 0:
                    continue
                observations.append((station, item["local_weight"]))

            tempo_station = _weighted_average(observations)
            if tempo_station is not None:
                tempo_estimates.append((tempo_station, tempo_weight))

        estimate = _weighted_average(tempo_estimates)

        # A reference tempo may legitimately miss an operation that exists in
        # another approved tempo (method revision / data completeness).  Do not
        # drop the operation from layout supervision.  Only when the active
        # interpolation anchors have no observation for this occurrence, use
        # the nearest available tempo as a low-level fallback.  This fallback
        # never competes with an observation from the active tempo anchors.
        if estimate is None:
            for fallback_ct in sorted(
                tempo_profiles.keys(),
                key=lambda value: (abs(float(value) - target_ct), float(value)),
            ):
                observations = []
                for item in tempo_profiles[fallback_ct]:
                    entry = item["observations"].get(key)
                    if entry is None:
                        continue
                    station = _float(entry.get("PhysicalStationNumber"))
                    if station is None or station <= 0:
                        continue
                    observations.append((station, item["local_weight"]))
                estimate = _weighted_average(observations)
                if estimate is not None:
                    break

        if estimate is not None:
            op["TempoLayoutPreferredPhysicalStationNumber"] = float(estimate)
            learned_position_count += 1

    learned_pairs = 0
    for left, right in zip(main, main[1:]):
        left_key = _occurrence_key(left)
        right_key = _occurrence_key(right)

        tempo_pair_values = []
        pair_evidence_count = 0
        for bucket_ct, tempo_weight in tempo_weights.items():
            if tempo_weight <= _EPS:
                continue

            local_values = []
            for item in tempo_profiles[bucket_ct]:
                a = item["observations"].get(left_key)
                b = item["observations"].get(right_key)
                if a is None or b is None:
                    continue

                station_a = _float(a.get("StationSequence"))
                station_b = _float(b.get("StationSequence"))
                if station_a is None or station_b is None:
                    continue

                pair_evidence_count += 1
                local_values.append((
                    1.0 if int(round(station_a)) == int(round(station_b)) else 0.0,
                    item["local_weight"],
                ))

            local_probability = _weighted_average(local_values)
            if local_probability is not None:
                tempo_pair_values.append((local_probability, tempo_weight))

        learned_probability = _weighted_average(tempo_pair_values)

        # Same completeness fallback as station position: use another tempo
        # only if neither active interpolation anchor has evidence for the
        # adjacent pair.
        if learned_probability is None:
            for fallback_ct in sorted(
                tempo_profiles.keys(),
                key=lambda value: (abs(float(value) - target_ct), float(value)),
            ):
                local_values = []
                for item in tempo_profiles[fallback_ct]:
                    a = item["observations"].get(left_key)
                    b = item["observations"].get(right_key)
                    if a is None or b is None:
                        continue
                    station_a = _float(a.get("StationSequence"))
                    station_b = _float(b.get("StationSequence"))
                    if station_a is None or station_b is None:
                        continue
                    pair_evidence_count += 1
                    local_values.append((
                        1.0 if int(round(station_a)) == int(round(station_b)) else 0.0,
                        item["local_weight"],
                    ))
                learned_probability = _weighted_average(local_values)
                if learned_probability is not None:
                    break

        if learned_probability is None:
            continue

        previous = _float(left.get("LearnedSameStationWithNextProbability"))
        # The pairwise Group ML contains richer duration/config information;
        # tempo layout acts as complementary historical evidence.  Preserve the
        # previous signal but make the explicit continuous tempo profile strong
        # enough to correct intermediate-speed grouping.
        if previous is not None:
            posterior = 0.40 * previous + 0.60 * learned_probability
        else:
            posterior = learned_probability

        left["LearnedSameStationWithNextProbability"] = float(
            max(0.0, min(1.0, posterior))
        )
        left["TempoLayoutPairEvidenceCount"] = int(pair_evidence_count)
        learned_pairs += 1

    if mentor_rows:
        primary = mentor_rows[0]
        main_mentor_model = primary["model"]
        main_mentor_ct = primary["ct"]
    else:
        main_mentor_model = ""
        main_mentor_ct = ""

    return {
        "status": "TEMPO_LAYOUT_TRANSFER_ACTIVE",
        "interpolation_mode": interpolation_mode,
        "method_regime_model": str(method_regime_model or ""),
        "predicted_ct": float(target_ct),
        "tempo_weights": {
            str(round(ct, 6)): round(weight, 6)
            for ct, weight in sorted(tempo_weights.items())
        },
        "available_cycle_times": [
            round(ct, 6) for ct in sorted(tempo_profiles.keys())
        ],
        "matched_count": learned_position_count,
        "learned_pairs": learned_pairs,
        "mentors": mentor_rows,
        "main_mentor_model": main_mentor_model,
        "main_mentor_ct": main_mentor_ct,
    }