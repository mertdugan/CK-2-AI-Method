# -*- coding: utf-8 -*-
"""CK-2 AI Metod - auditable, coherent operation-inventory constraints.

The ML models predict presence, duration and within-method placement. A production
method must not combine conflicting task variants or physical rotations copied
from different historical methods. We use a SINGLE comparable approved method
as an inventory/chronology constraint, not as a fixed station balance or a
nearest-tempo output. CT remains continuous and the ML predictors still run.

When evidence is insufficient, raise rather than produce a plausible-looking,
but physically unverified, high-saturation method.
"""
from __future__ import annotations
import logging

from collections import Counter, defaultdict
from dataclasses import dataclass
import math
from typing import Any, Mapping, Sequence

from orientation_sync import turn_kind


class MethodIntegrityError(ValueError):
    pass


def _safe_positive_int(value):
    try:
        number = float(value)
        if math.isfinite(number) and number > 0 and number.is_integer():
            return int(number)
    except (TypeError, ValueError, OverflowError):
        pass
    return None


def _key(operation_id, occurrence):
    return str(operation_id) + '#' + str(int(occurrence))


def _turns(operations, name_key='CanonicalName'):
    return [turn_kind(op.get(name_key, '')) for op in operations
            if turn_kind(op.get(name_key, ''))[0] is not None]


def _structured_history(instance_history):
    """Build ONE method per historical ModelNo__T####, never merge tempos."""
    by_model = defaultdict(dict)
    duplicate_keys = set()
    for operation_key, observations in (instance_history or {}).items():
        if '#' not in str(operation_key):
            continue
        for item in observations or ():
            model_no = str(item.get('ModelNo') or '').strip()
            if not model_no:
                continue
            if operation_key in by_model[model_no]:
                duplicate_keys.add((model_no, str(operation_key)))
            by_model[model_no][str(operation_key)] = dict(item)
    return by_model, duplicate_keys


@dataclass(frozen=True)
class CoherentMethod:
    model_no: str
    similarity: float
    observed_ct: float | None
    members: Mapping[str, Mapping[str, Any]]
    order: tuple[str, ...]
    counts: Mapping[str, int]
    turn_signature: tuple[tuple[str, int], ...]


def choose_coherent_method(
    similar_models,
    instance_history,
    canonical_name_map,
    *,
    minimum_similarity=0.975,
    presence_probabilities=None,
    excluded_models=(),
):
    """Pick a config-compatible, internally ordered inventory.

    No high-confidence reference -> fail closed. Selection uses config
    similarity first; target CT only breaks a tie between truly comparable
    product configurations. Operation times are still ML predictions.
    """
    indexed, duplicates = _structured_history(instance_history)
    examined = []
    rejected = []
    # T1065 / T1330 are training examples of the SAME process at different
    # cycle times. A near-identical product at the wrong CT must not lock
    # Metodu Koru to the wrong chronological method when an equally comparable
    # on-target method exists. Only coherent, validated method inventories
    # can compete here. Durations are still predicted continuously by ML.
    comparable_band = 0.02
    for entry in similar_models or ():
        model_no = str(entry.get('ModelNo') or '')
        if model_no in excluded_models:
            continue
        try:
            similarity = float(entry.get('Similarity', 0) or 0)
        except (ValueError, TypeError):
            continue
        if not math.isfinite(similarity) or similarity < minimum_similarity:
            continue
        members = indexed.get(model_no, {})
        if not members or any(pair[0] == model_no for pair in duplicates):
            continue
        valid = True
        ordered = []
        counts = defaultdict(int)
        for key, observation in members.items():
            operation_id, sep, occurrence = key.rpartition('#')
            sequence = _safe_positive_int(observation.get('StationSequence'))
            station_operation = _safe_positive_int(observation.get('StationOperationSequence'))
            occurrence_number = _safe_positive_int(occurrence)
            station_type = str(observation.get('StationType') or '').strip()
            if (not sep or sequence is None or station_operation is None or
                    occurrence_number is None or not station_type or
                    operation_id not in canonical_name_map):
                valid = False
                break
            counts[operation_id] = max(counts[operation_id], occurrence_number)
            ordered.append((sequence, station_operation, key))
        if not valid:
            continue
        ordered.sort()
        if len({(seq, step) for seq, step, _ in ordered}) != len(ordered):
            # Global station sequence + local operation order must identify
            # each row. Do not invent a chronological order from tie-breakers.
            continue
        # Contiguous occurrence indices are required, otherwise the supplied
        # method is not a complete source of inventory evidence.
        if any(any(_key(op, i) not in members for i in range(1, count+1))
               for op, count in counts.items()):
            continue
        signature = tuple(
            kind for _, _, key in ordered
            if (kind := turn_kind(canonical_name_map[key.rpartition('#')[0]]))[0]
        )
        distance = entry.get('CycleTimeDistanceSeconds')
        try:
            distance = float(distance)
            if not math.isfinite(distance):
                distance = 1000000.0
        except (TypeError, ValueError):
            distance = 1000000.0
        # Selecting a method is about product sameness, not nearest tempo.
        # A small CT tie-break is used ONLY if product similarities coincide.
        candidate = CoherentMethod(model_no, similarity, distance, members,
                                   tuple(item[2] for item in ordered),
                                   dict(counts), signature)
        try:
            require_reference_has_hard_operations(candidate, canonical_name_map)
        except MethodIntegrityError as exc:
            rejected.append(model_no + ': ' + str(exc))
            logging.getLogger('ck2.method').warning(
                'REFERENCE_REJECTED %s: %s', model_no, exc)
            continue
        # Learned presence probabilities are evaluated at the REQUESTED
        # continuous CT. They choose between equally compatible coherent
        # process inventories, but cannot mix individual tasks between them.
        # Use log-likelihood per canonical operation, not raw task count,
        # to avoid systematic bias toward the longest method.
        if presence_probabilities:
            support = set(counts)
            total_log_likelihood = 0.0
            for op_id, probability in presence_probabilities.items():
                probability = min(.999, max(.001, float(probability)))
                total_log_likelihood += math.log(
                    probability if op_id in support else 1.0 - probability
                )
            ml_score = total_log_likelihood / max(1, len(presence_probabilities))
        else:
            ml_score = 0.0
        examined.append((similarity, ml_score, -distance, len(ordered), model_no,
                         members, tuple(item[2] for item in ordered),
                         dict(counts), signature))
    if not examined:
        raise MethodIntegrityError(
            'METHOD_REFERENCE_UNAVAILABLE: Ürün konfigürasyonu ile en az %97,5 '
            'uyumlu, mühendislik kurallarıyla çelişmeyen, operasyon sırası '
            'eksiksiz bir referans bulunamadı. '
            'Karşılaşılan çelişkiler: ' + ' | '.join(rejected[:4]) +
            '. Farklı modellerin operasyonlarını birleştirerek tahmin üretilmeyecek.'
        )
    # Product configuration is a hard eligibility gate (minimum_similarity).
    # Inside a small comparable band, prefer a method observed at the
    # requested CT; then use the ML inventory likelihood. This prevents a
    # T1330 reference silently defeating an available compatible T1065
    # layout solely due to a tiny configuration-score difference.
    highest_similarity = max(row[0] for row in examined)
    comparable = [row for row in examined
                  if row[0] >= highest_similarity - comparable_band]
    # Do not treat a missing CT as a close match.
    chosen = max(comparable, key=lambda row: (row[2], row[1], row[0], row[3], row[4]))
    sim, _, minus_distance, _, model_no, members, order, counts, signature = chosen
    return CoherentMethod(model_no, sim, -minus_distance, members, order,
                          counts, signature)


def _normalised_name(value):
    return str(value or '').upper().translate(str.maketrans({
        'İ': 'I', 'ı': 'I', 'Ş': 'S', 'ş': 'S',
        'Ğ': 'G', 'ğ': 'G', 'Ö': 'O', 'ö': 'O',
        'Ü': 'U', 'ü': 'U', 'Ç': 'C', 'ç': 'C',
    }))


def semantic_family(name):
    """Only physically unambiguous *alternative* operation descriptions.

    Do NOT merge turns, different screw counts, left/right components,
    distinct lamp locations or pallet positions based on fuzzy text.
    """
    text = _normalised_name(name)
    if ('CEHENNEM' in text and 'BARKOD' in text and
            'ETIKET' in text and 'YAP' in text):
        return 'CEHENNEMLIK_BARCODE_VARIANT'
    if ('FAN MOTOR' in text or 'FAN MOTUR' in text) and 'SNAP' in text and 'TAK' in text and 'VIDA' not in text:
        return 'SNAP_FAN_MOTOR_INSTALL_VARIANT'
    if 'TEPSI' in text and ('FIRINA' in text or 'FIRININ ICINE' in text) and (
            'YERLESTIR' in text or 'KOY' in text):
        return 'TRAY_LOAD_VARIANT'
    if 'IZGARA' in text and 'FIRINA' in text and ('YERLESTIR' in text or 'KOY' in text):
        return 'GRILL_LOAD_VARIANT'
    return None


def require_reference_has_hard_operations(method, canonical_name_map):
    """Do not override a conflicting real reference with a fake operation."""
    names = {op: _normalised_name(canonical_name_map.get(op, ''))
             for op in method.counts}
    # Both label variants (on the hell-liner OR on the bumper) are the same
    # physical step (see semantic_family: CEHENNEMLIK_BARCODE_VARIANT). The
    # real T1065 methods use the bumper variant, T1330 the hell-liner one.
    # Exactly ONE of them must exist in a reference.
    required = [op for op, name in names.items()
                if 'CEHENNEM' in name and 'BARKOD' in name and
                'YAP' in name and 'ETIKET' in name]
    if not required:
        raise MethodIntegrityError(
            'STANDARD_LABEL_MISMATCH: Referans metotta zorunlu cehennemlik '
            'barkod etiketi operasyonu (cehennemlik veya bumper uzerine) '
            'bulunamadi; referansi dogrulayin.'
        )
    if len(required) != 1 or method.counts[required[0]] != 1:
        raise MethodIntegrityError(
            'STANDARD_LABEL_DUPLICATE: Referansta zorunlu barkod islemi '
            'tam olarak bir kez bulunmali.'
        )
    families = defaultdict(set)
    for operation_id, name in names.items():
        family = semantic_family(name)
        if family:
            families[family].add(operation_id)
    conflicts = {family: ids for family, ids in families.items() if len(ids) > 1}
    if conflicts:
        details = ', '.join('{}:{}'.format(family, '/'.join(sorted(ids)))
                            for family, ids in sorted(conflicts.items()))
        raise MethodIntegrityError(
            'SEMANTIC_VARIANT_CONFLICT: Aynı montajın alternatif tarifleri '
            'tek metotta bulunuyor: ' + details
        )


def attach_coherent_chronology(operations, method: CoherentMethod):
    """Rewrite chronology ONLY, NEVER the ML duration or station workload."""
    by_key = {}
    for op in operations:
        key = _key(op.get('CanonicalOperationId'), op.get('OccurrenceIndex', 1))
        if key in by_key:
            raise MethodIntegrityError('DUPLICATE_OPERATION_INSTANCE: ' + key)
        by_key[key] = op
    missing = set(method.order) - set(by_key)
    extra = set(by_key) - set(method.order)
    if missing or extra:
        raise MethodIntegrityError(
            'INVENTORY_MISMATCH: Eksik={} Fazla={}. '.format(
                ','.join(sorted(missing)[:12]), ','.join(sorted(extra)[:12])) +
            'Dengelemeye eksik veya karışık operasyon gönderilmeyecek.'
        )
    chronological = []
    for i, key in enumerate(method.order, 1):
        op = by_key[key]
        source = method.members[key]
        expected_type = str(source['StationType'])
        predicted_type = str(op.get('PredictedStationType') or '')
        if expected_type != predicted_type:
            # Learned station classifier may disagree, but classifying a door
            # or test operation as Main can destroy physical process routing.
            op['PredictedStationType'] = expected_type
            op['StationTypeSource'] = 'COHERENT_APPROVED_REFERENCE'
        op['PredictedProcessSequence'] = i
        op['PreservedReferenceModelNo'] = method.model_no
        op['PreservedReferenceStationType'] = expected_type
        op['PreservedReferenceStationSequence'] = _safe_positive_int(source.get('StationSequence'))
        op['PreservedReferenceStationOperationSequence'] = _safe_positive_int(source.get('StationOperationSequence'))
        op['WithinStationOrderSource'] = 'COHERENT_APPROVED_REFERENCE'
        physical = _safe_positive_int(source.get('PhysicalStationNumber'))
        if physical is not None:
            forced = _safe_positive_int(op.get('ForcedPhysicalStationNumber'))
            if forced is not None and forced != physical:
                raise MethodIntegrityError(
                    'FIXED_STATION_CONFLICT: {} gerçek istasyon {}, mühendislik kuralı {}'
                    .format(key, physical, forced)
                )
            op['PreservedReferenceStationNumber'] = physical
            op['PreferredPhysicalStationNumber'] = physical
        chronological.append(op)
    actual_signature = tuple(_turns(chronological))
    if actual_signature != method.turn_signature:
        raise MethodIntegrityError(
            'ORIENTATION_SEQUENCE_MISMATCH: Öğrenilmiş palet/cehennemlik '
            'dönüş dizisi referans metotla eşleşmiyor.'
        )
    return chronological


def post_balance_integrity(reference_operations, final_operations, method):
    """Final-stage integrity check, including market/engineering overrides."""
    keys = [_key(x.get('CanonicalOperationId'), x.get('OccurrenceIndex', 1))
            for x in final_operations if str(x.get('OperationOrigin', 'AI_PREDICTION')) == 'AI_PREDICTION']
    if len(keys) != len(set(keys)) or set(keys) != set(method.order):
        raise MethodIntegrityError(
            'FINAL_OPERATION_INVENTORY_CHANGED: Metot sonrası operasyon '
            'eklendi, silindi veya tekrarlandı. Excel güvenlik nedeniyle oluşturulmadı.'
        )
    final_by_key = {
        _key(x.get('CanonicalOperationId'), x.get('OccurrenceIndex', 1)): x
        for x in final_operations
        if str(x.get('OperationOrigin', 'AI_PREDICTION')) == 'AI_PREDICTION'
    }
    final_signature = tuple(
        kind for key in method.order
        if (kind := turn_kind(final_by_key[key].get('CanonicalName', '')))[0]
    )
    if final_signature != method.turn_signature:
        raise MethodIntegrityError(
            'FINAL_ORIENTATION_CHANGED: Palet/cehennemlik dönüşlerinin türü, '
            'açısı veya sırası referansla değişmiş. Excel oluşturulmayacak.'
        )
    # Orientation is independently validated by orientation_sync.validate_orientation.
    # This additionally proves no new ML task appeared after rebalancing.
    return {
        'source': method.model_no,
        'operation_count': len(method.order),
        'rotation_count': len(method.turn_signature),
    }