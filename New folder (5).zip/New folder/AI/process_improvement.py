# -*- coding: utf-8 -*-
"""CK-2: verified-clock-time staffing improvement scenarios.

Does NOT silently edit measured/ML operation seconds or certify a factory
method. The proposals minimize the time study required for a smaller crew,
while preserving complete operation inventory, order, orientation sequence,
fixture positions and approved co-location links.
"""
from __future__ import annotations

from collections import defaultdict
from functools import lru_cache
import math


def _seconds(op):
    try:
        x = float(op.get("PredictedTimeSeconds") or 0)
        return x if math.isfinite(x) and x >= 0 else None
    except (ValueError, TypeError, OverflowError):
        return None


def _is_main(op):
    return str(op.get("AssignedStationType", op.get("PredictedStationType", "Main"))).lower() == "main"


def _is_turn(op):
    if str(op.get("OrientationTurnKind") or "").upper() in ("PALLET", "PALLET_TURN"):
        return True
    name = str(op.get("CanonicalName") or "").casefold()
    return "palet" in name and any(w in name for w in ("çevir", "cevir", "döndür"))


def _fixed_physical(op):
    value = op.get("ForcedPhysicalStationNumber")
    if value is not None:
        try:
            return int(value)
        except (ValueError, TypeError, OverflowError):
            return None
    rule = str(op.get("EngineeringRule") or "").upper()
    if "STANDARD_CEHENNEMLIK_LABEL" in rule:
        return 1
    if "KAPI_ETIKETI_CONFIG_VAR_PHYSICAL_44_OR_49" in rule:
        for field in ("PhysicalStationNumber", "PreferredPhysicalStationNumber"):
            try:
                candidate = int(op.get(field))
                if candidate in (44, 49):
                    return candidate
            except (TypeError, ValueError, OverflowError):
                pass
    return None


def _occ_key(op):
    return (str(op.get("CanonicalOperationId") or ""), int(op.get("OccurrenceIndex") or 1))


def _certified(edge):
    if edge.get("EngineeringApproved") is True or edge.get("IsApproved") is True:
        return True
    return str(edge.get("ConstraintSource") or edge.get("RuleSource") or "").upper() in {
        "ENGINEERING_APPROVED", "HARD_TOOLING", "PHYSICAL_FIXTURE", "PHYSICAL_PROCESS", "SAFETY"}


def propose_improvements(operations, station_records, cycle_time,
                         target_main_counts=(20, 21), hard_bundle_edges=None,
                         max_rotation_move_slots=3, max_turns_per_station=2,
                         max_station_load=None):
    """Return audited *conditional* 26/27-person alternatives; never an approved layout.

    Two-stage exact dynamic programming:
    (1) least aggregate seconds to save for a specified number of ordered stations;
    (2) real physical station mapping with rotation anchors and fixture locks.
    This is a time-study plan, NOT a prediction that operations magically get faster.
    """
    main = [dict(x) for x in operations if _is_main(x)]
    if len(main) < 2 or not (math.isfinite(cycle_time) and cycle_time > 0):
        return []
    capacity = float(max_station_load) if max_station_load is not None else float(cycle_time)
    if not math.isfinite(capacity) or capacity <= 0 or capacity > cycle_time + 1e-8:
        return []
    durations = [_seconds(op) for op in main]
    if any(x is None for x in durations):
        return []
    n = len(main)
    physical = sorted({int(x.get("PhysicalStationNumber")) for x in main
                       if x.get("PhysicalStationNumber") is not None})
    if not physical:
        return []
    original_index = {number: i for i, number in enumerate(physical)}
    forced = [_fixed_physical(op) for op in main]
    turns = [int(_is_turn(op)) for op in main]
    if any(x is not None and x not in original_index for x in forced):
        return []
    current_main_count = len(physical)
    current_all_count = len(station_records)
    special_count = current_all_count - current_main_count
    if special_count < 0:
        return []
    forbidden_cuts = set()
    forced_cuts = {i for i, op in enumerate(main[:-1])
                   if op.get("AdaptiveMandatoryBoundaryAfter")}
    # Tray and grid operations are a single physical workstation by policy.
    tray = [i for i, op in enumerate(main)
            if "TEPSI_IZGARA_SAME_PHYSICAL_STATION" in str(op.get("EngineeringRule") or "")]
    if len(tray) > 1:
        forbidden_cuts.update(range(min(tray), max(tray)))
    by_id = {_occ_key(op): i for i, op in enumerate(main)}
    for edge in hard_bundle_edges or ():
        if not _certified(edge):
            continue
        a = by_id.get((str(edge.get("Source")), int(edge.get("SourceOccurrenceIndex") or 1)))
        b = by_id.get((str(edge.get("Target")), int(edge.get("TargetOccurrenceIndex") or 1)))
        if a is not None and b is not None and a != b:
            forbidden_cuts.update(range(min(a,b), max(a,b)))
    if forbidden_cuts.intersection(forced_cuts):
        return []
    prefix = [0.0]
    rotations = [0]
    for duration, turn in zip(durations, turns):
        prefix.append(prefix[-1] + duration)
        rotations.append(rotations[-1] + turn)
    candidates = []
    for requested in sorted({int(x) for x in target_main_counts}, reverse=True):
        if requested < 1 or requested >= current_main_count or requested > len(physical):
            continue
        # Exact ordered partition, minimizing time gain required.
        inf = float("inf")
        dp = [[inf]*(n+1) for _ in range(requested+1)]
        back = [[None]*(n+1) for _ in range(requested+1)]
        dp[0][0] = 0.0
        for k in range(1, requested+1):
            for stop in range(k, n+1):
                if stop < n and stop-1 in forbidden_cuts:
                    continue
                for start in range(k-1, stop):
                    if dp[k-1][start] == inf:
                        continue
                    if rotations[stop]-rotations[start] > max_turns_per_station:
                        continue
                    if any(start <= cut < stop-1 for cut in forced_cuts):
                        continue
                    overload = max(0.0, prefix[stop]-prefix[start]-capacity)
                    # Tiny tie-breaker favours learned same-station probabilities.
                    cut_probability = main[stop-1].get("LearnedSameStationWithNextProbability") if stop<n else None
                    try:
                        cut_penalty = 0.000001*max(0., min(1., float(cut_probability)))
                    except (TypeError, ValueError, OverflowError):
                        cut_penalty = 0.
                    score = dp[k-1][start] + overload + cut_penalty
                    if score + 1e-12 < dp[k][stop]:
                        dp[k][stop] = score
                        back[k][stop] = start
        if not math.isfinite(dp[requested][n]):
            continue
        groups = []
        stop = n
        for k in range(requested, 0, -1):
            start = back[k][stop]
            if start is None:
                groups=[]
                break
            groups.append((start, stop))
            stop = start
        groups.reverse()
        if not groups or stop != 0:
            continue
        # Place the *ordered* groups only on existing physical Main station IDs.
        @lru_cache(None)
        def place(group_no, next_slot):
            if group_no >= requested:
                return 0.0, ()
            start, stop = groups[group_no]
            remain = requested-group_no-1
            best_cost, best_positions = inf, None
            locks = {x for x in forced[start:stop] if x is not None}
            if len(locks)>1:
                return inf, None
            for slot in range(next_slot, len(physical)-remain):
                pos = physical[slot]
                if locks and pos not in locks:
                    continue
                moves = 0.0
                valid = True
                for op in main[start:stop]:
                    old = op.get("PhysicalStationNumber")
                    try:
                        old_slot = original_index[int(old)]
                    except (ValueError, TypeError, KeyError, OverflowError):
                        continue
                    if _is_turn(op) and abs(slot-old_slot) > max_rotation_move_slots:
                        valid=False
                        break
                    moves += abs(slot-old_slot)*(6. if _is_turn(op) else 1.)
                if not valid:
                    continue
                child, positions = place(group_no+1, slot+1)
                if positions is None:
                    continue
                if moves+child < best_cost:
                    best_cost=moves+child
                    best_positions=(pos,)+positions
            return best_cost,best_positions
        movement, mapped = place(0,0)
        if mapped is None:
            continue
        records=[]
        for position,(start,stop) in zip(mapped,groups):
            total = prefix[stop]-prefix[start]
            reduction = max(0.,total-capacity)
            records.append({
                "PhysicalStationNumber": position,
                "Operations": [
                    {"Id": _occ_key(main[i]),"Name":str(main[i].get("CanonicalName") or ""),
                     "Seconds":durations[i],"Turn":bool(turns[i])}
                    for i in range(start,stop)],
                "OriginalLoadSeconds":round(total,6),
                "TimeStudySavingsNeededSeconds":round(reduction,6),
                "RequiredMaxLoadSeconds":round(min(total,capacity),6),
                "TurnCount": rotations[stop]-rotations[start],
                "OperationCount": stop-start,
            })
        improvement=sum(r["TimeStudySavingsNeededSeconds"] for r in records)
        work=sum(durations) + sum(float(r.get("StationLoadSeconds") or 0)
                                 for r in station_records if str(r.get("StationType") or "").lower() != "main")
        effective=work-improvement
        proposal={
            "CurrentTotalStaff":current_all_count,
            "ProposedTotalStaff":requested+special_count,
            "ProposedMainStaff":requested,
            "SpecialProcessStaffUnchanged":special_count,
            "OriginalWorkContentSeconds":round(work,6),
            "TotalTimeStudySavingsNeededSeconds":round(improvement,6),
            "ConditionalSaturationPercent":round(100*effective/(cycle_time*(requested+special_count)),4),
            "OriginalOperationCount":n,
            "PreservedOrientationTurnCount":sum(turns),
            "PhysicalMovementCost":round(movement,2),
            "Stations":records,
            "Status":"ENGINEERING_TIME_STUDY_REQUIRED_NOT_APPROVED",
            "Interpretation": "Süre kazanımları SAHADA doğrulanmadan öneri üretime uygulanamaz.",
        }
        candidates.append(proposal)
    return sorted(candidates,key=lambda x:x["ProposedTotalStaff"])
