# -*- coding: utf-8 -*-
"""CK-2 AI Metod: learned station-boundary preferences.

A supervised model learns whether two consecutive Main operations occupied
one workstation in approved historical methods, conditioned on target CT.
It is NEVER an engineering authority: orientation, process order, capacity,
fixed physical stations and approved fixture bundles stay hard constraints.

The grouping preference is soft and secondary to minimum workforce.
"""
from __future__ import annotations

import math
import re
from collections import Counter

import numpy as np
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_extraction import DictVectorizer
from sklearn.metrics import balanced_accuracy_score, brier_score_loss
from sklearn.model_selection import GroupShuffleSplit
from sklearn.ensemble import RandomForestClassifier


def _number(value, default=0.0):
    try:
        result = float(value)
        return result if math.isfinite(result) else float(default)
    except (ValueError, TypeError):
        return float(default)


def _whole(value, default=1):
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return int(default)


def _raw_model_name(model_key):
    return re.sub(r"__T\d+$", "", str(model_key), flags=re.I)


def _pair_features(config, a, b, cycle_time):
    """Same feature schema for approved real methods and unseen predictions."""
    ct = max(0.01, _number(cycle_time, 30.0))
    t1 = max(0.0, _number(a.get("OperationTimeSeconds", a.get("PredictedTimeSeconds"))))
    t2 = max(0.0, _number(b.get("OperationTimeSeconds", b.get("PredictedTimeSeconds"))))
    left_id = str(a.get("CanonicalOperationId") or "")
    right_id = str(b.get("CanonicalOperationId") or "")
    return {
        "left_operation": left_id,
        "right_operation": right_id,
        "left_occurrence": _whole(a.get("OccurrenceIndex")),
        "right_occurrence": _whole(b.get("OccurrenceIndex")),
        "cycle_time_seconds": ct,
        "left_duration_over_ct": min(5., t1 / ct),
        "right_duration_over_ct": min(5., t2 / ct),
        "pair_duration_over_ct": min(10., (t1 + t2) / ct),
        "remaining_capacity_seconds": max(-ct, ct-t1-t2),
        "pair_fits_cycle": int(t1+t2 <= ct + 1e-6),
        "duration_difference_over_ct": min(5., abs(t1-t2)/ct),
        "duration_max_over_ct": min(5., max(t1,t2)/ct),
        "left_duration_seconds": t1,
        "right_duration_seconds": t2,
        "family": str(config.get("CataPyro") or ""),
        "model_type": str(config.get("ModelType") or ""),
        "fan_type": str(config.get("FanType") or config.get("Fan") or ""),
        "timer_type": str(config.get("TimerType") or ""),
        "cehennemlik_type": str(config.get("CehennemlikType") or ""),
        "travers_snap": str(config.get("TraversSnap") or ""),
        "astar_cam": str(config.get("AstarCam") or ""),
        "tepsi_count": _number(config.get("Tepsi")),
        "izgara_count": _number(config.get("Izgara")),
        "ray": str(config.get("Ray") or ""),
        "limitor": str(config.get("Limitor") or ""),
        "door_type": str(config.get("DoorType") or ""),
    }


def training_pairs(sequence, approved):
    """Build true same-station labels, isolating each model+tempo example.

    Input dataframes are already canonicalized in trainer.py. The operation
    order is from the REAL method, not from predicted or synthetic ordering.
    """
    lookup = {str(row["ModelNo"]): row.to_dict()
              for _, row in approved.iterrows()}
    required = ("ModelNo", "StationSequence", "StationType",
                "CanonicalOperationId", "OperationSequence")
    missing = [x for x in required if x not in sequence.columns]
    if missing:
        raise ValueError("Station grouping: veri setinde eksik alanlar: " + ", ".join(missing))
    result = []
    for model_key, method in sequence.groupby("ModelNo", sort=False):
        config = lookup.get(str(model_key))
        if config is None:
            continue
        ct = _number(config.get("ConfigReferenceCycleTimeSeconds"), 0)
        if ct <= 0:
            tempo = re.search(r"__T(\d+)$", str(model_key))
            if tempo:
                ct = 31950.0 / float(tempo.group(1))
        if ct <= 0:
            continue
        method = method.sort_values(["OperationSequence", "StationSequence"])
        for station_type, zone in method.groupby("StationType", sort=False):
            if str(station_type).strip().lower() != "main":
                continue
            rows = [row.to_dict() for _, row in zone.iterrows()]
            for left, right in zip(rows, rows[1:]):
                if left.get("StationSequence") is None or right.get("StationSequence") is None:
                    continue
                label = int(_whole(left["StationSequence"], -1) ==
                            _whole(right["StationSequence"], -2))
                result.append({
                    "features": _pair_features(config, left, right, ct),
                    "same_station": label,
                    "model_key": str(model_key),
                    "group": _raw_model_name(model_key),
                })
    return result


def fit_station_group_model(sequence, approved):
    """Train pairwise boundary classifier; prevent same-model tempo leakage."""
    samples = training_pairs(sequence, approved)
    labels = np.array([sample["same_station"] for sample in samples], dtype=int)
    metadata = {
        "sample_count": int(len(samples)),
        "model_count": len(set(s["group"] for s in samples)),
        "positive_count": int(labels.sum()) if len(labels) else 0,
        "negative_count": int((labels == 0).sum()) if len(labels) else 0,
        "training_target": "MAIN_ADJACENT_OPERATIONS_SAME_STATION_AT_CYCLE_TIME",
    }
    # Do not train a fictitious classifier on one class or very few examples.
    if len(samples) < 35 or len(set(labels)) < 2 or metadata["model_count"] < 3:
        metadata["status"] = "INSUFFICIENT_APPROVED_DATA"
        return None, metadata

    vec = DictVectorizer(sparse=False)
    x = vec.fit_transform([sample["features"] for sample in samples])
    groups = np.array([sample["group"] for sample in samples])
    prediction_model = ExtraTreesClassifier(
        n_estimators=200, min_samples_leaf=4, max_features=0.85,
        class_weight="balanced_subsample", random_state=42, n_jobs=1,
    )
    from collections import Counter as _Counter
    per_group = _Counter(groups.tolist())
    weights = np.asarray([1.0 / per_group[g] for g in groups], dtype=float)
    weights *= len(weights) / weights.sum()
    if len(set(groups)) >= 5:
        split = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=42)
        train_idx, test_idx = next(split.split(x, labels, groups))
        if len(set(labels[train_idx])) == 2 and len(set(labels[test_idx])) == 2:
            holdout = ExtraTreesClassifier(
                n_estimators=200, min_samples_leaf=4, max_features=0.85,
                class_weight="balanced_subsample", random_state=42, n_jobs=1,
            )
            holdout.fit(x[train_idx], labels[train_idx], sample_weight=weights[train_idx])
            probability = holdout.predict_proba(x[test_idx])[:, list(holdout.classes_).index(1)]
            metadata.update({
                "holdout_model_count": len(set(groups[test_idx])),
                "holdout_balanced_accuracy": round(float(balanced_accuracy_score(labels[test_idx], probability >= 0.5)), 4),
                "holdout_brier_score": round(float(brier_score_loss(labels[test_idx], probability)), 4),
            })
    # Each distinct product carries similar total influence, even when its
    # approved method has more operation rows or multiple tempo versions.
    prediction_model.fit(x, labels, sample_weight=weights)
    metadata["feature_schema"] = "GROUP_ML_V2_CONFIG_DURATION_CT"
    metadata["weighted_by_product"] = True
    metadata["feature_count"] = int(x.shape[1])
    metadata["status"] = "TRAINED"
    return {"model": prediction_model, "vectorizer": vec}, metadata


def annotate_station_groups(operations, config, bundle):
    """Add SOFT grouping probabilities to each consecutive Main operation."""
    estimator = bundle.get("station_group_estimator")
    if not estimator:
        return 0
    classifier = estimator["model"]
    vectorizer = estimator["vectorizer"]
    ct = _number(config.get("ConfigReferenceCycleTimeSeconds"), 0.0)
    if ct <= 0:
        return 0
    main = [op for op in operations
            if str(op.get("PredictedStationType", "Main")) == "Main"]
    if len(main) < 2:
        return 0
    features = [_pair_features(config, a, b, ct) for a, b in zip(main, main[1:])]
    x = vectorizer.transform(features)
    probabilities = classifier.predict_proba(x)[:, list(classifier.classes_).index(1)]
    # Both operations must fit; ML cannot nominate an impossible same-station
    # pairing at the current CT. Other hard constraints stay in the balancer.
    for i, (a, b) in enumerate(zip(main, main[1:])):
        a_time = _number(a.get("PredictedTimeSeconds"), 0.0)
        b_time = _number(b.get("PredictedTimeSeconds"), 0.0)
        if a_time + b_time > ct + 1e-6:
            probabilities[i] = 0.0
    for op, probability in zip(main, probabilities):
        op["LearnedSameStationWithNextProbability"] = float(probability)
    main[-1].pop("LearnedSameStationWithNextProbability", None)
    return len(probabilities)
