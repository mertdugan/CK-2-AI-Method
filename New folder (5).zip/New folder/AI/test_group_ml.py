# -*- coding: utf-8 -*-
"""CK2 grouping ML and safe staffing smoke/regression tests."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import pandas as pd
from station_group_learning import fit_station_group_model, annotate_station_groups
from line_balancer import _fast_global_staffing


def artificial_approved_methods():
    # Eight distinct base models each observed at BOTH 24 and 30 seconds.
    # In 30s grouping changes: C moves into the same station as A+B.
    configs, ops = [], []
    for model_index in range(8):
        for tempo, ct in ((1330, 31950 / 1330), (1065, 30.0)):
            model = f"337{model_index:05d}__T{tempo}"
            configs.append({"ModelNo": model, "HasApprovedMethodData": 1,
                            "CataPyro": "Cata", "ModelType": "Fan Assisted",
                            "ConfigReferenceCycleTimeSeconds": ct})
            for idx, op in enumerate("ABCDEF"):
                seq = idx + 1
                station = idx // (3 if tempo == 1065 else 2) + 1
                ops.append({"ModelNo": model, "OperationSequence": seq,
                            "CanonicalOperationId": "COP_" + op,
                            "OccurrenceIndex": 1, "StationType": "Main",
                            "StationSequence": station,
                            "OperationTimeSeconds": 9.0})
    return pd.DataFrame(ops), pd.DataFrame(configs)


def test_group_model():
    operations, config = artificial_approved_methods()
    estimator, stats = fit_station_group_model(operations, config)
    assert estimator is not None, stats
    assert stats["status"] == "TRAINED", stats
    assert stats["model_count"] == 8, stats
    results = {}
    for ct in (31950.0 / 1330, 30.0):
        examples = [{"CanonicalOperationId": "COP_" + op,
                     "OccurrenceIndex": 1, "PredictedStationType": "Main",
                     "PredictedTimeSeconds": 9.0} for op in "ABCDEF"]
        count = annotate_station_groups(examples, {
            "ConfigReferenceCycleTimeSeconds": ct,
            "CataPyro": "Cata", "ModelType": "Fan Assisted",
        }, {"station_group_estimator": estimator})
        assert count == 5, count
        results[ct] = examples[1]["LearnedSameStationWithNextProbability"]
    assert results[30.0] > results[31950.0 / 1330], results
    return stats, results


def test_safe_grouping():
    # A+B or B+C are both within 8s capacity. Learned probability for
    # A+B must break the tie, without increasing workforce or violating order.
    operations = [
        {"CanonicalOperationId": name, "OccurrenceIndex": 1,
         "CanonicalName": name, "PredictedTimeSeconds": 4.,
         "PreferredPhysicalStationNumber": i + 1,
         "LearnedSameStationWithNextProbability": p}
        for i, (name, p) in enumerate((("A", 0.99), ("B", 0.05), ("C", None)))
    ]
    solution = _fast_global_staffing(
        operations=operations, candidates=[1, 2, 3],
        max_station_load=8., station_count=2, precedence_edges=[],
        max_move_candidates=None, pallet_anchor_radius=3,
        max_time_seconds=10,
    )
    assert solution is not None, 'No MILP solution'
    result = solution['AssignedCandidateIndices']
    assert result[0] == result[1], result
    assert result[1] <= result[2], result
    assert len(set(result)) == 2, result
    return result


if __name__ == "__main__":
    print("GROUP_MODEL", test_group_model())
    print("STAFFING", test_safe_grouping())
    print("ALL TESTS PASS")
