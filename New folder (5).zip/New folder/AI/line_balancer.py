﻿# -*- coding: utf-8 -*-
import math
import statistics
import time
from collections import defaultdict
from typing import List, Dict, Any
from orientation_sync import orientation_phases, is_pallet_turn, validate_orientation
from adaptive_reorder import propose_single_reorder
from contextvars import ContextVar
_CK2_ALLOW_REVIEW_VARIANT = ContextVar("ck2_allow_review_variant", default=False)



def _is_seated_fan_cover(operation):
    from common import normalize_text
    name = normalize_text(operation.get('CanonicalName', ''))
    return ('FAN' in name and ('KAPAG' in name or 'KAPAK' in name)
            and 'VIDA' in name and ('SABIT' in name or 'SIK' in name))


def _is_standing_side_panel(operation):
    from common import normalize_text
    name = normalize_text(operation.get('CanonicalName', ''))
    return ('YAN' in name and ('SAC' in name or 'PANEL' in name)
            and ('SAG' in name or 'SOL' in name)
            and any(term in name for term in ('TAK', 'VIDA', 'SABIT', 'MONTAJ')))


def _seated_fan_station_compatible(operations):
    """User-confirmed seated fan task may share only observed compatible work.

    Co-location learning is authorised by the user from the human methods.
    The user's explicit standing-side-panel exclusion always wins over history.
    Unknown tasks cannot be silently mixed with the seated task.
    """
    if not any(_is_seated_fan_cover(op) for op in operations):
        return True
    return all(not _is_standing_side_panel(op)
               and (_is_seated_fan_cover(op)
                    or op.get('SeatedFanCompatible') is True)
               for op in operations)


SPECIAL_LABELS = {
    "DoorPreparation": "KAPI HAZIRLIK",
    "Test": "TEST İSTASYONU",
    "Visual": "GÖRSEL İSTASYON",
}


def _duration_value(operation):
    value = operation.get("PredictedTimeSeconds")

    if value is None:
        return 0.0

    return float(value)


def _ordered_greedy_count(
    operations,
    cycle_time
):
    if not operations:
        return 0

    count = 1
    current_load = 0.0

    for operation in operations:
        duration = _duration_value(
            operation
        )

        if duration > cycle_time + 1e-9:
            raise ValueError(
                f'{operation["CanonicalOperationId"]} tek başına '
                f'{duration:.3f} sn ve hedef CT '
                f'{cycle_time:.3f} sn. '
                "Operasyon bölünmeden hedef sağlanamaz."
            )

        if (
            current_load > 0.0
            and
            current_load +
            duration >
            cycle_time + 1e-9
        ):
            count += 1
            current_load = 0.0

        current_load += duration

    return count


def _preferred_station_indices(
    operations,
    station_count,
    station_profile=None
):
    if station_count <= 1:
        return [
            0
            for _ in operations
        ]

    result = []

    for operation in operations:
        process_position = float(
            operation.get(
                "PredictedProcessPosition",
                0.0
            )
        )

        station_position = float(
            operation.get(
                "PredictedStationPosition",
                process_position
            )
        )

        # Process order is more important than the old absolute
        # station position because target CT may change.
        blended_position = (
            0.75 *
            process_position
            +
            0.25 *
            station_position
        )

        blended_position = min(
            1.0,
            max(
                0.0,
                blended_position
            )
        )

        result.append(
            int(
                round(
                    blended_position *
                    (
                        station_count - 1
                    )
                )
            )
        )

    return result


def _build_instance_maps(
    operations
):
    by_instance_id = {}
    by_operation_id = defaultdict(
        list
    )

    for index, operation in enumerate(
        operations
    ):
        instance_id = str(
            operation.get(
                "InstanceId",
                f"IDX_{index}"
            )
        )

        by_instance_id[
            instance_id
        ] = index

        by_operation_id[
            str(
                operation[
                    "CanonicalOperationId"
                ]
            )
        ].append(
            (
                index,
                operation
            )
        )

    for operation_id in (
        by_operation_id.keys()
    ):
        by_operation_id[
            operation_id
        ].sort(
            key=lambda item: (
                int(
                    item[1].get(
                        "OccurrenceIndex",
                        1
                    )
                ),
                int(
                    item[1].get(
                        "PredictedProcessSequence",
                        item[0]
                    )
                ),
            )
        )

    return (
        by_instance_id,
        by_operation_id,
    )


def _hard_occurrence_edges(
    operations
):
    (
        _,
        by_operation_id,
    ) = _build_instance_maps(
        operations
    )

    edges = []

    for values in (
        by_operation_id.values()
    ):
        for index in range(
            len(values) - 1
        ):
            source_index = (
                values[index][0]
            )

            target_index = (
                values[index + 1][0]
            )

            edges.append(
                (
                    source_index,
                    target_index,
                )
            )

    return edges


def _soft_precedence_edges(
    operations,
    precedence_edges,
    max_edges=800
):
    (
        _,
        by_operation_id,
    ) = _build_instance_maps(
        operations
    )

    candidates = []

    for edge in (
        precedence_edges
        or []
    ):
        source_operation = str(
            edge.get(
                "Source",
                ""
            )
        )

        target_operation = str(
            edge.get(
                "Target",
                ""
            )
        )

        if (
            source_operation not in
            by_operation_id
            or
            target_operation not in
            by_operation_id
        ):
            continue

        source_values = (
            by_operation_id[
                source_operation
            ]
        )

        target_values = (
            by_operation_id[
                target_operation
            ]
        )

        # Engineering constraints override historical sequence.
        # Example: standard door-label operation is physically
        # forced to Station 1 even if old method files recorded it
        # at the end of the line.
        if any(
            value[1].get(
                "ForcedPhysicalStationNumber"
            ) is not None
            for value in (
                source_values +
                target_values
            )
        ):
            continue

        # Historical canonical precedence:
        # last occurrence of A should normally not be after
        # first occurrence of B.
        source_index = (
            source_values[-1][0]
        )

        target_index = (
            target_values[0][0]
        )

        if source_index == target_index:
            continue

        confidence = float(
            edge.get(
                "Confidence",
                0.0
            )
        )

        support = int(
            edge.get(
                "Support",
                0
            )
        )

        if (
            confidence < 0.90
            or support < 5
        ):
            continue

        score = (
            confidence *
            min(
                support,
                50
            )
        )

        candidates.append(
            (
                score,
                source_index,
                target_index,
                confidence,
                support,
            )
        )

    candidates.sort(
        key=lambda item: item[0],
        reverse=True
    )

    selected = []
    seen = set()

    for candidate in candidates:
        (
            score,
            source_index,
            target_index,
            confidence,
            support,
        ) = candidate

        key = (
            source_index,
            target_index,
        )

        if key in seen:
            continue

        seen.add(
            key
        )

        selected.append({
            "SourceIndex":
                source_index,
            "TargetIndex":
                target_index,
            "Confidence":
                confidence,
            "Support":
                support,
            "Score":
                score,
        })

        if len(
            selected
        ) >= max_edges:
            break

    return selected


def _greedy_assign_exact_count(
    operations,
    cycle_time,
    station_count
):
    if not operations:
        return []

    assignments = []
    current_station = 0
    current_load = 0.0

    remaining_operations = len(
        operations
    )

    for index, operation in enumerate(
        operations
    ):
        duration = _duration_value(
            operation
        )

        stations_remaining = (
            station_count -
            current_station
        )

        operations_remaining = (
            remaining_operations -
            index
        )

        should_move = (
            current_load > 0.0
            and (
                current_load +
                duration >
                cycle_time + 1e-9
                or (
                    stations_remaining > 1
                    and
                    operations_remaining <=
                    stations_remaining
                )
            )
        )

        if should_move:
            current_station += 1
            current_load = 0.0

        if current_station >= station_count:
            raise ValueError(
                "Sabit istasyon adedi ile hedef CT sağlanamadı."
            )

        assignments.append(
            current_station
        )

        current_load += duration

    return assignments


def _solve_partial_order_for_count(
    operations,
    cycle_time,
    station_count,
    precedence_edges,
    max_time_seconds=12.0
):
    try:
        from ortools.sat.python import (
            cp_model,
        )
    except Exception:
        return None

    operation_count = len(
        operations
    )

    if (
        station_count <= 0
        or
        operation_count == 0
    ):
        return None

    scale = 1000

    durations = [
        max(
            1,
            int(
                round(
                    _duration_value(
                        operation
                    ) *
                    scale
                )
            )
        )
        for operation in operations
    ]

    capacity = int(
        round(
            cycle_time *
            scale
        )
    )

    total_duration = sum(
        durations
    )

    for index, duration in enumerate(
        durations
    ):
        if duration > capacity:
            raise ValueError(
                f'{operations[index]["CanonicalOperationId"]} '
                f'tek başına '
                f'{duration / scale:.3f} sn ve '
                f'hedef CT {cycle_time:.3f} sn.'
            )

    # If exactly N stations are used and every station is capped at CT,
    # this is a mathematically valid lower bound for every station load.
    # At very tight lower-bound solutions (e.g. 19 x 30 sec), this
    # drastically reduces the CP-SAT search space.
    minimum_station_load = max(
        0,
        total_duration -
        (
            station_count - 1
        ) *
        capacity
    )

    model = cp_model.CpModel()

    assigned = [
        model.NewIntVar(
            0,
            station_count - 1,
            f"station_{index}"
        )
        for index in range(
            operation_count
        )
    ]

    # Hard engineering station placement rules.
    for operation_index, operation in enumerate(
        operations
    ):
        forced_ordinal = operation.get(
            "ForcedMainOrdinal"
        )

        if forced_ordinal is None:
            continue

        forced_index = int(
            forced_ordinal
        ) - 1

        if (
            forced_index < 0
            or
            forced_index >=
            station_count
        ):
            return None

        model.Add(
            assigned[
                operation_index
            ] ==
            forced_index
        )

    assignment_flags = {}

    for operation_index in range(
        operation_count
    ):
        flags = []

        for station_index in range(
            station_count
        ):
            flag = model.NewBoolVar(
                f"x_{operation_index}_{station_index}"
            )

            assignment_flags[
                (
                    operation_index,
                    station_index,
                )
            ] = flag

            model.Add(
                assigned[
                    operation_index
                ] ==
                station_index
            ).OnlyEnforceIf(
                flag
            )

            model.Add(
                assigned[
                    operation_index
                ] !=
                station_index
            ).OnlyEnforceIf(
                flag.Not()
            )

            flags.append(
                flag
            )

        model.Add(
            sum(
                flags
            ) == 1
        )

    station_loads = []

    for station_index in range(
        station_count
    ):
        load = model.NewIntVar(
            minimum_station_load,
            capacity,
            f"load_{station_index}"
        )

        model.Add(
            load ==
            sum(
                durations[
                    operation_index
                ] *
                assignment_flags[
                    (
                        operation_index,
                        station_index,
                    )
                ]
                for operation_index
                in range(
                    operation_count
                )
            )
        )

        model.Add(
            load <=
            capacity
        )

        if minimum_station_load > 0:
            model.Add(
                load >=
                minimum_station_load
            )

        # Every selected station must actually contain work.
        model.Add(
            sum(
                assignment_flags[
                    (
                        operation_index,
                        station_index,
                    )
                ]
                for operation_index
                in range(
                    operation_count
                )
            ) >= 1
        )

        station_loads.append(
            load
        )

    # Redundant but useful propagation.
    model.Add(
        sum(
            station_loads
        ) ==
        total_duration
    )

    # Only repeated occurrences are hard process constraints.
    hard_edges = (
        _hard_occurrence_edges(
            operations
        )
    )

    for (
        source_index,
        target_index,
    ) in hard_edges:
        model.Add(
            assigned[
                source_index
            ] <=
            assigned[
                target_index
            ]
        )

    # ---------------------------------------------
    # PHASE 1 — PURE FEASIBILITY
    # ---------------------------------------------
    # First answer the engineering question:
    # "Can this work content physically fit into N stations?"
    #
    # No historical preference objective is used in this phase.
    # This prevents an optimization objective from consuming the
    # entire time limit before a very tight feasible packing is found.
    feasibility_solver = (
        cp_model.CpSolver()
    )

    if minimum_station_load > 0:
        feasibility_time = max(
            35.0,
            max_time_seconds
        )
    else:
        feasibility_time = max(
            12.0,
            max_time_seconds
        )

    feasibility_solver.parameters.max_time_in_seconds = (
        feasibility_time
    )

    feasibility_solver.parameters.num_search_workers = (
        8
    )

    feasibility_status = (
        feasibility_solver.Solve(
            model
        )
    )

    if feasibility_status not in (
        cp_model.OPTIMAL,
        cp_model.FEASIBLE,
    ):
        return None

    base_assignments = [
        int(
            feasibility_solver.Value(
                variable
            )
        )
        for variable in assigned
    ]

    # Use the proven feasible solution as the starting hint
    # for the engineering-quality optimization phase.
    for (
        variable,
        value
    ) in zip(
        assigned,
        base_assignments
    ):
        model.AddHint(
            variable,
            value
        )

    # ---------------------------------------------
    # PHASE 2 — QUALITY OPTIMIZATION
    # ---------------------------------------------
    # Learned precedence is intentionally soft.
    soft_edges = (
        _soft_precedence_edges(
            operations,
            precedence_edges
        )
    )

    violation_flags = []

    for edge_index, edge in enumerate(
        soft_edges
    ):
        source_index = int(
            edge[
                "SourceIndex"
            ]
        )

        target_index = int(
            edge[
                "TargetIndex"
            ]
        )

        violation = model.NewBoolVar(
            f"precedence_violation_{edge_index}"
        )

        model.Add(
            assigned[
                source_index
            ] <=
            assigned[
                target_index
            ]
        ).OnlyEnforceIf(
            violation.Not()
        )

        model.Add(
            assigned[
                source_index
            ] >
            assigned[
                target_index
            ]
        ).OnlyEnforceIf(
            violation
        )

        weight = int(
            round(
                100.0 *
                float(
                    edge[
                        "Confidence"
                    ]
                )
                *
                min(
                    int(
                        edge[
                            "Support"
                        ]
                    ),
                    50
                )
            )
        )

        violation_flags.append(
            (
                violation,
                max(
                    weight,
                    1
                ),
            )
        )

    preferred = (
        _preferred_station_indices(
            operations,
            station_count
        )
    )

    deviations = []

    for index in range(
        operation_count
    ):
        deviation = model.NewIntVar(
            0,
            max(
                station_count - 1,
                0
            ),
            f"deviation_{index}"
        )

        model.AddAbsEquality(
            deviation,
            assigned[
                index
            ] -
            int(
                preferred[
                    index
                ]
            )
        )

        deviations.append(
            deviation
        )

    max_load = model.NewIntVar(
        minimum_station_load,
        capacity,
        "max_load"
    )

    min_load = model.NewIntVar(
        minimum_station_load,
        capacity,
        "min_load"
    )

    model.AddMaxEquality(
        max_load,
        station_loads
    )

    model.AddMinEquality(
        min_load,
        station_loads
    )

    load_spread = model.NewIntVar(
        0,
        capacity,
        "load_spread"
    )

    model.Add(
        load_spread ==
        max_load -
        min_load
    )

    precedence_penalty = sum(
        flag *
        weight
        for (
            flag,
            weight
        ) in violation_flags
    )

    position_penalty = sum(
        deviations
    )

    model.Minimize(
        precedence_penalty *
        10000
        +
        position_penalty *
        100
        +
        load_spread
    )

    quality_solver = (
        cp_model.CpSolver()
    )

    quality_solver.parameters.max_time_in_seconds = (
        max(
            12.0,
            max_time_seconds
        )
    )

    quality_solver.parameters.num_search_workers = (
        8
    )

    quality_status = (
        quality_solver.Solve(
            model
        )
    )

    if quality_status in (
        cp_model.OPTIMAL,
        cp_model.FEASIBLE,
    ):
        final_solver = (
            quality_solver
        )

        assignments = [
            int(
                final_solver.Value(
                    variable
                )
            )
            for variable in assigned
        ]

        violation_count = sum(
            int(
                final_solver.Value(
                    flag
                )
            )
            for (
                flag,
                _
            ) in violation_flags
        )

        weighted_violation = sum(
            int(
                final_solver.Value(
                    flag
                )
            ) *
            weight
            for (
                flag,
                weight
            ) in violation_flags
        )

        quality_status_name = (
            final_solver.StatusName(
                quality_status
            )
        )

    else:
        # Phase 1 already proved the station count feasible.
        # Never throw that valid result away just because the
        # secondary quality optimization timed out.
        assignments = (
            base_assignments
        )

        violation_count = 0
        weighted_violation = 0

        for edge in soft_edges:
            source_index = int(
                edge[
                    "SourceIndex"
                ]
            )

            target_index = int(
                edge[
                    "TargetIndex"
                ]
            )

            if (
                assignments[
                    source_index
                ] >
                assignments[
                    target_index
                ]
            ):
                violation_count += 1

                weight = int(
                    round(
                        100.0 *
                        float(
                            edge[
                                "Confidence"
                            ]
                        )
                        *
                        min(
                            int(
                                edge[
                                    "Support"
                                ]
                            ),
                            50
                        )
                    )
                )

                weighted_violation += max(
                    weight,
                    1
                )

        quality_status_name = (
            "FEASIBILITY_SOLUTION_USED"
        )

    diagnostics = {
        "StationCount":
            station_count,
        "HardOccurrenceEdges":
            len(
                hard_edges
            ),
        "SoftPrecedenceEdges":
            len(
                soft_edges
            ),
        "SoftPrecedenceViolations":
            violation_count,
        "WeightedPrecedenceViolation":
            weighted_violation,
        "MinimumStationLoadSeconds":
            minimum_station_load /
            scale,
        "TotalSlackSeconds":
            (
                station_count *
                capacity -
                total_duration
            ) /
            scale,
        "FeasibilityStatus":
            feasibility_solver.StatusName(
                feasibility_status
            ),
        "Status":
            quality_status_name,
    }

    return (
        assignments,
        diagnostics,
    )


def _cp_sat_assign_main(
    operations,
    cycle_time,
    precedence_edges
):
    if not operations:
        return (
            [],
            {
                "StationCount": 0,
                "Method": "NONE",
            },
        )

    total_duration = sum(
        _duration_value(
            operation
        )
        for operation in operations
    )

    lower_bound = int(
        math.ceil(
            (
                total_duration -
                1e-9
            ) /
            cycle_time
        )
    )

    lower_bound = max(
        lower_bound,
        1
    )

    ordered_upper_bound = (
        _ordered_greedy_count(
            operations,
            cycle_time
        )
    )

    for station_count in range(
        lower_bound,
        ordered_upper_bound + 1
    ):
        result = (
            _solve_partial_order_for_count(
                operations,
                cycle_time,
                station_count,
                precedence_edges
            )
        )

        if result is None:
            continue

        (
            assignments,
            diagnostics,
        ) = result

        diagnostics[
            "TheoreticalLowerBound"
        ] = lower_bound

        diagnostics[
            "OrderedGreedyUpperBound"
        ] = ordered_upper_bound

        diagnostics[
            "MainWorkContentSeconds"
        ] = total_duration

        diagnostics[
            "Method"
        ] = "CP_SAT_PARTIAL_ORDER"

        return (
            assignments,
            diagnostics,
        )

    # Defensive fallback: old ordered behaviour.
    assignments = (
        _greedy_assign_exact_count(
            operations,
            cycle_time,
            ordered_upper_bound
        )
    )

    return (
        assignments,
        {
            "StationCount":
                ordered_upper_bound,
            "TheoreticalLowerBound":
                lower_bound,
            "OrderedGreedyUpperBound":
                ordered_upper_bound,
            "MainWorkContentSeconds":
                total_duration,
            "SoftPrecedenceViolations":
                None,
            "Method":
                "ORDERED_GREEDY_FALLBACK",
        },
    )


def _cp_sat_assign_fixed_order(
    operations,
    cycle_time,
    station_count
):
    """
    Ordered special-process stations (DoorPreparation / Visual etc.)
    are partitioned into exactly station_count contiguous groups.

    Primary objective:
        Minimize the largest deviation from the ideal average load.

    Secondary objective:
        Minimize total absolute deviation from the ideal load.

    This is deterministic dynamic programming rather than CP-SAT,
    because for a fixed process order the real decision is only
    where the station boundaries are placed.
    """
    if not operations:
        return []

    operation_count = len(
        operations
    )

    if station_count <= 0:
        raise ValueError(
            "İstasyon adedi 0 olamaz."
        )

    if operation_count < station_count:
        raise ValueError(
            "Operasyon sayısı istasyon sayısından az. "
            "Her istasyonda en az bir operasyon olmalıdır."
        )

    durations = [
        _duration_value(
            operation
        )
        for operation in operations
    ]

    for index, duration in enumerate(
        durations
    ):
        if duration > cycle_time + 1e-9:
            raise ValueError(
                f'{operations[index]["CanonicalOperationId"]} '
                f'tek başına {duration:.3f} sn ve '
                f'hedef CT {cycle_time:.3f} sn.'
            )

    total_duration = sum(
        durations
    )

    ideal_load = (
        total_duration /
        station_count
    )

    prefix = [
        0.0
    ]

    for duration in durations:
        prefix.append(
            prefix[-1] +
            duration
        )

    # dp[part_count][operation_end_index]
    # cost tuple:
    # (
    #   maximum absolute deviation from ideal,
    #   total absolute deviation from ideal
    # )
    dp = [
        [
            None
            for _ in range(
                operation_count + 1
            )
        ]
        for _ in range(
            station_count + 1
        )
    ]

    parent = [
        [
            None
            for _ in range(
                operation_count + 1
            )
        ]
        for _ in range(
            station_count + 1
        )
    ]

    dp[0][0] = (
        0.0,
        0.0,
    )

    for part_count in range(
        1,
        station_count + 1
    ):
        minimum_end = (
            part_count
        )

        for end_index in range(
            minimum_end,
            operation_count + 1
        ):
            best_cost = None
            best_start = None

            # Leave at least one operation for every previous group.
            minimum_start = (
                part_count - 1
            )

            for start_index in range(
                minimum_start,
                end_index
            ):
                previous_cost = (
                    dp[
                        part_count - 1
                    ][
                        start_index
                    ]
                )

                if previous_cost is None:
                    continue

                load = (
                    prefix[
                        end_index
                    ] -
                    prefix[
                        start_index
                    ]
                )

                if load > (
                    cycle_time +
                    1e-9
                ):
                    continue

                deviation = abs(
                    load -
                    ideal_load
                )

                candidate_cost = (
                    max(
                        previous_cost[0],
                        deviation
                    ),
                    previous_cost[1] +
                    deviation,
                )

                if (
                    best_cost is None
                    or
                    candidate_cost <
                    best_cost
                ):
                    best_cost = (
                        candidate_cost
                    )

                    best_start = (
                        start_index
                    )

            dp[
                part_count
            ][
                end_index
            ] = best_cost

            parent[
                part_count
            ][
                end_index
            ] = best_start

    if (
        dp[
            station_count
        ][
            operation_count
        ] is None
    ):
        raise ValueError(
            "Sabit proses sırası ve mevcut istasyon adedi ile "
            "hedef CT sağlanamadı."
        )

    partitions = []

    current_end = (
        operation_count
    )

    for part_count in range(
        station_count,
        0,
        -1
    ):
        current_start = (
            parent[
                part_count
            ][
                current_end
            ]
        )

        if current_start is None:
            raise ValueError(
                "Dengeli istasyon bölme sonucu oluşturulamadı."
            )

        partitions.append(
            (
                current_start,
                current_end,
            )
        )

        current_end = (
            current_start
        )

    partitions.reverse()

    assignments = [
        0
        for _ in range(
            operation_count
        )
    ]

    for (
        station_index,
        partition
    ) in enumerate(
        partitions
    ):
        start_index, end_index = (
            partition
        )

        for operation_index in range(
            start_index,
            end_index
        ):
            assignments[
                operation_index
            ] = station_index

    return assignments


def _build_timed_zone(
    operations,
    cycle_time,
    max_station_load,
    max_saturation_percent,
    station_type,
    station_profile,
    fixed_count=None,
    precedence_edges=None
):
    if not operations:
        return (
            [],
            [],
            [],
        )

    ordered = sorted(
        operations,
        key=lambda item: (
            int(
                item.get(
                    "PredictedProcessSequence",
                    0
                )
            ),
            float(
                item.get(
                    "PredictedProcessPosition",
                    0.0
                )
            ),
        )
    )

    warnings = []
    diagnostics = None

    if (
        station_type == "Main"
        and fixed_count is None
    ):
        (
            assignments,
            diagnostics,
        ) = _cp_sat_assign_main(
            ordered,
            max_station_load,
            precedence_edges
        )

        station_count = int(
            diagnostics[
                "StationCount"
            ]
        )

        warnings.append(
            "MAIN_OPTIMIZER: "
            f"work_content="
            f'{diagnostics.get("MainWorkContentSeconds", 0.0):.3f} sn, '
            f'lower_bound='
            f'{diagnostics.get("TheoreticalLowerBound", station_count)}, '
            f'ordered_upper='
            f'{diagnostics.get("OrderedGreedyUpperBound", station_count)}, '
            f'assigned='
            f'{station_count}, '
            f'soft_precedence_violations='
            f'{diagnostics.get("SoftPrecedenceViolations", 0)}, '
            f'method='
            f'{diagnostics.get("Method", "")}.'
        )

    else:
        minimum_required = (
            _ordered_greedy_count(
                ordered,
                max_station_load
            )
        )

        # Door preparation and Visual are manual process zones.
        # Their historical count is a reference, not a physical hard limit.
        # When CT / maximum saturation changes, the optimizer may increase
        # or reduce their operator/station count automatically.
        if station_type in (
            "DoorPreparation",
            "Visual",
        ):
            station_count = max(
                1,
                minimum_required
            )

            if (
                fixed_count is not None
                and
                int(
                    fixed_count
                ) !=
                station_count
            ):
                warnings.append(
                    f"{station_type}: tarihsel "
                    f"{int(fixed_count)} istasyon yerine "
                    f"hedef CT {cycle_time:.3f} sn ve "
                    f"maksimum saturasyon "
                    f"%{max_saturation_percent:.1f} için "
                    f"{station_count} istasyon önerildi."
                )

        elif fixed_count is None:
            station_count = max(
                1,
                minimum_required
            )

        else:
            station_count = int(
                fixed_count
            )

            if (
                minimum_required >
                station_count
            ):
                raise ValueError(
                    f"{station_type} için tarihsel sabit "
                    f"{station_count} istasyon, "
                    f"hedef CT {cycle_time:.3f} sn ve "
                    f"maksimum saturasyon "
                    f"%{max_saturation_percent:.1f} altında yeterli değil. "
                    f"En az {minimum_required} istasyon gerekiyor."
                )

        assignments = (
            _cp_sat_assign_fixed_order(
                ordered,
                max_station_load,
                station_count
            )
        )

    station_operations = defaultdict(
        list
    )

    for (
        operation,
        station_index
    ) in zip(
        ordered,
        assignments
    ):
        station_operations[
            station_index + 1
        ].append(
            operation
        )

    result_operations = []
    station_records = []

    for local_station in range(
        1,
        station_count + 1
    ):
        assigned_operations = (
            station_operations.get(
                local_station,
                []
            )
        )

        # Within a station, display the AI predicted topological sequence.
        assigned_operations.sort(
            key=lambda item: (
                int(
                    item.get(
                        "PredictedProcessSequence",
                        0
                    )
                ),
                float(
                    item.get(
                        "PredictedProcessPosition",
                        0.0
                    )
                ),
            )
        )

        load = sum(
            _duration_value(
                operation
            )
            for operation
            in assigned_operations
        )

        station_records.append({
            "StationType":
                station_type,
            "StationWithinType":
                local_station,
            "StationLoadSeconds":
                load,
            "StationCycleSource":
                "SUM_OPERATION_TIMES",
            "StationSaturationPercent":
                (
                    load /
                    cycle_time *
                    100.0
                    if cycle_time > 0
                    else 0.0
                ),
            "MaxTargetSaturationPercent":
                max_saturation_percent,
            "SaturationLimitExceeded":
                (
                    load >
                    max_station_load +
                    1e-9
                ),
            "StationFeasible":
                load <=
                max_station_load +
                1e-9,
        })

        for (
            operation_index,
            operation
        ) in enumerate(
            assigned_operations,
            start=1
        ):
            item = dict(
                operation
            )

            item[
                "AssignedStationType"
            ] = station_type

            item[
                "StationWithinType"
            ] = local_station

            item[
                "StationOperationSequence"
            ] = operation_index

            item[
                "StationLoadSeconds"
            ] = load

            item[
                "StationSaturationPercent"
            ] = (
                load /
                cycle_time *
                100.0
                if cycle_time > 0
                else 0.0
            )

            item[
                "StationCycleSource"
            ] = "SUM_OPERATION_TIMES"

            item[
                "MaxTargetSaturationPercent"
            ] = max_saturation_percent

            item[
                "SaturationLimitExceeded"
            ] = (
                load >
                max_station_load +
                1e-9
            )

            result_operations.append(
                item
            )

    return (
        result_operations,
        station_records,
        warnings,
    )


def _ck2_station_count(station_profile, station_type="Special"):
    """Derive a missing profile count from real observations, never invent station IDs."""
    raw = station_profile.get("CountMode")
    if raw is not None and str(raw).strip():
        try:
            value = int(raw)
        except (TypeError, ValueError, OverflowError) as error:
            raise ValueError(
                f"{station_type}: tarihsel CountMode değeri geçersiz: {raw!r}"
            ) from error
        if value > 0:
            return value
    ordinals = station_profile.get("StationOrdinals") or []
    if ordinals:
        return len(ordinals)
    layouts = station_profile.get("PhysicalLayoutsByCount") or {}
    for key, numbers in layouts.items():
        if numbers and str(key).isdigit() and int(key) == len(numbers):
            return len(numbers)
    physical_numbers = [number for number in
                        (station_profile.get("PhysicalStationNumbers") or [])
                        if number is not None]
    if physical_numbers:
        return len(set(physical_numbers))
    raise ValueError(
        f"{station_type}: CountMode ve gerçek istasyon profili bulunamadı. "
        "Veri setini ve modelin özel proses kayıtlarını kontrol edin."
    )


def _aggregate_operation_counts(
    total_operation_count,
    station_profile
):
    ordinal_profiles = (
        station_profile.get(
            "StationOrdinals",
            []
        )
    )

    station_count = _ck2_station_count(station_profile)

    historical_counts = [
        max(
            0.0,
            float(
                item.get(
                    "MedianOperationCount",
                    0.0
                )
            )
        )
        for item in ordinal_profiles[
            :station_count
        ]
    ]

    if (
        len(
            historical_counts
        ) != station_count
        or sum(
            historical_counts
        ) <= 0.0
    ):
        historical_counts = [
            1.0
            for _ in range(
                station_count
            )
        ]

    total_weight = sum(
        historical_counts
    )

    raw_counts = [
        (
            total_operation_count *
            weight /
            total_weight
        )
        for weight in historical_counts
    ]

    counts = [
        int(
            value
        )
        for value in raw_counts
    ]

    assigned = sum(
        counts
    )

    remaining = (
        total_operation_count -
        assigned
    )

    fractional_order = sorted(
        range(
            station_count
        ),
        key=lambda index: (
            raw_counts[
                index
            ] -
            counts[
                index
            ]
        ),
        reverse=True
    )

    for index in fractional_order[
        :remaining
    ]:
        counts[
            index
        ] += 1

    return counts


def _build_aggregate_zone(
    operations,
    cycle_time,
    max_station_load,
    max_saturation_percent,
    station_type,
    station_profile
):
    if not operations:
        return (
            [],
            [],
            [],
        )

    ordered = sorted(
        operations,
        key=lambda item: (
            int(
                item.get(
                    "PredictedProcessSequence",
                    0
                )
            ),
            float(
                item.get(
                    "PredictedProcessPosition",
                    0.0
                )
            ),
        )
    )

    station_count = _ck2_station_count(station_profile, station_type)

    counts = (
        _aggregate_operation_counts(
            len(
                ordered
            ),
            station_profile
        )
    )

    ordinal_profiles = (
        station_profile.get(
            "StationOrdinals",
            []
        )
    )

    # Follow the approved reference: how many aggregate stations (e.g. 1 merged
    # test station at 30 s CT, 3 parallel ones at 24 s CT) it has decides the
    # station count, the operation split and the learned per-station time.
    reference_sequences = sorted({
        int(item["PreservedReferenceStationSequence"])
        for item in ordered
        if item.get("PreservedReferenceStationSequence") is not None
    })
    if reference_sequences:
        ordered = sorted(
            ordered,
            key=lambda item: (
                int(item.get("PreservedReferenceStationSequence") or 0),
                int(item.get("PreservedReferenceStationOperationSequence") or 0),
            ),
        )
        station_count = len(reference_sequences)
        counts = [
            sum(1 for item in ordered
                if int(item["PreservedReferenceStationSequence"]) == sequence)
            for sequence in reference_sequences
        ]
        by_count = station_profile.get("StationOrdinalsByCount") or {}
        if by_count.get(str(station_count)):
            ordinal_profiles = by_count[str(station_count)]

    result_operations = []
    station_records = []
    warnings = []

    cursor = 0

    for local_station in range(
        1,
        station_count + 1
    ):
        operation_count = counts[
            local_station - 1
        ]

        assigned_operations = ordered[
            cursor:
            cursor + operation_count
        ]

        cursor += operation_count

        ordinal_profile = (
            ordinal_profiles[
                local_station - 1
            ]
            if (
                local_station - 1 <
                len(
                    ordinal_profiles
                )
            )
            else {}
        )

        learned_cycle_time = float(
            ordinal_profile.get(
                "MedianCycleTimeSeconds",
                0.0
            )
        )

        feasible = (
            learned_cycle_time <=
            max_station_load +
            1e-9
        )

        if not feasible:
            warnings.append(
                f"{station_type} {local_station}: "
                f"tarihsel çevrim {learned_cycle_time:.3f} sn, "
                f"hedef CT {cycle_time:.3f} sn. "
                "Özel proses kapasitesi yetersiz."
            )

        station_records.append({
            "StationType":
                station_type,
            "StationWithinType":
                local_station,
            "StationLoadSeconds":
                learned_cycle_time,
            "StationCycleSource":
                "HISTORICAL_STATION_AGGREGATE",
            "StationSaturationPercent":
                (
                    learned_cycle_time /
                    cycle_time *
                    100.0
                    if cycle_time > 0
                    else 0.0
                ),
            "MaxTargetSaturationPercent":
                max_saturation_percent,
            "SaturationLimitExceeded":
                not feasible,
            "StationFeasible":
                feasible,
        })

        for (
            operation_index,
            operation
        ) in enumerate(
            assigned_operations,
            start=1
        ):
            item = dict(
                operation
            )

            item[
                "PredictedTimeSeconds"
            ] = None

            item[
                "TimeSource"
            ] = (
                "STATION_AGGREGATE_" +
                f"{learned_cycle_time:.3f}_SEC"
            )

            item[
                "AssignedStationType"
            ] = station_type

            item[
                "StationWithinType"
            ] = local_station

            item[
                "StationOperationSequence"
            ] = operation_index

            item[
                "StationLoadSeconds"
            ] = learned_cycle_time

            item[
                "StationSaturationPercent"
            ] = (
                learned_cycle_time /
                cycle_time *
                100.0
                if cycle_time > 0
                else 0.0
            )

            item[
                "StationCycleSource"
            ] = (
                "HISTORICAL_STATION_AGGREGATE"
            )

            item[
                "MaxTargetSaturationPercent"
            ] = max_saturation_percent

            item[
                "SaturationLimitExceeded"
            ] = not feasible

            result_operations.append(
                item
            )

    return (
        result_operations,
        station_records,
        warnings,
    )


def _nearest_candidate_index(
    candidates,
    value
):
    if not candidates:
        return 0

    return min(
        range(
            len(
                candidates
            )
        ),
        key=lambda index: abs(
            float(
                candidates[
                    index
                ]
            ) -
            float(
                value
            )
        )
    )


def _assign_main_physical_station_numbers(
    main_station_records,
    main_operations,
    main_profile
):
    station_count = len(
        main_station_records
    )

    if station_count == 0:
        return []

    layouts = (
        main_profile.get(
            "PhysicalLayoutsByCount",
            {}
        )
    )

    exact_layout = layouts.get(
        str(
            station_count
        )
    )

    # If training contains the exact real-line layout for this
    # station count, use it directly.
    if (
        exact_layout
        and
        len(
            exact_layout
        ) ==
        station_count
    ):
        return [
            int(
                value
            )
            for value
            in exact_layout
        ]

    candidates = sorted({
        int(
            value
        )
        for value in (
            main_profile.get(
                "PhysicalStationNumbers",
                []
            )
        )
        if value is not None
    })

    if not candidates:
        return [
            None
            for _ in range(
                station_count
            )
        ]

    if station_count > len(
        candidates
    ):
        raise ValueError(
            "Hedef için gereken Main istasyon sayısı, "
            "öğrenilmiş fiziksel ana-hat istasyon sayısından fazla. "
            f"Gereken={station_count}, "
            f"öğrenilmiş fiziksel istasyon={len(candidates)}."
        )

    operations_by_station = defaultdict(
        list
    )

    for operation in main_operations:
        local_station = int(
            operation.get(
                "StationWithinType",
                0
            )
        )

        if local_station > 0:
            operations_by_station[
                local_station
            ].append(
                operation
            )

    target_indices = []
    forced_numbers = []

    for local_station in range(
        1,
        station_count + 1
    ):
        operations = (
            operations_by_station.get(
                local_station,
                []
            )
        )

        forced = sorted({
            int(
                operation[
                    "ForcedPhysicalStationNumber"
                ]
            )
            for operation in operations
            if operation.get(
                "ForcedPhysicalStationNumber"
            ) is not None
        })

        if len(
            forced
        ) > 1:
            raise ValueError(
                "Aynı AI istasyonuna birden fazla farklı "
                "zorunlu fiziksel istasyon kuralı düştü: " +
                ", ".join(
                    str(
                        value
                    )
                    for value
                    in forced
                )
            )

        forced_number = (
            forced[0]
            if forced
            else None
        )

        if (
            forced_number is not None
            and
            forced_number not in candidates
        ):
            raise ValueError(
                f"Zorunlu fiziksel istasyon "
                f"{forced_number}, öğrenilmiş Main "
                "fiziksel istasyon listesinde yok."
            )

        preferred_values = [
            float(
                operation[
                    "PreferredPhysicalStationNumber"
                ]
            )
            for operation in operations
            if operation.get(
                "PreferredPhysicalStationNumber"
            ) is not None
        ]

        if forced_number is not None:
            target_index = (
                candidates.index(
                    forced_number
                )
            )

        elif preferred_values:
            preferred_number = (
                statistics.median(
                    preferred_values
                )
            )

            target_index = (
                _nearest_candidate_index(
                    candidates,
                    preferred_number
                )
            )

        elif station_count <= 1:
            target_index = 0

        else:
            target_index = int(
                round(
                    (
                        local_station -
                        1
                    )
                    *
                    (
                        len(
                            candidates
                        ) -
                        1
                    )
                    /
                    (
                        station_count -
                        1
                    )
                )
            )

        target_indices.append(
            target_index
        )

        forced_numbers.append(
            forced_number
        )

    # Dynamic programming:
    # choose a strictly increasing subset of real physical
    # stations that best matches operation history.
    infinity = float(
        "inf"
    )

    dp = [
        [
            infinity
            for _ in candidates
        ]
        for _ in range(
            station_count
        )
    ]

    parent = [
        [
            None
            for _ in candidates
        ]
        for _ in range(
            station_count
        )
    ]

    for candidate_index in range(
        0,
        len(
            candidates
        ) -
        station_count +
        1
    ):
        if (
            forced_numbers[0]
            is not None
            and
            candidates[
                candidate_index
            ] !=
            forced_numbers[0]
        ):
            continue

        dp[0][
            candidate_index
        ] = abs(
            candidate_index -
            target_indices[0]
        )

    for station_index in range(
        1,
        station_count
    ):
        minimum_candidate = (
            station_index
        )

        maximum_candidate = (
            len(
                candidates
            ) -
            (
                station_count -
                station_index
            )
        )

        for candidate_index in range(
            minimum_candidate,
            maximum_candidate + 1
        ):
            if candidate_index >= len(
                candidates
            ):
                continue

            if (
                forced_numbers[
                    station_index
                ] is not None
                and
                candidates[
                    candidate_index
                ] !=
                forced_numbers[
                    station_index
                ]
            ):
                continue

            own_cost = abs(
                candidate_index -
                target_indices[
                    station_index
                ]
            )

            best_previous = None
            best_cost = infinity

            for previous_index in range(
                station_index - 1,
                candidate_index
            ):
                previous_cost = dp[
                    station_index - 1
                ][
                    previous_index
                ]

                if previous_cost == infinity:
                    continue

                candidate_cost = (
                    previous_cost +
                    own_cost
                )

                if (
                    candidate_cost <
                    best_cost
                ):
                    best_cost = (
                        candidate_cost
                    )

                    best_previous = (
                        previous_index
                    )

            if best_previous is not None:
                dp[
                    station_index
                ][
                    candidate_index
                ] = best_cost

                parent[
                    station_index
                ][
                    candidate_index
                ] = best_previous

    last_station = (
        station_count -
        1
    )

    valid_last_indices = [
        index
        for index, value
        in enumerate(
            dp[
                last_station
            ]
        )
        if value != infinity
    ]

    if not valid_last_indices:
        raise ValueError(
            "Gerçek fiziksel Main istasyon numaraları "
            "AI istasyonlarına monoton olarak atanamadı."
        )

    current_index = min(
        valid_last_indices,
        key=lambda index: dp[
            last_station
        ][
            index
        ]
    )

    selected_indices = [
        current_index
    ]

    for station_index in range(
        last_station,
        0,
        -1
    ):
        current_index = parent[
            station_index
        ][
            current_index
        ]

        selected_indices.append(
            current_index
        )

    selected_indices.reverse()

    return [
        candidates[
            index
        ]
        for index
        in selected_indices
    ]


def _special_physical_station_numbers(
    station_type,
    station_count,
    profile
):
    layouts = profile.get(
        "PhysicalLayoutsByCount",
        {}
    )

    exact_layout = layouts.get(
        str(
            station_count
        )
    )

    if (
        exact_layout
        and
        len(
            exact_layout
        ) ==
        station_count
    ):
        # Historical special stations can have no documented physical ID.
        # Keep them UNNUMBERED rather than crashing on int(None) or
        # fabricating an electrical-test/visual workstation number.
        def _physical_number(value):
            if value is None or str(value).strip() == "":
                return None
            try:
                return int(value)
            except (TypeError, ValueError, OverflowError) as error:
                raise ValueError(
                    f"{station_type}: fiziksel istasyon numarası geçersiz: {value!r}"
                ) from error
        return [_physical_number(value) for value in exact_layout]

    candidates = sorted({
        int(
            value
        )
        for value in profile.get(
            "PhysicalStationNumbers",
            []
        )
        if value is not None
    })

    if station_count <= len(
        candidates
    ):
        return candidates[
            :station_count
        ]

    # Do not invent a factory station number that training data
    # has never shown. Extra capacity is explicitly marked as EK.
    return (
        candidates +
        [
            None
            for _ in range(
                station_count -
                len(
                    candidates
                )
            )
        ]
    )


def _station_label(
    station_type,
    station_within_type,
    physical_station_number=None,
    extra_index=None
):
    if station_type == "Main":
        if physical_station_number is not None:
            return (
                f"{int(physical_station_number)}.İSTASYON"
            )

        return (
            f"ANA HAT {station_within_type}"
        )

    prefix = SPECIAL_LABELS.get(
        station_type,
        station_type.upper()
    )

    if physical_station_number is not None:
        return (
            f"{prefix} "
            f"{int(physical_station_number)}"
        )

    if extra_index is not None:
        return (
            f"{prefix} EK-{extra_index}"
        )

    return (
        f"{prefix} "
        f"{station_within_type}"
    )


def _parallel_feeder_consumer(reference_operations, station_type):
    """Conservative supply dependency from the approved reference method.

    The first Main operation after this source block must have its component
    available. The feeder may be displayed before that ENTIRE Main station;
    it does not split the Main operation sequence into two physical stations.
    """
    sequence = lambda op: int(op.get('AdaptiveReferenceSequence')
                              or op.get('PredictedProcessSequence') or 0)
    feeder = [op for op in reference_operations
              if op.get('PredictedStationType', op.get('AssignedStationType', 'Main')) == station_type]
    if not feeder:
        raise ValueError('PARALLEL_FEEDER_REFERENCE_MISSING: ' + station_type)
    last = max(sequence(op) for op in feeder)
    following = [op for op in reference_operations
                 if op.get('PredictedStationType', op.get('AssignedStationType', 'Main')) == 'Main'
                 and sequence(op) > last]
    if not following:
        raise ValueError('PARALLEL_FEEDER_CONSUMER_MISSING: ' + station_type)
    return min(following, key=sequence)


def _validate_parallel_feeder_supply(source, operations, station_type):
    consumer = _parallel_feeder_consumer(source, station_type)
    identity = lambda op: (str(op.get('CanonicalOperationId')), int(op.get('OccurrenceIndex') or 1))
    placed = {identity(op): op for op in operations}
    if identity(consumer) not in placed:
        raise ValueError('PARALLEL_FEEDER_CONSUMER_LOST')
    consumer_station = int(placed[identity(consumer)]['DisplayOrder'])
    feeder = [op for op in operations
              if op.get('AssignedStationType', op.get('PredictedStationType')) == station_type]
    if not feeder or any(int(op['DisplayOrder']) >= consumer_station for op in feeder):
        raise ValueError('PARALLEL_FEEDER_SUPPLY_ORDER_VIOLATION')
    return identity(consumer)


def _merge_station_layout(
    zone_operations,
    zone_station_records,
    station_type_profiles,
    reference_operations=None,
):
    main_station_records = (
        zone_station_records.get(
            "Main",
            []
        )
    )

    main_station_count = len(
        main_station_records
    )

    main_operations = (
        zone_operations.get(
            "Main",
            []
        )
    )

    main_profile = (
        station_type_profiles.get(
            "Main",
            {}
        )
    )

    main_physical_numbers = (
        _assign_main_physical_station_numbers(
            main_station_records,
            main_operations,
            main_profile
        )
    )

    special_types = [
        station_type
        for station_type in
        zone_station_records.keys()
        if station_type != "Main"
    ]

    special_types.sort(
        key=lambda station_type: (
            float(
                station_type_profiles.get(
                    station_type,
                    {}
                ).get(
                    "BlockAnchorAfterMainFraction",
                    1.0
                )
            ),
            float(
                station_type_profiles.get(
                    station_type,
                    {}
                ).get(
                    "HistoricalOrderRank",
                    1.0
                )
            ),
            station_type,
        )
    )

    special_physical_numbers = {}

    for station_type in special_types:
        records = (
            zone_station_records[
                station_type
            ]
        )

        special_physical_numbers[
            station_type
        ] = (
            _special_physical_station_numbers(
                station_type,
                len(
                    records
                ),
                station_type_profiles.get(
                    station_type,
                    {}
                )
            )
        )

    special_after_main = defaultdict(
        list
    )

    # Historical ratios are unsuitable once station count changes. Anchor
    # every special process block to its actual predecessor MAIN operation.
    ref_main_by_id = {}
    if reference_operations:
        for op in zone_operations.get("Main", []):
            ref_main_by_id[
                (str(op.get("CanonicalOperationId")),
                 int(op.get("OccurrenceIndex", 1)))
            ] = int(op["StationWithinType"])

    for station_type in special_types:
        if (reference_operations and
                station_type_profiles.get(station_type, {}).get('ParallelFeeder', False)):
            consumer = _parallel_feeder_consumer(reference_operations, station_type)
            consumer_key = (str(consumer.get('CanonicalOperationId')),
                            int(consumer.get('OccurrenceIndex') or 1))
            if consumer_key not in ref_main_by_id:
                raise ValueError('PARALLEL_FEEDER_MAIN_ASSIGNMENT_MISSING')
            main_before = ref_main_by_id[consumer_key] - 1
        elif reference_operations:
            special_reference = [op for op in reference_operations
                                 if str(op.get("PredictedStationType", "Main"))
                                 == station_type]
            if not special_reference:
                raise ValueError("Referans özel proses bloğu eksik: " + station_type)
            first_sequence = min(int(op["AdaptiveReferenceSequence"])
                                 for op in special_reference)
            before_main = [op for op in reference_operations
                           if str(op.get("PredictedStationType", "Main")) == "Main"
                           and int(op["AdaptiveReferenceSequence"]) < first_sequence]
            if before_main:
                preceding_stations = []
                for predecessor in before_main:
                    key = (str(predecessor["CanonicalOperationId"]),
                           int(predecessor.get("OccurrenceIndex", 1)))
                    if key not in ref_main_by_id:
                        raise ValueError("Özel proses referans Main bağı bulunamadı.")
                    preceding_stations.append(ref_main_by_id[key])
                main_before = max(preceding_stations)
            else:
                main_before = 0
        else:
            profile = station_type_profiles.get(station_type, {})
            fraction = float(profile.get("BlockAnchorAfterMainFraction", 1.0))
            main_before = int(round(fraction * main_station_count))
            main_before = max(0, min(main_before, main_station_count))
        special_after_main[main_before].append(station_type)

    for main_before in (
        special_after_main.keys()
    ):
        special_after_main[
            main_before
        ].sort(
            key=lambda station_type: (
                float(
                    station_type_profiles.get(
                        station_type,
                        {}
                    ).get(
                        "HistoricalOrderRank",
                        1.0
                    )
                ),
                station_type,
            )
        )

    global_station_records = []
    station_map = {}
    global_station_no = 0

    def append_special_blocks(
        main_before_count
    ):
        nonlocal global_station_no

        for station_type in (
            special_after_main.get(
                main_before_count,
                []
            )
        ):
            physical_values = (
                special_physical_numbers.get(
                    station_type,
                    []
                )
            )

            extra_counter = 0

            for record_index, record in enumerate(
                zone_station_records[
                    station_type
                ]
            ):
                global_station_no += 1

                physical_number = (
                    physical_values[
                        record_index
                    ]
                    if (
                        record_index <
                        len(
                            physical_values
                        )
                    )
                    else None
                )

                extra_index = None

                if physical_number is None:
                    extra_counter += 1
                    extra_index = (
                        extra_counter
                    )

                mapped = dict(
                    record
                )

                mapped[
                    "AssignedStation"
                ] = global_station_no

                mapped[
                    "DisplayOrder"
                ] = global_station_no

                mapped[
                    "PhysicalStationNumber"
                ] = physical_number

                mapped[
                    "AssignedStationLabel"
                ] = _station_label(
                    station_type,
                    int(
                        record[
                            "StationWithinType"
                        ]
                    ),
                    physical_number,
                    extra_index
                )

                global_station_records.append(
                    mapped
                )

                station_map[
                    (
                        station_type,
                        int(
                            record[
                                "StationWithinType"
                            ]
                        ),
                    )
                ] = (
                    global_station_no,
                    mapped[
                        "AssignedStationLabel"
                    ],
                    physical_number,
                )

    append_special_blocks(
        0
    )

    for main_index in range(
        1,
        main_station_count + 1
    ):
        record = dict(
            main_station_records[
                main_index - 1
            ]
        )

        global_station_no += 1

        physical_number = (
            main_physical_numbers[
                main_index - 1
            ]
            if (
                main_index - 1 <
                len(
                    main_physical_numbers
                )
            )
            else None
        )

        record[
            "AssignedStation"
        ] = global_station_no

        record[
            "DisplayOrder"
        ] = global_station_no

        record[
            "PhysicalStationNumber"
        ] = physical_number

        record[
            "AssignedStationLabel"
        ] = _station_label(
            "Main",
            main_index,
            physical_number
        )

        global_station_records.append(
            record
        )

        station_map[
            (
                "Main",
                main_index,
            )
        ] = (
            global_station_no,
            record[
                "AssignedStationLabel"
            ],
            physical_number,
        )

        append_special_blocks(
            main_index
        )

    final_operations = []

    for (
        station_type,
        operations
    ) in zone_operations.items():
        for operation in operations:
            key = (
                station_type,
                int(
                    operation[
                        "StationWithinType"
                    ]
                ),
            )

            (
                global_no,
                label,
                physical_number,
            ) = station_map[
                key
            ]

            item = dict(
                operation
            )

            item[
                "AssignedStation"
            ] = global_no

            item[
                "DisplayOrder"
            ] = global_no

            item[
                "PhysicalStationNumber"
            ] = physical_number

            item[
                "AssignedStationLabel"
            ] = label

            final_operations.append(
                item
            )

    final_operations.sort(
        key=lambda item: (
            int(
                item[
                    "DisplayOrder"
                ]
            ),
            int(
                item.get(
                    "StationOperationSequence",
                    0
                )
            ),
            int(
                item.get(
                    "PredictedProcessSequence",
                    0
                )
            ),
        )
    )

    for sequence, operation in enumerate(
        final_operations,
        start=1
    ):
        operation[
            "Sequence"
        ] = sequence

    return (
        final_operations,
        global_station_records,
    )


def balance_operations(
    operations: List[Dict[str, Any]],
    cycle_time: float,
    station_type_profiles: Dict[str, Any],
    precedence_edges=None,
    max_saturation_percent: float = 100.0,
):
    if not operations:
        return (
            [],
            [],
            "NONE",
            [],
        )

    if (
        max_saturation_percent <= 0.0
        or
        max_saturation_percent > 100.0
    ):
        raise ValueError(
            "Maksimum hedef saturasyon 0 ile 100 arasında olmalıdır."
        )

    max_station_load = (
        cycle_time *
        max_saturation_percent /
        100.0
    )

    by_type = defaultdict(
        list
    )

    for operation in operations:
        station_type = str(
            operation.get(
                "PredictedStationType",
                "Main"
            )
        )

        by_type[
            station_type
        ].append(
            operation
        )

    zone_operations = {}
    zone_station_records = {}
    warnings = []
    balancer_names = []

    main_operations = (
        by_type.pop(
            "Main",
            []
        )
    )

    if main_operations:
        (
            balanced_operations,
            station_records,
            zone_warnings,
        ) = _build_timed_zone(
            main_operations,
            cycle_time,
            max_station_load,
            max_saturation_percent,
            "Main",
            station_type_profiles.get(
                "Main",
                {}
            ),
            fixed_count=None,
            precedence_edges=
                precedence_edges
        )

        zone_operations[
            "Main"
        ] = balanced_operations

        zone_station_records[
            "Main"
        ] = station_records

        warnings.extend(
            zone_warnings
        )

        balancer_names.append(
            "MAIN_CP_SAT_PARTIAL_ORDER"
        )

    for (
        station_type,
        type_operations
    ) in by_type.items():
        profile = (
            station_type_profiles.get(
                station_type,
                {}
            )
        )

        if not profile:
            raise ValueError(
                f"{station_type} için tarihsel istasyon profili bulunamadı."
            )

        if profile.get(
            "AggregateStationTime",
            False
        ):
            (
                balanced_operations,
                station_records,
                zone_warnings,
            ) = _build_aggregate_zone(
                type_operations,
                cycle_time,
                max_station_load,
                max_saturation_percent,
                station_type,
                profile
            )

            balancer_names.append(
                station_type.upper() +
                "_AGGREGATE"
            )

        else:
            fixed_count = (
                _ck2_station_count(profile, station_type)
                if profile.get("FixedCount", False)
                else None
            )

            (
                balanced_operations,
                station_records,
                zone_warnings,
            ) = _build_timed_zone(
                type_operations,
                cycle_time,
                max_station_load,
                max_saturation_percent,
                station_type,
                profile,
                fixed_count=
                    fixed_count,
                precedence_edges=None
            )

            balancer_names.append(
                station_type.upper() +
                "_CP_SAT_FIXED_ORDER"
            )

        zone_operations[
            station_type
        ] = balanced_operations

        zone_station_records[
            station_type
        ] = station_records

        warnings.extend(
            zone_warnings
        )

    (
        final_operations,
        station_records,
    ) = _merge_station_layout(
        zone_operations,
        zone_station_records,
        station_type_profiles
    )

    for record in station_records:
        if (
            record.get(
                "StationType"
            ) != "Main"
            and
            record.get(
                "PhysicalStationNumber"
            ) is None
        ):
            warnings.append(
                str(
                    record.get(
                        "AssignedStationLabel",
                        "Özel proses istasyonu"
                    )
                )
                +
                ": tarihsel veride birebir fiziksel istasyon numarası "
                "bulunamadı. Ek kapasite için mühendislik onayı gerekir."
            )

    return (
        final_operations,
        station_records,
        "+".join(
            balancer_names
        ),
        warnings,
    )


# =====================================================================
# V5 DIRECT PHYSICAL MAIN-STATION OPTIMIZER
# =====================================================================
# Main operations are no longer balanced into artificial Main-1/Main-2
# buckets first and mapped to factory stations afterwards.
#
# The CP-SAT decision variable itself is now the real learned physical
# Main station index. This preserves learned factory location much more
# strongly while still respecting target CT / max saturation.
# =====================================================================

_legacy_assign_main_physical_station_numbers = (
    _assign_main_physical_station_numbers
)


def _preferred_physical_candidate_index(
    operation,
    candidates
):
    preference_source = str(
        operation.get(
            "PhysicalStationPreferenceSource",
            ""
        )
        or ""
    )

    preferred_number = operation.get(
        "PreferredPhysicalStationNumber"
    )

    # Soft real T1065/T1330 station learning, independent of the product
    # inventory reference. Do not overwrite mandatory pallet anchors or locks.
    if (not operation.get('IsPalletOrientationAnchor') and
            operation.get('ForcedPhysicalStationNumber') is None and
            operation.get('TempoLayoutPreferredPhysicalStationNumber') is not None):
        try:
            return _nearest_candidate_index(
                candidates, float(operation['TempoLayoutPreferredPhysicalStationNumber']))
        except (TypeError, ValueError, OverflowError):
            pass

    if bool(
        operation.get(
            "IsPalletOrientationAnchor",
            False
        )
    ):
        pallet_context_preferred = operation.get(
            "PalletContextPreferredStationNumber"
        )

        if pallet_context_preferred is not None:
            preferred_number = (
                pallet_context_preferred
            )


    # Occurrence profile / unique-operation profile:
    # use the learned real physical station directly.
    if (
        preferred_number is not None
        and
        preference_source !=
        "INSTANCE_STATION_POSITION_FALLBACK"
    ):
        try:
            return _nearest_candidate_index(
                candidates,
                float(
                    preferred_number
                )
            )
        except Exception:
            pass

    # Repeated operations (turn pallet, repeated screws, repeated
    # accessory loading, etc.) must use their instance-specific
    # learned station position. Otherwise every occurrence inherits
    # one canonical median/mode station and collapses into one place.
    station_position = float(
        operation.get(
            "PredictedStationPosition",
            operation.get(
                "PredictedProcessPosition",
                0.0
            )
        )
    )

    process_position = float(
        operation.get(
            "PredictedProcessPosition",
            station_position
        )
    )

    blended_position = (
        0.75 *
        station_position
        +
        0.25 *
        process_position
    )

    blended_position = min(
        1.0,
        max(
            0.0,
            blended_position
        )
    )

    if len(
        candidates
    ) <= 1:
        return 0

    return int(
        round(
            blended_position *
            (
                len(
                    candidates
                ) -
                1
            )
        )
    )


def _ck2_main_flow_phases(operations):
    # Each explicit pallet or cehennemlik rotation is its OWN physical
    # transition. A component turn must not corrupt the product heading.
    return orientation_phases(operations)


def _ck2_reference_reorder_count(operations, assignments):
    """Count changed chronological station pairs for an audit warning."""
    moved = 0
    for i, a in enumerate(assignments):
        for b in assignments[i + 1:]:
            if a > b:
                moved += 1
    return moved


def _solve_direct_physical_main_for_count(
    operations,
    candidates,
    max_station_load,
    station_count,
    precedence_edges,
    hard_bundle_edges=None,
    operation_block_map=None,
    process_block_order_edges=None,
    max_move_candidates=None,
    pallet_anchor_radius=1,
    max_time_seconds=35.0,
    status_sink=None,
):
    try:
        from ortools.sat.python import cp_model
    except ImportError as exc:
        raise RuntimeError(
            "Hat dengeleme için OR-Tools kurulu değil. "
            "Python ortamında pip install ortools komutunu çalıştırın."
        ) from exc

    operation_count = len(
        operations
    )

    candidate_count = len(
        candidates
    )

    if (
        operation_count == 0
        or
        candidate_count == 0
        or
        station_count <= 0
        or
        station_count >
        candidate_count
    ):
        return None

    scale = 1000

    durations = [
        max(
            1,
            int(
                round(
                    _duration_value(
                        operation
                    ) *
                    scale
                )
            )
        )
        for operation in operations
    ]

    capacity = int(
        round(
            max_station_load *
            scale
        )
    )

    total_duration = sum(
        durations
    )

    for index, duration in enumerate(
        durations
    ):
        if duration > capacity:
            raise ValueError(
                f'{operations[index]["CanonicalOperationId"]} '
                f'tek başına '
                f'{duration / scale:.3f} sn ve izin verilen '
                f'istasyon yükü {max_station_load:.3f} sn.'
            )

    model = cp_model.CpModel()

    assignment_flags = {}
    assigned_rank = []

    for operation_index in range(
        operation_count
    ):
        rank = model.NewIntVar(
            0,
            candidate_count - 1,
            f"physical_rank_{operation_index}"
        )

        assigned_rank.append(
            rank
        )

        flags = []

        for candidate_index in range(
            candidate_count
        ):
            flag = model.NewBoolVar(
                f"x_{operation_index}_{candidate_index}"
            )

            assignment_flags[
                (
                    operation_index,
                    candidate_index,
                )
            ] = flag

            model.Add(
                rank ==
                candidate_index
            ).OnlyEnforceIf(
                flag
            )

            model.Add(
                rank !=
                candidate_index
            ).OnlyEnforceIf(
                flag.Not()
            )

            flags.append(
                flag
            )

        model.Add(
            sum(
                flags
            ) == 1
        )

    station_used = []
    station_loads = []

    for candidate_index in range(
        candidate_count
    ):
        used = model.NewBoolVar(
            f"used_{candidate_index}"
        )

        station_used.append(
            used
        )

        assigned_count = sum(
            assignment_flags[
                (
                    operation_index,
                    candidate_index,
                )
            ]
            for operation_index in range(
                operation_count
            )
        )

        model.Add(
            assigned_count >= 1
        ).OnlyEnforceIf(
            used
        )

        model.Add(
            assigned_count == 0
        ).OnlyEnforceIf(
            used.Not()
        )

        load = model.NewIntVar(
            0,
            capacity,
            f"load_{candidate_index}"
        )

        model.Add(
            load ==
            sum(
                durations[
                    operation_index
                ] *
                assignment_flags[
                    (
                        operation_index,
                        candidate_index,
                    )
                ]
                for operation_index
                in range(
                    operation_count
                )
            )
        )

        model.Add(
            load <=
            capacity
        )

        station_loads.append(
            load
        )

    model.Add(
        sum(
            station_used
        ) ==
        station_count
    )

    # -------------------------------------------------------------
    # Hard engineering rules
    # -------------------------------------------------------------
    for operation_index, operation in enumerate(
        operations
    ):
        forced_number = operation.get(
            "ForcedPhysicalStationNumber"
        )

        if forced_number is None:
            continue

        forced_number = int(
            forced_number
        )

        if forced_number not in candidates:
            raise ValueError(
                f"Zorunlu fiziksel istasyon {forced_number}, "
                "öğrenilmiş Main istasyon listesinde yok."
            )

        forced_index = candidates.index(
            forced_number
        )

        model.Add(
            assigned_rank[
                operation_index
            ] ==
            forced_index
        )

    # -------------------------------------------------------------
    # Keep REAL process-state chronology; do not freeze historical station
    # layout or every independent operation into one artificial total order.
    # Pallet rotations and transfers to door/test/visual are process barriers.
    # Within each barrier segment, an operation may move to another physical
    # station if capacity permits, while its historical within-station chain
    # and approved precedence rules remain non-decreasing.
    # -------------------------------------------------------------
    flow_phases = _ck2_main_flow_phases(operations)
    for phase_index, phase in enumerate(flow_phases[:-1]):
        next_phase = flow_phases[phase_index + 1]
        phase_max = model.NewIntVar(0, candidate_count - 1,
                                    f"phase_max_{phase_index}")
        phase_next_min = model.NewIntVar(0, candidate_count - 1,
                                         f"phase_next_min_{phase_index}")
        model.AddMaxEquality(phase_max, [assigned_rank[k] for k in phase])
        model.AddMinEquality(phase_next_min,
                             [assigned_rank[k] for k in next_phase])
        model.Add(phase_max <= phase_next_min)
        last_op = operations[phase[-1]]
        if last_op.get("AdaptiveMandatoryBoundaryAfter"):
            model.Add(phase_max < phase_next_min)

    historical_station_chain = defaultdict(list)
    for index, op in enumerate(operations):
        ref = op.get("PreservedReferenceStationSequence")
        if ref is not None:
            historical_station_chain[int(ref)].append(index)
    for indices in historical_station_chain.values():
        for first, second in zip(indices, indices[1:]):
            model.Add(assigned_rank[first] <= assigned_rank[second])

    # IMPORTANT: Group co-occurrence and statistical precedence do not
    # prove a physical dependency. The trained _build_precedence() emits
    # thousands of high-confidence historical pairs. Making all of them
    # hard constraints silently freezes the old 24-second choreography.
    # Only explicitly engineering-approved edges may constrain feasibility.
    # Other learned relations are scored as SOFT preferences below.
    by_operation = defaultdict(list)
    for index, op in enumerate(operations):
        by_operation[str(op.get("CanonicalOperationId", ""))].append(index)

    hard_flow_count = 0
    historical_soft_flow_count = 0
    for edge in precedence_edges or []:
        source_instances = by_operation.get(str(edge.get("Source", "")), [])
        target_instances = by_operation.get(str(edge.get("Target", "")), [])
        if not source_instances or not target_instances:
            continue
        approved = (
            edge.get("EngineeringApproved") is True
            or edge.get("IsApproved") is True
            or str(edge.get("ConstraintSource") or "").upper()
                in {"ENGINEERING_APPROVED", "PHYSICAL_PROCESS", "SAFETY"}
        )
        if not approved:
            historical_soft_flow_count += 1
            continue
        a, b = source_instances[-1], target_instances[0]
        if a == b:
            continue
        model.Add(assigned_rank[a] <= assigned_rank[b])
        hard_flow_count += 1

    # Pallet-orientation process-state anchors
    # -------------------------------------------------------------
    # These operations change the physical orientation of the product.
    # They are not ordinary movable work elements.
    #
    # Rules:
    #   1) each anchor stays within ±1 learned physical station slot,
    #   2) existing occurrence-order constraints keep them in process order,
    #   3) do not allow optimizer to pile many turns into one station.
    #
    # The allowed duplicate count is learned from the current occurrence
    # preferences. If history naturally has two rotations in one station
    # (e.g. station 1), two remain legal; three-way accidental clustering
    # is prevented.
    pallet_anchor_indices = []

    pallet_preferred_indices = []

    for operation_index, operation in enumerate(
        operations
    ):
        if not bool(
            operation.get(
                "IsPalletOrientationAnchor",
                False
            )
        ):
            continue

        pallet_anchor_indices.append(
            operation_index
        )

        preferred_index = (
            _preferred_physical_candidate_index(
                operation,
                candidates
            )
        )

        pallet_preferred_indices.append(
            preferred_index
        )

        pallet_radius = max(
            1,
            int(
                pallet_anchor_radius
            )
        )

        low_index = max(
            0,
            preferred_index -
            pallet_radius
        )

        high_index = min(
            candidate_count - 1,
            preferred_index +
            pallet_radius
        )

        model.Add(
            assigned_rank[
                operation_index
            ] >=
            low_index
        )

        model.Add(
            assigned_rank[
                operation_index
            ] <=
            high_index
        )

    pallet_cluster_limit = 1

    if pallet_preferred_indices:
        preferred_counts = {}

        for preferred_index in (
            pallet_preferred_indices
        ):
            preferred_counts[
                preferred_index
            ] = (
                preferred_counts.get(
                    preferred_index,
                    0
                )
                + 1
            )

        pallet_cluster_limit = max(
            preferred_counts.values()
        )

        # Defensive engineering ceiling: more than two pallet rotations
        # in one physical station is almost always an optimizer artefact.
        pallet_cluster_limit = min(
            max(
                1,
                pallet_cluster_limit
            ),
            2
        )

        for candidate_index in range(
            candidate_count
        ):
            model.Add(
                sum(
                    assignment_flags[
                        (
                            operation_index,
                            candidate_index,
                        )
                    ]
                    for operation_index
                    in pallet_anchor_indices
                )
                <=
                pallet_cluster_limit
            )

    # -------------------------------------------------------------
    # Learned hard operation bundles - FEASIBILITY SAFE
    # -------------------------------------------------------------
    # V9 initially added every learned pair as an unconditional equality.
    # Transitive pair chains can accidentally create a giant bundle or a
    # bundle whose members have incompatible physical-station ranges.
    # That made the whole CP-SAT model infeasible.
    #
    # V9.2 validates each merge before making it hard:
    #   - pallet-orientation anchors are NEVER absorbed into a bundle,
    #   - total bundle duration must fit one station,
    #   - all members must share at least one allowed physical station,
    #   - forced-station constraints must therefore remain compatible.
    #
    # Strongest historical bundle edges are accepted first. Invalid edges
    # are skipped instead of crashing the whole method generation.
    operation_index_by_key = {}

    for operation_index, operation in enumerate(
        operations
    ):
        operation_index_by_key[
            (
                str(
                    operation.get(
                        "CanonicalOperationId",
                        ""
                    )
                ),
                int(
                    operation.get(
                        "OccurrenceIndex",
                        1
                    )
                ),
            )
        ] = operation_index

    parent = list(
        range(
            operation_count
        )
    )

    component_members = {
        index: {
            index
        }
        for index in range(
            operation_count
        )
    }

    component_duration = {
        index:
            float(
                _duration_value(
                    operations[
                        index
                    ]
                )
            )
        for index in range(
            operation_count
        )
    }

    all_candidate_indices = set(
        range(
            candidate_count
        )
    )

    component_allowed = {}

    for operation_index, operation in enumerate(
        operations
    ):
        forced_number = operation.get(
            "ForcedPhysicalStationNumber"
        )

        if forced_number is not None:
            try:
                forced_number = int(
                    forced_number
                )
            except Exception:
                forced_number = None

        if (
            forced_number is not None
            and
            forced_number in candidates
        ):
            allowed = {
                candidates.index(
                    forced_number
                )
            }

        elif (
            max_move_candidates is not None
        ):
            preferred_index = (
                _preferred_physical_candidate_index(
                    operation,
                    candidates
                )
            )

            movement_limit = max(
                0,
                int(
                    max_move_candidates
                )
            )

            allowed = set(
                range(
                    max(
                        0,
                        preferred_index -
                        movement_limit
                    ),
                    min(
                        candidate_count - 1,
                        preferred_index +
                        movement_limit
                    )
                    + 1
                )
            )

        else:
            allowed = set(
                all_candidate_indices
            )

        component_allowed[
            operation_index
        ] = allowed

    def find_root(
        index
    ):
        while (
            parent[
                index
            ] !=
            index
        ):
            parent[
                index
            ] = parent[
                parent[
                    index
                ]
            ]

            index = parent[
                index
            ]

        return index

    def union_roots(
        first_root,
        second_root
    ):
        if (
            first_root ==
            second_root
        ):
            return first_root

        if len(
            component_members[
                first_root
            ]
        ) < len(
            component_members[
                second_root
            ]
        ):
            first_root, second_root = (
                second_root,
                first_root
            )

        parent[
            second_root
        ] = first_root

        component_members[
            first_root
        ].update(
            component_members[
                second_root
            ]
        )

        component_duration[
            first_root
        ] += component_duration[
            second_root
        ]

        component_allowed[
            first_root
        ] = (
            component_allowed[
                first_root
            ]
            &
            component_allowed[
                second_root
            ]
        )

        del component_members[
            second_root
        ]

        del component_duration[
            second_root
        ]

        del component_allowed[
            second_root
        ]

        return first_root

    applied_bundle_edges = 0
    skipped_bundle_edges = 0
    applied_bundle_components = 0

    sorted_bundle_edges = sorted(
        hard_bundle_edges
        or [],
        key=lambda edge: (
            float(
                edge.get(
                    "CoLocationConfidence",
                    0.0
                )
            ),
            float(
                edge.get(
                    "AdjacentConfidence",
                    0.0
                )
            ),
            int(
                edge.get(
                    "Support",
                    0
                )
            ),
        ),
        reverse=True
    )

    for edge in sorted_bundle_edges:
        source_key = (
            str(
                edge.get(
                    "Source",
                    ""
                )
            ),
            int(
                edge.get(
                    "SourceOccurrenceIndex",
                    1
                )
            ),
        )

        target_key = (
            str(
                edge.get(
                    "Target",
                    ""
                )
            ),
            int(
                edge.get(
                    "TargetOccurrenceIndex",
                    1
                )
            ),
        )

        source_index = (
            operation_index_by_key.get(
                source_key
            )
        )

        target_index = (
            operation_index_by_key.get(
                target_key
            )
        )

        if (
            source_index is None
            or
            target_index is None
            or
            source_index ==
            target_index
        ):
            continue

        # Pallet turning is a process-state boundary. Never glue it to a
        # tooling/resource bundle.
        if (
            bool(
                operations[
                    source_index
                ].get(
                    "IsPalletOrientationAnchor",
                    False
                )
            )
            or
            bool(
                operations[
                    target_index
                ].get(
                    "IsPalletOrientationAnchor",
                    False
                )
            )
        ):
            skipped_bundle_edges += 1
            continue

        source_root = find_root(
            source_index
        )

        target_root = find_root(
            target_index
        )

        if (
            source_root ==
            target_root
        ):
            continue

        merged_duration = (
            component_duration[
                source_root
            ]
            +
            component_duration[
                target_root
            ]
        )

        common_allowed = (
            component_allowed[
                source_root
            ]
            &
            component_allowed[
                target_root
            ]
        )

        if (
            merged_duration >
            max_station_load +
            1e-9
            or
            not common_allowed
        ):
            skipped_bundle_edges += 1
            continue

        # This equality is safe because the entire resulting component
        # still fits one station and has at least one common legal station.
        model.Add(
            assigned_rank[
                source_index
            ] ==
            assigned_rank[
                target_index
            ]
        )

        union_roots(
            source_root,
            target_root
        )

        applied_bundle_edges += 1

    applied_bundle_components = sum(
        1
        for root, members
        in component_members.items()
        if len(
            members
        ) > 1
    )

    # -------------------------------------------------------------
    # Learned LOCAL PROCESS-BLOCK ORDER - STRONG SOFT CONSTRAINT
    # -------------------------------------------------------------
    # Process-block order is learned statistically from approved methods.
    # It is very important, but it is NOT an absolute engineering law.
    #
    # V10 made these edges hard (source_station <= target_station). A few
    # model-specific differences could then conflict with pallet anchors,
    # hard bundles, or local physical-station ranges and make the entire
    # CP-SAT model infeasible.
    #
    # V10.1 keeps the same learned block sequence but models each edge as
    # a heavily penalized SOFT constraint:
    #     SourceBlock should be before/equal TargetBlock.
    #
    # This preserves block order whenever physically possible, while a
    # rare model-specific exception no longer prevents method generation.
    operation_block_map = (
        operation_block_map
        or {}
    )

    process_block_order_edges = (
        process_block_order_edges
        or []
    )

    present_block_to_indices = defaultdict(
        list
    )

    for operation_index, operation in enumerate(
        operations
    ):
        key_text = (
            str(
                operation.get(
                    "CanonicalOperationId",
                    ""
                )
            )
            +
            "#"
            +
            str(
                int(
                    operation.get(
                        "OccurrenceIndex",
                        1
                    )
                )
            )
        )

        block_id = operation_block_map.get(
            key_text
        )

        if block_id:
            present_block_to_indices[
                block_id
            ].append(
                operation_index
            )

    accepted_block_graph = defaultdict(
        set
    )

    def block_path_exists(
        start_block,
        target_block,
    ):
        if (
            start_block ==
            target_block
        ):
            return True

        stack = [
            start_block
        ]

        visited = set()

        while stack:
            current = stack.pop()

            if (
                current ==
                target_block
            ):
                return True

            if current in visited:
                continue

            visited.add(
                current
            )

            stack.extend(
                accepted_block_graph.get(
                    current,
                    []
                )
            )

        return False

    applied_process_block_edges = 0
    skipped_process_block_edges = 0

    process_block_violation_terms = []

    sorted_process_edges = sorted(
        process_block_order_edges,
        key=lambda edge: (
            float(
                edge.get(
                    "Confidence",
                    0.0
                )
            ),
            int(
                edge.get(
                    "Support",
                    0
                )
            ),
            -float(
                edge.get(
                    "AverageRankDistance",
                    99.0
                )
            ),
        ),
        reverse=True
    )

    for edge_index, edge in enumerate(
        sorted_process_edges
    ):
        source_block = str(
            edge.get(
                "SourceBlock",
                ""
            )
        )

        target_block = str(
            edge.get(
                "TargetBlock",
                ""
            )
        )

        if (
            not source_block
            or
            not target_block
            or
            source_block ==
                target_block
        ):
            continue

        source_indices = (
            present_block_to_indices.get(
                source_block,
                []
            )
        )

        target_indices = (
            present_block_to_indices.get(
                target_block,
                []
            )
        )

        if (
            not source_indices
            or
            not target_indices
        ):
            continue

        # Keep only a clean acyclic historical preference graph.
        # This is not required for feasibility anymore, but removes
        # contradictory/noisy edges from the optimization objective.
        if block_path_exists(
            target_block,
            source_block,
        ):
            skipped_process_block_edges += 1
            continue

        source_index = min(
            source_indices,
            key=lambda index:
                int(
                    operations[
                        index
                    ].get(
                        "PredictedProcessSequence",
                        0
                    )
                )
        )

        target_index = min(
            target_indices,
            key=lambda index:
                int(
                    operations[
                        index
                    ].get(
                        "PredictedProcessSequence",
                        0
                    )
                )
        )

        violation = model.NewBoolVar(
            f"process_block_violation_{edge_index}"
        )

        model.Add(
            assigned_rank[
                source_index
            ] <=
            assigned_rank[
                target_index
            ]
        ).OnlyEnforceIf(
            violation.Not()
        )

        model.Add(
            assigned_rank[
                source_index
            ] >
            assigned_rank[
                target_index
            ]
        ).OnlyEnforceIf(
            violation
        )

        confidence = float(
            edge.get(
                "Confidence",
                0.0
            )
        )

        support = int(
            edge.get(
                "Support",
                0
            )
        )

        average_rank_distance = float(
            edge.get(
                "AverageRankDistance",
                4.0
            )
            or 4.0
        )

        # Strong, frequently observed and local historical ordering gets
        # the highest weight. Cap support so one ubiquitous edge does not
        # dominate the complete line.
        edge_weight = max(
            1,
            int(
                round(
                    confidence
                    *
                    min(
                        support,
                        10
                    )
                    *
                    (
                        1.0
                        +
                        max(
                            0.0,
                            4.0 -
                            min(
                                average_rank_distance,
                                4.0
                            )
                        )
                        /
                        4.0
                    )
                )
            )
        )

        process_block_violation_terms.append(
            (
                violation,
                edge_weight,
            )
        )

        accepted_block_graph[
            source_block
        ].add(
            target_block
        )

        applied_process_block_edges += 1

    # -------------------------------------------------------------
    # "Metodu Koru" local movement boundary
    # -------------------------------------------------------------
    if (
        max_move_candidates is not None
    ):
        movement_limit = max(
            0,
            int(
                max_move_candidates
            )
        )

        for operation_index, operation in enumerate(
            operations
        ):
            if operation.get(
                "ForcedPhysicalStationNumber"
            ) is not None:
                continue

            preferred_index = (
                _preferred_physical_candidate_index(
                    operation,
                    candidates
                )
            )

            model.Add(
                assigned_rank[
                    operation_index
                ] >=
                max(
                    0,
                    preferred_index -
                    movement_limit
                )
            )

            model.Add(
                assigned_rank[
                    operation_index
                ] <=
                min(
                    candidate_count - 1,
                    preferred_index +
                    movement_limit
                )
            )

    # Repeated instances of the same canonical operation may not
    # travel backwards in the physical process.
    hard_occurrence_edges = (
        _hard_occurrence_edges(
            operations
        )
    )

    for (
        source_index,
        target_index,
    ) in hard_occurrence_edges:
        model.Add(
            assigned_rank[
                source_index
            ] <=
            assigned_rank[
                target_index
            ]
        )

    # -------------------------------------------------------------
    # Learned precedence remains soft.
    # -------------------------------------------------------------
    soft_edges = (
        _soft_precedence_edges(
            operations,
            precedence_edges
        )
    )

    precedence_violation_terms = []

    for edge_index, edge in enumerate(
        soft_edges
    ):
        source_index = int(
            edge[
                "SourceIndex"
            ]
        )

        target_index = int(
            edge[
                "TargetIndex"
            ]
        )

        violation = model.NewBoolVar(
            f"soft_precedence_violation_{edge_index}"
        )

        model.Add(
            assigned_rank[
                source_index
            ] <=
            assigned_rank[
                target_index
            ]
        ).OnlyEnforceIf(
            violation.Not()
        )

        model.Add(
            assigned_rank[
                source_index
            ] >
            assigned_rank[
                target_index
            ]
        ).OnlyEnforceIf(
            violation
        )

        confidence = float(
            edge.get(
                "Confidence",
                0.0
            )
        )

        support = int(
            edge.get(
                "Support",
                0
            )
        )

        edge_weight = max(
            1,
            int(
                round(
                    confidence *
                    min(
                        support,
                        50
                    ) *
                    10
                )
            )
        )

        precedence_violation_terms.append(
            (
                violation,
                edge_weight,
            )
        )

    # -------------------------------------------------------------
    # Physical-position objective.
    # This is intentionally stronger than soft precedence:
    # if the ML says "operation normally belongs to station 22",
    # the optimizer should not send it to station 1 just to obtain
    # a cosmetically good packing.
    # -------------------------------------------------------------
    physical_deviations = []
    large_move_flags = []

    for operation_index, operation in enumerate(
        operations
    ):
        preferred_index = (
            _preferred_physical_candidate_index(
                operation,
                candidates
            )
        )

        deviation = model.NewIntVar(
            0,
            candidate_count - 1,
            f"physical_deviation_{operation_index}"
        )

        model.AddAbsEquality(
            deviation,
            assigned_rank[
                operation_index
            ] -
            preferred_index
        )

        physical_deviations.append(
            deviation
        )

        large_move = model.NewBoolVar(
            f"large_move_{operation_index}"
        )

        # A move of more than 3 learned physical Main positions
        # is allowed only when capacity forces it, but receives
        # an additional heavy penalty.
        model.Add(
            deviation >= 4
        ).OnlyEnforceIf(
            large_move
        )

        model.Add(
            deviation <= 3
        ).OnlyEnforceIf(
            large_move.Not()
        )

        large_move_flags.append(
            large_move
        )

    # -------------------------------------------------------------
    # Load balance objective for the selected physical stations.
    # -------------------------------------------------------------
    ideal_load = int(
        round(
            total_duration /
            station_count
        )
    )

    load_deviations = []

    for candidate_index in range(
        candidate_count
    ):
        deviation = model.NewIntVar(
            0,
            capacity,
            f"load_deviation_{candidate_index}"
        )

        # For unused stations: expected load is 0.
        # For used stations: expected load is average load.
        model.AddAbsEquality(
            deviation,
            station_loads[
                candidate_index
            ] -
            ideal_load *
            station_used[
                candidate_index
            ]
        )

        load_deviations.append(
            deviation
        )

    physical_penalty = sum(
        physical_deviations
    )

    large_move_penalty = sum(
        large_move_flags
    )

    precedence_penalty = sum(
        flag *
        weight
        for (
            flag,
            weight
        ) in precedence_violation_terms
    )

    process_block_penalty = sum(
        flag *
        weight
        for (
            flag,
            weight
        ) in process_block_violation_terms
    )

    balance_penalty = sum(
        load_deviations
    )

    # Primary crew minimisation occurs in the OUTER LOOP. Within a fixed
    # crew count, score learned preferences as soft costs while retaining
    # the capacity and genuinely approved hard physical constraints.
    #
    # Hard engineering constraints (bundle equality, pallet-state limits,
    # forced stations and CT) remain outside the objective and can never
    # be violated.
    model.Minimize(
        large_move_penalty *
        100000000
        +
        process_block_penalty *
        5000000
        +
        physical_penalty *
        100000
        +
        precedence_penalty *
        1000
        +
        balance_penalty
    )

    solver = cp_model.CpSolver()

    solver.parameters.max_time_in_seconds = (
        max_time_seconds
    )

    solver.parameters.num_search_workers = (
        8
    )

    status = solver.Solve(model)
    if status_sink is not None:
        status_sink.append({
            "Count": int(station_count),
            "Status": solver.StatusName(status),
            "MoveRadius": max_move_candidates,
            "PalletRadius": pallet_anchor_radius,
        })

    if status not in (
        cp_model.OPTIMAL,
        cp_model.FEASIBLE,
    ):
        return None

    assigned_indices = [
        int(
            solver.Value(
                variable
            )
        )
        for variable in assigned_rank
    ]

    used_indices = [
        index
        for index, used
        in enumerate(
            station_used
        )
        if int(
            solver.Value(
                used
            )
        ) == 1
    ]

    precedence_violation_count = sum(
        int(
            solver.Value(
                flag
            )
        )
        for (
            flag,
            _
        ) in precedence_violation_terms
    )

    process_block_violation_count = sum(
        int(
            solver.Value(
                flag
            )
        )
        for (
            flag,
            _
        ) in process_block_violation_terms
    )

    process_block_weighted_violation = sum(
        int(
            solver.Value(
                flag
            )
        ) *
        int(
            weight
        )
        for (
            flag,
            weight
        ) in process_block_violation_terms
    )

    physical_deviation_sum = sum(
        int(
            solver.Value(
                deviation
            )
        )
        for deviation in
        physical_deviations
    )

    large_move_count = sum(
        int(
            solver.Value(
                flag
            )
        )
        for flag in
        large_move_flags
    )

    return {
        "AssignedCandidateIndices":
            assigned_indices,
        "UsedCandidateIndices":
            used_indices,
        "SoftPrecedenceViolations":
            precedence_violation_count,
        "PhysicalDeviationSum":
            physical_deviation_sum,
        "LargeMoveCount":
            large_move_count,
        "AppliedHardBundleEdges":
            applied_bundle_edges,
        "SkippedHardBundleEdges":
            skipped_bundle_edges,
        "AppliedHardBundleComponents":
            applied_bundle_components,
        "AppliedProcessBlockEdges":
            applied_process_block_edges,
        "SkippedProcessBlockEdges":
            skipped_process_block_edges,
        "ProcessBlockViolations":
            process_block_violation_count,
        "ProcessBlockWeightedViolation":
            process_block_weighted_violation,
        "PalletAnchorCount":
            len(
                pallet_anchor_indices
            ),
        "PalletClusterLimit":
            pallet_cluster_limit,
        "HistoricalFlowEdgesKeptSoft": historical_soft_flow_count,
        "HardFlowEdges": hard_flow_count,
        "FlowPhases": len(flow_phases),
        "CrossOrderChanges": _ck2_reference_reorder_count(
            operations, assigned_indices),
        "Status":
            solver.StatusName(
                status
            ),
    }


def _natural_main_candidate_assignments(
    operations,
    candidates
):
    assignments = []

    for operation in operations:
        forced_number = operation.get(
            "ForcedPhysicalStationNumber"
        )

        if forced_number is not None:
            forced_number = int(
                forced_number
            )

            if forced_number not in candidates:
                raise ValueError(
                    f"Zorunlu fiziksel istasyon {forced_number}, "
                    "öğrenilmiş Main istasyon listesinde yok."
                )

            assignments.append(
                candidates.index(
                    forced_number
                )
            )

            continue

        assignments.append(
            _preferred_physical_candidate_index(
                operation,
                candidates
            )
        )

    return assignments


def _assignments_respect_hard_occurrence_order(
    operations,
    assignments
):
    for (
        source_index,
        target_index,
    ) in _hard_occurrence_edges(
        operations
    ):
        if (
            assignments[
                source_index
            ] >
            assignments[
                target_index
            ]
        ):
            return False

    return True


def _assignment_loads(
    operations,
    assignments,
    candidate_count
):
    loads = [
        0.0
        for _ in range(
            candidate_count
        )
    ]

    for operation, candidate_index in zip(
        operations,
        assignments
    ):
        loads[
            candidate_index
        ] += _duration_value(
            operation
        )

    return loads


def _build_main_zone_from_assignment(
    ordered,
    candidates,
    assigned_candidate_indices,
    cycle_time,
    max_station_load,
    max_saturation_percent,
):
    used_candidate_indices = sorted({
        int(
            value
        )
        for value in
        assigned_candidate_indices
    })

    physical_to_local = {
        candidate_index:
            local_index + 1
        for local_index, candidate_index
        in enumerate(
            used_candidate_indices
        )
    }

    station_operations = defaultdict(
        list
    )

    for operation, candidate_index in zip(
        ordered,
        assigned_candidate_indices
    ):
        physical_number = candidates[
            candidate_index
        ]

        local_station = (
            physical_to_local[
                candidate_index
            ]
        )

        item = dict(
            operation
        )

        item[
            "AssignedStationType"
        ] = "Main"

        item[
            "StationWithinType"
        ] = local_station

        item[
            "PhysicalStationNumber"
        ] = physical_number

        station_operations[
            local_station
        ].append(
            item
        )

    result_operations = []
    station_records = []

    for local_station, candidate_index in enumerate(
        used_candidate_indices,
        start=1
    ):
        physical_number = candidates[
            candidate_index
        ]

        assigned_operations = (
            station_operations[
                local_station
            ]
        )

        assigned_operations.sort(
            key=lambda item: (
                int(
                    item.get(
                        "PredictedProcessSequence",
                        0
                    )
                ),
                float(
                    item.get(
                        "PredictedProcessPosition",
                        0.0
                    )
                ),
            )
        )

        load = sum(
            _duration_value(
                operation
            )
            for operation
            in assigned_operations
        )

        saturation = (
            load /
            cycle_time *
            100.0
            if cycle_time > 0
            else 0.0
        )

        station_records.append({
            "StationType":
                "Main",
            "StationWithinType":
                local_station,
            "PhysicalStationNumber":
                physical_number,
            "StationLoadSeconds":
                load,
            "StationCycleSource":
                "SUM_OPERATION_TIMES",
            "StationSaturationPercent":
                saturation,
            "MaxTargetSaturationPercent":
                max_saturation_percent,
            "SaturationLimitExceeded":
                load >
                max_station_load +
                1e-9,
            "StationFeasible":
                load <=
                max_station_load +
                1e-9,
        })

        for station_operation_sequence, operation in enumerate(
            assigned_operations,
            start=1
        ):
            operation[
                "StationOperationSequence"
            ] = station_operation_sequence

            operation[
                "StationLoadSeconds"
            ] = load

            operation[
                "StationSaturationPercent"
            ] = saturation

            operation[
                "StationCycleSource"
            ] = "SUM_OPERATION_TIMES"

            operation[
                "MaxTargetSaturationPercent"
            ] = max_saturation_percent

            operation[
                "SaturationLimitExceeded"
            ] = (
                load >
                max_station_load +
                1e-9
            )

            result_operations.append(
                operation
            )

    return (
        result_operations,
        station_records,
        used_candidate_indices,
    )




def _first_station_pallet_limit(operations):
    """Confirmed plant rule: source spreadsheets cannot authorize two turns."""
    return 1


def _ck2_ordered_min_personnel_dp(
    operations,
    candidates,
    max_station_load,
    hard_bundle_edges=None,
    movement_radius=None,
    pallet_radius=3,
):
    """Find the smallest feasible *ordered* Main staffing layout.

    The result is a constructive feasible arrangement, not a proof that a
    smaller non-ordered OR-Tools layout is impossible. It respects operation
    order, fixed physical stations, accepted co-location groups and pallet
    anchor locality. Cannot make up extra physical station numbers.
    """
    if not operations or not candidates:
        return None

    first_turn_limit = _first_station_pallet_limit(operations)
    operation_count = len(operations)
    slot_count = len(candidates)
    capacity = float(max_station_load)
    if capacity <= 0:
        return None
    duration = [_duration_value(op) for op in operations]
    if any(not math.isfinite(t) or t < 0 or t > capacity + 1e-9 for t in duration):
        return None

    slot_map = {int(number): index for index, number in enumerate(candidates)}
    forced = []
    preferred = []
    is_rotation = []
    for op in operations:
        fixed = op.get('ForcedPhysicalStationNumber')
        if fixed is not None:
            try:
                slot = slot_map[int(fixed)]
            except (KeyError, TypeError, ValueError):
                return None
        else:
            slot = None
        forced.append(slot)
        preferred.append(_preferred_physical_candidate_index(op, candidates))
        name = str(op.get('CanonicalName', '')).upper()
        rule = str(op.get('EngineeringRule', '')).upper()
        is_rotation.append(bool(
            op.get('IsPalletOrientationAnchor', False)
            or 'PALLET_ORIENTATION' in rule
            or ('PALET' in name and ('CEVIR' in name or 'ÇEVİR' in name))
        ))

    # Preserve chronological separation of special process blocks.
    mandatory_boundaries = {
        i for i, op in enumerate(operations[:-1])
        if op.get('AdaptiveMandatoryBoundaryAfter')
    }

    # Explicit co-location evidence is accepted conservatively. Chains that
    # would exceed the station capacity / fixed-location rules are not forced.
    prohibited_boundaries = set()
    skipped_bundles = 0
    applied_bundles = 0
    by_occurrence = {
        (str(op.get('CanonicalOperationId')), int(op.get('OccurrenceIndex') or 1)): index
        for index, op in enumerate(operations)
    }
    edges = sorted(hard_bundle_edges or [], key=lambda edge: (
        float(edge.get('CoLocationConfidence') or 0),
        float(edge.get('AdjacentConfidence') or 0),
        int(edge.get('Support') or 0),
    ), reverse=True)

    def consistent_groups(boundaries):
        beginning = 0
        for end in range(operation_count):
            if end < operation_count - 1 and end in boundaries:
                continue
            group = range(beginning, end + 1)
            if sum(duration[k] for k in group) > capacity + 1e-9:
                return False
            locks = {forced[k] for k in group if forced[k] is not None}
            if len(locks) > 1:
                return False
            if locks:
                locked = next(iter(locks))
                if any(is_rotation[k] and pallet_radius is not None and abs(preferred[k] - locked) > pallet_radius for k in group):
                    return False
            beginning = end + 1
        return True

    for edge in edges:
        source = by_occurrence.get((
            str(edge.get('Source')),
            int(edge.get('SourceOccurrenceIndex') or 1),
        ))
        target = by_occurrence.get((
            str(edge.get('Target')),
            int(edge.get('TargetOccurrenceIndex') or 1),
        ))
        if source is None or target is None or source == target:
            continue
        lo, hi = sorted((source, target))
        proposal = prohibited_boundaries.union(range(lo, hi))
        if (proposal & mandatory_boundaries
                or any(is_rotation[k] for k in range(lo, hi + 1))
                or not consistent_groups(proposal)):
            skipped_bundles += 1
            continue
        prohibited_boundaries = proposal
        applied_bundles += 1

    # Historical maximum pallet turns at a single physical station, bounded
    # to two as in the CP-SAT optimizer.
    historic_turns = defaultdict(int)
    for i, yes in enumerate(is_rotation):
        if yes:
            historic_turns[preferred[i]] += 1
    turn_limit = max(1, min(2, max(historic_turns.values(), default=1)))

    prefix = [0.0]
    for seconds in duration:
        prefix.append(prefix[-1] + seconds)

    # SOFT station-boundary probabilities learned at target CT. They affect
    # the actual ordered DP optimization (not merely Excel warnings).
    # Crew remains lexicographically primary. Hard fixture rules stay hard.
    boundary_same = []
    for op in operations[:-1]:
        try:
            probability = float(op.get('LearnedSameStationWithNextProbability'))
            boundary_same.append(max(0.0, min(1.0, probability))
                                 if math.isfinite(probability) else 0.5)
        except (TypeError, ValueError, OverflowError):
            boundary_same.append(0.5)
    joining_prefix = [0.0]
    for probability in boundary_same:
        joining_prefix.append(joining_prefix[-1] + 12.0 * max(0., 0.5 - probability))

    # dp[processed physical slots][processed operations] ->
    # (operator count, total deviation). Lexicographic optimum.
    dp = [[None] * (operation_count + 1) for _ in range(slot_count + 1)]
    parent = [[None] * (operation_count + 1) for _ in range(slot_count + 1)]
    dp[0][0] = (0, 0)
    for physical_index in range(slot_count):
        for start in range(operation_count + 1):
            best = dp[physical_index][start]
            if best is None:
                continue
            # A real physical station can remain unused.
            if dp[physical_index + 1][start] is None or best < dp[physical_index + 1][start]:
                dp[physical_index + 1][start] = best
                parent[physical_index + 1][start] = (start, False)
            movement = 0
            rotations = 0
            for end in range(start + 1, operation_count + 1):
                index = end - 1
                if index > start and index - 1 in mandatory_boundaries:
                    break
                if prefix[end] - prefix[start] > capacity + 1e-9:
                    break
                if forced[index] is not None and forced[index] != physical_index:
                    break
                if movement_radius is not None and abs(preferred[index] - physical_index) > movement_radius:
                    break
                if is_rotation[index] and pallet_radius is not None and abs(preferred[index] - physical_index) > pallet_radius:
                    break
                rotations += int(is_rotation[index])
                # The confirmed station-1 limit overrides erroneous
                # repeated station-1 rotations in a source spreadsheet.
                local_turn_limit = first_turn_limit if int(candidates[physical_index]) == 1 else turn_limit
                if rotations > local_turn_limit:
                    break
                if not _seated_fan_station_compatible(operations[start:end]):
                    break
                movement += (6 if is_rotation[index] else 1) * abs(preferred[index] - physical_index)
                if end < operation_count and end - 1 in prohibited_boundaries:
                    continue
                # Penalize splitting a high-confidence learned pair and
                # joining a low-confidence pair. Both are *soft* penalties.
                join_cost = (joining_prefix[end-1] - joining_prefix[start]
                             if end - 1 >= start else 0.0)
                split_cost = (15.0 * max(0.0, boundary_same[end-1] - 0.5)
                              if end < operation_count else 0.0)
                proposal = (best[0] + 1, best[1] + movement + join_cost + split_cost)
                existing = dp[physical_index + 1][end]
                if existing is None or proposal < existing:
                    dp[physical_index + 1][end] = proposal
                    parent[physical_index + 1][end] = (start, True)

    score = dp[slot_count][operation_count]
    if score is None:
        return None
    assigned = [-1] * operation_count
    p, q = slot_count, operation_count
    while p > 0:
        previous = parent[p][q]
        if previous is None:
            return None
        start, used = previous
        if used:
            for i in range(start, q):
                assigned[i] = p - 1
        q, p = start, p - 1
    if any(i < 0 for i in assigned):
        return None
    for i in range(operation_count):
        if forced[i] is not None and assigned[i] != forced[i]:
            return None
        if i < operation_count - 1:
            if i in prohibited_boundaries and assigned[i] != assigned[i + 1]:
                return None
            if i in mandatory_boundaries and assigned[i] == assigned[i + 1]:
                return None
            if assigned[i] > assigned[i + 1]:
                return None
    loads = _assignment_loads(operations, assigned, slot_count)
    if any(load > capacity + 1e-7 for load in loads):
        return None
    return {
        'AssignedCandidateIndices': assigned,
        'UsedCandidateIndices': sorted(set(assigned)),
        'SoftPrecedenceViolations': 0,
        'PhysicalDeviationSum': score[1],
        'LargeMoveCount': sum(abs(a - b) > 3 for a, b in zip(assigned, preferred)),
        'AppliedHardBundleEdges': applied_bundles,
        'SkippedHardBundleEdges': skipped_bundles,
        'AppliedHardBundleComponents': 0,
        'AppliedProcessBlockEdges': 0,
        'SkippedProcessBlockEdges': 0,
        'ProcessBlockViolations': 0,
        'ProcessBlockWeightedViolation': 0,
        'PalletAnchorCount': sum(is_rotation),
        'PalletClusterLimit': turn_limit,
        'Status': 'ORDERED_DP_FEASIBLE',
    }


def _ordered_main_capacity_analysis(durations, capacity, station_slots):
    """Fixed-order lower bound; never invent physical stations or split tasks.

    Greedy is exact for the number of contiguous groups at a fixed capacity
    with nonnegative indivisible durations. Ignoring extra physical locks is
    a relaxation: failure here proves failure of the stricter ordered model.
    """
    values = [float(value) for value in durations]
    if not values:
        return {'minimum_ordered_stations': 0, 'minimum_capacity_for_slots': 0.0}
    if capacity <= 0 or not math.isfinite(capacity) or any(
            not math.isfinite(value) or value < 0 for value in values):
        raise ValueError('Ana hat kapasitesi ve işlem süreleri geçerli olmalı.')
    if max(values) > capacity + 1e-9:
        return {'minimum_ordered_stations': None, 'oversized_operation_seconds': max(values)}
    count, load = 1, 0.0
    for value in values:
        if load + value > capacity + 1e-9:
            count += 1
            load = 0.0
        load += value
    result = {'minimum_ordered_stations': count}
    if count <= station_slots:
        return result
    if station_slots <= 0:
        raise ValueError('Tanımlı ana hat istasyonu yok.')
    # Exact minimax partition for a lower bound on the required per-slot
    # capacity. This still ignores tooling and fixed-station restrictions.
    prefix = [0.0]
    for value in values:
        prefix.append(prefix[-1] + value)
    n, groups = len(values), min(station_slots, len(values))
    previous = [float('inf')] * (n + 1)
    previous[0] = 0.0
    for group in range(1, groups + 1):
        current = [float('inf')] * (n + 1)
        for end in range(group, n + 1):
            current[end] = min(max(previous[start], prefix[end] - prefix[start])
                               for start in range(group - 1, end))
        previous = current
    result['minimum_capacity_for_slots'] = previous[n]
    return result


def _build_direct_physical_main_zone(
    operations,
    cycle_time,
    max_station_load,
    max_saturation_percent,
    station_profile,
    precedence_edges,
    hard_bundle_edges=None,
    operation_block_map=None,
    process_block_order_edges=None,
    balance_mode="preserve_method",
    reference_main_station_count=None,
):
    if not operations:
        return (
            [],
            [],
            [],
        )

    ordered = sorted(
        operations,
        key=lambda item: (
            int(
                item.get(
                    "PredictedProcessSequence",
                    0
                )
            ),
            float(
                item.get(
                    "PredictedProcessPosition",
                    0.0
                )
            ),
        )
    )

    candidates = sorted({
        int(
            value
        )
        for value in (
            station_profile.get(
                "PhysicalStationNumbers",
                []
            )
        )
        if value is not None
    })

    if not candidates:
        return _build_timed_zone(
            operations,
            cycle_time,
            max_station_load,
            max_saturation_percent,
            "Main",
            station_profile,
            fixed_count=None,
            precedence_edges=
                precedence_edges
        )

    total_duration = sum(
        _duration_value(
            operation
        )
        for operation in ordered
    )

    capacity_audit = _ordered_main_capacity_analysis(
        [_duration_value(op) for op in ordered], float(max_station_load), len(candidates))
    if capacity_audit['minimum_ordered_stations'] is None:
        raise ValueError(
            'Bölünemeyen bir ana işlem {:.3f} saniye; bu ayarda istasyon yük sınırı '
            '{:.3f} saniye. Hedef çevrim {:.3f} saniye ve maks. saturasyon %{:.1f}. '
            'İş süresi azaltılmadı. Üretim hedefini, saturasyon sınırını veya '
            'gerçekten uygulanabilir iş bölünmesini gözden geçirin.'.format(
                capacity_audit['oversized_operation_seconds'], max_station_load,
                cycle_time, max_saturation_percent))
    if capacity_audit['minimum_ordered_stations'] > len(candidates):
        required = capacity_audit['minimum_capacity_for_slots']
        raise ValueError(
            'Ana hatta mevcut iş sırası için kapasite yetersiz.\n'
            'Hedef çevrim: {:.3f} sn; maks. saturasyon: %{:.1f}; '
            'istasyon başına yük sınırı: {:.3f} sn.\n'
            'İş sırası ve süreler korununca en az {} ana istasyon gerekiyor; '
            'tanımlı fiziksel ana hat pozisyonu {}. '
            'Toplam süreyi kapasiteye bölmek, bölünemeyen işlerin sınırlarını hesaba katmaz.\n'
            '{} pozisyona sığmak için ek fiziksel kısıtlar yok sayıldığında bile '
            'istasyon yük sınırı en az {:.3f} sn, yani maks. saturasyon en az %{:.2f} '
            'olmalı. Bu alt sınır, fiziksel yerleşim için çözüm garantisi değildir.\n'
            'Üretim hedefini azaltın, maks. saturasyon sınırını yükseltin veya '
            'gerçekten kullanılabilir ek ana hat pozisyonlarını tanımlayın. '
            'Süreler ve işlem sırası değiştirilmedi.'.format(
                cycle_time, max_saturation_percent, max_station_load,
                capacity_audit['minimum_ordered_stations'], len(candidates),
                len(candidates), required, required / cycle_time * 100.0))

    lower_bound = max(
        1,
        int(
            math.ceil(
                (
                    total_duration -
                    1e-9
                ) /
                max_station_load
            )
        )
    )

    if lower_bound > len(
        candidates
    ):
        raise ValueError(
            "Hedef CT / maksimum saturasyon için gereken "
            "Main istasyon sayısı öğrenilmiş gerçek fiziksel "
            "Main istasyon sayısından fazla. "
            f"Gereken en az={lower_bound}, "
            f"mevcut öğrenilmiş={len(candidates)}."
        )

    natural_assignments = (
        _natural_main_candidate_assignments(
            ordered,
            candidates
        )
    )

    natural_loads = _assignment_loads(
        ordered,
        natural_assignments,
        len(
            candidates
        )
    )

    natural_used_indices = sorted({
        int(
            value
        )
        for value in
        natural_assignments
    })

    natural_feasible = (
        all(
            load <=
            max_station_load +
            1e-9
            for load in
            natural_loads
        )
        and
        _assignments_respect_hard_occurrence_order(
            ordered,
            natural_assignments
        )
        and all(a <= b for a, b in zip(natural_assignments, natural_assignments[1:]))
    )

    # Tek yöntem. Eski preserve/min ayrimi artik dengeleme kararini
    # etkilemez; islem envanteri ve palet senkronu degismez.
    normalized_mode = "preserve_method"

    warnings = []

    # Training co-location is a statistical observation, not a certified
    # physical/tooling requirement. Only engineer-approved edges may prohibit
    # separating two operations when the target CT changes.
    def _certified_bundle(edge):
        if edge.get("EngineeringApproved") is True or edge.get("IsApproved") is True:
            return True
        approval = str(edge.get("ConstraintSource") or edge.get("RuleSource") or "").upper()
        return approval in {"ENGINEERING_APPROVED", "HARD_TOOLING", "PHYSICAL_FIXTURE"}

    historical_bundle_edges = list(hard_bundle_edges or [])
    approved_bundle_edges = [edge for edge in historical_bundle_edges if _certified_bundle(edge)]
    uncertain_bundle_count = len(historical_bundle_edges) - len(approved_bundle_edges)
    if uncertain_bundle_count:
        warnings.append(
            "HISTORICAL_BUNDLES_SOFTENED: " + str(uncertain_bundle_count)
            + " training co-location edge(s) were not certified engineering"
              " locks. They do not freeze the 24-second station layout."
              " Review tooling / screw-gun associations before production."
        )
    hard_bundle_edges = approved_bundle_edges

    # Tek optimizer: once sirali, dogrulanabilir bir aday bulur;
    # sonra AI'nin ogrendigi bagimsiz isler icin daha az personel arar.
    start_count = lower_bound
    solve_stages = [
        ("AI_LOCAL_2", 2, 1),
        ("AI_LOCAL_4", 4, 2),
        ("AI_PROCESS_ORDER", None, 3),
    ]
    solution = None
    selected_stage_name = None
    attempt_status = []

    # Build a CERTIFIED feasible incumbent in BOTH modes. The previous
    # implementation did this only for preserve_method. Minimum Personnel
    # had no fallback: a time-limited MILP search could return None even
    # when a fully ordered, physically feasible layout exists.
    #
    # Pallet-context positions are LEARNED preferences. They must NEVER
    # make an otherwise valid product-orientation sequence infeasible.
    # This fallback moves the station of a turn without moving the turn
    # relative to any operation. Engineering fixed-station locks remain.
    for dp_radius, turn_radius, stage in (
        (2, 3, "ORDERED_LOCAL"),
        (4, 5, "ORDERED_EXPANDED"),
        (None, None, "ORDERED_FULL_PHYSICAL"),
    ):
        dp_solution = _ck2_ordered_min_personnel_dp(
            ordered, candidates, max_station_load,
            hard_bundle_edges=hard_bundle_edges,
            movement_radius=dp_radius,
            pallet_radius=turn_radius,
        )
        if dp_solution is not None:
            if (solution is None or
                len(dp_solution["UsedCandidateIndices"]) <
                    len(solution["UsedCandidateIndices"])):
                solution = dp_solution
                selected_stage_name = stage
            attempt_status.append({
                "Count": len(dp_solution["UsedCandidateIndices"]),
                "Status": "ORDERED_DP_FEASIBLE",
                "MoveRadius": dp_radius,
                "PalletRadius": turn_radius,
            })
        else:
            attempt_status.append({
                "Count": "UNKNOWN",
                "Status": "ORDERED_DP_NOT_FOUND",
                "MoveRadius": dp_radius,
                "PalletRadius": turn_radius,
            })

    # CK2 V019 FIX: The ordered dynamic programmer is a safe, but deliberately
    # restrictive, CONSTRUCTIVE search. Failure there is not a mathematical
    # infeasibility certificate. The old control flow silently skipped the
    # global optimizer unless an ordered incumbent already existed, then
    # raised ORDERED_DP_NOT_FOUND.
    #
    # Try a full-physical, process-state-safe global feasibility search even
    # without any ordered incumbent. Pallet/cehennemlik phase order, any actual
    # fixed-position locks, certified tooling bundles, and source-station
    # operation order remain HARD. Purely statistical station preferences do
    # not prevent finding a safe new 30-second balance.
    fallback_ran = solution is None
    fallback_started = time.perf_counter() if fallback_ran else None
    if solution is None:
        try:
            fallback_solution = _solve_direct_physical_main_for_count(
                ordered, candidates, max_station_load, len(candidates),
                precedence_edges,
                hard_bundle_edges=hard_bundle_edges,
                operation_block_map=operation_block_map,
                process_block_order_edges=process_block_order_edges,
                max_move_candidates=None,
                pallet_anchor_radius=None,
                max_time_seconds=8.0,
                status_sink=attempt_status,
                feasibility_only=True,
            )
        except RuntimeError as exc:
            fallback_solution = None
            warnings.append(
                "GLOBAL_FEASIBILITY_SOLVER_UNAVAILABLE: " + str(exc)
            )
        if fallback_solution is not None:
            solution = fallback_solution
            selected_stage_name = "GLOBAL_FEASIBILITY_AFTER_ORDERED_DP"
            warnings.append(
                "ORDERED_DP_FALLBACK_SUCCESS: Independent operations within "
                "a product-orientation phase were reassigned. Every physical "
                "rotation boundary, certified tooling lock, fixed station "
                "and learned source-station operation order is retained. "
                "Engineering validation before shopfloor use is mandatory."
            )
        else:
            warnings.append(
                "ORDERED_DP_FALLBACK_UNRESOLVED: Even a full-range global "
                "search found no validated solution in the allotted time; "
                "this is NOT proof of physical infeasibility."
            )

    # First create a fully validated, feasible chronology-preserving result.
    # THEN search smaller crews with CP-SAT. Within a process-state phase,
    # independent tasks may use different stations while approved dependencies
    # and within-reference-station chains remain mandatory. This is still
    # Metodu Koru: the method remains, but redundant historical station splits
    # do not dictate staffing at the new target CT.
    preserve = normalized_mode == "preserve_method"
    if preserve and solution is not None:
        # METODU KORU: optimize the *same method* for the requested cycle time.
        # Search staffing counts only below the best feasible ordered layout.
        # Never return an unvalidated or larger-staff result from this phase.
        incumbent = solution
        incumbent_count = len(incumbent["UsedCandidateIndices"])
        ortools_missing = False
        for station_count in range(incumbent_count - 1, lower_bound - 1, -1):
            if fallback_ran and time.perf_counter() - fallback_started > 19.0:
                warnings.append("PRESERVE_TIME_BUDGET: best chronology-safe layout kept")
                break
            stage_specs = (
                (("PRESERVE_POST_FALLBACK", None, None),)
                if fallback_ran else
                (("PRESERVE_GLOBAL", None, None),
                 ("PRESERVE_NEAR_REFERENCE", 4, 5))
            )
            best_for_count = None
            best_stage = None
            for stage_name, move_radius, pallet_radius in stage_specs:
                try:
                    candidate = _solve_direct_physical_main_for_count(
                        ordered, candidates, max_station_load, station_count,
                        precedence_edges, hard_bundle_edges=hard_bundle_edges,
                        operation_block_map=operation_block_map,
                        process_block_order_edges=process_block_order_edges,
                        max_move_candidates=move_radius,
                        pallet_anchor_radius=pallet_radius,
                        max_time_seconds=7.0 if not fallback_ran else 4.0,
                        status_sink=attempt_status,
                        feasibility_only=fallback_ran,
                    )
                except RuntimeError as exc:
                    if "OR-Tools" not in str(exc) and "SciPy" not in str(exc):
                        raise
                    warnings.append("PRESERVE_SOLVER_UNAVAILABLE: " + str(exc))
                    ortools_missing = True
                    break
                if candidate is None:
                    continue
                # A tighter numeric target is NOT evidence of fewer operators.
                # Count actually occupied stations and reject any regression.
                actual_count = len(candidate.get("UsedCandidateIndices", []))
                if not actual_count or actual_count >= incumbent_count:
                    continue
                if actual_count > station_count:
                    continue
                # Respect full chronological order in Metodu Koru. Pallet
                # rotations are operations in the sequence and cannot move
                # across any surrounding manufacturing operation.
                positions = candidate.get("AssignedCandidateIndices") or []
                if len(positions) != len(ordered) or any(
                    positions[i] > positions[i + 1]
                    for i in range(len(positions) - 1)
                ):
                    continue
                if best_for_count is None or actual_count < len(
                    best_for_count["UsedCandidateIndices"]
                ):
                    best_for_count = candidate
                    best_stage = stage_name
            if best_for_count is not None:
                incumbent = best_for_count
                incumbent_count = len(incumbent["UsedCandidateIndices"])
                selected_stage_name = best_stage
            if ortools_missing:
                break
        solution = incumbent

        # CK2 V027: The ordered DP above is intentionally conservative and is
        # excellent for finding the minimum chronology-safe staffing count, but
        # it does not optimise load distribution among stations with that SAME
        # staffing count. Previously the global MILP was only called while
        # searching smaller staffing counts, so a badly underloaded station
        # could survive unchanged. Run one final global optimisation AT THE
        # SAME COUNT. Headcount and all hard engineering constraints are kept.
        try:
            same_count_candidate = _solve_direct_physical_main_for_count(
                ordered, candidates, max_station_load, incumbent_count,
                precedence_edges,
                hard_bundle_edges=hard_bundle_edges,
                operation_block_map=operation_block_map,
                process_block_order_edges=process_block_order_edges,
                max_move_candidates=None,
                pallet_anchor_radius=None,
                max_time_seconds=12.0,
                status_sink=attempt_status,
                feasibility_only=False,
            )
        except RuntimeError as exc:
            same_count_candidate = None
            warnings.append("SAME_COUNT_REBALANCE_UNAVAILABLE: " + str(exc))

        if same_count_candidate is not None:
            candidate_positions = same_count_candidate.get(
                "AssignedCandidateIndices"
            ) or []
            candidate_used = same_count_candidate.get(
                "UsedCandidateIndices"
            ) or []
            incumbent_positions = solution.get(
                "AssignedCandidateIndices"
            ) or []
            incumbent_used = solution.get(
                "UsedCandidateIndices"
            ) or []

            def _ck2_assignment_balance_key(positions, used_indices):
                if len(positions) != len(ordered) or not used_indices:
                    return (float("inf"), float("inf"), float("inf"))
                station_loads = defaultdict(float)
                for operation, assigned_index in zip(ordered, positions):
                    station_loads[int(assigned_index)] += _duration_value(operation)
                used_loads = [
                    station_loads[int(index)]
                    for index in sorted(set(int(v) for v in used_indices))
                ]
                if not used_loads:
                    return (float("inf"), float("inf"), float("inf"))
                mean_load = sum(used_loads) / len(used_loads)
                return (
                    max(max_station_load - load for load in used_loads),
                    max(used_loads) - min(used_loads),
                    sum((load - mean_load) ** 2 for load in used_loads),
                )

            candidate_count = len(set(int(v) for v in candidate_used))
            incumbent_actual_count = len(set(int(v) for v in incumbent_used))
            candidate_is_ordered = (
                len(candidate_positions) == len(ordered)
                and all(
                    int(candidate_positions[i]) <= int(candidate_positions[i + 1])
                    for i in range(len(candidate_positions) - 1)
                )
            )
            candidate_key = _ck2_assignment_balance_key(
                candidate_positions, candidate_used
            )
            incumbent_key = _ck2_assignment_balance_key(
                incumbent_positions, incumbent_used
            )

            if (
                candidate_count == incumbent_actual_count
                and candidate_count == incumbent_count
                and candidate_is_ordered
                and candidate_key < incumbent_key
            ):
                solution = same_count_candidate
                selected_stage_name = "SAME_COUNT_LOAD_REBALANCE"
                warnings.append(
                    "SAME_COUNT_LOAD_REBALANCE_APPLIED: main_count={}; "
                    "old_min_load={:.3f}s; new_min_load={:.3f}s; "
                    "hard chronology/orientation constraints retained.".format(
                        incumbent_count,
                        max_station_load - incumbent_key[0],
                        max_station_load - candidate_key[0],
                    )
                )
            else:
                warnings.append(
                    "SAME_COUNT_LOAD_REBALANCE_NOT_BETTER: main_count={}; "
                    "incumbent_balance={}; candidate_balance={}.".format(
                        incumbent_count,
                        tuple(round(float(v), 4) for v in incumbent_key),
                        tuple(round(float(v), 4) for v in candidate_key),
                    )
                )

        warnings.append(
            "PRESERVE_METHOD_CT_STAFFING: chronology/pallet order retained; "
            "best feasible main station count=" + str(incumbent_count)
        )
    # V048: preserve the certified chronological baseline. Learned evidence
    # alone does not authorise swapping Main operations to save one operator.
    # The separately user-confirmed Visual rule is unaffected.

    if solution and solution.get("Status")=="ENGINEERING_REVIEW_REQUIRED_SINGLE_ADJACENT_SWAP":
        details = solution.get("ReviewSwap") or []
        warnings.append("REVIEW_REQUIRED_INDEPENDENT_SWAP: This is a NOT-YET-APPROVED"
                        " engineering proposal; never deploy directly: " +
                        " / ".join(str(x.get("Name")) for x in details))

    # Never call a time-limited solver result 'proven minimal'.
    if solution is not None:
        best_count = len(solution["UsedCandidateIndices"])
        unresolved = [a for a in attempt_status
                      if (a.get("Status") in ("UNKNOWN", "MODEL_INVALID"))
                      and int(a.get("Count", 0)) < best_count]
        if unresolved:
            warnings.append(
                "OPTIMALITY_NOT_PROVEN: Smaller staffing layouts timed out; "
                "result is BEST_FOUND, not mathematical minimum."
            )

    # Include EVERY searched crew size; FEASIBLE/OPTIMAL here certifies only
    # a particular station count. It does not prove global minimum staffing.
    for attempt in attempt_status:
        count = attempt.get("Count", "?")
        status = attempt.get("Status", "UNKNOWN")
        warnings.append(
            "STAFFING_SEARCH_ATTEMPT: main_count={}, status={}, "
            "move_radius={}, pallet_radius={}".format(
                count, status, attempt.get("MoveRadius"),
                attempt.get("PalletRadius")))

    if solution is None:
        problems = []
        physical_set = set(candidates)
        forced_ops = []
        for seq_index, op in enumerate(ordered):
            forced_slot = op.get("ForcedPhysicalStationNumber")
            if forced_slot is not None:
                forced_ops.append((seq_index, int(forced_slot), op))
                if int(forced_slot) not in physical_set:
                    problems.append(
                        "Zorunlu fiziksel istasyon {} öğrenilmiş Main yerleşiminde yok: {}".format(
                            forced_slot, op.get("CanonicalName", "")))
        for (i, station_i, op_i), (j, station_j, op_j) in zip(forced_ops, forced_ops[1:]):
            if station_i > station_j:
                problems.append(
                    "Zorunlu işlem sırası çelişkisi: sıra {} / istasyon {} ({}) "
                    "sonrasında sıra {} / istasyon {} ({}) geliyor".format(
                        i + 1, station_i, op_i.get("CanonicalName", ""),
                        j + 1, station_j, op_j.get("CanonicalName", "")))
        forced_loads = defaultdict(float)
        for _, forced_slot, op in forced_ops:
            forced_loads[forced_slot] += _duration_value(op)
        for fixed_slot, seconds in sorted(forced_loads.items()):
            if seconds > max_station_load + 1e-8:
                problems.append(
                    "İstasyon {} zorunlu operasyon yükü {:.2f}s, kapasite {:.2f}s".format(
                        fixed_slot, seconds, max_station_load))
        for index, op in enumerate(ordered):
            if _duration_value(op) > max_station_load + 1e-8:
                problems.append(
                    "Bölünemeyen operasyon {} ({}) {:.2f}s > CT {:.2f}s".format(
                        index + 1, op.get("CanonicalName", ""),
                        _duration_value(op), max_station_load))
        details = ("; ".join(problems[:4]) if problems else
                   "Mevcut fiziksel istasyon sayısı, ürün yön/sıra sınırları ve "
                   "hedef CT iş yükü birlikte incelenmeli. ML istasyon tercihi "
                   "sabit kısıt olarak kullanılmadı.")
        raise ValueError(
            "Main dengeleme uygulanabilir çözüm bulamadı. " + details +
            "; CT={:.3f}s, toplam iş={:.3f}s, Main fiziksel pozisyon={}, "
            "kuramsal minimum={}. Arama: {}".format(
                max_station_load, total_duration, len(candidates),
                lower_bound, ", ".join(str(a.get("Status")) for a in attempt_status[-8:])))

    assigned_candidate_indices = solution[
        "AssignedCandidateIndices"
    ]

    (
        result_operations,
        station_records,
        used_candidate_indices,
    ) = _build_main_zone_from_assignment(
        ordered,
        candidates,
        assigned_candidate_indices,
        cycle_time,
        max_station_load,
        max_saturation_percent,
    )

    # The historical co-location edges are AUDIT evidence only. Count how
    # many were split by CT-driven regrouping, so the method is never passed
    # off as production-approved before tooling checks.
    final_by_key = {
        (str(op.get("CanonicalOperationId")), int(op.get("OccurrenceIndex") or 1)):
            op.get("PhysicalStationNumber")
        for op in result_operations
    }
    split_uncertified = []
    for edge in historical_bundle_edges:
        if _certified_bundle(edge):
            continue
        a = (str(edge.get("Source")), int(edge.get("SourceOccurrenceIndex") or 1))
        b = (str(edge.get("Target")), int(edge.get("TargetOccurrenceIndex") or 1))
        if a in final_by_key and b in final_by_key and final_by_key[a] != final_by_key[b]:
            split_uncertified.append((a, b))
    if split_uncertified:
        warnings.append(
            "ENGINEERING_REVIEW_REQUIRED: " + str(len(split_uncertified))
            + " historical same-station operation pairs were separated."
              " Verify screw guns, fixtures, access and tooling."
        )
    repeated_cluster_warnings = []

    repeated_groups = defaultdict(
        list
    )

    for operation in result_operations:
        repeated_groups[
            str(
                operation.get(
                    "CanonicalOperationId",
                    ""
                )
            )
        ].append(
            operation
        )

    for (
        operation_id,
        group
    ) in repeated_groups.items():
        if len(
            group
        ) < 4:
            continue

        assigned_station_numbers = {
            int(
                operation.get(
                    "PhysicalStationNumber",
                    -1
                )
            )
            for operation in group
            if operation.get(
                "PhysicalStationNumber"
            ) is not None
        }

        process_positions = [
            float(
                operation.get(
                    "PredictedProcessPosition",
                    0.0
                )
            )
            for operation in group
        ]

        if (
            len(
                assigned_station_numbers
            ) <= 1
            and
            (
                max(
                    process_positions
                ) -
                min(
                    process_positions
                )
            ) >= 0.15
        ):
            repeated_cluster_warnings.append(
                "REPEATED_OPERATION_CLUSTER_WARNING: "
                f"operation={operation_id}, "
                f"occurrences={len(group)}, "
                "geniş proses aralığına rağmen tek fiziksel "
                "istasyonda kümelendi."
            )

    mode_text = "AI_HAT_DENGELEME"

    warnings = warnings + repeated_cluster_warnings + [
        "MAIN_DIRECT_PHYSICAL_OPTIMIZER: "
        f"mode={mode_text}, "
        f"work_content={total_duration:.3f} sn, "
        f"max_station_load={max_station_load:.3f} sn, "
        f"natural_physical_stations={len(natural_used_indices)}, "
        f"assigned_physical_stations={len(used_candidate_indices)}, "
        f"soft_precedence_violations="
        f'{solution.get("SoftPrecedenceViolations", 0)}, '
        f'physical_deviation_sum='
        f'{solution.get("PhysicalDeviationSum", 0)}, '
        f'large_moves='
        f'{solution.get("LargeMoveCount", 0)}, '
        f'solve_stage={selected_stage_name}, '
        f'optimizer_status={solution.get("Status", "CP_SAT")}, '
        f'cross_order_changes={solution.get("CrossOrderChanges", 0)}, '
        f'flow_phases={solution.get("FlowPhases", 0)}, '
        f'hard_flow_edges={solution.get("HardFlowEdges", 0)}, '
        f'historical_flow_edges_soft={solution.get("HistoricalFlowEdgesKeptSoft", 0)}, '
        f'attempts={len(attempt_status)}, '
        f'hard_bundle_edges='
        f'{solution.get("AppliedHardBundleEdges", 0)}, '
        f'uncertified_historical_bundle_edges={uncertain_bundle_count}, '
        f'split_historical_bundle_edges={len(split_uncertified)}, '
        f'skipped_bundle_edges='
        f'{solution.get("SkippedHardBundleEdges", 0)}, '
        f'bundle_components='
        f'{solution.get("AppliedHardBundleComponents", 0)}, '
        f'process_block_edges='
        f'{solution.get("AppliedProcessBlockEdges", 0)}, '
        f'skipped_process_block_edges='
        f'{solution.get("SkippedProcessBlockEdges", 0)}, '
        f'process_block_violations='
        f'{solution.get("ProcessBlockViolations", 0)}, '
        f'process_block_weighted_violation='
        f'{solution.get("ProcessBlockWeightedViolation", 0)}, '
        f'pallet_anchors='
        f'{solution.get("PalletAnchorCount", 0)}, '
        f'pallet_cluster_limit='
        f'{solution.get("PalletClusterLimit", 1)}, '
        f'method={solution.get("Status", "BUNDLE_AWARE_PHYSICAL_CP_SAT")}.'
    ]

    if selected_stage_name in ("PRESERVE_AI_LOCAL", "PRESERVE_AI_FULL"):
        warnings.append(
            "PRESERVE_AI_REBALANCE: New cycle time used to redistribute"
            " independent operations. Process-state barriers and approved"
            " engineering dependencies respected. Engineer must validate"
            " workstation ergonomics/tooling before production release."
        )

    changed_pairs = int(solution.get("CrossOrderChanges", 0) or 0)
    if changed_pairs:
        warnings.append(
            "ENGINEERING_REVIEW_REQUIRED: "
            f"{changed_pairs} chronological station pair(s) regrouped inside "
            "process-state phases. Validate component access, tools and "
            "true dependencies before releasing the new method."
        )

    return (
        result_operations,
        station_records,
        warnings,
    )


def _assign_main_physical_station_numbers(
    main_station_records,
    main_operations,
    main_profile
):
    # Direct-physical optimizer already decided the real factory
    # station number. Preserve that decision exactly.
    direct_numbers = [
        record.get(
            "PhysicalStationNumber"
        )
        for record in
        main_station_records
    ]

    if (
        direct_numbers
        and
        all(
            value is not None
            for value in
            direct_numbers
        )
    ):
        return [
            int(
                value
            )
            for value in
            direct_numbers
        ]

    return (
        _legacy_assign_main_physical_station_numbers(
            main_station_records,
            main_operations,
            main_profile
        )
    )



def _learned_order_for_station(
    station_operations,
    same_station_precedence_edges,
):
    """
    Order operations inside ONE assigned station.

    Priority:
      1) occurrence-specific learned same-station precedence,
      2) canonical learned same-station precedence,
      3) predicted within-station relative position,
      4) global process sequence,
      5) occurrence index.

    Edges are added strongest-first and only when they do not introduce
    a cycle. Therefore the resulting station method is deterministic and
    never falls back to random ordering.
    """
    if len(
        station_operations
    ) <= 1:
        return list(
            station_operations
        )

    if all(str(op.get("AssignedStationType", "")) == "Main"
           for op in station_operations):
        # Keep the same process sequence made mandatory across stations.
        # A later within-station historical majority must not undo it.
        return sorted(station_operations, key=lambda op: (
            int(op.get("PredictedProcessSequence", 0)),
            int(op.get("OccurrenceIndex", 1)),
        ))

    operations = list(
        station_operations
    )

    indices_by_canonical = defaultdict(
        list
    )

    index_by_occurrence_key = {}

    for index, operation in enumerate(
        operations
    ):
        operation_id = str(
            operation.get(
                "CanonicalOperationId",
                ""
            )
        )

        occurrence_index = int(
            operation.get(
                "OccurrenceIndex",
                1
            )
        )

        indices_by_canonical[
            operation_id
        ].append(
            index
        )

        index_by_occurrence_key[
            (
                operation_id,
                occurrence_index,
            )
        ] = index

    adjacency = defaultdict(
        set
    )

    def creates_path(
        start_index,
        target_index,
    ):
        """
        Return True if a path already exists from start_index to
        target_index in the currently accepted graph.
        """
        if start_index == target_index:
            return True

        stack = [
            start_index
        ]

        visited = set()

        while stack:
            current = stack.pop()

            if current == target_index:
                return True

            if current in visited:
                continue

            visited.add(
                current
            )

            stack.extend(
                adjacency.get(
                    current,
                    []
                )
            )

        return False

    def add_edge_if_acyclic(
        source_index,
        target_index,
    ):
        if (
            source_index ==
            target_index
        ):
            return

        if target_index in adjacency[
            source_index
        ]:
            return

        # Adding source -> target would create a cycle if
        # target can already reach source.
        if creates_path(
            target_index,
            source_index,
        ):
            return

        adjacency[
            source_index
        ].add(
            target_index
        )

    # ---------------------------------------------------------
    # Historical same-station precedence, strongest first.
    # ---------------------------------------------------------
    sorted_edges = sorted(
        same_station_precedence_edges
        or [],
        key=lambda edge: (
            # Occurrence-specific rules are the strongest.
            1
            if edge.get(
                "Scope"
            ) == "Occurrence"
            else 0,
            # A pair repeatedly observed directly next to each other
            # should beat a broad non-adjacent precedence rule.
            int(
                edge.get(
                    "DirectSupport",
                    0
                )
            ),
            float(
                edge.get(
                    "AdjacentConfidence",
                    0.0
                )
            ),
            float(
                edge.get(
                    "Confidence",
                    0.0
                )
            ),
            int(
                edge.get(
                    "Support",
                    0
                )
            ),
        ),
        reverse=True
    )

    for edge in sorted_edges:
        source_id = str(
            edge.get(
                "Source",
                ""
            )
        )

        target_id = str(
            edge.get(
                "Target",
                ""
            )
        )

        if (
            not source_id
            or
            not target_id
        ):
            continue

        scope = str(
            edge.get(
                "Scope",
                "Canonical"
            )
        )

        if scope == "Occurrence":
            source_occurrence = edge.get(
                "SourceOccurrenceIndex"
            )

            target_occurrence = edge.get(
                "TargetOccurrenceIndex"
            )

            if (
                source_occurrence is None
                or
                target_occurrence is None
            ):
                continue

            source_index = (
                index_by_occurrence_key.get(
                    (
                        source_id,
                        int(
                            source_occurrence
                        ),
                    )
                )
            )

            target_index = (
                index_by_occurrence_key.get(
                    (
                        target_id,
                        int(
                            target_occurrence
                        ),
                    )
                )
            )

            if (
                source_index is None
                or
                target_index is None
            ):
                continue

            add_edge_if_acyclic(
                source_index,
                target_index,
            )

        else:
            source_indices = (
                indices_by_canonical.get(
                    source_id,
                    []
                )
            )

            target_indices = (
                indices_by_canonical.get(
                    target_id,
                    []
                )
            )

            if (
                not source_indices
                or
                not target_indices
            ):
                continue

            for source_index in source_indices:
                for target_index in target_indices:
                    add_edge_if_acyclic(
                        source_index,
                        target_index,
                    )

    # Same canonical operation occurrences always keep their
    # occurrence order inside the station.
    for indices in (
        indices_by_canonical.values()
    ):
        if len(
            indices
        ) <= 1:
            continue

        ordered_indices = sorted(
            indices,
            key=lambda index: (
                int(
                    operations[
                        index
                    ].get(
                        "OccurrenceIndex",
                        1
                    )
                ),
                float(
                    operations[
                        index
                    ].get(
                        "PredictedWithinStationPosition",
                        0.5
                    )
                    if operations[
                        index
                    ].get(
                        "PredictedWithinStationPosition"
                    ) is not None
                    else 0.5
                ),
                int(
                    operations[
                        index
                    ].get(
                        "PredictedProcessSequence",
                        0
                    )
                ),
            )
        )

        for source_index, target_index in zip(
            ordered_indices[:-1],
            ordered_indices[1:]
        ):
            add_edge_if_acyclic(
                source_index,
                target_index,
            )

    indegree = [
        0
        for _ in operations
    ]

    for source_index, targets in (
        adjacency.items()
    ):
        for target_index in targets:
            indegree[
                target_index
            ] += 1

    def priority(
        index
    ):
        operation = operations[
            index
        ]

        within_position = (
            operation.get(
                "PredictedWithinStationPosition"
            )
        )

        if within_position is None:
            within_position = 0.5

        return (
            float(
                within_position
            ),
            int(
                operation.get(
                    "PredictedProcessSequence",
                    0
                )
            ),
            int(
                operation.get(
                    "OccurrenceIndex",
                    1
                )
            ),
            str(
                operation.get(
                    "CanonicalName",
                    ""
                )
            ),
            index,
        )

    import heapq

    heap = []

    for index in range(
        len(
            operations
        )
    ):
        if indegree[
            index
        ] == 0:
            heapq.heappush(
                heap,
                (
                    priority(
                        index
                    ),
                    index,
                )
            )

    ordered_indices = []

    while heap:
        _, current_index = (
            heapq.heappop(
                heap
            )
        )

        ordered_indices.append(
            current_index
        )

        for next_index in sorted(
            adjacency.get(
                current_index,
                []
            )
        ):
            indegree[
                next_index
            ] -= 1

            if indegree[
                next_index
            ] == 0:
                heapq.heappush(
                    heap,
                    (
                        priority(
                            next_index
                        ),
                        next_index,
                    )
                )

    # The graph is built cycle-safe. This fallback is only defensive.
    if len(
        ordered_indices
    ) < len(
        operations
    ):
        used = set(
            ordered_indices
        )

        remaining = [
            index
            for index in range(
                len(
                    operations
                )
            )
            if index not in used
        ]

        remaining.sort(
            key=priority
        )

        ordered_indices.extend(
            remaining
        )

    return [
        operations[
            index
        ]
        for index in
        ordered_indices
    ]


def _apply_learned_within_station_order(
    final_operations,
    same_station_precedence_edges,
):
    by_display_order = defaultdict(
        list
    )

    for operation in final_operations:
        by_display_order[
            int(
                operation.get(
                    "DisplayOrder",
                    operation.get(
                        "AssignedStation",
                        0
                    )
                )
            )
        ].append(
            operation
        )

    ordered_final = []

    for display_order in sorted(
        by_display_order.keys()
    ):
        station_operations = (
            _learned_order_for_station(
                by_display_order[
                    display_order
                ],
                same_station_precedence_edges
            )
        )

        for station_sequence, operation in enumerate(
            station_operations,
            start=1
        ):
            operation[
                "StationOperationSequence"
            ] = station_sequence

            ordered_final.append(
                operation
            )

    for sequence, operation in enumerate(
        ordered_final,
        start=1
    ):
        operation[
            "Sequence"
        ] = sequence

    return ordered_final


def _preserved_reference_layout(operations, cycle_time, profiles, max_saturation_percent):
    """Keep an entire coherent reference method and validate its real loads.

    No solver is allowed to silently merge stations or reverse assembly order
    to make this mode fit a tighter production target.
    """
    required = (
        "PreservedReferenceModelNo", "PreservedReferenceStationType",
        "PreservedReferenceStationNumber", "PreservedReferenceStationSequence",
        "PreservedReferenceStationOperationSequence",
    )
    if any(any(op.get(field) is None for field in required) for op in operations):
        raise ValueError("Korunacak referans metodun istasyon/sıra bilgileri eksik.")
    models = {str(op["PreservedReferenceModelNo"]) for op in operations}
    if len(models) != 1 or not next(iter(models)).strip():
        raise ValueError("Metodu Koru için tek ve tutarlı bir referans ürün gerekir.")
    if not math.isfinite(float(cycle_time)) or cycle_time <= 0:
        raise ValueError("Hedef çevrim süresi pozitif ve sonlu olmalıdır.")

    def positive_int(value):
        value = float(value)
        if not math.isfinite(value) or value <= 0 or not value.is_integer():
            raise ValueError("Referans istasyon ve sıra numaraları pozitif tam sayı olmalıdır.")
        return int(value)

    groups, identities, station_keys = defaultdict(list), set(), {}
    for original in operations:
        op = dict(original)
        identity = (str(op["CanonicalOperationId"]), int(op.get("OccurrenceIndex", 1)))
        if identity in identities:
            raise ValueError("Referans metotta yinelenen operasyon oluşum kimliği var.")
        identities.add(identity)
        station_type = str(op["PreservedReferenceStationType"])
        physical = positive_int(op["PreservedReferenceStationNumber"])
        station_sequence = positive_int(op["PreservedReferenceStationSequence"])
        station_order = positive_int(op["PreservedReferenceStationOperationSequence"])
        if station_type != str(op.get("PredictedStationType", "Main")):
            raise ValueError("Referans ve tahminin proses istasyonu türleri uyuşmuyor.")
        profile = profiles.get(station_type, {})
        if not profile:
            raise ValueError(f"{station_type}: korunacak istasyon için tarihsel proses profili yok.")
        known_numbers = {int(n) for n in profile.get("PhysicalStationNumbers", []) if n is not None}
        if known_numbers and physical not in known_numbers:
            raise ValueError(f"Referans fiziksel istasyon öğrenilmiş layout içinde yok: {station_type} {physical}.")
        forced = op.get("ForcedPhysicalStationNumber")
        if forced is not None and positive_int(forced) != physical:
            raise ValueError("Referans yerleşimi zorunlu mühendislik istasyonuyla çelişiyor.")
        key = (station_type, physical)
        if station_sequence in station_keys and station_keys[station_sequence] != key:
            raise ValueError("Aynı referans istasyon sırasına iki farklı fiziksel istasyon atanmış.")
        if key in station_keys.values() and station_keys.get(station_sequence) != key:
            raise ValueError("Referans fiziksel istasyonun sıra bilgisi tutarsız.")
        station_keys[station_sequence] = key
        op["PreservedReferenceStationOperationSequence"] = station_order
        groups[station_sequence].append(op)
    if sorted(groups) != list(range(1, len(groups) + 1)):
        raise ValueError("Korunacak referans metodun istasyon sıraları eksik veya kesintili.")
    main_numbers = [station_keys[i][1] for i in sorted(station_keys)
                    if station_keys[i][0] == "Main"]
    if main_numbers != sorted(main_numbers):
        raise ValueError("Referans ana hat fiziksel istasyonları proses yönüyle çelişiyor.")

    capacity = cycle_time * max_saturation_percent / 100.0
    final, records, local_counts = [], [], defaultdict(int)
    for display_order in sorted(groups):
        station_type, physical = station_keys[display_order]
        assigned = sorted(groups[display_order], key=lambda op: op["PreservedReferenceStationOperationSequence"])
        orders = [op["PreservedReferenceStationOperationSequence"] for op in assigned]
        if orders != list(range(1, len(assigned) + 1)):
            raise ValueError("Referans istasyon içi sıra numaraları eksik veya yinelenmiş.")
        local_counts[station_type] += 1
        local = local_counts[station_type]
        profile = profiles.get(station_type, {})
        if profile.get("AggregateStationTime", False):
            ordinal_profiles = profile.get("StationOrdinals", [])
            ordinal = next((p for p in ordinal_profiles
                            if p.get("ModePhysicalStationNumber") == physical), None)
            if ordinal is None and local <= len(ordinal_profiles):
                ordinal = ordinal_profiles[local - 1]
            load = float((ordinal or {}).get("MedianCycleTimeSeconds", 0.0))
            source = "HISTORICAL_STATION_AGGREGATE"
            if not math.isfinite(load) or load <= 0:
                raise ValueError(f"{station_type} {physical}: geçerli toplu test süresi yok.")
        else:
            times = [op.get("PredictedTimeSeconds") for op in assigned]
            if any(t is None or not math.isfinite(float(t)) or float(t) < 0 for t in times):
                raise ValueError(f"{station_type} {physical}: operasyon süresi eksik veya geçersiz.")
            load = sum(float(t) for t in times)
            source = "SUM_OPERATION_TIMES"
        label = _station_label(station_type, local, physical, None)
        if load > capacity + 1e-9:
            raise ValueError(
                f"METODU_KORU_KAPASITE: {label} yükü {load:.3f} sn, izin verilen yük "
                f"{capacity:.3f} sn. Referans metot istasyon/sıra değiştirilerek sıkıştırılmadı. "
                "Üretim hedefini veya kapasiteyi mühendislik açısından gözden geçirin."
            )
        record = {
            "StationType": station_type, "StationWithinType": local,
            "PhysicalStationNumber": physical, "AssignedStation": display_order,
            "DisplayOrder": display_order, "AssignedStationLabel": label,
            "StationLoadSeconds": load, "StationCycleSource": source,
            "StationSaturationPercent": load / cycle_time * 100.0,
            "MaxTargetSaturationPercent": max_saturation_percent,
            "SaturationLimitExceeded": False, "StationFeasible": True,
        }
        records.append(record)
        for station_order, op in enumerate(assigned, 1):
            op.update({k: v for k, v in record.items() if k not in {"StationType", "StationFeasible"}})
            op["AssignedStationType"] = station_type
            op["StationOperationSequence"] = station_order
            op["Sequence"] = len(final) + 1
            op["PredictedProcessSequence"] = len(final) + 1
            op["WithinStationOrderSource"] = "COHERENT_REFERENCE_METHOD"
            final.append(op)
    warning = (
        "PRESERVED_REFERENCE_METHOD: reference=" + next(iter(models))
        + f", stations={len(records)}, operation_instances={len(final)}, "
        "station_order_preserved=true, capacity_checked=true."
    )
    warnings = [warning]
    for op in final:
        if op.get("PreservedReferenceVariant", False):
            warnings.append(
                "REFERENCE_QUANTITY_VARIANT: " + str(op["CanonicalName"])
                + " | Yerleşim, referanstaki aynı yükleme işinin miktar varyantından alındı; "
                "adet ve süre tahminden korundu. Konfigürasyon ile onaylı metottaki "
                "ızgara adedini doğrulayın."
            )
    return final, records, "PRESERVED_REFERENCE_METHOD", warnings



def _adaptive_reference_operations(operations, profiles):
    """Restore the reference's global order while allowing station regrouping.

    A coherent reference supplies *process order*, not a frozen workforce.
    Source operation durations still come from the current AI prediction.
    """
    required = (
        "PreservedReferenceModelNo",
        "PreservedReferenceStationType",
        "PreservedReferenceStationNumber",
        "PreservedReferenceStationSequence",
        "PreservedReferenceStationOperationSequence",
    )
    if not operations or not all(
        all(op.get(field) is not None for field in required)
        for op in operations
    ):
        raise ValueError("Metodu Koru: referans işlem sırası eksik.")

    model_numbers = {str(op["PreservedReferenceModelNo"]).strip() for op in operations}
    if len(model_numbers) != 1 or not next(iter(model_numbers)):
        raise ValueError("Metodu Koru: tek ve tutarlı referans model gerekiyor.")

    identities = set()
    source_stations = {}
    source_station_orders = defaultdict(set)
    copies = []

    def positive_integer(value, label):
        try:
            number = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"Referans {label} geçersiz: {value}")
        if not math.isfinite(number) or number <= 0 or not number.is_integer():
            raise ValueError(f"Referans {label} pozitif tam sayı olmalı: {value}")
        return int(number)

    for operation in operations:
        op = dict(operation)
        identity = (
            str(op["CanonicalOperationId"]),
            positive_integer(op.get("OccurrenceIndex", 1), "operasyon tekrarı"),
        )
        if identity in identities:
            raise ValueError("Referansta yinelenen operasyon oluşumu var: " + str(identity))
        identities.add(identity)

        station_type = str(op["PreservedReferenceStationType"])
        if station_type != str(op.get("PredictedStationType", "Main")):
            raise ValueError("Referans ve tahmin istasyon türü uyuşmuyor.")
        station_sequence = positive_integer(op["PreservedReferenceStationSequence"], "istasyon sırası")
        within_station = positive_integer(
            op["PreservedReferenceStationOperationSequence"], "istasyon içi sıra"
        )
        physical = positive_integer(op["PreservedReferenceStationNumber"], "fiziksel istasyon")
        key = (station_type, physical)

        if station_sequence in source_stations and source_stations[station_sequence] != key:
            raise ValueError("Referans istasyon numaraları kendi içinde çelişiyor.")
        source_stations[station_sequence] = key
        if within_station in source_station_orders[station_sequence]:
            raise ValueError("Referans istasyon içinde yinelenen işlem sırası.")
        source_station_orders[station_sequence].add(within_station)

        profile = profiles.get(station_type, {})
        known = {int(v) for v in profile.get(
            "ObservedReferenceStationNumbers", profile.get("PhysicalStationNumbers", [])) if v is not None}
        if known and physical not in known:
            raise ValueError(f"Referans istasyon öğrenilmiş fiziksel hatta yok: {key}")

        forced = op.get("ForcedPhysicalStationNumber")
        if forced is not None and int(forced) != physical:
            raise ValueError("Referans, zorunlu fiziksel istasyon kuralıyla çelişiyor.")
        copies.append(op)

    if sorted(source_stations) != list(range(1, len(source_stations) + 1)):
        raise ValueError("Referans istasyon sıraları eksik veya kesintili.")

    main_numbers = [source_stations[i][1] for i in sorted(source_stations)
                    if source_stations[i][0] == "Main"]
    if main_numbers != sorted(main_numbers) or len(main_numbers) != len(set(main_numbers)):
        raise ValueError("Referans Main istasyon sırası fiziksel akışla uyuşmuyor.")

    for source_seq, orders in source_station_orders.items():
        if sorted(orders) != list(range(1, len(orders) + 1)):
            raise ValueError(f"Referans {source_seq}: istasyon içi işlem sırası eksik.")

    copies.sort(key=lambda op: (
        int(op["PreservedReferenceStationSequence"]),
        int(op["PreservedReferenceStationOperationSequence"]),
    ))
    for i, op in enumerate(copies, start=1):
        op["PredictedProcessSequence"] = i
        op["AdaptiveReferenceSequence"] = i
        if str(op.get("PredictedStationType", "Main")) == "Main":
            following = copies[i:]
            next_main = next(
                (j for j, future in enumerate(following)
                 if str(future.get("PredictedStationType", "Main")) == "Main"),
                None,
            )
            op["AdaptiveMandatoryBoundaryAfter"] = bool(
                next_main is not None
                and any(str(other.get("PredictedStationType", "Main")) != "Main"
                        and not profiles.get(str(other.get("PredictedStationType", "Main")), {})
                                        .get('ParallelFeeder', False)
                        for other in following[:next_main])
            )
    return copies, next(iter(model_numbers))


def _adaptive_restore_station_order(operations):
    """Merged reference stations keep original relative operation order."""
    by_station = defaultdict(list)
    for op in operations:
        by_station[int(op["DisplayOrder"])].append(op)
    result = []
    for station in sorted(by_station):
        items = sorted(
            by_station[station],
            key=lambda op: int(op["AdaptiveReferenceSequence"]),
        )
        for station_position, operation in enumerate(items, start=1):
            operation["StationOperationSequence"] = station_position
            operation["WithinStationOrderSource"] = "ADAPTIVE_REFERENCE_SEQUENCE"
            operation["Sequence"] = len(result) + 1
            result.append(operation)
    return result


def _adaptive_validate(operations, records, cycle_time, max_station_load):
    """Reject actual engineering constraint violations, not safe regrouping."""
    stations = {int(r["DisplayOrder"]): r for r in records}
    grouped = defaultdict(list)
    for record in records:
        load = float(record["StationLoadSeconds"])
        if (not math.isfinite(load) or load < -1e-8 or
                load > max_station_load + 1e-6):
            raise ValueError("Kapasite ihlali: " +
                             str(record.get("AssignedStationLabel")))
    for op in operations:
        station = int(op["DisplayOrder"])
        if station not in stations:
            raise ValueError("Operasyon geçersiz istasyona atandı.")
        forced = op.get("ForcedPhysicalStationNumber")
        if forced is not None and int(forced) != int(op["PhysicalStationNumber"]):
            raise ValueError("Zorunlu fiziksel istasyon ihlali: " +
                             str(op.get("CanonicalName")))
        grouped[station].append(op)
    first_turns = [op for op in operations
                   if op.get('AssignedStationType') == 'Main'
                   and int(op.get('PhysicalStationNumber') or 0) == 1
                   and (op.get('IsPalletOrientationAnchor')
                        or is_pallet_turn(op.get('CanonicalName', '')))]
    if len(first_turns) > _first_station_pallet_limit(operations):
        raise ValueError('FIRST_MAIN_STATION_PALLET_TURN_LIMIT: 1. istasyondaki '
                         'palet dönüşleri doğrulanmış referans sınırını aşıyor; işlem silinmez.')
    if first_turns and int(first_turns[0].get('StationOperationSequence') or 0) != 1:
        raise ValueError('FIRST_MAIN_STATION_TURN_NOT_FIRST: 1. istasyondaki dönüş ilk işlem olmalı.')
    for index, rows in grouped.items():
        if not _seated_fan_station_compatible(rows):
            raise ValueError('SEATED_FAN_STATION_CONFLICT: ' +
                             str(stations[index].get('AssignedStationLabel')) +
                             ' fan kapağı sıkma ile uyumsuz ayakta/kanıtsız iş aynı istasyonda.')
        positions = sorted(int(op["StationOperationSequence"]) for op in rows)
        if positions != list(range(1, len(rows) + 1)):
            raise ValueError(f"İstasyon {index} işlem sırası hatalı.")
    main = sorted((op for op in operations
                   if op.get("AssignedStationType") == "Main"),
                  key=lambda o: int(o.get("AdaptiveReferenceSequence",
                                          o.get("PredictedProcessSequence", 0))))
    if not main:
        return
    source_stations = defaultdict(list)
    for op in main:
        original = op.get("PreservedReferenceStationSequence")
        if original is not None:
            source_stations[int(original)].append(op)
    for group in source_stations.values():
        group.sort(key=lambda o: int(o["AdaptiveReferenceSequence"]))
        numbers = [int(op["PhysicalStationNumber"]) for op in group]
        if numbers != sorted(numbers):
            raise ValueError("Referans istasyon içi operasyon bağı tersine döndü.")
    phases = _ck2_main_flow_phases(main)
    for first, second in zip(phases, phases[1:]):
        max_first = max(int(main[i]["PhysicalStationNumber"]) for i in first)
        min_second = min(int(main[i]["PhysicalStationNumber"]) for i in second)
        if max_first > min_second:
            raise ValueError("Palet yönü veya proses fazı tersine döndü.")
        if main[first[-1]].get("AdaptiveMandatoryBoundaryAfter"):
            if max_first >= min_second:
                raise ValueError("Özel proses aktarım sınırı kayboldu.")
    # The full historical station order is a guide, not a hard law. Only
    # approved dependency chains and state barriers are non-negotiable.



def balance_operations(
    operations: List[Dict[str, Any]],
    cycle_time: float,
    station_type_profiles: Dict[str, Any],
    precedence_edges=None,
    max_saturation_percent: float = 100.0,
    balance_mode: str = "preserve_method",
    reference_total_station_count=None,
    same_station_precedence_edges=None,
    hard_bundle_edges=None,
    operation_block_map=None,
    process_block_order_edges=None,
):
    if not operations:
        return (
            [],
            [],
            "NONE",
            [],
        )

    if (
        max_saturation_percent <= 0.0
        or
        max_saturation_percent > 100.0
    ):
        raise ValueError(
            "Maksimum hedef saturasyon 0 ile 100 arasında olmalıdır."
        )

    max_station_load = (
        cycle_time *
        max_saturation_percent /
        100.0
    )

    if not math.isfinite(float(cycle_time)) or cycle_time <= 0:
        raise ValueError("Hedef çevrim süresi pozitif ve sonlu olmalıdır.")
    if not math.isfinite(float(max_saturation_percent)):
        raise ValueError("Maksimum hedef saturasyon sonlu olmalıdır.")

    is_reference_preserved = (
        str(balance_mode).strip().lower() == "preserve_method"
        and any("PreservedReferenceModelNo" in op for op in operations)
    )
    reference_model = None
    if is_reference_preserved:
        operations, reference_model = _adaptive_reference_operations(
            operations, station_type_profiles
        )

    by_type = defaultdict(
        list
    )

    for operation in operations:
        station_type = str(
            operation.get(
                "PredictedStationType",
                "Main"
            )
        )

        by_type[
            station_type
        ].append(
            operation
        )

    # Estimate the non-Main reference count from learned process-zone
    # profiles so MODEL_Config CalisanSayisi can be interpreted as the
    # total reference staffing/layout.
    reference_special_count = 0

    for station_type in (
        by_type.keys()
    ):
        if station_type == "Main":
            continue

        profile = (
            station_type_profiles.get(
                station_type,
                {}
            )
        )

        if profile:
            reference_special_count += int(
                profile.get(
                    "CountMode",
                    0
                )
                or 0
            )

    reference_main_station_count = None

    if (
        reference_total_station_count
        is not None
    ):
        try:
            total_reference = int(
                round(
                    float(
                        reference_total_station_count
                    )
                )
            )
        except Exception:
            total_reference = 0

        if total_reference > 0:
            reference_main_station_count = max(
                1,
                total_reference -
                reference_special_count
            )

    zone_operations = {}
    zone_station_records = {}
    warnings = []
    balancer_names = []

    main_operations = (
        by_type.pop(
            "Main",
            []
        )
    )

    if main_operations:
        (
            balanced_operations,
            station_records,
            zone_warnings,
        ) = _build_direct_physical_main_zone(
            main_operations,
            cycle_time,
            max_station_load,
            max_saturation_percent,
            station_type_profiles.get(
                "Main",
                {}
            ),
            precedence_edges,
            hard_bundle_edges=
                hard_bundle_edges,
            operation_block_map=
                operation_block_map,
            process_block_order_edges=
                process_block_order_edges,
            balance_mode=
                balance_mode,
            reference_main_station_count=
                reference_main_station_count,
        )

        zone_operations[
            "Main"
        ] = balanced_operations

        zone_station_records[
            "Main"
        ] = station_records

        warnings.extend(
            zone_warnings
        )

        balancer_names.append("MAIN_AI_HAT_DENGELEME")

    for (
        station_type,
        type_operations
    ) in by_type.items():
        profile = (
            station_type_profiles.get(
                station_type,
                {}
            )
        )

        if not profile:
            raise ValueError(
                f"{station_type} için tarihsel istasyon profili bulunamadı."
            )

        if profile.get(
            "AggregateStationTime",
            False
        ):
            (
                balanced_operations,
                station_records,
                zone_warnings,
            ) = _build_aggregate_zone(
                type_operations,
                cycle_time,
                max_station_load,
                max_saturation_percent,
                station_type,
                profile
            )

            balancer_names.append(
                station_type.upper() +
                "_AGGREGATE"
            )

        else:
            fixed_count = (
                _ck2_station_count(profile, station_type)
                if profile.get("FixedCount", False)
                else None
            )

            (
                balanced_operations,
                station_records,
                zone_warnings,
            ) = _build_timed_zone(
                type_operations,
                cycle_time,
                max_station_load,
                max_saturation_percent,
                station_type,
                profile,
                fixed_count=
                    fixed_count,
                precedence_edges=None
            )

            balancer_names.append(
                station_type.upper() +
                "_BALANCED_ORDER"
            )

        zone_operations[
            station_type
        ] = balanced_operations

        zone_station_records[
            station_type
        ] = station_records

        warnings.extend(
            zone_warnings
        )

    (
        final_operations,
        station_records,
    ) = _merge_station_layout(
        zone_operations,
        zone_station_records,
        station_type_profiles,
        reference_operations=(operations if is_reference_preserved else None),
    )

    if is_reference_preserved:
        final_operations = _adaptive_restore_station_order(final_operations)
        warnings.insert(0, (
            "ADAPTIVE_REFERENCE_METHOD: reference=" + str(reference_model)
            + "; preserved=operations+process_state_phases+within_station_chains; "
            + "workforce=search_for_target_cycle_time; engineering_review=required_for_reorders"
        ))
    else:
        final_operations = _apply_learned_within_station_order(
            final_operations, same_station_precedence_edges
        )

    for record in station_records:
        if (
            record.get(
                "StationType"
            ) != "Main"
            and
            record.get(
                "PhysicalStationNumber"
            ) is None
        ):
            warnings.append(
                str(
                    record.get(
                        "AssignedStationLabel",
                        "Özel proses istasyonu"
                    )
                )
                +
                ": tarihsel veride birebir fiziksel istasyon numarası "
                "bulunamadı. Ek kapasite için mühendislik onayı gerekir."
            )

    _adaptive_validate(
        final_operations, station_records, cycle_time, max_station_load
    )

    warnings.insert(0, "CK2_ENGINE_REVISION=20261013_MULTIFILE_CT_OPTIMIZER")
    effective_work_content = sum(float(r["StationLoadSeconds"])
                                 for r in station_records)
    total_people = len(station_records)
    avg_saturation = (100.0 * effective_work_content /
                      (cycle_time * total_people))
    warnings.append(
        "TARGET_CT_BALANCE: cycle={:.3f}s, operators={}, "
        "mean_saturation={:.2f}%, special_stations={}, "
        "physical_limit={:.3f}s".format(
            cycle_time, total_people, avg_saturation,
            sum(r.get("StationType") != "Main" for r in station_records),
            max_station_load
        )
    )
    if avg_saturation < 90.0 - 1e-9:
        required_ceiling = int(math.floor(
            effective_work_content / (0.90 * cycle_time) + 1e-9
        ))
        warnings.append(
            "SATURATION_90_NOT_ACHIEVED: {} operators found;"
            " total operators must be at most {} for >=90% at this CT."
            " This is a mathematical condition, NOT a proof that the"
            " smaller layout is physically feasible. Further approved"
            " process/equipment changes may be required.".format(
                total_people, required_ceiling
            )
        )

    return (
        final_operations,
        station_records,
        "+".join(
            balancer_names
        ),
        warnings,
    )


# ----------------------------------------------------------------------
# CK2 AI Metod - standalone HiGHS/Scipy optional workforce optimisation.
# Entire original balancer above retained, no _legacy dependency.
# ----------------------------------------------------------------------

def _approved(edge):
    if edge.get("EngineeringApproved") is True or edge.get("IsApproved") is True:
        return True
    source = str(edge.get("ConstraintSource") or edge.get("RuleSource") or "").upper()
    return source in {
        "ENGINEERING_APPROVED", "HARD_TOOLING", "PHYSICAL_FIXTURE",
        "PHYSICAL_PROCESS", "SAFETY"
    }


def _ck2_reviewable_single_swap(operations, candidates, capacity_seconds, ceiling,
                                hard_bundle_edges, precedence_edges,
                                max_move_candidates, pallet_anchor_radius):
    """Generate a one-swap staffing PROPOSAL, not an approved manufacturing method.

    For the minimum-personnel mode only. Every candidate must retain the complete
    operation inventory and the physical orientation/turn sequence. A changed
    process order is explicitly reported as ENGINEERING_REVIEW_REQUIRED.
    Never silently approve or remove a process dependency.
    """
    n, m = len(operations), len(candidates)
    if n < 2 or m < 2:
        return None
    original = [float(op.get("PredictedTimeSeconds") or 0) for op in operations]
    cap = float(capacity_seconds)
    turn_phases = {}
    for phase_no, phase in enumerate(_ck2_main_flow_phases(operations)):
        for i in phase:
            turn_phases[i] = phase_no
    approved_precedence = set()
    for edge in precedence_edges or ():
        if not _approved(edge):
            continue
        src = str(edge.get("Source", ""))
        dst = str(edge.get("Target", ""))
        aa = [i for i,o in enumerate(operations) if str(o.get("CanonicalOperationId")) == src]
        bb = [i for i,o in enumerate(operations) if str(o.get("CanonicalOperationId")) == dst]
        if aa and bb:
            approved_precedence.add((aa[-1], bb[0]))

    approved_bundles = []
    for edge in hard_bundle_edges or ():
        if not _approved(edge):
            continue
        aa = [i for i,o in enumerate(operations)
              if str(o.get("CanonicalOperationId")) == str(edge.get("Source"))
              and int(o.get("OccurrenceIndex") or 1) == int(edge.get("SourceOccurrenceIndex") or 1)]
        bb = [i for i,o in enumerate(operations)
              if str(o.get("CanonicalOperationId")) == str(edge.get("Target"))
              and int(o.get("OccurrenceIndex") or 1) == int(edge.get("TargetOccurrenceIndex") or 1)]
        if aa and bb:
            approved_bundles.append((aa[0],bb[0]))

    possibilities = []
    for index in range(n - 1):
        left, right = operations[index], operations[index + 1]
        # No pallet or cehennemlik rotation and NO transfer across one.
        if (turn_phases[index] != turn_phases[index + 1]
                or is_pallet_turn(left.get("CanonicalName", ""))
                or is_pallet_turn(right.get("CanonicalName", ""))):
            continue
        if any((index, index+1)==edge for edge in approved_precedence):
            continue
        # Engineering dependency screening: no inspection before assembly,
        # knob before thermostat fixing, or screw-group order reversal.
        left_name = str(left.get("CanonicalName") or "").casefold()
        right_name = str(right.get("CanonicalName") or "").casefold()
        if ("kontrol" in right_name or "check" in right_name or
            ("düğme" in right_name and ("termostat" in left_name or
                                         "testata" in left_name)) or
            ("vida" in left_name and "vida" in right_name)):
            continue
        # Keep operation order INSIDE the real reference station.
        if left.get("PreservedReferenceStationSequence") == right.get("PreservedReferenceStationSequence"):
            continue
        # Do not move explicit physical lock operations.
        if any(o.get("ForcedPhysicalStationNumber") is not None or
               "STANDARD_CEHENNEMLIK_LABEL_PHYSICAL_STATION_1" in str(o.get("EngineeringRule") or "") or
               "KAPI_ETIKETI_CONFIG_VAR_PHYSICAL_44_OR_49" in str(o.get("EngineeringRule") or "")
               for o in (left,right)):
            continue
        order = list(range(n))
        order[index], order[index + 1] = order[index + 1], order[index]
        groups, loads = [], []
        for op_index in order:
            duration = original[op_index]
            if duration > cap + 1e-7:
                groups = []
                break
            if not loads or loads[-1] + duration > cap + 1e-7:
                groups.append([])
                loads.append(0.)
            groups[-1].append(op_index)
            loads[-1] += duration
        k = len(groups)
        if not groups or k > int(ceiling) or k > m:
            continue
        # The station numbers remain from the REAL physical layout; no
        # fictitious physical stations are created.
        station_slots = [round(g*(m-1)/max(1,k-1)) for g in range(k)]
        if len(set(station_slots)) != k:
            continue
        assigned = [None] * n
        for group_id, group in enumerate(groups):
            for operation_index in group:
                assigned[operation_index] = station_slots[group_id]
        feasible = True
        for i, op in enumerate(operations):
            physical = candidates[assigned[i]]
            fixed = op.get("ForcedPhysicalStationNumber")
            rule = str(op.get("EngineeringRule") or "")
            if fixed is None and "STANDARD_CEHENNEMLIK_LABEL_PHYSICAL_STATION_1" in rule:
                fixed = 1
            if fixed is None and "KAPI_ETIKETI_CONFIG_VAR_PHYSICAL_44_OR_49" in rule:
                preferred = op.get("PreferredPhysicalStationNumber")
                if preferred is None:
                    preferred = op.get("PreservedReferenceStationNumber")
                if preferred is not None and int(preferred) in (44,49):
                    fixed = int(preferred)
            if fixed is not None and int(physical) != int(fixed):
                feasible = False
                break
            original_index = _preferred_physical_candidate_index(op,candidates)
            if max_move_candidates is not None and abs(original_index-assigned[i]) > int(max_move_candidates):
                feasible = False
                break
            if (is_pallet_turn(op.get("CanonicalName","")) and
                pallet_anchor_radius is not None and
                abs(original_index-assigned[i]) > int(pallet_anchor_radius)):
                feasible = False
                break
        if not feasible:
            continue
        if any(assigned[a] > assigned[b] for a,b in approved_precedence):
            continue
        if any(assigned[a] != assigned[b] for a,b in approved_bundles):
            continue
        if any(assigned[a] > assigned[b] for a,b in
               ((i,j) for i in range(n) for j in range(i+1,n)
                if turn_phases[i] < turn_phases[j])):
            continue
        # All operations of one real reference station retain their order.
        station_history = defaultdict(list)
        for i,o in enumerate(operations):
            station_history[o.get("PreservedReferenceStationSequence")].append(i)
        if any(assigned[i] > assigned[j] for inds in station_history.values()
               for i,j in zip(inds,inds[1:])):
            continue
        pallet_loads = defaultdict(int)
        for i,op in enumerate(operations):
            if is_pallet_turn(op.get("CanonicalName", "")):
                pallet_loads[assigned[i]] += 1
        if max(pallet_loads.values(),default=0) > 2:
            continue
        changes = sum(assigned[i] > assigned[j]
                      for i in range(n) for j in range(i+1,n))
        # This is a proposal: minimize chronology inversions as first priority.
        possibilities.append((changes, k, index, assigned,station_slots))
    if not possibilities:
        return None
    # Staffing is the primary objective in Minimum Personel mode.
    # The former (changes, k) key picked a 29-person layout with zero
    # inversions ahead of a 28-person one with a reviewable inversion.
    # The chronology change must still be explicitly reported to engineers.
    changes,k,index,assigned,used = min(possibilities, key=lambda r:(r[1],r[0],r[2]))
    return {
        "AssignedCandidateIndices": assigned,
        "UsedCandidateIndices": used,
        "SoftPrecedenceViolations": None,
        "PhysicalDeviationSum": sum(abs(assigned[i]-_preferred_physical_candidate_index(op,candidates))
                                    for i,op in enumerate(operations)),
        "LargeMoveCount": sum(abs(assigned[i]-_preferred_physical_candidate_index(op,candidates))>3
                              for i,op in enumerate(operations)),
        "AppliedHardBundleEdges": len(approved_bundles),
        "SkippedHardBundleEdges": 0,
        "AppliedHardBundleComponents": len(approved_bundles),
        "AppliedProcessBlockEdges": 0,
        "SkippedProcessBlockEdges": 0,
        "ProcessBlockViolations": 0,
        "ProcessBlockWeightedViolation": 0,
        "PalletAnchorCount": sum(is_pallet_turn(op.get("CanonicalName","")) for op in operations),
        "PalletClusterLimit": 2,
        "HistoricalFlowEdgesKeptSoft": len(precedence_edges or []),
        "HardFlowEdges": len(approved_precedence),
        "FlowPhases": len(set(turn_phases.values())),
        "CrossOrderChanges": changes,
        "Status": "ENGINEERING_REVIEW_REQUIRED_SINGLE_ADJACENT_SWAP",
        "ReviewSwap": [
            {"Id":operations[index]["CanonicalOperationId"],"Name":operations[index].get("CanonicalName")},
            {"Id":operations[index+1]["CanonicalOperationId"],"Name":operations[index+1].get("CanonicalName")}
        ],
    }


def _fast_global_staffing(
    operations, candidates, max_station_load, station_count,
    precedence_edges, hard_bundle_edges=None, operation_block_map=None,
    process_block_order_edges=None, max_move_candidates=None,
    pallet_anchor_radius=1, max_time_seconds=8.0, status_sink=None,
    feasibility_only=False,
):
    try:
        import numpy as np
        from scipy.optimize import Bounds, LinearConstraint, milp
        from scipy.sparse import lil_matrix
    except ImportError as exc:
        raise RuntimeError(
            "SciPy eksik. Python 3.10 ortamında pip install scipy kullanın."
        ) from exc

    n, m = len(operations), len(candidates)
    if not n or not m or station_count < 1:
        return None
    cap = int(round(float(max_station_load) * 1000))
    if cap < 1:
        raise ValueError("Hedef istasyon kapasitesi pozitif olmalı")
    durations = np.array([
        max(1, int(round(float(op.get("PredictedTimeSeconds") or 0) * 1000)))
        for op in operations
    ], dtype=np.int64)
    if any(duration > cap for duration in durations):
        raise ValueError("Hedef CT'yi aşan bölünemez operasyon mevcut")
    if sum(durations) > cap * station_count:
        if status_sink is not None:
            status_sink.append({"Count": station_count, "Status": "PROVEN_CAPACITY_INFEASIBLE",
                                "MoveRadius": max_move_candidates,
                                "PalletRadius": pallet_anchor_radius})
        return None

    if _CK2_ALLOW_REVIEW_VARIANT.get():
        proposal = _ck2_reviewable_single_swap(
            operations, candidates, max_station_load, station_count,
            hard_bundle_edges, precedence_edges,
            max_move_candidates, pallet_anchor_radius,
        )
        if proposal is not None:
            if status_sink is not None:
                status_sink.append({"Count": len(proposal["UsedCandidateIndices"]),
                                    "Status":proposal["Status"],
                                    "MoveRadius":max_move_candidates,
                                    "PalletRadius":pallet_anchor_radius})
            return proposal

    # CK2 V020 SAFETY: hard chronological order. Previous optimiser only
    # protected within-station chains and turn *phases*, while freely moving
    # tasks from different source stations within a phase. That generated
    # 136 inversions on the 33704184 30-second test although the pallet-turn
    # sequence itself appeared intact. Such a layout is NOT a preserved method.
    # For now chronological source order is mandatory for Metodu Koru.
    # Any future relaxation must use an explicit engineer-approved edge list.
    strict_order_minimum = 1
    ordered_load = 0
    for duration in durations:
        if ordered_load + duration > cap:
            strict_order_minimum += 1
            ordered_load = 0
        ordered_load += duration
    if station_count < strict_order_minimum:
        if status_sink is not None:
            status_sink.append({
                "Count": station_count,
                "Status": "PROVEN_SEQUENCE_INFEASIBLE",
                "OrderedMinimum": strict_order_minimum,
                "MoveRadius": max_move_candidates,
                "PalletRadius": pallet_anchor_radius,
            })
        return None

    # Each operation is assigned to one true physical Main slot. Station
    # population is a DECISION, never the fixed 24-second learned count.
    total_vars = n * m + m
    lo_bounds = np.zeros(total_vars)
    hi_bounds = np.ones(total_vars)
    pallet_indices = []
    pallet_preferred = []
    forced_by_operation = {}
    for i, op in enumerate(operations):
        fixed = op.get("ForcedPhysicalStationNumber")
        rule = str(op.get("EngineeringRule") or "")
        if fixed is None and "STANDARD_CEHENNEMLIK_LABEL_PHYSICAL_STATION_1" in rule:
            fixed = 1
        if fixed is None and "KAPI_ETIKETI_CONFIG_VAR_PHYSICAL_44_OR_49" in rule:
            reference_location = op.get("PreferredPhysicalStationNumber")
            if reference_location is None:
                reference_location = op.get("PreservedReferenceStationNumber")
            try:
                if int(reference_location) in (44, 49):
                    fixed = int(reference_location)
            except (TypeError, ValueError, OverflowError):
                pass
        if fixed is not None:
            forced_by_operation[i] = int(fixed)
        preferred = _preferred_physical_candidate_index(op, candidates)
        turn = is_pallet_turn(op.get("CanonicalName", ""))
        if turn:
            pallet_indices.append(i)
            pallet_preferred.append(preferred)
        for j, number in enumerate(candidates):
            if fixed is not None and int(fixed) != int(number):
                hi_bounds[i * m + j] = 0
            elif (turn and pallet_anchor_radius is not None
                  and abs(j - preferred) > int(pallet_anchor_radius)):
                hi_bounds[i * m + j] = 0
            elif (max_move_candidates is not None and
                  abs(j - preferred) > int(max_move_candidates)):
                hi_bounds[i * m + j] = 0

    for i in range(n):
        if not hi_bounds[i * m:(i + 1) * m].any():
            if status_sink is not None:
                status_sink.append({"Count": station_count, "Status": "NO_ALLOWED_PHYSICAL_STATION",
                                    "MoveRadius": max_move_candidates,
                                    "PalletRadius": pallet_anchor_radius})
            return None

    # Approved edges are hard. Historical correlations are NOT.
    by_operation = defaultdict(list)
    index_by_occurrence = {}
    for i, op in enumerate(operations):
        op_id = str(op.get("CanonicalOperationId", ""))
        by_operation[op_id].append(i)
        index_by_occurrence[(op_id, int(op.get("OccurrenceIndex") or 1))] = i
    precedence = set()
    # Process chronology is a hard manufacturing constraint. Consecutive
    # operations may share a station, but a later operation cannot be placed
    # at an earlier station than its predecessor. Orientation edges remain
    # active too; the extra edges do not change any turn angles or counts.
    precedence.update((i, i + 1, 0) for i in range(n - 1))
    for i in range(n):
        for j in range(i + 1, n):
            if not _seated_fan_station_compatible((operations[i], operations[j])):
                precedence.add((i, j, 1))
    for edge in precedence_edges or []:
        if not _approved(edge):
            continue
        first = by_operation.get(str(edge.get("Source", "")), [])
        second = by_operation.get(str(edge.get("Target", "")), [])
        if first and second and first[-1] != second[0]:
            precedence.add((first[-1], second[0], 0))

    phases = _ck2_main_flow_phases(operations)
    for a, b in zip(phases, phases[1:]):
        strictly_after = int(bool(operations[a[-1]].get("AdaptiveMandatoryBoundaryAfter")))
        for i in a:
            for j in b:
                precedence.add((i, j, strictly_after))

    groups = defaultdict(list)
    for i, op in enumerate(operations):
        original_station = op.get("PreservedReferenceStationSequence")
        if original_station is not None:
            groups[int(original_station)].append(i)
    for indices in groups.values():
        for i, j in zip(indices, indices[1:]):
            precedence.add((i, j, 0))

    together = set()
    for edge in hard_bundle_edges or []:
        if not _approved(edge):
            continue
        a = index_by_occurrence.get((str(edge.get("Source")),
                                     int(edge.get("SourceOccurrenceIndex") or 1)))
        b = index_by_occurrence.get((str(edge.get("Target")),
                                     int(edge.get("TargetOccurrenceIndex") or 1)))
        if a is not None and b is not None and a != b:
            together.add(tuple(sorted((a, b))))

    # Each pallet anchor is a process-state boundary. Pallet rotations are
    # capped to the actual historically observed cluster size (max 2).
    pallet_limit = min(2, max(1, max(
        (pallet_preferred.count(v) for v in set(pallet_preferred)),
        default=1
    )))

    # CK2 V026: once the requested staffing level is feasible, do not accept
    # extremely empty stations merely because historical grouping prefers a cut.
    # Add one continuous variable containing the maximum unused capacity of any
    # opened Main station.  Headcount remains the first objective; this load
    # imbalance term is the second objective; historical grouping is third.
    imbalance_var = total_vars
    total_vars += 1
    lo_bounds = np.concatenate((lo_bounds, np.array([0.0])))
    hi_bounds = np.concatenate((hi_bounds, np.array([float(cap)])))

    row_count = n + m + len(precedence) + 2 * len(together) + m + 1 + m
    constraint = lil_matrix((row_count, total_vars), dtype=float)
    low = np.full(row_count, -np.inf)
    high = np.full(row_count, np.inf)
    row = 0
    for i in range(n):
        constraint[row, i * m:(i + 1) * m] = 1
        low[row] = high[row] = 1
        row += 1
    for j in range(m):
        constraint[row, j:n * m:m] = durations
        constraint[row, n * m + j] = -cap
        high[row] = 0
        row += 1
    ranks = np.arange(m, dtype=float)
    for i, j, strict in precedence:
        constraint[row, i * m:(i + 1) * m] = ranks
        constraint[row, j * m:(j + 1) * m] = -ranks
        high[row] = -strict
        row += 1
    for i, j in together:
        # Rank equality, not just adjacent slots.
        constraint[row, i * m:(i + 1) * m] = ranks
        constraint[row, j * m:(j + 1) * m] = -ranks
        high[row] = 0
        row += 1
        constraint[row, j * m:(j + 1) * m] = ranks
        constraint[row, i * m:(i + 1) * m] = -ranks
        high[row] = 0
        row += 1
    for j in range(m):
        for i in pallet_indices:
            constraint[row, i * m + j] = 1
        high[row] = _first_station_pallet_limit(operations) if int(candidates[j]) == 1 else pallet_limit
        row += 1
    constraint[row, n * m:n * m + m] = 1
    high[row] = station_count
    row += 1

    # Maximum unused capacity among OPENED stations. For an unused station
    # y_j=0 and load_j=0, therefore this row is automatically satisfied.
    # For an opened station it enforces:
    #     imbalance >= capacity - station_load
    # Minimising imbalance therefore prevents layouts such as 27.9 s / 4.5 s
    # at adjacent stations when the same headcount can be distributed better.
    for j in range(m):
        constraint[row, j:n * m:m] = -durations
        constraint[row, n * m + j] = cap
        constraint[row, imbalance_var] = -1
        high[row] = 0
        row += 1

    # Lexicographic objective: MINIMUM HEADCOUNT FIRST, load balance second,
    # learned grouping third.  The maximum possible imbalance is one CT in
    # milliseconds, so a 100000-point station penalty remains dominant.
    # second. The grouping model never creates a hard constraint and cannot
    # break palet/cehennemlik orientation or actual assembly chronology.
    cost = np.zeros(total_vars)
    if not feasibility_only:
        cost[n * m:n * m + m] = 100000.0
        cost[imbalance_var] = 1.0
        for i, op in enumerate(operations):
            preferred = _preferred_physical_candidate_index(op, candidates)
            for j in range(m):
                cost[i * m + j] = 0.00001 * abs(preferred - j)

        # For non-decreasing physical indices, the difference of station
        # ranks is zero if operations stay together, positive if split.
        # A learned high probability therefore discourages a cut, WITHOUT
        # overriding minimum workforce or any hard physical rule.
        for i in range(n - 1):
            raw_probability = operations[i].get(
                "LearnedSameStationWithNextProbability"
            )
            if raw_probability is None:
                continue
            try:
                probability = float(raw_probability)
            except (TypeError, ValueError):
                continue
            if not math.isfinite(probability):
                continue
            weight = 1.0 + 8.0 * max(0.0, min(1.0, probability) - 0.5)
            cost[(i + 1) * m:(i + 2) * m] += weight * ranks
            cost[i * m:(i + 1) * m] -= weight * ranks

    result = milp(
        cost,
        integrality=np.concatenate((
            np.ones(total_vars - 1, dtype=np.uint8),
            np.zeros(1, dtype=np.uint8),
        )),
        bounds=Bounds(lo_bounds, hi_bounds),
        constraints=LinearConstraint(constraint.tocsr(), low, high),
        options={"time_limit": max(1.0, float(max_time_seconds)),
                 "mip_rel_gap": 0.01, "disp": False},
    )
    status = ("PROVEN_INFEASIBLE" if result.status == 2 else
              "OPTIMAL" if result.status == 0 else
              "TIME_LIMIT" if result.status == 1 else "SOLVER_ERROR")
    if status_sink is not None:
        status_sink.append({"Count": station_count, "Status": status,
                            "MoveRadius": max_move_candidates,
                            "PalletRadius": pallet_anchor_radius})
    if result.x is None:
        return None
    matrix = result.x[:n * m].reshape(n, m)
    assigned = np.argmax(matrix, axis=1).tolist()
    if any(matrix[i, assigned[i]] < 1 - 1e-5 for i in range(n)):
        return None
    if any(sum(durations[i] for i, a in enumerate(assigned) if a == j) > cap
           for j in range(m)):
        return None
    if any(assigned[i] + strict > assigned[j]
           for i, j, strict in precedence):
        return None
    if any(assigned[i] != assigned[j] for i, j in together):
        return None
    if any(sum(assigned[i] == j for i in pallet_indices) > pallet_limit
           for j in range(m)):
        return None
    if any(int(candidates[assigned[i]]) != forced_by_operation[i]
           for i in forced_by_operation):
        return None
    used = sorted(set(assigned))
    if len(used) > station_count:
        return None
    return {
        "AssignedCandidateIndices": assigned,
        "UsedCandidateIndices": used,
        "SoftPrecedenceViolations": None,
        "PhysicalDeviationSum": sum(abs(assigned[i] -
            _preferred_physical_candidate_index(op, candidates))
                                     for i, op in enumerate(operations)),
        "LargeMoveCount": sum(abs(assigned[i] -
            _preferred_physical_candidate_index(op, candidates)) > 3
                              for i, op in enumerate(operations)),
        "AppliedHardBundleEdges": len(together),
        "SkippedHardBundleEdges": 0,
        "AppliedHardBundleComponents": len(together),
        "AppliedProcessBlockEdges": 0,
        "SkippedProcessBlockEdges": 0,
        "ProcessBlockViolations": 0,
        "ProcessBlockWeightedViolation": 0,
        "PalletAnchorCount": len(pallet_indices),
        "PalletClusterLimit": pallet_limit,
        "HistoricalFlowEdgesKeptSoft": len(precedence_edges or []),
        "HardFlowEdges": len([e for e in precedence_edges or [] if _approved(e)]),
        "FlowPhases": len(phases),
        "CrossOrderChanges": _ck2_reference_reorder_count(operations, assigned),
        "Status": ("HIGHS_FEASIBILITY_CERTIFIED" if feasibility_only else
                   "HIGHS_" + ("FEASIBLE" if result.status == 1 else status)),
    }




# Activate the global minimum-staff search as the physical main solver.
_solve_direct_physical_main_for_count = _fast_global_staffing


# CK2 V019 null-data diagnostic: keep the traceback's real failing location.
# This does not change operation order, timing or process-state constraints.
_ck2_core_balance_operations = balance_operations


def balance_operations(*args, **kwargs):
    try:
        return _ck2_core_balance_operations(*args, **kwargs)
    except TypeError as exc:
        if "int()" not in str(exc) or "NoneType" not in str(exc):
            raise
        import traceback
        frames = traceback.extract_tb(exc.__traceback__)
        local_frames = [f for f in frames if f.filename == __file__]
        last = local_frames[-1] if local_frames else frames[-1]
        raise ValueError(
            "CK2_NULL_INTEGER_FIELD: line_balancer.py:{} in {}. "
            "Boş gelen zorunlu sayısal alan tanımlanmalı; "
            "palet senkronu/istasyon kısıtları değiştirilmeyecek. "
            "Asıl hata: {}".format(last.lineno, last.name, exc)
        ) from exc


# ---------------------------------------------------------------------------
# CK2 V020 - final, independent manufacturing-order acceptance test.
# A layout with chronological inversions is rejected, not silently labelled
# ORIENTATION_SYNC_VALIDATED. Engineering safety > theoretical utilisation.
# ---------------------------------------------------------------------------
_ck2_balancing_before_sequence_validation = balance_operations


def _ck2_reference_instance_key(operation):
    return (
        str(operation.get("CanonicalOperationId", "")),
        int(operation.get("OccurrenceIndex") or 1),
    )


def _ck2_certify_manufacturing_order(source_operations, balanced_operations):
    source_main = [
        operation for operation in source_operations
        if str(operation.get("PredictedStationType", "Main")) == "Main"
    ]
    result_main = [
        operation for operation in balanced_operations
        if str(operation.get("AssignedStationType",
                             operation.get("PredictedStationType", "Main"))) == "Main"
    ]
    if not source_main:
        return
    source_keys = [_ck2_reference_instance_key(op) for op in source_main]
    if len(set(source_keys)) != len(source_keys):
        raise ValueError("SEQUENCE_SOURCE_DUPLICATE: Main operasyon kimliği tekrarlanıyor.")
    result_by_key = {_ck2_reference_instance_key(op): op for op in result_main}
    if set(source_keys) != set(result_by_key) or len(result_main) != len(source_keys):
        raise ValueError("SEQUENCE_INVENTORY_MISMATCH: Dengeleme operasyona ekleme/eksiltme yaptı.")
    prev = None
    for key in source_keys:
        operation = result_by_key[key]
        try:
            # PhysicalStationNumber may have gaps, but StationWithinType
            # must be monotonically increasing along the manufacturing flow.
            location = (
                int(operation["StationWithinType"]),
                int(operation["StationOperationSequence"]),
            )
        except (KeyError, TypeError, ValueError, OverflowError) as exc:
            raise ValueError("SEQUENCE_LOCATION_MISSING: {}".format(key)) from exc
        if prev is not None and location <= prev:
            raise ValueError(
                "SEQUENCE_ORDER_VIOLATION: Main işlem sırası bozuldu; "
                "önceki konum {} şimdiki konum {}, operasyon {}. "
                "Bu tahmin üretime uygun değildir.".format(prev, location, key)
            )
        prev = location


def _ck2_certify_exact_review_swap(source, balanced, warning):
    """Only the exact declared adjacent pair may invert; nothing else may."""
    source_main = [op for op in source if str(op.get("PredictedStationType", "Main")) == "Main"]
    output_main = [op for op in balanced
                   if str(op.get("AssignedStationType",op.get("PredictedStationType","Main"))) == "Main"]
    keys = [_ck2_reference_instance_key(x) for x in source_main]
    if len(set(keys)) != len(keys):
        raise ValueError("REVIEW_SOURCE_DUPLICATE")
    mapped = {_ck2_reference_instance_key(x):x for x in output_main}
    if len(mapped) != len(keys) or set(mapped) != set(keys):
        raise ValueError("REVIEW_OPERATION_INVENTORY_MISMATCH")
    claim = warning.partition("=")[2].strip().split("->")
    if len(claim) != 2:
        raise ValueError("REVIEW_INVALID_SWAP_DECLARATION")
    def fmt(k):return "{}#{}".format(k[0],k[1])
    actual_pairs = []
    locations=[]
    for k in keys:
        op=mapped[k]
        locations.append((int(op["StationWithinType"]),int(op["StationOperationSequence"])))
    for i in range(len(keys)-1):
        if locations[i] >= locations[i+1]:
            actual_pairs.append((fmt(keys[i]),fmt(keys[i+1])))
    if actual_pairs != [tuple(claim)]:
        raise ValueError("REVIEW_EXCESS_ORDER_INVERSIONS: {} != {}".format(actual_pairs,claim))
    # The orientation_sync module checks turn type, angle and direction state.
    validate_orientation(source, balanced)


def balance_operations(*args, **kwargs):
    """One AI balancing workflow for every client and every target CT.

    Retain the trained operation inventory and certified product-orientation
    constraints. Search the smallest feasible crew using the existing
    ordered baseline and learned-independent-operation proposal machinery.
    Unapproved chronology changes are explicitly marked for review.
    """
    params = list(args)
    kwargs = dict(kwargs)
    if len(params) > 5:
        # Historical sixth positional argument is the old balance_mode.
        params[5] = "preserve_method"
        kwargs.pop("balance_mode", None)
    else:
        kwargs["balance_mode"] = "preserve_method"

    source = params[0] if params else kwargs.get("operations", [])
    token = _CK2_ALLOW_REVIEW_VARIANT.set(False)
    try:
        result = _ck2_balancing_before_sequence_validation(*params, **kwargs)
        if not isinstance(result, tuple) or len(result) != 4:
            raise ValueError("AI_DENGELEME_GECERSIZ_SONUC")

        review_markers = [str(w) for w in result[3]
                          if str(w).startswith("REORDER_REVIEW_PAIR=")]
        if review_markers:
            if len(review_markers) != 1:
                raise ValueError("REVIEW_MULTIPLE_SWAP_MARKERS")
            _ck2_certify_exact_review_swap(source, result[0], review_markers[0])
        else:
            _ck2_certify_manufacturing_order(source, result[0])

        balanced, stations, _, warnings = result
        warnings = list(warnings)
        warnings.append(
            "AI_HAT_DENGELEME_SINGLE_MODE: Kullanicinin mod secimi yok; "
            "CT ve onayli muhendislik kurallariyla personel arandi; "
            "sira degisimi varsa ENGINEERING_REVIEW_REQUIRED zorunludur."
        )
        return balanced, stations, "AI_HAT_DENGELEME", warnings
    finally:
        _CK2_ALLOW_REVIEW_VARIANT.reset(token)


# ============================================================================
# CK-2 2026-10-16: APPLIED CT/ML REBALANCING, not an advisory-only Excel sheet.
# The old solver (above) still runs first and supplies a certified fallback.
# A strictly smaller phase-constrained layout replaces it only after independent
# operation-inventory, physical-station, pallet and duration verification.
# Any actual process-order inversion is explicitly ENGINEERING_REVIEW_REQUIRED.
# ============================================================================
_ck2_previous_single_workflow = balance_operations


def balance_operations(*args, **kwargs):
    """Single AI Hat Dengeleme. Search for real station reassignment.

    It never changes times, deletes operations, reorders pallet turns or
    represents unapproved manufacturing swaps as production-ready.
    """
    base_operations, base_stations, _, initial_warnings = (
        _ck2_previous_single_workflow(*args, **kwargs)
    )
    base = (base_operations, base_stations, "AI_HAT_DENGELEME", list(initial_warnings))

    try:
        from ck2_phase_optimizer import solve_one_fewer_main_station
    except ImportError as exc:
        warnings = list(initial_warnings)
        warnings.append("PHASE_OPTIMIZER_NOT_INSTALLED: " + str(exc))
        return base_operations, base_stations, "AI_HAT_DENGELEME", warnings

    source = args[0] if args else kwargs.get("operations", [])
    cycle_time = args[1] if len(args) > 1 else kwargs.get("cycle_time")
    profiles = args[2] if len(args) > 2 else kwargs.get("station_type_profiles")
    if not isinstance(profiles, dict) or cycle_time is None:
        return base
    saturation = kwargs.get("max_saturation_percent", 100.0)
    if len(args) >= 5:
        saturation = args[4]
    try:
        capacity = float(cycle_time) * float(saturation) / 100.0
    except (ValueError, TypeError, OverflowError):
        return base
    if capacity <= 0 or not math.isfinite(capacity):
        return base

    original_main = [o for o in source
                     if str(o.get("PredictedStationType", "Main")) == "Main"]
    actual_main = [o for o in base_operations
                   if str(o.get("AssignedStationType", "Main")) == "Main"]
    main_stations = [r for r in base_stations if r.get("StationType") == "Main"]
    physical = sorted({int(r["PhysicalStationNumber"]) for r in main_stations
                       if r.get("PhysicalStationNumber") is not None})
    if len(original_main) < 3 or len(physical) != len(main_stations):
        return base

    # The learned source chronology, not the already optimised station order,
    # determines orientation phases and historical within-station chains.
    ordered = sorted(original_main, key=lambda o: (
        int(o.get("PreservedReferenceStationSequence")
            or o.get("PredictedProcessSequence") or 0),
        int(o.get("PreservedReferenceStationOperationSequence") or 0),
    ))
    if len({_ck2_reference_instance_key(op) for op in ordered}) != len(ordered):
        return base
    current_by_key = {_ck2_reference_instance_key(op): op for op in actual_main}
    if set(current_by_key) != {_ck2_reference_instance_key(op) for op in ordered}:
        return base
    prepared = []
    for op in ordered:
        key = _ck2_reference_instance_key(op)
        item = dict(current_by_key[key])
        for attr in ("OrientationPhase", "OrientationBeforeDegrees",
                     "OrientationAfterDegrees", "OrientationTurnKind",
                     "OrientationTurnDegrees", "IsPalletOrientationAnchor",
                     "EngineeringRule", "AdaptiveMandatoryBoundaryAfter",
                     "PreservedReferenceStationSequence",
                     "PreservedReferenceStationOperationSequence",
                     "ForcedPhysicalStationNumber",
                     "LearnedSameStationWithNextProbability",
                     "TempoLayoutPreferredPhysicalStationNumber"):
            if attr in op:
                item[attr] = op[attr]
        prepared.append(item)

    # -------------------------------------------------------------------
    # CK2 V031 - deterministic fixed-count repartition for intermediate CT.
    #
    # The 1141 case proved that the existing physical optimiser can keep the
    # correct 24-person headcount yet leave a 11.796 s tail station although
    # the SAME operation order is mathematically partitionable near 20 s.
    # Before trying expensive one-less-station MILPs, repartition the existing
    # Main chronology over the already approved physical station set.
    #
    # Safety: operation order, inventory, durations, physical station set,
    # forced stations, forced Main ordinals, mandatory boundaries, approved
    # hard bundles and pallet-anchor locality are retained. Special processes
    # are not touched. Endpoint CTs (~24 s and 30 s) are intentionally locked.
    # -------------------------------------------------------------------
    # V047: use the same constraint-checked, fixed-count load balancing for
    # reduced saturation ceilings as well. At 100% the existing endpoint
    # methods follow exactly the same path as before.
    # V050: the first-station turn rule can split a fast-tempo group and
    # leave a very light station. Try the existing certified fixed-count
    # repartition there too; never change order, durations or station count.
    underloaded_main = any(float(r.get('StationLoadSeconds') or 0) < 0.5 * capacity
                           for r in main_stations)
    if (24.25 < float(cycle_time) < 29.75 or float(saturation) < 100.0 - 1e-9
            or underloaded_main) and len(main_stations) >= 2:
        try:
            ordered_main_records = sorted(
                main_stations, key=lambda r: int(r.get("StationWithinType") or 0)
            )
            physical_order = [
                int(r["PhysicalStationNumber"]) for r in ordered_main_records
            ]
            m = len(physical_order)
            n = len(prepared)
            durations = [float(op.get("PredictedTimeSeconds") or 0.0) for op in prepared]
            prefix = [0.0]
            for value in durations:
                prefix.append(prefix[-1] + value)

            # Mandatory cuts cannot be crossed. Approved hard bundles cannot
            # be cut. Historical (uncertified) co-location remains soft.
            mandatory_cuts = {
                i for i, op in enumerate(prepared[:-1])
                if op.get("AdaptiveMandatoryBoundaryAfter")
            }
            prohibited_cuts = set()
            by_occurrence = {
                _ck2_reference_instance_key(op): i for i, op in enumerate(prepared)
            }
            for edge in kwargs.get("hard_bundle_edges") or ():
                if not _approved(edge):
                    continue
                a = by_occurrence.get((
                    str(edge.get("Source")),
                    int(edge.get("SourceOccurrenceIndex") or 1),
                ))
                b = by_occurrence.get((
                    str(edge.get("Target")),
                    int(edge.get("TargetOccurrenceIndex") or 1),
                ))
                if a is None or b is None or a == b:
                    continue
                lo, hi = sorted((a, b))
                prohibited_cuts.update(range(lo, hi))

            # Pallet-anchor reference is interpreted in physical station-slot
            # space, not numeric station distance (37 -> 45 is one line slot).
            physical_index = {number: i for i, number in enumerate(physical_order)}

            def _nearest_physical_index(value):
                try:
                    number = float(value)
                except (TypeError, ValueError, OverflowError):
                    return None
                if not math.isfinite(number):
                    return None
                return min(
                    range(len(physical_order)),
                    key=lambda idx: abs(float(physical_order[idx]) - number),
                )

            # Use the same documented pallet-turn grouping allowance as the
            # active physical optimizer: at most two, and only when the
            # already validated incumbent contains two in one Main station.
            actual_turn_counts = defaultdict(int)
            for main_op in actual_main:
                if bool(main_op.get("IsPalletOrientationAnchor")):
                    actual_turn_counts[int(main_op.get("StationWithinType") or 0)] += 1
            documented_turn_limit = min(2, max(actual_turn_counts.values(), default=1))
            repartition_rejections = defaultdict(int)
            # Retain each Main station's side of the complete special-process
            # block, not merely a cut somewhere in the Main-only sequence.
            operation_regions = [sum(cut < i for cut in mandatory_cuts) for i in range(n)]
            station_regions = []
            for local in range(1, m + 1):
                regions = {operation_regions[i] for i, op in enumerate(prepared)
                           if int(current_by_key[_ck2_reference_instance_key(op)]
                                  .get('StationWithinType') or 0) == local}
                if len(regions) != 1:
                    raise ValueError('fixed_count_station_crosses_special_process_region')
                station_regions.append(next(iter(regions)))

            def _segment_valid(group_index, start, end):
                # [start, end) assigned to physical_order[group_index].
                if start >= end:
                    return False
                load = prefix[end] - prefix[start]
                if load > capacity + 1e-9:
                    return False
                assigned_physical = physical_order[group_index]
                if not _seated_fan_station_compatible(prepared[start:end]):
                    repartition_rejections['SEATED_STANDING_CONFLICT'] += 1
                    return False
                if (operation_regions[start] != station_regions[group_index]
                        or operation_regions[end - 1] != station_regions[group_index]):
                    return False

                # A mandatory boundary inside the segment would be crossed.
                if any(cut in mandatory_cuts for cut in range(start, end - 1)):
                    return False

                forced_numbers = set()
                pallet_count = 0
                for i in range(start, end):
                    op = prepared[i]
                    forced = op.get("ForcedPhysicalStationNumber")
                    if forced is not None:
                        forced_numbers.add(int(forced))
                    forced_ordinal = op.get("ForcedMainOrdinal")
                    if forced_ordinal is not None:
                        try:
                            if int(forced_ordinal) != group_index + 1:
                                return False
                        except (TypeError, ValueError, OverflowError):
                            return False
                    if op.get("IsPalletOrientationAnchor"):
                        # Pallet-turn ORDER is a hard process-state constraint,
                        # but its historical physical station is only a learned
                        # layout preference. Making +/-1 physical-slot locality
                        # hard made intermediate CT layouts (for example 1141)
                        # mathematically infeasible even though the SAME
                        # chronology is safely partitionable. Keep at most one
                        # pallet anchor in a station here; physical locality is
                        # handled as a soft tie-break below.
                        pallet_count += 1
                if len(forced_numbers) > 1:
                    return False
                if forced_numbers and assigned_physical not in forced_numbers:
                    return False
                local_turn_limit = _first_station_pallet_limit(prepared) if assigned_physical == 1 else documented_turn_limit
                if pallet_count > local_turn_limit:
                    repartition_rejections["PALLET_CLUSTER_LIMIT"] += 1
                    return False
                return True

            # Maximise the weakest station load with EXACTLY the existing Main
            # headcount. Secondary tie-break minimises squared deviation from
            # the ideal average load.
            ideal = prefix[-1] / float(m)
            neg = -1.0
            dp = [[None] * (n + 1) for _ in range(m + 1)]
            dp[0][0] = (float("inf"), 0.0, 0.0, -1)
            for groups in range(1, m + 1):
                min_i = groups
                max_i = n - (m - groups)
                for end in range(min_i, max_i + 1):
                    best = None
                    for start in range(end - 1, groups - 2, -1):
                        segment_load = prefix[end] - prefix[start]
                        if segment_load > capacity + 1e-9:
                            break
                        if start > 0 and (start - 1) in prohibited_cuts:
                            continue
                        prev = dp[groups - 1][start]
                        if prev is None:
                            continue
                        if not _segment_valid(groups - 1, start, end):
                            continue
                        weakest = min(prev[0], segment_load)
                        sqdev = prev[1] + (segment_load - ideal) ** 2

                        # Historical pallet physical position is SOFT. Preserve
                        # it when two equally balanced partitions exist, but do
                        # not reject a safe intermediate-CT partition solely
                        # because the learned station number came from 1065.
                        pallet_penalty = float(prev[2])
                        for i in range(start, end):
                            op = prepared[i]
                            if not op.get("IsPalletOrientationAnchor"):
                                continue
                            preferred = (
                                op.get("TempoLayoutPreferredPhysicalStationNumber")
                                if op.get("TempoLayoutPreferredPhysicalStationNumber") is not None
                                else op.get("PreferredPhysicalStationNumber")
                            )
                            pref_index = _nearest_physical_index(preferred)
                            if pref_index is not None:
                                pallet_penalty += abs(pref_index - (groups - 1))

                        candidate = (weakest, sqdev, pallet_penalty, start)
                        if (best is None
                                or candidate[0] > best[0] + 1e-9
                                or (abs(candidate[0] - best[0]) <= 1e-9
                                    and candidate[1] < best[1] - 1e-9)
                                or (abs(candidate[0] - best[0]) <= 1e-9
                                    and abs(candidate[1] - best[1]) <= 1e-9
                                    and candidate[2] < best[2] - 1e-9)):
                            best = candidate
                    dp[groups][end] = best

            # V041: solve the secondary objective in a separate additive pass.
            # A bottleneck at the final station must not freeze avoidable
            # 27.8s/19.2s imbalances elsewhere in the same unchanged chronology.
            from fair_partition import partition as _fair_partition
            def _pallet_preference(group_index, start, end):
                value = 0.0
                for i in range(start, end):
                    op = prepared[i]
                    if op.get('IsPalletOrientationAnchor'):
                        preferred = op.get('TempoLayoutPreferredPhysicalStationNumber')
                        if preferred is None:
                            preferred = op.get('PreferredPhysicalStationNumber')
                        pref_index = _nearest_physical_index(preferred)
                        if pref_index is not None:
                            value += abs(pref_index - group_index)
                return value
            fair = _fair_partition(
                durations, m, capacity, valid=_segment_valid,
                forbidden_cuts={cut + 1 for cut in prohibited_cuts},
                penalty=_pallet_preference,
            )
            if fair is not None:
                for group, (start, end, load) in enumerate(fair['segments'], 1):
                    dp[group][end] = (fair['minimum_load'], fair['squared_deviation'],
                                      fair['preference_penalty'], start)
            final_state = dp[m][n]
            if final_state is None:
                initial_warnings = list(initial_warnings)
                initial_warnings.append(
                    "INTERMEDIATE_CT_FIXED_COUNT_REPARTITION_NO_SOLUTION_V033: "
                    "main_count={}; operations={}; capacity={:.3f}s; "
                    "documented_turn_limit={}; rejection_counts={}; "
                    "baseline_kept=True".format(
                        m, n, capacity, documented_turn_limit,
                        dict(repartition_rejections)))
            if final_state is not None:
                boundaries = []
                end = n
                for groups in range(m, 0, -1):
                    state = dp[groups][end]
                    start = int(state[3])
                    boundaries.append((start, end))
                    end = start
                boundaries.reverse()

                assigned = [None] * n
                candidate_loads = []
                for group_index, (start, end) in enumerate(boundaries):
                    candidate_loads.append(prefix[end] - prefix[start])
                    for i in range(start, end):
                        assigned[i] = group_index

                old_loads = [float(r.get("StationLoadSeconds") or 0.0)
                             for r in ordered_main_records]
                old_min = min(old_loads) if old_loads else 0.0
                new_min = min(candidate_loads) if candidate_loads else 0.0
                old_sqdev = sum((value - ideal) ** 2 for value in old_loads)
                new_sqdev = sum((value - ideal) ** 2 for value in candidate_loads)
                material_improvement = (
                    new_min > old_min + 1.0 or
                    (new_min >= old_min - 1e-7 and new_sqdev < old_sqdev - 1.0)
                )

                # Apply only a material improvement. Equal/noisy solutions keep
                # the certified existing layout unchanged.
                if not material_improvement:
                    # V034 DIAGNOSTIC ONLY: isolate which constraint families
                    # prevent a better fixed-headcount partition. No relaxed
                    # candidate can ever be applied to the factory method.
                    def _v034_relaxed_best(relax):
                        relaxed = [[None] * (n + 1) for _ in range(m + 1)]
                        relaxed[0][0] = (float('inf'), 0.0)
                        for group in range(1, m + 1):
                            for finish in range(group, n - (m - group) + 1):
                                best_tuple = None
                                for begin in range(finish - 1, group - 2, -1):
                                    load = prefix[finish] - prefix[begin]
                                    if load > capacity + 1e-9:
                                        break
                                    previous = relaxed[group - 1][begin]
                                    if previous is None:
                                        continue
                                    if 'BUNDLE' not in relax and begin > 0 and begin - 1 in prohibited_cuts:
                                        continue
                                    if 'BOUNDARY' not in relax and any(
                                            cut in mandatory_cuts for cut in range(begin, finish - 1)):
                                        continue
                                    forced_set = set()
                                    turns = 0
                                    bad_ordinal = False
                                    for ix in range(begin, finish):
                                        item = prepared[ix]
                                        fixed = item.get('ForcedPhysicalStationNumber')
                                        if fixed is not None:
                                            forced_set.add(int(fixed))
                                        ordinal = item.get('ForcedMainOrdinal')
                                        if 'ORDINAL' not in relax and ordinal is not None:
                                            try:
                                                if int(ordinal) != group:
                                                    bad_ordinal = True
                                            except (TypeError, ValueError, OverflowError):
                                                bad_ordinal = True
                                        turns += bool(item.get('IsPalletOrientationAnchor'))
                                    if bad_ordinal:
                                        continue
                                    if len(forced_set) > 1 or (
                                        forced_set and physical_order[group - 1] not in forced_set
                                    ):
                                        continue
                                    if 'PALLET' not in relax and turns > documented_turn_limit:
                                        continue
                                    weak = min(previous[0], load)
                                    variance = previous[1] + (load - ideal) ** 2
                                    new_tuple = (weak, variance)
                                    if (best_tuple is None or weak > best_tuple[0] + 1e-9
                                            or (abs(weak - best_tuple[0]) <= 1e-9
                                                and variance < best_tuple[1])):
                                        best_tuple = new_tuple
                                relaxed[group][finish] = best_tuple
                        final = relaxed[m][n]
                        return None if final is None else round(final[0], 3)

                    ablations = {
                        'BASE': round(new_min, 3),
                        'NO_ORDINAL': _v034_relaxed_best({'ORDINAL'}),
                        'NO_BOUNDARY': _v034_relaxed_best({'BOUNDARY'}),
                        'NO_PALLET_LIMIT': _v034_relaxed_best({'PALLET'}),
                        'NO_APPROVED_BUNDLE': _v034_relaxed_best({'BUNDLE'}),
                        'ONLY_FORCED_PHYSICAL': _v034_relaxed_best(
                            {'ORDINAL', 'BOUNDARY', 'PALLET', 'BUNDLE'}),
                    }
                    initial_warnings = list(initial_warnings)
                    initial_warnings.append(
                        'V034_CONSTRAINT_ABLATION_DIAGNOSTIC_ONLY: '
                        + '; '.join('{}={}s'.format(k, 'INFEASIBLE' if v is None else v)
                                    for k, v in ablations.items())
                        + '; relaxed_results_NOT_APPLIED=True'
                    )
                    # V035: inspect the hard process barrier without relaxing it.
                    for boundary_index in sorted(mandatory_cuts):
                        left_work = prefix[boundary_index + 1]
                        right_work = prefix[-1] - left_work
                        left_min = math.ceil((left_work - 1e-9) / capacity)
                        right_min = math.ceil((right_work - 1e-9) / capacity)
                        left = prepared[boundary_index]
                        right = prepared[boundary_index + 1]
                        before_stations = sorted({
                            int(current_by_key[_ck2_reference_instance_key(op)]
                                .get('StationWithinType') or 0)
                            for op in prepared[:boundary_index + 1]
                        })
                        after_stations = sorted({
                            int(current_by_key[_ck2_reference_instance_key(op)]
                                .get('StationWithinType') or 0)
                            for op in prepared[boundary_index + 1:]
                        })
                        initial_warnings.append(
                            'V035_MANDATORY_PROCESS_BARRIER_DIAGNOSTIC_ONLY: '
                            'after_main_operation={} ({}); next_main_operation={} ({}); '
                            'before_work={:.3f}s; after_work={:.3f}s; '
                            'capacity={:.3f}s; before_min_stations={}; '
                            'after_min_stations={}; combined_lower_bound={}; '
                            'baseline_before_stations={}; baseline_after_stations={}; '
                            'barrier_RETAINED=True'.format(
                                boundary_index + 1, _ck2_reference_instance_key(left),
                                boundary_index + 2, _ck2_reference_instance_key(right),
                                left_work, right_work, capacity, left_min, right_min,
                                left_min + right_min, before_stations, after_stations))
                    if not mandatory_cuts:
                        initial_warnings.append(
                            'V035_MANDATORY_PROCESS_BARRIER_DIAGNOSTIC_ONLY: '
                            'no Main-special-Main barrier detected')
                    # V036: solve the two Main segments independently as a
                    # CONSTRUCTIVE check for one fewer Main employee.
                    # This does NOT lift the DoorPreparation process barrier,
                    # change timings or approve station movement. All results
                    # are advisory; the production baseline remains unchanged.
                    if len(mandatory_cuts) == 1:
                        cut = next(iter(mandatory_cuts)) + 1
                        baseline_left = len({
                            int(current_by_key[_ck2_reference_instance_key(op)]
                                .get('StationWithinType') or 0)
                            for op in prepared[:cut]
                        })
                        baseline_right = len({
                            int(current_by_key[_ck2_reference_instance_key(op)]
                                .get('StationWithinType') or 0)
                            for op in prepared[cut:]
                        })

                        # Check 17+6 at the physical-station level, trying each
                        # deleted pre-barrier station, with all fixed physical
                        # locks, certified bundles, pallet limits and chronology.
                        # Ordinals remain binding to their original physical
                        # station slot; they must not shift on deletion.
                        def _v036_region_dp(lo, hi, station_numbers):
                            k = hi - lo
                            if k < len(station_numbers) or not station_numbers:
                                return None
                            rp = [0.0]
                            for ix in range(lo, hi):
                                rp.append(rp[-1] + durations[ix])
                            num = len(station_numbers)
                            states = [[None] * (k + 1) for _ in range(num + 1)]
                            states[0][0] = (float('inf'), 0.0)
                            for g in range(1, num + 1):
                                station_number = station_numbers[g-1]
                                original_ordinal = physical_order.index(station_number) + 1
                                for e in range(g, k - (num-g) + 1):
                                    best_pair = None
                                    for b in range(e-1, g-2, -1):
                                        work = rp[e] - rp[b]
                                        if work > capacity + 1e-9:
                                            break
                                        prev = states[g-1][b]
                                        if prev is None:
                                            continue
                                        # No cut through an approved bundle.
                                        if b > 0 and lo+b-1 in prohibited_cuts:
                                            continue
                                        fixed = set()
                                        turn_count = 0
                                        legal = True
                                        for ix in range(lo+b, lo+e):
                                            op = prepared[ix]
                                            f = op.get('ForcedPhysicalStationNumber')
                                            if f is not None:
                                                fixed.add(int(f))
                                            ordinal = op.get('ForcedMainOrdinal')
                                            if ordinal is not None and int(ordinal) != original_ordinal:
                                                legal = False
                                                break
                                            turn_count += bool(op.get('IsPalletOrientationAnchor'))
                                        if not legal or len(fixed)>1 or (fixed and station_number not in fixed):
                                            continue
                                        if turn_count > documented_turn_limit:
                                            continue
                                        metric = (min(prev[0], work),
                                                  prev[1] + (work-rp[-1]/num)**2)
                                        if (best_pair is None or metric[0] > best_pair[0] + 1e-9
                                                or (abs(metric[0]-best_pair[0]) <= 1e-9
                                                    and metric[1] < best_pair[1])):
                                            best_pair = metric
                                    states[g][e] = best_pair
                            return states[num][k]

                        before_phys = physical_order[:baseline_left]
                        after_phys = physical_order[baseline_left:]
                        after_result = _v036_region_dp(cut, n, after_phys)
                        feasible_23 = []
                        if (len(before_phys) == baseline_left
                                and len(after_phys) == baseline_right
                                and after_result is not None):
                            for removed in before_phys:
                                remaining = [x for x in before_phys if x != removed]
                                candidate = _v036_region_dp(0, cut, remaining)
                                if candidate is not None:
                                    feasible_23.append((min(candidate[0], after_result[0]), removed))
                        if feasible_23:
                            best23 = max(feasible_23)
                            initial_warnings.append(
                                'V036_23_MAIN_CONSTRUCTIVE_FEASIBLE_DIAGNOSTIC_ONLY: '
                                'regions={}+{}; remove_physical_station={}; '
                                'min_station_load={:.3f}s; NOT_APPLIED=True; '
                                'full_orientation_and_special_merge_validation_required=True'.format(
                                    baseline_left-1, baseline_right, best23[1], best23[0]))
                        else:
                            initial_warnings.append(
                                'V036_23_MAIN_CONSTRUCTIVE_NOT_FOUND: '
                                'regions={}+{}; tried_pre_barrier_removals={}; '
                                'post_region_feasible={}; NOT_PROOF_OF_INFEASIBILITY=True; '
                                'baseline_kept=True'.format(
                                    baseline_left-1, baseline_right,
                                    len(before_phys), after_result is not None))

                    initial_warnings.append(
                        'V034_FIXED_COUNT_CONTEXT: n_operations={}; main_stations={}; '
                        'mandatory_cuts={}; approved_bundle_cuts={}; forced_ordinals={}; '
                        'forced_physical_ops={}; pallet_anchors={}; turn_limit={}'.format(
                            n, m, len(mandatory_cuts), len(prohibited_cuts),
                            sum(op.get('ForcedMainOrdinal') is not None for op in prepared),
                            sum(op.get('ForcedPhysicalStationNumber') is not None for op in prepared),
                            sum(bool(op.get('IsPalletOrientationAnchor')) for op in prepared),
                            documented_turn_limit,
                        )
                    )
                    initial_warnings.append(
                        "INTERMEDIATE_CT_FIXED_COUNT_REPARTITION_NOT_BETTER_V033: "
                        "old_min={:.3f}s; candidate_min={:.3f}s; "
                        "documented_turn_limit={}; baseline_kept=True".format(
                            old_min, new_min, documented_turn_limit))
                if material_improvement:
                    new_main, new_main_stations, used = _build_main_zone_from_assignment(
                        prepared, physical_order, assigned,
                        float(cycle_time), capacity, float(saturation),
                    )
                    if len(new_main_stations) != len(main_stations):
                        raise ValueError("fixed_count_repartition_changed_headcount")
                    if len(used) != len(physical_order):
                        raise ValueError("fixed_count_repartition_unused_station")

                    zone_ops = defaultdict(list)
                    zone_records = defaultdict(list)
                    for op in base_operations:
                        typ = str(op.get("AssignedStationType", "Main"))
                        if typ != "Main":
                            zone_ops[typ].append(op)
                    for record in base_stations:
                        typ = str(record.get("StationType", "Main"))
                        if typ != "Main":
                            zone_records[typ].append(record)
                    zone_ops["Main"] = new_main
                    zone_records["Main"] = new_main_stations

                    merged, records = _merge_station_layout(
                        zone_ops, zone_records, profiles,
                        reference_operations=base_operations,
                    )
                    merged = _adaptive_restore_station_order(merged)
                    _adaptive_validate(merged, records, float(cycle_time), capacity)
                    validate_orientation(prepared, merged)

                    output_main = [
                        op for op in merged
                        if str(op.get("AssignedStationType", "Main")) == "Main"
                    ]
                    output_by_key = {
                        _ck2_reference_instance_key(op): op for op in output_main
                    }
                    expected_keys = {_ck2_reference_instance_key(op) for op in prepared}
                    if (len(output_main) != len(prepared)
                            or set(output_by_key) != expected_keys):
                        raise ValueError("fixed_count_repartition_inventory_mismatch")
                    for original in prepared:
                        changed = output_by_key[_ck2_reference_instance_key(original)]
                        if abs(float(original["PredictedTimeSeconds"])
                               - float(changed["PredictedTimeSeconds"])) > 1e-8:
                            raise ValueError("fixed_count_repartition_duration_changed")
                    locations = [(
                        int(output_by_key[_ck2_reference_instance_key(op)]["StationWithinType"]),
                        int(output_by_key[_ck2_reference_instance_key(op)]["StationOperationSequence"]),
                    ) for op in prepared]
                    if any(locations[i] > locations[i + 1]
                           for i in range(len(locations) - 1)):
                        raise ValueError("fixed_count_repartition_order_inversion")

                    warnings = list(initial_warnings)
                    if underloaded_main and not (24.25 < float(cycle_time) < 29.75) and float(saturation) >= 100.0 - 1e-9:
                        warnings.append(
                            'V050_UNDERLOADED_MAIN_FIXED_COUNT_BALANCE: '
                            'main_count={}; old_min_load={:.6f}s; new_min_load={:.6f}s; '
                            'physical_station_set_order_times_and_headcount=UNCHANGED; '
                            'first_station_reference_turn_limit=RETAINED'.format(m, old_min, new_min))
                    if float(saturation) < 100.0 - 1e-9:
                        warnings.append(
                            'V047_REDUCED_SATURATION_FIXED_COUNT_BALANCE: '
                            'main_count={}; old_min_load={:.6f}s; new_min_load={:.6f}s; '
                            'physical_station_set=UNCHANGED; special_zones=UNCHANGED; '
                            'operation_order_and_times=UNCHANGED'.format(m, old_min, new_min))
                    warnings.extend([
                        'V041_FAIR_FIXED_ORDER_BALANCE: old_squared_deviation={:.6f}; '
                        'new_squared_deviation={:.6f}; mean_workload=UNCHANGED; '
                        'headcount=UNCHANGED; special_process_regions=PRESERVED'.format(
                            old_sqdev, new_sqdev),
                        "INTERMEDIATE_CT_FIXED_COUNT_REPARTITION_APPLIED_V032: "
                        "main_count={}; old_min_load={:.3f}s; new_min_load={:.3f}s; "
                        "capacity={:.3f}s; chronology=UNCHANGED; physical_stations=UNCHANGED".format(
                            m, old_min, new_min, capacity),
                        "FIXED_COUNT_REPARTITION_SAFETY_VALIDATED: inventory, durations, "
                        "forced stations, pallet locality, hard bundles, chronology and orientation preserved.",
                    ])
                    return merged, records, "AI_HAT_DENGELEME_FIXED_COUNT_DP", warnings
        except (ValueError, TypeError, KeyError, OverflowError, IndexError) as exc:
            initial_warnings = list(initial_warnings)
            initial_warnings.append(
                "INTERMEDIATE_CT_FIXED_COUNT_REPARTITION_REJECTED: " + str(exc)[:300]
            )

    # Search EVERY removable physical station. The historical implementation
    # tried just the least-loaded one, then silently returned its baseline.
    proposals = []
    failed_station_candidates = []
    try:
        fixed_numbers = {int(o["ForcedPhysicalStationNumber"])
                         for o in prepared
                         if o.get("ForcedPhysicalStationNumber") is not None}
        for station in physical[1:-1]:
            if station in fixed_numbers:
                continue
            candidate = solve_one_fewer_main_station(
                prepared, physical, capacity,
                precedence_edges=kwargs.get("precedence_edges"),
                hard_bundle_edges=kwargs.get("hard_bundle_edges"),
                time_limit=8.0,
                removed_station=station,
            )
            if candidate is not None:
                proposals.append(candidate)
            else:
                failed_station_candidates.append(station)
    except RuntimeError as exc:
        warnings = list(initial_warnings)
        warnings.append("PHASE_OPTIMIZER_SKIPPED: " + str(exc))
        return base_operations, base_stations, "AI_HAT_DENGELEME", warnings
    if not proposals:
        warnings = list(initial_warnings)
        warnings.append(
            "ONE_LESS_STATION_SEARCH_UNRESOLVED: tried_removing={}; "
            "no_valid_solution_within_time_limit; original_station_count={}".format(
                ",".join(str(x) for x in failed_station_candidates), len(physical)))
        return base_operations, base_stations, "AI_HAT_DENGELEME", warnings

    # Evaluate EVERY MILP feasible proposal through the real application
    # merge/validation pipeline. Never silently discard a candidate.
    audit = []
    sorted_proposals = sorted(
        proposals, key=lambda q: (max(q["loads"]), sum(x*x for x in q["loads"]))
    )
    for proposal in sorted_proposals:
        stage = "BUILD"
        try:
            candidate_numbers = proposal["used_physical_numbers"]
            indices = {number: i for i, number in enumerate(candidate_numbers)}
            assigned = [indices[number] for number in proposal["assigned_physical_numbers"]]
            new_main, new_main_stations, used = _build_main_zone_from_assignment(
                prepared, candidate_numbers, assigned,
                float(cycle_time), capacity, float(saturation),
            )
            if len(new_main_stations) >= len(main_stations):
                raise ValueError("station_count_not_reduced")
            if len(used) != len(candidate_numbers):
                raise ValueError("unused_station_after_build")
            zone_ops = defaultdict(list)
            zone_records = defaultdict(list)
            for op in base_operations:
                typ = str(op.get("AssignedStationType", "Main"))
                if typ != "Main":
                    zone_ops[typ].append(op)
            for record in base_stations:
                typ = str(record.get("StationType", "Main"))
                if typ != "Main":
                    zone_records[typ].append(record)
            zone_ops["Main"] = new_main
            zone_records["Main"] = new_main_stations
            stage = "MERGE"
            merged, records = _merge_station_layout(
                zone_ops, zone_records, profiles, reference_operations=base_operations,
            )
            stage = "RESTORE_ORDER"
            merged = _adaptive_restore_station_order(merged)
            stage = "CHECK_CAPACITY_AND_HARD_RULES"
            _adaptive_validate(merged, records, float(cycle_time), capacity)
            stage = "CHECK_ORIENTATION"
            validate_orientation(prepared, merged)
            stage = "CHECK_INVENTORY"
            output_main = [op for op in merged
                           if str(op.get("AssignedStationType", "Main")) == "Main"]
            output_by_key = {_ck2_reference_instance_key(op): op for op in output_main}
            if (len(output_main) != len(prepared)
                    or len(output_by_key) != len(prepared)
                    or set(output_by_key) != {_ck2_reference_instance_key(o) for o in prepared}):
                raise ValueError("operation_inventory_mismatch")
            stage = "CHECK_TIMES"
            for original in prepared:
                changed = output_by_key[_ck2_reference_instance_key(original)]
                if abs(float(original["PredictedTimeSeconds"])
                       - float(changed["PredictedTimeSeconds"])) > 1e-8:
                    raise ValueError("operation_duration_changed")
            stage = "CHECK_STATION_TOTAL"
            if len(records) >= len(base_stations):
                raise ValueError("total_station_count_not_reduced")
            if abs(sum(float(r["StationLoadSeconds"]) for r in records)
                   - sum(float(r["StationLoadSeconds"]) for r in base_stations)) > 1e-5:
                raise ValueError("total_work_content_changed")
            stage = "CHECK_CHRONOLOGY"
            locations = [(
                int(output_by_key[_ck2_reference_instance_key(op)]["StationWithinType"]),
                int(output_by_key[_ck2_reference_instance_key(op)]["StationOperationSequence"]),
            ) for op in prepared]
            revised = []
            for i in range(len(prepared)-1):
                if locations[i] > locations[i+1]:
                    if prepared[i].get("OrientationPhase") != prepared[i+1].get("OrientationPhase"):
                        raise ValueError("orientation_phase_inversion")
                    revised.append((prepared[i], prepared[i+1]))
            if revised:
                raise ValueError("source_operation_order_inversions=" + str(len(revised)))
            warnings = list(initial_warnings)
            warnings.extend([
                "AI_REAL_REBALANCE_APPLIED: main_stations={} -> {}; total_stations={} -> {}; "
                "removed_physical_station={}".format(
                    len(main_stations), len(new_main_stations), len(base_stations),
                    len(records), proposal["removed_physical_number"]),
                "CHRONOLOGY_FULLY_PRESERVED: main_operations={}; "
                "adjacent_order_inversions=0".format(len(prepared)),
                "PHYSICAL_INSTALLATION_REVIEW_REQUIRED: Ekipman, aparat ve erişim saha onayı gerekir.",
            ])
            return merged, records, "AI_HAT_DENGELEME_STRICT_CT_MILP", warnings
        except (ValueError, TypeError, KeyError, OverflowError, IndexError) as exc:
            audit.append("remove_station={} stage={} reason={}".format(
                proposal.get("removed_physical_number"), stage, str(exc)[:250]))
            continue
    warnings = list(initial_warnings)
    warnings.append("AI_ONE_LESS_STATION_REJECTED_BY_APPLICATION: " + " | ".join(audit[:16]))
    return base_operations, base_stations, "AI_HAT_DENGELEME", warnings
# ============================================================================
# V038 — VERIFIED INTERMEDIATE-CT ENGINEERING PROPOSAL
# ============================================================================
# The V037 endpoint was advisory-only: it returned the unchanged baseline.
# V038 actually constructs and returns a different *review candidate* when
# there is a demonstrable same-headcount load improvement. It NEVER labels
# a changed manufacturing sequence as production-approved.
# No additional optimizer wrapping has been added: this REPLACES V037.
# ============================================================================
_ck2_v038_previous_balance_operations = balance_operations


def _ck2_v038_ordered_optimum(durations, count, capacity, boundary_after):
    """Exact max-min contiguous partition into count occupied stations.

    boundary_after is a 1-based number of operations before the mandatory
    DoorPreparation block. No group may cross that boundary. This function
    returns a proof-quality DP optimum under this specific fixed-order model,
    not a claim of global factory optimum under all possible process changes.
    """
    n = len(durations)
    if n < count or count <= 0:
        return None
    prefix = [0.0]
    for x in durations:
        x = float(x)
        if not math.isfinite(x) or x < 0 or x > capacity + 1e-8:
            return None
        prefix.append(prefix[-1] + x)
    best = [[-1.0] * (n + 1) for _ in range(count + 1)]
    back = [[-1] * (n + 1) for _ in range(count + 1)]
    best[0][0] = float('inf')
    for groups in range(1, count + 1):
        for end in range(groups, n - count + groups + 1):
            for start in range(end - 1, groups - 2, -1):
                load = prefix[end] - prefix[start]
                if load > capacity + 1e-8:
                    break
                if start < boundary_after < end:
                    continue
                prev = best[groups - 1][start]
                if prev < 0:
                    continue
                value = min(prev, load)
                if value > best[groups][end] + 1e-8:
                    best[groups][end] = value
                    back[groups][end] = start
    if best[count][n] < 0:
        return None
    segments = []
    end = n
    for groups in range(count, 0, -1):
        start = back[groups][end]
        if start < 0:
            return None
        segments.append((start, end, prefix[end] - prefix[start]))
        end = start
    if end != 0:
        return None
    segments.reverse()
    return best[count][n], segments


def _ck2_v038_candidate(source, balanced, stations, cycle_time,
                         saturation_percent, hard_bundle_edges, precedence_edges):
    """Return (balanced, station_records, diagnostic) for a review proposal.

    The only eligible edit is exactly one adjacent non-turn operation swap
    inside an existing orientation phase and on one side of a documented
    special-process boundary. Tool/precedence links explicitly approved by
    engineering cannot be inverted. Other operations stay in original order.
    """
    main_source = sorted(
        [op for op in source if str(op.get('PredictedStationType', 'Main')) == 'Main'],
        key=lambda op: (
            int(op.get('PredictedProcessSequence') or 0),
            float(op.get('PredictedProcessPosition') or 0.0),
        ))
    main_records = sorted(
        [r for r in stations if r.get('StationType') == 'Main'],
        key=lambda r: int(r.get('StationWithinType') or 0))
    if len(main_source) < 3 or len(main_records) < 2:
        return None, 'NO_MAIN'
    # V039: The previous code looked for an internal-only flag that is
    # frequently absent from the passed source operations.  A legitimate
    # Main -> DoorPreparation -> Main barrier is also observable in the
    # baseline's complete chronological output.  Reconstruct it by unique
    # operation *instance keys*, never by arbitrary row counts or by guessing
    # station numbers.  If independent evidence conflicts, refuse the edit.
    source_cuts = {
        i + 1 for i, op in enumerate(main_source[:-1])
        if op.get('AdaptiveMandatoryBoundaryAfter')
    }
    source_index = {
        _ck2_reference_instance_key(op): i + 1
        for i, op in enumerate(main_source)
    }
    if len(source_index) != len(main_source):
        return None, 'BARRIER_SOURCE_INSTANCE_DUPLICATE'

    baseline_order = sorted(
        balanced,
        key=lambda op: (
            int(op.get('Sequence') or op.get('DisplayOrder') or 0),
            int(op.get('StationOperationSequence') or 0),
        ),
    )
    inferred_cuts = set()
    preceding_main_key = None
    intervening_types = set()
    for op in baseline_order:
        kind = str(op.get('AssignedStationType', op.get('PredictedStationType', 'Main')))
        if kind == 'Main':
            if preceding_main_key is not None and intervening_types:
                prev_index = source_index.get(preceding_main_key)
                current_index = source_index.get(_ck2_reference_instance_key(op))
                if prev_index is None or current_index is None:
                    return None, 'BARRIER_OPERATION_KEY_NOT_FOUND'
                if current_index != prev_index + 1:
                    return None, 'BARRIER_BASELINE_ORDER_CONFLICT'
                inferred_cuts.add(prev_index)
            preceding_main_key = _ck2_reference_instance_key(op)
            intervening_types.clear()
        elif preceding_main_key is not None:
            intervening_types.add(kind)

    combined_cuts = source_cuts | inferred_cuts
    if len(combined_cuts) != 1:
        return None, 'BARRIER_AMBIGUOUS_source={}_output={}'.format(
            sorted(source_cuts), sorted(inferred_cuts))
    cut = next(iter(combined_cuts))
    barrier_source = 'OUTPUT_CHRONOLOGY' if not source_cuts else 'SOURCE_FLAG'
    old_main = [o for o in balanced if o.get('AssignedStationType') == 'Main']
    if len(old_main) != len(main_source):
        return None, 'MAIN_INVENTORY_MISMATCH'
    capacity = cycle_time * saturation_percent / 100.0
    n_stations = len(main_records)
    old_min = min(float(r['StationLoadSeconds']) for r in main_records)
    durations = [_duration_value(op) for op in main_source]
    base_best = _ck2_v038_ordered_optimum(durations, n_stations, capacity, cut)
    if base_best is None:
        return None, 'BASELINE_ORDERED_DP_INFEASIBLE'
    ids = [_ck2_reference_instance_key(op) for op in main_source]
    if len(ids) != len(set(ids)):
        return None, 'NON_UNIQUE_OPERATION_INSTANCES'
    current = {_ck2_reference_instance_key(op): op for op in old_main}
    if set(current) != set(ids):
        return None, 'RESULT_OPERATION_INVENTORY_MISMATCH'
    # Never swap across an explicitly approved process precedence constraint.
    approved_order = set()
    for edge in precedence_edges or ():
        ok = (edge.get('EngineeringApproved') is True or edge.get('IsApproved') is True
              or str(edge.get('ConstraintSource') or '').upper()
              in ('ENGINEERING_APPROVED', 'PHYSICAL_PROCESS', 'SAFETY'))
        if ok:
            approved_order.add((str(edge.get('Source')), str(edge.get('Target'))))
    approved_groups = []
    for edge in hard_bundle_edges or ():
        ok = (edge.get('EngineeringApproved') is True or edge.get('IsApproved') is True
              or str(edge.get('ConstraintSource') or edge.get('RuleSource') or '').upper()
              in ('ENGINEERING_APPROVED', 'HARD_TOOLING', 'PHYSICAL_FIXTURE'))
        if ok:
            approved_groups.append((
                (str(edge.get('Source')), int(edge.get('SourceOccurrenceIndex') or 1)),
                (str(edge.get('Target')), int(edge.get('TargetOccurrenceIndex') or 1))))

    best_trial = None
    for idx in range(len(main_source) - 1):
        # Do not change the side of the Door/Test/Visual transfer barrier.
        if idx + 1 == cut:
            continue
        first = main_source[idx]
        second = main_source[idx + 1]
        # V040: never invent a manufacturing reversal solely to improve load.
        # Require repeated examples of BOTH orders in approved human methods;
        # a consistent cross-tempo order is protected independently.
        from human_method_order import historically_supported_swap
        if not historically_supported_swap(first):
            continue
        if (first.get('IsPalletOrientationAnchor') or second.get('IsPalletOrientationAnchor')
                or is_pallet_turn(first.get('CanonicalName', ''))
                or is_pallet_turn(second.get('CanonicalName', ''))
                or first.get('AdaptiveMandatoryBoundaryAfter')
                or first.get('ForcedPhysicalStationNumber') is not None
                or second.get('ForcedPhysicalStationNumber') is not None
                or first.get('ForcedMainOrdinal') is not None
                or second.get('ForcedMainOrdinal') is not None
                or first.get('OrientationPhase') != second.get('OrientationPhase')):
            continue
        a_id, b_id = ids[idx], ids[idx + 1]
        if ((a_id[0], b_id[0]) in approved_order
                or (b_id[0], a_id[0]) in approved_order):
            continue
        test_duration = list(durations)
        test_duration[idx], test_duration[idx + 1] = (
            test_duration[idx + 1], test_duration[idx])
        trial = _ck2_v038_ordered_optimum(test_duration, n_stations, capacity, cut)
        if trial is None:
            continue
        improvement = trial[0] - old_min
        # Avoid noise; require a material same-personnel improvement.
        if improvement < max(2.0, 0.07 * capacity):
            continue
        if best_trial is None or trial[0] > best_trial[0] + 1e-8:
            best_trial = (trial[0], idx, trial[1])
    if best_trial is None:
        return None, 'NO_FEASIBLE_IMPROVING_SINGLE_SWAP'

    target_min, swapped_index, segments = best_trial
    sequence = list(ids)
    sequence[swapped_index], sequence[swapped_index + 1] = (
        sequence[swapped_index + 1], sequence[swapped_index])
    assigned = {}
    new_loads = []
    for local, (start, end, load) in enumerate(segments, 1):
        new_loads.append(load)
        for key in sequence[start:end]:
            assigned[key] = local
    if len(assigned) != len(ids):
        return None, 'CANDIDATE_LOST_AN_OPERATION'
    # Check all fixed station anchors and accepted real tooling bundles.
    for key, local in assigned.items():
        original = main_source[ids.index(key)]
        record = main_records[local - 1]
        forced_number = original.get('ForcedPhysicalStationNumber')
        forced_ordinal = original.get('ForcedMainOrdinal')
        if (forced_number is not None
                and int(forced_number) != int(record.get('PhysicalStationNumber') or -1)):
            return None, 'FORCED_PHYSICAL_STATION_MISMATCH'
        if forced_ordinal is not None and int(forced_ordinal) != local:
            return None, 'FORCED_MAIN_ORDINAL_MISMATCH'
    for a_id, b_id in approved_groups:
        if a_id in assigned and b_id in assigned and assigned[a_id] != assigned[b_id]:
            return None, 'APPROVED_TOOLING_BUNDLE_SPLIT'
    # Within each existing physical station no more pallet turns than in the
    # approved base layout, except where no other layout is physically possible.
    original_turn_limit = max(1, max(
        (sum(bool(op.get('IsPalletOrientationAnchor'))
             for op in old_main if int(op.get('StationWithinType') or 0) == k)
         for k in range(1, n_stations + 1)), default=1))
    for local in range(1, n_stations + 1):
        turns = sum(bool(op.get('IsPalletOrientationAnchor'))
                    for op, key in zip(main_source, ids) if assigned[key] == local)
        if turns > original_turn_limit:
            return None, 'PALLET_TURN_STATION_LIMIT'
    # Extra audit: do not let any rotation jump across another rotation or
    # any surrounding operation. validate_orientation() is the final authority.
    new_records = [dict(r) for r in stations]
    record_by_ordinal = {int(r['StationWithinType']): r for r in new_records
                         if r.get('StationType') == 'Main'}
    for local, load in enumerate(new_loads, 1):
        r = record_by_ordinal[local]
        r['StationLoadSeconds'] = float(load)
        r['StationSaturationPercent'] = 100.0 * load / cycle_time
        r['SaturationLimitExceeded'] = load > capacity + 1e-8
        r['StationFeasible'] = load <= capacity + 1e-8
    new_main = []
    for local, (start, end, load) in enumerate(segments, 1):
        station = record_by_ordinal[local]
        for within, key in enumerate(sequence[start:end], 1):
            op = dict(current[key])
            op['AssignedStationType'] = 'Main'
            op['StationWithinType'] = local
            op['StationOperationSequence'] = within
            op['AssignedStation'] = station['AssignedStation']
            op['DisplayOrder'] = station['DisplayOrder']
            op['PhysicalStationNumber'] = station.get('PhysicalStationNumber')
            op['AssignedStationLabel'] = station['AssignedStationLabel']
            op['StationLoadSeconds'] = float(load)
            op['StationSaturationPercent'] = 100.0 * load / cycle_time
            op['SaturationLimitExceeded'] = load > capacity + 1e-8
            new_main.append(op)
    combined = new_main + [dict(op) for op in balanced
                           if op.get('AssignedStationType') != 'Main']
    combined.sort(key=lambda op: (int(op.get('DisplayOrder') or 0),
                                  int(op.get('StationOperationSequence') or 0)))
    for position, op in enumerate(combined, 1):
        op['Sequence'] = position
    swapped = (ids[swapped_index], ids[swapped_index + 1])
    signature = 'REORDER_REVIEW_PAIR={}#{}->{}#{}'.format(
        swapped[0][0], swapped[0][1], swapped[1][0], swapped[1][1])
    try:
        _ck2_certify_exact_review_swap(source, combined, signature)
        if len(combined) != len(balanced):
            raise ValueError('ALL_OPERATION_COUNT_CHANGED')
        original_times = {_ck2_reference_instance_key(op): op.get('PredictedTimeSeconds')
                          for op in balanced}
        for op in combined:
            value = op.get('PredictedTimeSeconds')
            prior = original_times[_ck2_reference_instance_key(op)]
            if value is None and prior is None:
                continue
            if abs(float(value) - float(prior)) > 1e-8:
                raise ValueError('OPERATION_DURATION_CHANGED')
        if abs(sum(float(r['StationLoadSeconds']) for r in stations)
               - sum(float(r['StationLoadSeconds']) for r in new_records)) > 1e-7:
            raise ValueError('TOTAL_WORKLOAD_CHANGED')
        for row in new_records:
            if row.get('StationType') == 'Main' and row['StationLoadSeconds'] > capacity + 1e-8:
                raise ValueError('CT_VIOLATED')
    except (ValueError, KeyError, TypeError, IndexError, OverflowError) as error:
        return None, 'V038_CERTIFICATION_FAILED_' + str(error)[:200]
    diagnostic = {
        'old_min': old_min,
        'new_min': min(new_loads),
        'headcount': n_stations,
        'swap': signature,
        'phase': main_source[swapped_index].get('OrientationPhase'),
        'barrier_source': barrier_source,
        'barrier_cut': cut,
    }
    return (combined, new_records), diagnostic


def _apply_user_confirmed_visual_order(operations, records, cycle_time,
                                       saturation_percent, warnings,
                                       hard_bundle_edges=(), precedence_edges=()):
    """Apply ONLY the explicitly confirmed inspection/cable order change.

    User confirmed that hell-liner inspection may precede placing the power
    cable on the pallet. This is an explicit process rule, not an ML discovery
    and not permission to reorder other visual tasks. Names identify the two
    process roles; no product or canonical operation number is hard-coded.
    """
    visual_records = sorted((r for r in records if r.get('StationType') == 'Visual'),
                            key=lambda r: int(r['StationWithinType']))
    if len(visual_records) <= 2:
        return operations, records, warnings
    visual = sorted((op for op in operations if op.get('AssignedStationType') == 'Visual'),
                    key=lambda op: (int(op['DisplayOrder']), int(op['StationOperationSequence'])))
    from common import normalize_text
    names = [normalize_text(op.get('CanonicalName')) for op in visual]
    inspections = [i for i, name in enumerate(names)
                   if name == 'CEHENNEMLIK KONTROLU YAP']
    cables = [i for i, name in enumerate(names)
              if 'ENERJI KABLO' in name and 'PALET' in name and 'APARAT' in name]
    if len(inspections) != 1 or len(cables) != 1:
        return operations, records, warnings
    inspection, cable = inspections[0], cables[0]
    if inspection != cable + 1:
        return operations, records, warnings
    if any(visual[i].get('IsPalletOrientationAnchor') for i in (inspection, cable)):
        return operations, records, warnings
    candidate = [dict(op) for op in visual]
    candidate[cable], candidate[inspection] = candidate[inspection], candidate[cable]
    identity = _ck2_reference_instance_key
    expected = [identity(op) for op in visual]
    allowed = list(expected)
    allowed[cable], allowed[inspection] = allowed[inspection], allowed[cable]
    if [identity(op) for op in candidate] != allowed:
        raise ValueError('V043_UNAPPROVED_VISUAL_ORDER_CHANGE')
    capacity = float(cycle_time) * float(saturation_percent) / 100.0
    positions = {identity(op): i for i, op in enumerate(candidate)}
    canonical_positions = defaultdict(list)
    for i, op in enumerate(candidate):
        canonical_positions[str(op['CanonicalOperationId'])].append(i)
    # Explicit physical precedence and certified tooling remain binding.
    for edge in precedence_edges or ():
        if not _approved(edge):
            continue
        left = canonical_positions.get(str(edge.get('Source')), [])
        right = canonical_positions.get(str(edge.get('Target')), [])
        if left and right and max(left) >= min(right):
            return operations, records, list(warnings) + ['V043_VISUAL_RULE_BLOCKED_BY_APPROVED_PRECEDENCE']
    forbidden = set()
    for edge in hard_bundle_edges or ():
        if not _approved(edge):
            continue
        a = positions.get((str(edge.get('Source')), int(edge.get('SourceOccurrenceIndex') or 1)))
        b = positions.get((str(edge.get('Target')), int(edge.get('TargetOccurrenceIndex') or 1)))
        if a is not None and b is not None:
            lo, hi = sorted((a, b))
            forbidden.update(range(lo + 1, hi + 1))
    def valid(group, start, end):
        physical = visual_records[group].get('PhysicalStationNumber')
        for op in candidate[start:end]:
            forced = op.get('ForcedPhysicalStationNumber')
            if forced is not None and (physical is None or int(forced) != int(physical)):
                return False
        return True
    from fair_partition import partition
    plan = partition([_duration_value(op) for op in candidate], 2, capacity,
                     valid=valid, forbidden_cuts=forbidden)
    if plan is None:
        return operations, records, list(warnings) + ['V043_CONFIRMED_VISUAL_ORDER_TWO_STATIONS_INFEASIBLE']
    new_visual, new_visual_records = [], []
    for group, (start, end, load) in enumerate(plan['segments']):
        record = dict(visual_records[group])
        record.update(StationWithinType=group + 1, StationLoadSeconds=load,
                      StationCycleSource='SUM_OPERATION_TIMES',
                      StationSaturationPercent=load / cycle_time * 100.0,
                      MaxTargetSaturationPercent=saturation_percent,
                      SaturationLimitExceeded=False, StationFeasible=True)
        new_visual_records.append(record)
        for within, op in enumerate(candidate[start:end], 1):
            item = dict(op)
            for field in ('AssignedStation', 'DisplayOrder', 'AssignedStationLabel',
                          'PhysicalStationNumber', 'StationWithinType', 'StationLoadSeconds',
                          'StationCycleSource', 'StationSaturationPercent',
                          'MaxTargetSaturationPercent', 'SaturationLimitExceeded'):
                item[field] = record[field]
            item['StationOperationSequence'] = within
            item['WithinStationOrderSource'] = 'USER_CONFIRMED_VISUAL_INSPECTION_BEFORE_CABLE'
            new_visual.append(item)
    new_records = sorted([dict(r) for r in records if r.get('StationType') != 'Visual']
                         + new_visual_records, key=lambda r: int(r['DisplayOrder']))
    remap = {int(r['DisplayOrder']): i for i, r in enumerate(new_records, 1)}
    new_operations = [dict(op) for op in operations if op.get('AssignedStationType') != 'Visual'] + new_visual
    for record in new_records:
        record['DisplayOrder'] = record['AssignedStation'] = remap[int(record['DisplayOrder'])]
    for op in new_operations:
        op['DisplayOrder'] = op['AssignedStation'] = remap[int(op['DisplayOrder'])]
    new_operations.sort(key=lambda op: (int(op['DisplayOrder']), int(op['StationOperationSequence'])))
    for index, op in enumerate(new_operations, 1):
        op['Sequence'] = index
    before = {identity(op): op.get('PredictedTimeSeconds') for op in operations}
    after = {identity(op): op.get('PredictedTimeSeconds') for op in new_operations}
    if before != after or len(new_operations) != len(operations):
        raise ValueError('V043_VISUAL_INVENTORY_OR_DURATION_CHANGED')
    _ck2_certify_manufacturing_order(operations, new_operations)
    _adaptive_validate(new_operations, new_records, cycle_time, capacity)
    if abs(sum(float(r['StationLoadSeconds']) for r in records)
           - sum(float(r['StationLoadSeconds']) for r in new_records)) > 1e-7:
        raise ValueError('V043_TOTAL_WORKLOAD_CHANGED')
    # Remove statements that describe the superseded three-station result.
    updated = [w for w in warnings if not str(w).startswith((
        'Visual:', 'GÖRSEL İSTASYON EK-', 'TARGET_CT_BALANCE:',
        'SATURATION_90_NOT_ACHIEVED:', 'TARGET_90_GAP:'))]
    work = sum(float(r['StationLoadSeconds']) for r in new_records)
    updated.extend([
        'V043_USER_CONFIRMED_VISUAL_ORDER: inspection_before_power_cable=True; '
        'visual_stations={}->2; loads={}; operation_times=UNCHANGED; '
        'main_order=UNCHANGED; source=explicit_user_process_confirmation'.format(
            len(visual_records), ','.join('{:.6f}s'.format(s[2]) for s in plan['segments'])),
        'TARGET_CT_BALANCE: cycle={:.3f}s, operators={}, mean_saturation={:.2f}%, '
        'visual_order=user_confirmed'.format(cycle_time, len(new_records),
                                             work / (cycle_time * len(new_records)) * 100.0),
    ])
    return new_operations, new_records, updated


def balance_operations(*args, **kwargs):
    """Preserve feasible groups and use the confirmed Main positions 1..49.

    Historical positions are preferred, not the physical capacity ceiling.
    Existing physical labels are retained without moving work groups.
    Door preparation supplies Main as a separate parallel feeder.
    """
    ct = float(args[1] if len(args) > 1 else kwargs.get('cycle_time', 0))
    saturation = float(args[4] if len(args) > 4 else kwargs.get('max_saturation_percent', 100.0))
    from copy import deepcopy
    params, kwargs = list(args), dict(kwargs)
    profiles = deepcopy(params[2] if len(params) > 2 else kwargs.get('station_type_profiles', {}))
    topology_active = 24.25 < ct < 29.75 or saturation < 100.0 - 1e-9
    if topology_active:
        if 'DoorPreparation' in profiles:
            profiles['DoorPreparation']['ParallelFeeder'] = True
    if len(params) > 2:
        params[2] = profiles
        kwargs.pop('station_type_profiles', None)
    else:
        kwargs['station_type_profiles'] = profiles
    args = tuple(params)
    expanded = False
    try:
        # Historical used positions remain preferences on already feasible
        # methods. Failure does not turn them into a factory capacity limit.
        result = _ck2_v038_previous_balance_operations(*args, **kwargs)
    except ValueError as error:
        reason = str(error)
        if not any(marker in reason for marker in (
                'Ana hatta mevcut iş sırası için kapasite yetersiz',
                'Main dengeleme uygulanabilir çözüm bulamadı',
                'gereken Main istasyon sayısı')):
            raise
        main_profile = profiles.get('Main')
        if not main_profile:
            raise
        main_profile['ObservedReferenceStationNumbers'] = list(main_profile.get('PhysicalStationNumbers', []))
        main_profile['PhysicalStationNumbers'] = list(range(1, 50))
        # These positions were explicitly supplied by the user as real Main
        # positions. Special zones continue to use their own separate profiles.
        result = _ck2_v038_previous_balance_operations(*args, **kwargs)
        expanded = True
    result_ops, result_records, result_method, result_warnings = result
    # Physical labels are real plant locations, not ranks to compress.
    # Keep the accepted 49; reject invalid Main labels instead of relabelling.
    for record in result_records:
        if record.get('StationType') == 'Main':
            number = int(record['PhysicalStationNumber'])
            if not 1 <= number <= 49:
                raise ValueError('Ana hat fiziksel istasyonu 1-49 aralığında olmalı: {}'.format(number))
    result_warnings = list(result_warnings)
    if expanded:
        result_warnings.append('V046_CONFIRMED_MAIN_POSITIONS_USED: available=1..49; '
                               'history_used_positions_are_preferences_not_capacity_limits=True; '
                               'special_zones=SEPARATE; source=explicit_user_topology')
    result = result_ops, result_records, result_method, result_warnings
    source = args[0] if args else kwargs.get('operations', ())
    if not topology_active:
        return result
    old_ops, old_records, method, original_warnings = result
    saturation = float(args[4] if len(args) > 4 else
                       kwargs.get('max_saturation_percent', 100.0))
    old_ops, old_records, original_warnings = _apply_user_confirmed_visual_order(
        old_ops, old_records, ct, saturation, original_warnings,
        kwargs.get('hard_bundle_edges'), kwargs.get('precedence_edges'))
    if profiles.get('DoorPreparation', {}).get('ParallelFeeder'):
        consumer_key = _validate_parallel_feeder_supply(source, old_ops, 'DoorPreparation')
        warnings = list(original_warnings)
        warnings.append('V042_PARALLEL_DOOR_FEEDER_VALIDATED: topology=user_confirmed; '
                        'main_flow_cut=False; supply_before_consumer={}#{}; '
                        'door_preparation_staff_and_workload=RETAINED; '
                        'main_operation_order=UNCHANGED; '
                        'startup_buffer_and_transport_time=NOT_MEASURED'.format(*consumer_key))
        # V039's proposal routine interprets any special display block as a
        # physical Main boundary. It is inapplicable to a parallel feeder.
        return old_ops, old_records, method, warnings
    saturation = float(args[4] if len(args) > 4 else
                       kwargs.get('max_saturation_percent', 100.0))
    bundles = kwargs.get('hard_bundle_edges')
    precedence = kwargs.get('precedence_edges')
    changed, diagnostic = _ck2_v038_candidate(
        source, old_ops, old_records, ct, saturation, bundles, precedence)
    warnings = list(original_warnings)
    if changed is None:
        warnings.append('V039_NO_UNAPPROVED_MODIFICATION: reason={}; baseline_kept=True'.format(diagnostic))
        return old_ops, old_records, method, warnings
    new_ops, new_records = changed
    # Make contradictory old-baseline commentary unambiguous in the report.
    warnings = [w for w in warnings if not str(w).startswith((
        'PRESERVE_METHOD_CT_STAFFING:', 'CHRONOLOGY_FULLY_PRESERVED:'))]
    warnings.extend([
        'ENGINEERING_REVIEW_REQUIRED_REORDER: ' + diagnostic['swap']
            + '; NOT_CERTIFIED_FOR_PRODUCTION=True',
        'V039_BOUNDARY_SOURCE: source={}; cut_after_main_operation={}'.format(
            diagnostic['barrier_source'], diagnostic['barrier_cut']),
        'V039_INTERMEDIATE_CT_ENGINEERING_PROPOSAL_APPLIED: '
            'main_count={}; old_min_load={:.3f}s; new_min_load={:.3f}s; '
            'source_inventory=UNCHANGED; pallet_turn_order=PRESERVED; '
            'mandatory_special_process_boundary=PRESERVED; '
            'one_unapproved_adjacent_operation_swap=True'.format(
                diagnostic['headcount'], diagnostic['old_min'], diagnostic['new_min']),
        'V039_ENGINEERING_APPROVAL_REQUIRED: Proposed physical operation '
            'sequence must be approved by manufacturing engineering before '
            'release; the AI-generated method is for review only.',
    ])
    return new_ops, new_records, method + '+V039_REVIEW_CANDIDATE', warnings
