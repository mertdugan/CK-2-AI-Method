"""Run with PYTHONPATH=../CK2_ORIENTATION_SYNC:.. python test_regression.py"""
import sys, re, collections, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'CK2_ORIENTATION_SYNC'))
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ck2_xlsx_reader import load
import line_balancer as lb
from orientation_sync import turn_kind

p=load(str(ROOT/'33704184_AI_Method_20261014_144730.xlsx'))['Predicted_Method']
h={str(v):k for k,v in p[0][1].items()}
src, existing=[], []
for rn,x in p[1:]:
 if x.get(h['AssignedStationType'])!='Main':continue
 o={key:x.get(h[key]) for key in h if x.get(h[key]) is not None}
 o['PreservedReferenceStationSequence']=int(x[h['NearestReferenceStationSequence']]);o['PreservedReferenceStationOperationSequence']=int(x[h['NearestReferenceStationOperationSequence']])
 o['PredictedStationType']='Main';o['AssignedStationType']='Main'
 src.append(dict(o));existing.append(dict(o))
src.sort(key=lambda o:int(o['PredictedProcessSequence']))
assert len(src)==102
load_value=sum(op['PredictedTimeSeconds'] for op in src)
assert math.isclose(load_value,572.8650266666666,abs_tol=.001)
min_ordered=1;acc=0
for op in src:
 d=op['PredictedTimeSeconds']
 if acc+d >30+1e-8:min_ordered+=1;acc=0
 acc+=d
assert min_ordered==23, min_ordered
print('PASS: 102 operations; real ordered 30 s lower bound = 23 Main stations')
real=load(str(ROOT/'33704184.xlsx'))['33704184 grf']
candidates=sorted(set(int(re.match(r'(\d+)',str(x[0])).group(1)) for _,x in real if isinstance(x.get(0),str) and re.match(r'\d+',x[0])))
for n in (20,21,22):
 sink=[]
 result=lb._fast_global_staffing(src,candidates,30,n,[],max_move_candidates=None,pallet_anchor_radius=None,max_time_seconds=1,status_sink=sink,feasibility_only=True)
 assert result is None
 assert sink and sink[0]['Status']=='PROVEN_SEQUENCE_INFEASIBLE',sink
 print('PASS: {} Main rejected as impossible with strict ordering'.format(n))
try:
 lb._ck2_certify_manufacturing_order(src,existing)
except ValueError as e:
 assert 'SEQUENCE_ORDER_VIOLATION' in str(e),str(e)
 print('PASS: Previous 28-station Excel chronology inversion caught:',str(e)[:180])
else:
 raise AssertionError('Previous unsafely re-ordered output was not rejected')
for fname, sheet, expected in [('33704217_.xlsx','33704217',(9,7,16)),('33704184.xlsx','33704184',(17,0,17))]:
 rows=load(str(ROOT/fname))[sheet]
 rotations=[turn_kind(str(x.get(0,''))) for _,x in rows]
 counts=collections.Counter(kind for kind,degrees in rotations if kind)
 assert (counts['PALLET'],counts['COMPONENT'],sum(counts.values()))==expected,(fname,counts)
 print('PASS:',fname,'rotation signatures',dict(counts))
# A feasible conservative solution must also pass the final safety gate.
import json
safepath=ROOT/'ck2_solution23.json'
if safepath.exists():
 plan=json.loads(safepath.read_text(encoding='utf-8'))
 source_by_key={(str(o['CanonicalOperationId']),int(o['OccurrenceIndex'])):o for o in src}
 safe=[];counter=collections.Counter()
 for i,operation in enumerate(plan['ops']):
  op=dict(operation)
  rank=plan['used'].index(plan['assignment'][i])+1
  counter[rank]+=1
  op['StationWithinType']=rank
  op['StationOperationSequence']=counter[rank]
  op['AssignedStationType']='Main'
  safe.append(op)
 lb._ck2_certify_manufacturing_order(src,safe)
 assert len(set(plan['assignment']))==23
 assert all(sum(op['PredictedTimeSeconds'] for op,j in zip(plan['ops'],plan['assignment']) if j==idx) <=30+1e-6 for idx in set(plan['assignment']))
 refs={}
 for op,j in zip(plan['ops'],plan['assignment']):
  rule=str(op.get('EngineeringRule') or '')
  if 'STANDARD_CEHENNEMLIK_LABEL_PHYSICAL_STATION_1' in rule: assert plan['candidates'][j]==1
  if 'KAPI_ETIKETI_CONFIG_VAR_PHYSICAL_44_OR_49' in rule: assert plan['candidates'][j] in (44,49)
 print('PASS: 23 Main, 0 inversions, <=30 seconds and both physical label anchors respected')
print('ALL LOCAL REGRESSIONS PASSED')
