# -*- coding: utf-8 -*-
import heapq
import csv
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

import joblib
import pandas as pd

from common import (
    normalize_model_no,
    CONFIG_FIELDS,
    config_similarity_score,
    load_json,
    normalize_text,
    note_segments,
    note_terms,
    pair_feature_dict,
    read_model_config,
)
from orientation_sync import (
    is_pallet_turn, mark_orientation_phases, validate_orientation,
    turn_kind, reference_chronology,
)
from station_group_learning import annotate_station_groups
from reorder_learning import annotate_reorder_evidence
from tempo_layout_learning import learn_tempo_station_layout
from human_method_order import annotate_human_order, validate_human_order
from process_improvement import propose_improvements
from line_balancer import (
    balance_operations, _is_seated_fan_cover, _is_standing_side_panel,
)
from method_integrity import (
    choose_coherent_method, require_reference_has_hard_operations,
    attach_coherent_chronology, post_balance_integrity,
    MethodIntegrityError,
)







from dataclasses import replace

def base_model_no(value) -> str:
    """Identity shared by all tempo observations of one physical product."""
    return re.sub(r"__T\d+$", "", normalize_model_no(value), flags=re.I)

def workforce_metrics(stations, cycle_time, staffing_plan):
    ct = float(cycle_time)
    if not math.isfinite(ct) or ct <= 0:
        raise ValueError('Çevrim süresi pozitif ve sonlu olmalı.')
    manual, machine = [], []
    for station in stations:
        seconds = float(station.get('StationLoadSeconds') or 0)
        if not math.isfinite(seconds) or seconds < 0:
            raise ValueError('İstasyon yükü negatif veya sonlu olmayan bir değer içeriyor.')
        if station.get('StationCycleSource') == 'HISTORICAL_STATION_AGGREGATE':
            machine.append(seconds)
        else:
            manual.append(seconds)
    known_seconds = sum(manual)
    operators = int(staffing_plan['operator_count'])
    manual_average = 100 * known_seconds / (ct * len(manual)) if manual else None
    overall = (100 * known_seconds / (ct * operators)
               if operators > 0 and not machine else None)
    return {
        'manual_work_seconds': known_seconds,
        'manual_station_count': len(manual),
        'manual_saturation_percent': manual_average,
        'manual_min_saturation_percent': 100 * min(manual) / ct if manual else None,
        'manual_max_saturation_percent': 100 * max(manual) / ct if manual else None,
        'machine_station_count': len(machine),
        'machine_cycle_seconds': sum(machine),
        'machine_saturation_percent': 100 * sum(machine) / (ct * len(machine)) if machine else None,
        'operator_saturation_percent': overall,
        'operator_saturation_status': ('TEST_ACTIVE_LABOR_TIME_NOT_MEASURED'
                                        if machine else 'KNOWN_TIMED_WORK'),
        'operator_saturation_known_lower_bound_percent': (
            100 * known_seconds / (ct * operators) if operators > 0 else None),
        'max_staff_for_90_percent': (
            int(math.floor(known_seconds / (ct * .9) + 1e-9)) if not machine else None),
    }

def adapt_quantity_occurrences(method, expected_counts):
    """Adapt explicitly configured part counts, retaining one coherent process.

    Only already present operation templates may be repeated. New components,
    alternative assembly descriptions and orientation operations are not added.
    """
    members, order, counts = {}, [], dict(method.counts)
    for operation_id, expected in expected_counts.items():
        if operation_id not in counts or int(expected) < 0:
            raise MethodIntegrityError('CONFIG_QUANTITY_TEMPLATE_UNAVAILABLE: ' + operation_id)
        if any(turn_kind(str(method.members[key].get('CanonicalName', '')))[0]
               for key in method.order if key.rpartition('#')[0] == operation_id):
            raise MethodIntegrityError('CONFIG_QUANTITY_ROTATION_FORBIDDEN')
        counts[operation_id] = int(expected)
    for key in method.order:
        operation_id, _, occurrence = key.rpartition('#')
        if int(occurrence) <= counts[operation_id]:
            members[key] = dict(method.members[key])
            order.append(key)
        if int(occurrence) == method.counts[operation_id]:
            for index in range(method.counts[operation_id] + 1, counts[operation_id] + 1):
                added = '{}#{}'.format(operation_id, index)
                members[added] = dict(method.members[key])
                order.append(added)
    # Re-index station order after an extra tray, never insert a physical
    # station, and preserve the relative order of every original operation.
    station_indices, local = {}, Counter()
    for key in order:
        row = members[key]
        old_sequence = row['StationSequence']
        station_indices.setdefault(old_sequence, len(station_indices) + 1)
        row['StationSequence'] = station_indices[old_sequence]
        local[old_sequence] += 1
        row['StationOperationSequence'] = local[old_sequence]
    counts = {key: value for key, value in counts.items() if value}
    return replace(method, members=members, order=tuple(order), counts=counts)

def _annotate_seated_fan_evidence(operations, instance_history, names, target_model):
    """Learn permissible companions from repeated human station groups.

    Two distinct products are required; repeats at two tempos of one product
    alone do not count twice. The blind target is always excluded.
    """
    groups = defaultdict(list)
    target = str(target_model).split('__')[0]
    for key, observations in (instance_history or {}).items():
        operation_id = str(key).rpartition('#')[0]
        if not operation_id:
            continue
        for row in observations or ():
            model = str(row.get('ModelNo') or '')
            if not model or model.split('__')[0] == target:
                continue
            if row.get('StationType') != 'Main':
                continue
            groups[model, row.get('StationSequence')].append(operation_id)
    support = defaultdict(set)
    fan_groups = 0
    for (model, station), ids in groups.items():
        if not any(_is_seated_fan_cover({'CanonicalName': names.get(i, '')}) for i in ids):
            continue
        fan_groups += 1
        for operation_id in ids:
            if not _is_standing_side_panel({'CanonicalName': names.get(operation_id, '')}):
                support[operation_id].add(model.split('__')[0])
    accepted = []
    for op in operations:
        operation_id = str(op['CanonicalOperationId'])
        anchor = _is_seated_fan_cover(op)
        count = len(support.get(operation_id, ()))
        compatible = not _is_standing_side_panel(op) and (anchor or count >= 2)
        op['SeatedFanCompatible'] = compatible
        op['SeatedFanEvidenceModelCount'] = count
        op['WorkPostureRule'] = ('SEATED_FAN_COVER' if anchor else
                                'HUMAN_METHOD_COMPANION' if compatible else
                                'STANDING_SIDE_PANEL' if _is_standing_side_panel(op) else
                                'NOT_CONFIRMED_WITH_SEATED_FAN')
        if compatible and not anchor:
            accepted.append((operation_id, count))
    return {'training_station_groups': fan_groups,
            'compatible_companions': sorted(set(accepted)),
            'target_model_excluded': True}


def _load_test_operator_override(config_path, model_no, target_quantity):
    """Read a scoped human-confirmed crew count, never infer it from machines."""
    path = Path(config_path).parent / 'Engineering' / 'Staffing_Overrides.csv'
    if not path.exists():
        return None
    matches = []
    with path.open(encoding='utf-8-sig', newline='') as stream:
        for row in csv.DictReader(stream):
            if (str(row.get('ModelNo', '')).strip() != str(model_no).strip()
                    or str(row.get('TargetQuantity', '')).strip() != str(int(target_quantity))
                    or str(row.get('StationType', '')).strip() != 'Test'):
                continue
            try:
                count = int(row['OperatorCount'])
                if count < 1:
                    raise ValueError()
            except (TypeError, ValueError, KeyError):
                raise ValueError('STAFFING_OVERRIDE_INVALID: Test operatör sayısı pozitif tam sayı olmalı.') from None
            if not str(row.get('ApprovalSource') or '').strip():
                raise ValueError('STAFFING_OVERRIDE_INVALID: Operatör sayısının onay kaynağı eksik.')
            matches.append({'OperatorCount': count, 'ApprovalSource': row['ApprovalSource']})
    if len(matches) > 1:
        raise ValueError('STAFFING_OVERRIDE_DUPLICATE: Aynı ürün ve tempo için birden fazla Test kaydı var.')
    return matches[0] if matches else None


def _operator_plan(station_records, test_override=None):
    counts = Counter(row['StationType'] for row in station_records)
    operators = dict(counts)
    if test_override is not None:
        count = int(test_override['OperatorCount'])
        if count < 1 or count > counts.get('Test', 0):
            raise ValueError('STAFFING_OVERRIDE_INVALID: Test operatör sayısı fiziksel Test sayısıyla uyumsuz.')
        operators['Test'] = count
    return {'physical_station_count': sum(counts.values()),
            'operator_count': sum(operators.values()), 'operators_by_process': operators,
            'test_override': test_override,
            # Aggregate test cycle time is NOT measured active operator time.
            'operator_saturation_percent': None,
            'operator_saturation_status': 'TEST_ACTIVE_LABOR_TIME_NOT_MEASURED'}


def _config_compatible_inventory_candidates(config, ranked, training_profiles):
    """A nearby tempo cannot override the target's physical configuration.

    Notes remain handled by the existing note rules; throughput and staffing
    are not product identity. Physical fields match; tray/grill quantities
    are adapted from the target configuration using the reference templates.
    """
    numeric = {'AstarCam', 'Limitor', 'Tepsi', 'Izgara'}
    profiles = {str(p.get('ModelNo')): p for p in training_profiles or ()}
    def value(raw, field):
        if field in numeric:
            try:
                number = float(raw)
                if math.isfinite(number):
                    return ('NUMBER', number)
            except (TypeError, ValueError, OverflowError):
                pass
        return ('TEXT', normalize_text(raw))
    compatible, rejected = [], []
    for candidate in ranked:
        profile = profiles.get(str(candidate.get('ModelNo')))
        if profile is None:
            rejected.append((str(candidate.get('ModelNo')), ['MISSING_PROFILE']))
            continue
        differences = [field for field in CONFIG_FIELDS if field not in {'Not', 'Tepsi', 'Izgara'}
                       and value(config.get(field), field) != value(profile.get(field), field)]
        if differences:
            rejected.append((str(candidate.get('ModelNo')), differences))
        else:
            adjusted = dict(profile, Tepsi=config.get('Tepsi'), Izgara=config.get('Izgara'))
            compatible.append(dict(candidate, Similarity=config_similarity_score(config, adjusted)))
    if not compatible:
        raise ValueError('CONFIG_COMPATIBLE_REFERENCE_UNAVAILABLE: Ürün adetleri ve fiziksel '
                         'özellikleri ile aynı konfigürasyonda bir referans bulunamadı. '
                         'Yakın tempo uğruna farklı ürünün iş listesi kullanılmayacak.')
    return compatible, rejected


REQUIRED_ENGINE_SCHEMA = 11


def _production_bundle(
    models_root: Path
):
    """
    Development / validation model selection.

    During CK-2 AI Metod development, the user expects the model trained
    by the most recent "AI MODELİNİ EĞİT" action to be the model used by
    the next prediction.

    The old implementation always followed production.json. Therefore a
    newly trained holdout model could print PRODUCTION=False and the next
    prediction silently used the older production model. That invalidates
    blind-model tests because the older model may have seen the test model.

    New behavior:
      1) Find the newest valid V### model directory.
      2) If it contains a model bundle with the required schema, use it.
      3) Only fall back to production.json when no valid latest model exists.

    Before final factory deployment this can be changed back to strict
    production.json selection if release-gating is desired.
    """

    models_root.mkdir(
        parents=True,
        exist_ok=True
    )

    version_candidates = []

    for version_dir in models_root.glob(
        "V[0-9][0-9][0-9]"
    ):
        try:
            version_number = int(
                version_dir.name[1:]
            )
        except Exception:
            continue

        bundle_path = (
            version_dir /
            "model_bundle.joblib"
        )

        if not bundle_path.exists():
            continue

        version_candidates.append(
            (
                version_number,
                version_dir.name,
                version_dir,
                bundle_path,
            )
        )

    version_candidates.sort(
        key=lambda item:
            item[0],
        reverse=True
    )

    for (
        _,
        version,
        version_dir,
        bundle_path,
    ) in version_candidates:
        try:
            bundle = joblib.load(
                bundle_path
            )

            schema_version = int(
                bundle.get(
                    "engine_schema_version",
                    1
                )
            )

            if (
                schema_version >=
                REQUIRED_ENGINE_SCHEMA
            ):
                return (
                    bundle,
                    version,
                    version_dir,
                )

        except Exception:
            continue

    # Defensive fallback to production.json.
    pointer_path = (
        models_root /
        "production.json"
    )

    if not pointer_path.exists():
        raise FileNotFoundError(
            "Kullanılabilir AI modeli bulunamadı. "
            "Önce AI MODELİNİ EĞİT butonunu çalıştırın."
        )

    pointer = load_json(
        pointer_path
    )

    version = pointer[
        "version"
    ]

    version_dir = (
        models_root /
        version
    )

    bundle_path = (
        version_dir /
        "model_bundle.joblib"
    )

    if not bundle_path.exists():
        raise FileNotFoundError(
            "AI model bundle bulunamadı: " +
            str(
                bundle_path
            )
        )

    bundle = joblib.load(
        bundle_path
    )

    schema_version = int(
        bundle.get(
            "engine_schema_version",
            1
        )
    )

    if (
        schema_version <
        REQUIRED_ENGINE_SCHEMA
    ):
        raise ValueError(
            "Aktif AI modelinin engine schema sürümü eski. "
            "AI MODELİNİ EĞİT butonuna tekrar basın."
        )

    return (
        bundle,
        version,
        version_dir,
    )


def _presence_probability(
    model,
    x
):
    if hasattr(
        model,
        "predict_proba"
    ):
        probability = (
            model.predict_proba(
                x
            )
        )

        if len(
            model.classes_
        ) == 2:
            positive_index = list(
                model.classes_
            ).index(1)

            return float(
                probability[
                    0
                ][
                    positive_index
                ]
            )

    return float(
        model.predict(
            x
        )[0]
    )


def _is_door_label_operation(
    canonical_name
):
    text = normalize_text(
        canonical_name
    )

    return (
        "KAPI" in text
        and
        (
            "ETIKET" in text
            or
            "ETKET" in text
        )
        and
        "YAPISTIR" in text
    )


def _is_rear_cover_control_panel_label_operation(
    canonical_name
):
    """
    Known end-of-line label operation:
    "kontrol paneli üzerindeki etiketi al arka kapağa yapıştır"

    Historical physical location is the final Main area.
    Use station 49 as preferred physical station, but do not make it
    impossible for the optimizer to move it if a future target CT
    requires rebalancing.
    """
    text = normalize_text(
        canonical_name
    )

    return (
        "KONTROL PANEL" in text
        and
        (
            "ETIKET" in text
            or
            "ETKET" in text
        )
        and
        (
            "ARKA KAPAK" in text
            or
            "ARKA KAPAGA" in text
            or
            "ARKA KAPA" in text
        )
        and
        "YAPISTIR" in text
    )


def _is_pallet_orientation_operation(canonical_name):
    # A rotation changes the PRODUCT heading only if the pallet turns.
    return is_pallet_turn(canonical_name)


def _is_standard_cehennemlik_label_operation(
    canonical_name
):
    text = normalize_text(
        canonical_name
    )

    # Hard engineering rule is intentionally narrow.
    # Only the real standard operation:
    # "cehennemlik barkod etiketini cehennemlik üzerine yapıştır"
    # is forced to physical station 1.
    #
    # Other labels that merely contain the word CEHENNEMLIK
    # (for example a panel/type label placed on the side)
    # must remain ML/config driven.
    return (
        "CEHENNEMLIK" in text
        and
        "BARKOD" in text
        and
        "YAPISTIR" in text
    )


def _config_int(
    value
):
    try:
        if value is None or pd.isna(
            value
        ):
            return None

        return max(
            0,
            int(
                round(
                    float(
                        value
                    )
                )
            )
        )
    except Exception:
        return None



def _quantity_loading_kind(
    canonical_name,
    canonical_component,
):
    text = normalize_text(
        canonical_name
    )

    component = normalize_text(
        canonical_component
    )

    is_loading = bool(re.search(
        r'\bFIRIN(?:A|IN ICINE| ICINE)\s+(?:YERLESTIR\w*|KOY\w*)\b', text
    )) and not any(word in text for word in ('CIKART', 'CIKAR', 'GERI KOY', 'TEKRAR RAF'))

    if not is_loading:
        return None

    if (
        component == "TEPSI"
        or
        "TEPSI" in text
    ):
        return "TEPSI"

    if (
        component == "IZGARA"
        or
        "IZGARA" in text
    ):
        return "IZGARA"

    return None


def _explicit_quantity_in_operation(
    canonical_name,
    kind,
):
    text = normalize_text(
        canonical_name
    )

    token = (
        "TEPSI"
        if kind == "TEPSI"
        else "IZGARA"
    )

    patterns = [
        rf"\b(\d+)\s+ADET\s+{token}\b",
        rf"\b(\d+)\s+{token}\b",
    ]

    for pattern in patterns:
        match = re.search(
            pattern,
            text
        )

        if match:
            try:
                return int(
                    match.group(1)
                )
            except Exception:
                return None

    return None


def _select_config_quantity_operation_variants(
    canonical_ids,
    canonical_name_map,
    canonical_component_map,
    prevalence,
    config,
):
    """
    Select ONE canonical loading operation for TEPSI and ONE for IZGARA.

    The old behavior could activate both "1 Izgara" and "2 Izgara"
    canonical alternatives at the same time. These are alternative method
    wordings, not separate required operations.
    """
    candidates = {
        "TEPSI": [],
        "IZGARA": [],
    }

    for operation_id in canonical_ids:
        name = canonical_name_map.get(
            operation_id,
            operation_id
        )

        component = canonical_component_map.get(
            str(
                operation_id
            ),
            ""
        )

        kind = _quantity_loading_kind(
            name,
            component
        )

        if kind is None:
            continue

        explicit_quantity = (
            _explicit_quantity_in_operation(
                name,
                kind
            )
        )

        historical_prevalence = float(
            prevalence.get(
                operation_id,
                prevalence.get(
                    str(
                        operation_id
                    ),
                    0.0
                )
            )
        )

        candidates[
            kind
        ].append({
            "OperationId":
                operation_id,
            "ExplicitQuantity":
                explicit_quantity,
            "Prevalence":
                historical_prevalence,
        })

    result = {}

    for kind in (
        "TEPSI",
        "IZGARA",
    ):
        config_field = (
            "Tepsi"
            if kind == "TEPSI"
            else "Izgara"
        )

        configured_quantity = _config_int(
            config.get(
                config_field
            )
        )

        if configured_quantity is None:
            continue

        if configured_quantity <= 0:
            result[
                kind
            ] = {
                "SelectedOperationId":
                    None,
                "OccurrenceCount":
                    0,
            }
            continue

        kind_candidates = candidates.get(
            kind,
            []
        )

        if not kind_candidates:
            continue

        def candidate_score(
            item
        ):
            explicit_quantity = item[
                "ExplicitQuantity"
            ]

            if kind == "TEPSI":
                # Tray loading is learned as one tray per operation;
                # configured quantity becomes occurrence count.
                quantity_score = (
                    100.0
                    if explicit_quantity == 1
                    else
                    70.0
                    if explicit_quantity is None
                    else
                    0.0
                )
            else:
                # Grid wording often already contains the configured
                # quantity (1 Izgara / 2 Izgara). Choose that alternative
                # once instead of repeating all canonical variants.
                quantity_score = (
                    120.0
                    if explicit_quantity == configured_quantity
                    else
                    70.0
                    if explicit_quantity is None
                    else
                    0.0
                )

            return (
                quantity_score
                +
                item[
                    "Prevalence"
                ] * 10.0
            )

        selected = max(
            kind_candidates,
            key=candidate_score
        )

        result[
            kind
        ] = {
            "SelectedOperationId":
                selected[
                    "OperationId"
                ],
            "OccurrenceCount":
                (
                    configured_quantity
                    if kind == "TEPSI"
                    else 1
                ),
        }

    return result


def _apply_tray_grid_same_station_rule(
    predicted_instances
):
    """
    Hard engineering rule:
    TEPSI and IZGARA loading operations are performed at the SAME
    physical station on every product.

    The anchor physical station is learned from the selected accessory
    operations. Once an anchor exists, every tray/grid occurrence is forced
    to that station. This applies to config-created extra tray occurrences
    as well.
    """
    accessory_operations = []

    for operation in predicted_instances:
        kind = _quantity_loading_kind(
            operation.get(
                "CanonicalName",
                ""
            ),
            operation.get(
                "CanonicalComponent",
                ""
            )
        )

        if kind in {
            "TEPSI",
            "IZGARA",
        }:
            accessory_operations.append(
                operation
            )

    if not accessory_operations:
        return

    # Prefer strong historical occurrence profiles.
    weighted_station_votes = defaultdict(
        float
    )

    for operation in accessory_operations:
        preferred = operation.get(
            "PreferredPhysicalStationNumber"
        )

        if preferred is None:
            continue

        try:
            station_number = int(
                round(
                    float(
                        preferred
                    )
                )
            )
        except Exception:
            continue

        source = str(
            operation.get(
                "PhysicalStationPreferenceSource",
                ""
            )
            or ""
        )

        sample_count = int(
            operation.get(
                "OccurrenceProfileSampleCount",
                0
            )
            or 0
        )

        weight = 1.0

        if source == (
            "HISTORICAL_OCCURRENCE_PROFILE"
        ):
            weight += 5.0

        elif source == (
            "HISTORICAL_OPERATION_PROFILE"
        ):
            weight += 3.0

        weight += min(
            sample_count,
            20
        ) * 0.10

        weighted_station_votes[
            station_number
        ] += weight

    if weighted_station_votes:
        anchor_station = sorted(
            weighted_station_votes.items(),
            key=lambda item: (
                -float(
                    item[1]
                ),
                int(
                    item[0]
                ),
            )
        )[0][0]

    else:
        # No historical physical station was available.
        # Keep all accessories together by using the first operation's
        # process-position fallback; the physical balancer will map it to
        # the nearest learned Main station.
        first_operation = accessory_operations[
            0
        ]

        preferred = first_operation.get(
            "PreferredPhysicalStationNumber"
        )

        if preferred is None:
            return

        anchor_station = int(
            round(
                float(
                    preferred
                )
            )
        )

    for operation in accessory_operations:
        operation[
            "PreferredPhysicalStationNumber"
        ] = anchor_station

        operation[
            "ForcedPhysicalStationNumber"
        ] = anchor_station

        operation[
            "PhysicalStationPreferenceSource"
        ] = (
            "ENGINEERING_RULE_TRAY_GRID_SAME_STATION"
        )

        current_rule = str(
            operation.get(
                "EngineeringRule",
                ""
            )
            or ""
        )

        same_station_rule = (
            "TEPSI_IZGARA_SAME_PHYSICAL_STATION"
        )

        operation[
            "EngineeringRule"
        ] = (
            current_rule
            +
            (
                ";"
                if current_rule
                else ""
            )
            +
            same_station_rule
        )


def _config_exact_occurrence_count(
    canonical_name,
    canonical_component,
    config
):
    text = normalize_text(
        canonical_name
    )

    component = normalize_text(
        canonical_component
    )
    loading_kind = _quantity_loading_kind(canonical_name, canonical_component)

    # Tray loading operation:
    # "Yandan sepetten 1 adet tepsi ... fırına yerleştir"
    # Do not apply this to final inspection/remove-and-return steps.
    if loading_kind == 'TEPSI':
        return _config_int(
            config.get(
                "Tepsi"
            )
        )

    # Grid loading canonical text normally already describes the
    # number of grids taken at once ("1 Izgara" / "2 Izgara").
    # After semantic variant selection it therefore occurs once.
    if loading_kind == 'IZGARA':
        configured = _config_int(
            config.get(
                "Izgara"
            )
        )

        if configured is None:
            return None

        return (
            1
            if configured > 0
            else 0
        )

    # Limit thermostat assembly and its repeated socket connection.
    # Both repeat once per configured limiter.
    if (
        "LIMIT TERMOSTAT" in text
        and
        (
            (
                "HAVALANDIRMA" in text
                and
                (
                    "YERLESTIR" in text
                    or
                    "SABITLE" in text
                )
            )
            or
            (
                "SOKET" in text
                and
                "BAGLA" in text
            )
        )
    ):
        return _config_int(
            config.get(
                "Limitor"
            )
        )

    return None


def _config_flag(
    value
):
    text = normalize_text(
        value
    )

    if text in {
        "VAR",
        "EVET",
        "YES",
        "1",
    }:
        return True

    if text in {
        "YOK",
        "HAYIR",
        "NO",
        "0",
    }:
        return False

    return None


def _topological_order(
    instances,
    precedence_edges
):
    nodes = [
        item[
            "InstanceId"
        ]
        for item in instances
    ]

    by_id = {
        item[
            "InstanceId"
        ]: item
        for item in instances
    }

    by_operation = defaultdict(
        list
    )

    for item in instances:
        by_operation[
            item[
                "CanonicalOperationId"
            ]
        ].append(
            item
        )

    for values in (
        by_operation.values()
    ):
        values.sort(
            key=lambda item: (
                item[
                    "OccurrenceIndex"
                ],
                item[
                    "PredictedProcessPosition"
                ],
            )
        )

    adjacency = defaultdict(
        set
    )

    indegree = {
        node: 0
        for node in nodes
    }

    def add_edge(
        source,
        target
    ):
        if source == target:
            return

        if target in adjacency[
            source
        ]:
            return

        adjacency[
            source
        ].add(
            target
        )

        indegree[
            target
        ] += 1

    for values in (
        by_operation.values()
    ):
        for index in range(
            len(values) - 1
        ):
            add_edge(
                values[
                    index
                ][
                    "InstanceId"
                ],
                values[
                    index + 1
                ][
                    "InstanceId"
                ],
            )

    for edge in precedence_edges:
        source_operation = str(
            edge[
                "Source"
            ]
        )

        target_operation = str(
            edge[
                "Target"
            ]
        )

        # A physical station pin does not make its operation the first task.
        # Keep learned process predecessors, including body -> barcode.
        if (
            source_operation not in
            by_operation
            or
            target_operation not in
            by_operation
        ):
            continue

        source_last = (
            by_operation[
                source_operation
            ][-1]
        )

        target_first = (
            by_operation[
                target_operation
            ][0]
        )

        add_edge(
            source_last[
                "InstanceId"
            ],
            target_first[
                "InstanceId"
            ],
        )

    heap = []

    for node in nodes:
        if indegree[
            node
        ] == 0:
            item = by_id[
                node
            ]

            heapq.heappush(
                heap,
                (
                    float(
                        item[
                            "PredictedProcessPosition"
                        ]
                    ),
                    int(
                        item[
                            "OccurrenceIndex"
                        ]
                    ),
                    node,
                )
            )

    ordered_ids = []

    while heap:
        _, _, node = (
            heapq.heappop(
                heap
            )
        )

        ordered_ids.append(
            node
        )

        for target in adjacency[
            node
        ]:
            indegree[
                target
            ] -= 1

            if indegree[
                target
            ] == 0:
                item = by_id[
                    target
                ]

                heapq.heappush(
                    heap,
                    (
                        float(
                            item[
                                "PredictedProcessPosition"
                            ]
                        ),
                        int(
                            item[
                                "OccurrenceIndex"
                            ]
                        ),
                        target,
                    )
                )

    if len(
        ordered_ids
    ) != len(nodes):
        return sorted(
            instances,
            key=lambda item: (
                item[
                    "PredictedProcessPosition"
                ],
                item[
                    "CanonicalOperationId"
                ],
                item[
                    "OccurrenceIndex"
                ],
            )
        )

    return [
        by_id[
            node
        ]
        for node in ordered_ids
    ]


def _choose_station_type(
    operation_id,
    instance_features,
    station_type_model,
    operation_station_profiles
):
    profile = (
        operation_station_profiles.get(
            operation_id,
            {}
        )
    )

    confidence = float(
        profile.get(
            "Confidence",
            0.0
        )
    )

    dominant_type = str(
        profile.get(
            "DominantStationType",
            ""
        )
    )

    if (
        dominant_type
        and confidence >= 0.65
    ):
        return (
            dominant_type,
            "HISTORICAL_DOMINANT",
            confidence,
        )

    predicted_type = str(
        station_type_model.predict(
            instance_features
        )[0]
    )

    return (
        predicted_type,
        "ML_CLASSIFIER",
        confidence,
    )


def _write_prediction_excel(
    output_path: Path,
    model_no: str,
    working_hours: float,
    target_quantity: int,
    cycle_time: float,
    max_saturation_percent: float,
    max_station_load_seconds: float,
    balance_mode: str,
    model_version: str,
    balancer_name: str,
    operations,
    station_records,
    warnings,
    config,
    similar_models=None,
    unresolved_note_segments=None,
    tempo_layout_result=None,
    operation_inventory_source=None,
    hard_bundle_edges=None,
    staffing_plan=None,
):
    output_path.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    operation_df = pd.DataFrame(operations)
    if "OperationOrigin" not in operation_df.columns:
        operation_df["OperationOrigin"] = "AI_PREDICTION"
    else:
        operation_df["OperationOrigin"] = operation_df["OperationOrigin"].fillna("AI_PREDICTION")

    wanted_columns = [
        "Sequence",
        "PredictedProcessSequence",
        "DisplayOrder",
        "PhysicalStationNumber",
        "AssignedStationLabel",
        "AssignedStationType",
        "StationWithinType",
        "StationOperationSequence",
        "CanonicalOperationId",
        "CanonicalName",
        "CanonicalComponent",
        "OccurrenceIndex",
        "EngineeringRule",
        "OrientationTurnKind",
        "OrientationTurnDegrees",
        "OrientationPhase",
        "OrientationBeforeDegrees",
        "OrientationAfterDegrees",
        "IsPalletOrientationAnchor",
        "OperationOrigin",
        "ApprovalSource",
        "NoteTriggerTerm",
        "NoteTriggerConfidence",
        "NoteTriggerSupport",
        "NearestReferenceModelNo",
        "NearestReferenceSimilarity",
        "NearestReferenceDurationSeconds",
        "NearestReferenceStationSequence",
        "NearestReferenceStationOperationSequence",
        "NearestReferenceWithinStationPosition",
        "PreferredPhysicalStationNumber",
        "PhysicalStationPreferenceSource",
        "OccurrenceProfileSampleCount",
        "PresenceProbability",
        "HistoricalPrevalence",
        "PredictedTimeSeconds",
        "TimeSource",
        "PredictedProcessPosition",
        "PredictedStationPosition",
        "PredictedWithinStationPosition",
        "WithinStationOrderSource",
        "WorkPostureRule",
        "SeatedFanCompatible",
        "SeatedFanEvidenceModelCount",
        "PredictedStationType",
        "StationTypeSource",
        "StationTypeHistoricalConfidence",
        "StationLoadSeconds",
        "StationCycleSource",
        "StationSaturationPercent",
        "MaxTargetSaturationPercent",
        "SaturationLimitExceeded",
    ]

    operation_df = operation_df[
        [
            column
            for column
            in wanted_columns
            if column in
            operation_df.columns
        ]
    ]

    station_df = pd.DataFrame(
        station_records
    )

    if len(
        station_df
    ):
        station_df = station_df[
            [
                column
                for column in [
                    "DisplayOrder",
                    "PhysicalStationNumber",
                    "AssignedStationLabel",
                    "StationType",
                    "StationWithinType",
                    "StationLoadSeconds",
                    "StationCycleSource",
                    "StationSaturationPercent",
                    "MaxTargetSaturationPercent",
                    "SaturationLimitExceeded",
                    "StationFeasible",
                ]
                if column in
                station_df.columns
            ]
        ]

        station_df = (
            station_df.sort_values(
                "DisplayOrder"
            )
        )

    timed_work_content = 0.0

    if (
        "PredictedTimeSeconds"
        in operation_df.columns
    ):
        timed_work_content = float(
            pd.to_numeric(
                operation_df[
                    "PredictedTimeSeconds"
                ],
                errors="coerce"
            )
            .fillna(0.0)
            .sum()
        )

    aggregate_station_content = 0.0

    if len(
        station_df
    ):
        aggregate_mask = (
            station_df[
                "StationCycleSource"
            ] ==
            "HISTORICAL_STATION_AGGREGATE"
        )

        aggregate_station_content = float(
            pd.to_numeric(
                station_df.loc[
                    aggregate_mask,
                    "StationLoadSeconds",
                ],
                errors="coerce"
            )
            .fillna(0.0)
            .sum()
        )

    total_effective_work_content = (
        timed_work_content +
        aggregate_station_content
    )

    infeasible_station_count = 0

    if (
        len(
            station_df
        )
        and
        "StationFeasible"
        in station_df.columns
    ):
        infeasible_station_count = int(
            (
                station_df[
                    "StationFeasible"
                ] == False
            ).sum()
        )

    # Crew planning is NOT the same as counting physical machines.
    # For Test, the training set often has only station aggregate CYCLE
    # time. 22 sec measured cycle does not establish 22 sec of active labor.
    # Keep the observed stations as a conservative staffing assumption,
    # expose its uncertainty, and do not claim an invented operator saving.
    zone_summary = []
    for zone_type, rows in station_df.groupby("StationType", sort=False):
        load_seconds = float(pd.to_numeric(
            rows["StationLoadSeconds"], errors="coerce").fillna(0).sum())
        aggregate_count = int((rows["StationCycleSource"] ==
            "HISTORICAL_STATION_AGGREGATE").sum())
        zone_summary.append({
            "Process": zone_type,
            "PhysicalStations": int(len(rows)),
            "SumStationLoadsSeconds": load_seconds,
            "TheoreticalMinStationsForCT": int(math.ceil(
                max(0, load_seconds - 1e-8) / max_station_load_seconds)),
            "ActiveLaborSecondsKnown": aggregate_count == 0,
            "StaffingAssumption": (
                "PROVISIONAL_1_OPERATOR_PER_STATION_MACHINE_TIME_UNKNOWN"
                if aggregate_count else "1_OPERATOR_PER_WORKSTATION"
            ),
        })
    staffing_plan = staffing_plan or _operator_plan(station_records)
    labor_metrics = workforce_metrics(station_records, cycle_time, staffing_plan)
    for item in zone_summary:
        item['Operators'] = staffing_plan['operators_by_process'].get(item['Process'], 0)
        item['OperatorCountSource'] = (
            staffing_plan['test_override']['ApprovalSource']
            if item['Process'] == 'Test' and staffing_plan['test_override']
            else 'ONE_OPERATOR_PER_WORKSTATION_ASSUMPTION')
        if item['Process'] == 'Test' and staffing_plan['test_override']:
            item['StaffingAssumption'] = 'USER_CONFIRMED_SHARED_TEST_OPERATOR'
        item['OperatorSaturationPercent'] = (100 * item['SumStationLoadsSeconds'] /
            (cycle_time * item['Operators']) if item['ActiveLaborSecondsKnown']
            and item['Operators'] > 0 else None)
        item['MachineUtilizationPercent'] = (100 * item['SumStationLoadsSeconds'] /
            (cycle_time * item['PhysicalStations']) if not item['ActiveLaborSecondsKnown'] else None)
    staffing_df = pd.DataFrame(zone_summary)
    total_stations = len(station_df)
    achieved_sat = (100.0 * total_effective_work_content /
                    (cycle_time * total_stations) if total_stations else 0.0)
    sat_goal = 90.0
    crew_max_for_goal = labor_metrics['max_staff_for_90_percent']
    theoretical_crew_min = int(math.ceil(
        (total_effective_work_content - 1e-8) / max_station_load_seconds))
    if labor_metrics['machine_station_count']:
        # No staffing target may be derived from automatic machine cycles.
        crew_max_for_goal = None
        theoretical_crew_min = None
    if any(not item["ActiveLaborSecondsKnown"] for item in zone_summary) and not staffing_plan['test_override']:
        warnings.append(
            "STAFFING_MODEL_LIMITATION: Test cycle aggregate is not measured"
            " active operator workload. Reported headcount is provisional"
            " (one person per physical station), not proven minimum staffing."
        )
    if crew_max_for_goal is not None and total_stations > crew_max_for_goal:
        warnings.append(
            "TARGET_90_GAP: achieved={:.2f}%; stations={}, max_staff_for_90pct={};"
            " no infeasible operation assignment is fabricated."
            .format(achieved_sat, total_stations, crew_max_for_goal)
        )
    staffing_audit_df = pd.DataFrame([
        ["TargetCycleTimeSeconds", cycle_time],
        ["MaxStationLoadSeconds", max_station_load_seconds],
        ["EffectiveWorkContentSeconds", total_effective_work_content],
        ["CurrentPhysicalStationCount", total_stations],
        ["MeanStationSaturationPercent", achieved_sat],
        ["TargetMeanSaturationPercent", sat_goal],
        ["MaxStaffFor90Percent", crew_max_for_goal],
        ["TheoreticalMinStaffFromWorkContent", theoretical_crew_min],
        ["StaffReductionNeededFor90Percent", (max(0, total_stations - crew_max_for_goal)
                                                   if crew_max_for_goal is not None else None)],
        ["HasAggregateMachineOrUnknownLaborTime", any(
            not item["ActiveLaborSecondsKnown"] for item in zone_summary)],
        ["StaffingConfidence", "PROVISIONAL" if any(
            not item["ActiveLaborSecondsKnown"] for item in zone_summary)
            else "STATION_EQUALS_OPERATOR_ASSUMPTION"],
    ], columns=["Metric", "Value"])

    summary_rows = [
        ['ManualWorkContentSeconds', labor_metrics['manual_work_seconds']],
        ['ManualStationCount', labor_metrics['manual_station_count']],
        ['ManualStationSaturationPercent', labor_metrics['manual_saturation_percent']],
        ['ManualMinSaturationPercent', labor_metrics['manual_min_saturation_percent']],
        ['ManualMaxSaturationPercent', labor_metrics['manual_max_saturation_percent']],
        ['MachineStationSaturationPercent', labor_metrics['machine_saturation_percent']],
        ['StationSaturationBasis', 'MIXED_STATION_UTILIZATION_NOT_OPERATOR_SATURATION'],
        [
            "ModelNo",
            model_no,
        ],
        [
            "AIModelVersion",
            model_version,
        ],
        [
            "AIEngineSchema",
            REQUIRED_ENGINE_SCHEMA,
        ],
        [
            "WorkingHours",
            working_hours,
        ],
        [
            "TargetQuantity",
            target_quantity,
        ],
        [
            "TargetCycleTimeSeconds",
            cycle_time,
        ],
        [
            "MaxTargetSaturationPercent",
            max_saturation_percent,
        ],
        [
            "BalanceMode",
            (
                "AI Hat Dengeleme"
            ),
        ],
        [
            "MaxStationWorkloadSeconds",
            max_station_load_seconds,
        ],
        [
            "PredictedOperationInstances",
            len(
                operation_df
            ),
        ],
        [
            "PredictedStations",
            len(
                station_df
            ),
        ],
        ["StationSaturationPercent", achieved_sat],
        ["MaxStaffFor90Percent", crew_max_for_goal],
        ["WorkforceGoal90Achieved", (
            None if labor_metrics['operator_saturation_percent'] is None
            else bool(labor_metrics['operator_saturation_percent'] >= sat_goal - 1e-8))],
        ["StaffingCountStatus", ('TEST_USER_CONFIRMED_OTHER_ZONES_ONE_OPERATOR_PER_STATION'
                                if staffing_plan['test_override'] else 'PROVISIONAL_STATION_AS_OPERATOR')],
        ["PredictedOperators", staffing_plan['operator_count']],
        ["OperatorSaturationPercent", staffing_plan['operator_saturation_percent']],
        ["OperatorSaturationStatus", staffing_plan['operator_saturation_status']],
        ["MLPredictedOperations", int((operation_df["OperationOrigin"] == "AI_PREDICTION").sum())],
        ["EngineeringApprovedOperations", int((operation_df["OperationOrigin"] == "ENGINEERING_APPROVED_NOT_ML").sum())],
        ["EngineeringApprovedDurationCorrections", int((operation_df["TimeSource"] == "APPROVED_ENGINEERING_TIME").sum())],
        [
            "ConfigCalisanSayisi_Bilgi",
            config.get(
                "CalisanSayisi",
                ""
            ),
        ],
        [
            "ConfigCalisanSayisi_OptimizerdaKullanildi",
            "Hayır",
        ],
        [
            "TimedOperationWorkContentSeconds",
            timed_work_content,
        ],
        [
            "AggregateStationWorkContentSeconds",
            aggregate_station_content,
        ],
        [
            "TotalEffectiveWorkContentSeconds",
            total_effective_work_content,
        ],
        [
            "InfeasibleStationCount",
            infeasible_station_count,
        ],
        [
            "Balancer",
            balancer_name,
        ],
        [
            "ProductGroup",
            config.get(
                "CataPyro",
                ""
            ),
        ],
        [
            "ModelType",
            config.get(
                "ModelType",
                ""
            ),
        ],
        # Compatibility: the UI-facing similar model is the actual station
        # mentor. Product-inventory reference is reported separately below.
        ["TopSimilarModel", (tempo_layout_result or {}).get(
            'main_mentor_model', '') or (
                similar_models[0]['ModelNo'] if similar_models else '')],
        [
            "TopConfigSimilarModel",
            (
                similar_models[0][
                    "ModelNo"
                ]
                if similar_models
                else ""
            ),
        ],
        [
            "TopSimilarModelScore",
            (
                similar_models[0][
                    "Similarity"
                ]
                if similar_models
                else ""
            ),
        ],
        ["OperationInventorySource", operation_inventory_source or ""],
        ["LayoutMentorModel", (tempo_layout_result or {}).get('main_mentor_model', '')],
        ["LayoutMentorCycleTimeSeconds", (tempo_layout_result or {}).get('main_mentor_ct', '')],
        ["LayoutMentorMatchedOperations", (tempo_layout_result or {}).get('matched_count', 0)],
        ["LayoutMentorPairs", (tempo_layout_result or {}).get('learned_pairs', 0)],
        ["LayoutLearningStatus", (tempo_layout_result or {}).get('status','')],
        [
            "UnresolvedNoteSegmentCount",
            len(
                unresolved_note_segments
                or []
            ),
        ],
    ]

    staffing_audit_df = pd.concat([staffing_audit_df, pd.DataFrame([
        ['CurrentOperatorCount', staffing_plan['operator_count']],
        ['TestOperatorCount', staffing_plan['operators_by_process'].get('Test', 0)],
        ['OperatorSaturationPercent', staffing_plan['operator_saturation_percent']],
        ['OperatorSaturationStatus', staffing_plan['operator_saturation_status']],
    ], columns=['Metric', 'Value'])], ignore_index=True)
    summary = pd.DataFrame(
        summary_rows,
        columns=[
            "Field",
            "Value",
        ]
    )

    config_df = pd.DataFrame([
        {
            key: value
            for (
                key,
                value
            ) in config.items()
        }
    ])

    # Modelin tahmini istasyon süresini gerçekte azaltmış gibi göstermiyoruz.
    # Tek mod içinde: mevcut uygulanabilir metot + mühendislik onayı gerektiren
    # personel azaltma planı; tüm palet dönüşleri ve işlem sırası korunur.
    improvement_summaries = []
    improvement_rows = []
    sorted_main_plan_input = sorted(
        operations,
        key=lambda item: (
            0 if str(item.get("AssignedStationType", item.get("PredictedStationType", "Main"))).lower() == "main" else 1,
            int(item.get("StationWithinType") or 0),
            int(item.get("StationOperationSequence") or 0),
        ),
    )
    improvement_proposals = propose_improvements(
        sorted_main_plan_input, station_records, float(cycle_time),
        target_main_counts=(20, 21),
        hard_bundle_edges=hard_bundle_edges,
        max_station_load=float(max_station_load_seconds),
    )
    if labor_metrics['machine_station_count']:
        improvement_proposals = []
        warnings.append('V049_OPERATOR_IMPROVEMENT_PLAN_WITHHELD: '
                        'shared_test_operator=True; active_test_labor_not_measured=True')
    for proposal in improvement_proposals:
        improvement_summaries.append({
            "HedefToplamPersonel": proposal["ProposedTotalStaff"],
            "HedefAnaHatPersonel": proposal["ProposedMainStaff"],
            "OzelProsesPersonel": proposal["SpecialProcessStaffUnchanged"],
            "GerekliToplamSureKazanciSn": proposal["TotalTimeStudySavingsNeededSeconds"],
            "KazanimDogrulanirsaSaturasyonYuzde": proposal["ConditionalSaturationPercent"],
            "KorunanAnaHatOperasyonu": proposal["OriginalOperationCount"],
            "KorunanPaletDonusu": proposal["PreservedOrientationTurnCount"],
            "Durum": proposal["Status"],
        })
        for station in proposal["Stations"]:
            improvement_rows.append({
                "HedefToplamPersonel": proposal["ProposedTotalStaff"],
                "FizikselIstasyon": station["PhysicalStationNumber"],
                "IslemAdedi": station["OperationCount"],
                "PaletDonusu": station["TurnCount"],
                "MevcutIslemSureleriToplamiSn": station["OriginalLoadSeconds"],
                "SahadaKazanilmasiGerekenSureSn": station["TimeStudySavingsNeededSeconds"],
                "KazanimSonrasiHedefSureSn": station["RequiredMaxLoadSeconds"],
                "Islemler": " | ".join(x["Name"] for x in station["Operations"]),
                "Durum": "SURE_ETUDU_ve_MUHENDISLIK_ONAYI_GEREKLI",
            })
    improvement_summary_df = pd.DataFrame(improvement_summaries)
    improvement_plan_df = pd.DataFrame(improvement_rows)
    if improvement_summaries:
        warnings.append(
            "AI_PROCESS_IMPROVEMENT_PROPOSAL: Palet/operasyon dizisi degismeden "
            "personel azaltma icin istasyon bazli gerekli sure iyilestirmesi "
            "AI_Iyilestirme_Ozet ve AI_Iyilestirme_Istasyon sayfalarindadir. "
            "Bu degerler olculmus sure kazanci DEGILDIR; uretim onayi yoktur."
        )

    warnings_df = pd.DataFrame(
        {
            "Warning": (
                warnings
                if warnings
                else [
                    "No warning."
                ]
            )
        }
    )

    similar_models_df = pd.DataFrame(
        similar_models
        or []
    )

    unseen_note_df = pd.DataFrame(
        [
            {
                "NoteSegment":
                    segment,
                "Status":
                    "ENGINEERING_REVIEW_REQUIRED",
                "Reason":
                    (
                        "Bu Not segmenti onaylı eğitim metodlarında "
                        "karşılık bulmadı. Sistem sıfır örnekten operasyon, "
                        "istasyon veya süre uydurmadı."
                    ),
            }
            for segment in (
                unresolved_note_segments
                or []
            )
        ]
    )

    with pd.ExcelWriter(
        output_path,
        engine="openpyxl"
    ) as writer:
        summary.to_excel(
            writer,
            sheet_name=
                "Summary",
            index=False
        )

        operation_df.to_excel(
            writer,
            sheet_name=
                "Predicted_Method",
            index=False
        )

        station_df.to_excel(
            writer,
            sheet_name=
                "Station_Summary",
            index=False
        )

        warnings_df.to_excel(
            writer,
            sheet_name=
                "Warnings",
            index=False
        )
        staffing_df.to_excel(
            writer, sheet_name="Workforce_By_Process", index=False)
        staffing_audit_df.to_excel(
            writer, sheet_name="Workforce_Analysis", index=False)
        if len(improvement_summary_df):
            improvement_summary_df.to_excel(
                writer, sheet_name="AI_Iyilestirme_Ozet", index=False)
        if len(improvement_plan_df):
            improvement_plan_df.to_excel(
                writer, sheet_name="AI_Iyilestirme_Istasyon", index=False)

        config_df.to_excel(
            writer,
            sheet_name=
                "Input_Config",
            index=False
        )

        if len(
            similar_models_df
        ):
            similar_models_df.to_excel(
                writer,
                sheet_name=
                    "Similar_Models",
                index=False
            )

        if len(
            unseen_note_df
        ):
            unseen_note_df.to_excel(
                writer,
                sheet_name=
                    "Unseen_Note_Review",
                index=False
            )

    from openpyxl import (
        load_workbook,
    )

    workbook = load_workbook(
        output_path
    )

    for worksheet in (
        workbook.worksheets
    ):
        worksheet.freeze_panes = (
            "A2"
        )

        worksheet.auto_filter.ref = (
            worksheet.dimensions
        )

        for column_cells in (
            worksheet.columns
        ):
            max_length = 0

            letter = (
                column_cells[
                    0
                ].column_letter
            )

            for cell in column_cells:
                value = (
                    ""
                    if cell.value is None
                    else str(
                        cell.value
                    )
                )

                max_length = max(
                    max_length,
                    len(
                        value
                    )
                )

            worksheet.column_dimensions[
                letter
            ].width = min(
                max(
                    max_length + 2,
                    10
                ),
                55
            )

    # ---------------------------------------------------------
    # Factory-style method layout sheet
    # ---------------------------------------------------------
    from collections import defaultdict as _defaultdict
    from openpyxl.styles import (
        Alignment,
        Border,
        Font,
        PatternFill,
        Side,
    )

    method_sheet_name = str(
        model_no
    )[:31]

    if method_sheet_name in workbook.sheetnames:
        del workbook[
            method_sheet_name
        ]

    method_sheet = workbook.create_sheet(
        method_sheet_name,
        0
    )

    method_sheet.sheet_view.showGridLines = False

    method_sheet[
        "A1"
    ] = model_no

    method_sheet[
        "A1"
    ].font = Font(
        name="Calibri",
        size=16,
        bold=True
    )

    method_sheet[
        "A1"
    ].alignment = Alignment(
        horizontal="center",
        vertical="center"
    )

    method_sheet.row_dimensions[
        1
    ].height = 24

    method_sheet.column_dimensions[
        "A"
    ].width = 95

    method_sheet.column_dimensions[
        "B"
    ].width = 12

    method_sheet.column_dimensions[
        "C"
    ].width = 28

    cyan_fill = PatternFill(
        fill_type="solid",
        fgColor="00DDE0"
    )

    load_fill = PatternFill(
        fill_type="solid",
        fgColor="A9D18E"
    )

    component_fill = PatternFill(
        fill_type="solid",
        fgColor="FFF200"
    )

    thin_side = Side(
        style="thin",
        color="000000"
    )

    thin_border = Border(
        left=thin_side,
        right=thin_side,
        top=thin_side,
        bottom=thin_side
    )

    operations_by_display = _defaultdict(
        list
    )

    for operation in operations:
        display_order = int(
            operation.get(
                "DisplayOrder",
                operation.get(
                    "AssignedStation",
                    0
                )
            )
        )

        operations_by_display[
            display_order
        ].append(
            operation
        )

    sorted_stations = sorted(
        station_records,
        key=lambda record: int(
            record.get(
                "DisplayOrder",
                record.get(
                    "AssignedStation",
                    0
                )
            )
        )
    )

    row_number = 2

    for station in sorted_stations:
        display_order = int(
            station.get(
                "DisplayOrder",
                station.get(
                    "AssignedStation",
                    0
                )
            )
        )

        station_type = str(
            station.get(
                "StationType",
                ""
            )
        )

        station_label = str(
            station.get(
                "AssignedStationLabel",
                ""
            )
        )

        physical_number = station.get(
            "PhysicalStationNumber"
        )

        method_sheet.cell(
            row=row_number,
            column=1,
            value=station_label
        )

        method_sheet.cell(
            row=row_number,
            column=2,
            value=float(
                station.get(
                    "StationLoadSeconds",
                    0.0
                )
            )
        )

        header_c = ""

        if station_type == "Main":
            header_c = station_label

        elif station_type == "Test":
            suffix = (
                int(
                    physical_number
                )
                if physical_number
                is not None
                else int(
                    station.get(
                        "StationWithinType",
                        0
                    )
                )
            )

            header_c = (
                f"TEST {suffix}"
            )

        elif station_type == "Visual":
            header_c = "GÖRSEL"

        method_sheet.cell(
            row=row_number,
            column=3,
            value=header_c
        )

        method_sheet.cell(
            row=row_number,
            column=1
        ).fill = cyan_fill

        method_sheet.cell(
            row=row_number,
            column=2
        ).fill = load_fill

        if header_c:
            method_sheet.cell(
                row=row_number,
                column=3
            ).fill = cyan_fill

        for column in range(
            1,
            4
        ):
            cell = method_sheet.cell(
                row=row_number,
                column=column
            )

            cell.font = Font(
                name="Calibri",
                size=11,
                bold=True
            )

            cell.border = thin_border

            cell.alignment = Alignment(
                vertical="center",
                wrap_text=True
            )

        method_sheet.cell(
            row=row_number,
            column=2
        ).number_format = "0.00"

        row_number += 1

        station_operations = sorted(
            operations_by_display.get(
                display_order,
                []
            ),
            key=lambda operation: int(
                operation.get(
                    "StationOperationSequence",
                    0
                )
            )
        )

        for operation in station_operations:
            method_sheet.cell(
                row=row_number,
                column=1,
                value=str(
                    operation.get(
                        "CanonicalName",
                        ""
                    )
                )
            )

            operation_time = operation.get(
                "PredictedTimeSeconds"
            )

            if operation_time is not None:
                method_sheet.cell(
                    row=row_number,
                    column=2,
                    value=float(
                        operation_time
                    )
                )

                method_sheet.cell(
                    row=row_number,
                    column=2
                ).number_format = "0.00"

            component = str(
                operation.get(
                    "CanonicalComponent",
                    ""
                )
                or
                ""
            ).strip()

            if component:
                method_sheet.cell(
                    row=row_number,
                    column=3,
                    value=component
                )

                method_sheet.cell(
                    row=row_number,
                    column=3
                ).fill = component_fill

                method_sheet.cell(
                    row=row_number,
                    column=3
                ).font = Font(
                    name="Calibri",
                    size=11,
                    bold=True
                )

            for column in range(
                1,
                4
            ):
                cell = method_sheet.cell(
                    row=row_number,
                    column=column
                )

                cell.border = thin_border

                cell.alignment = Alignment(
                    vertical="center",
                    wrap_text=True
                )

            row_number += 1

    method_sheet.freeze_panes = "A2"

    # ---------------------------------------------------------
    # Hat özet sheet - station CT table + chart + KPI block
    # ---------------------------------------------------------
    from openpyxl.chart import (
        BarChart,
        Reference,
    )
    from openpyxl.chart.label import (
        DataLabelList,
    )

    overview_sheet_name = "HAT ÖZET"

    if overview_sheet_name in workbook.sheetnames:
        del workbook[
            overview_sheet_name
        ]

    overview_sheet = workbook.create_sheet(
        overview_sheet_name,
        1
    )

    overview_sheet.sheet_view.showGridLines = True

    overview_sheet[
        "A1"
    ] = "İSTASYON"

    overview_sheet[
        "B1"
    ] = "TC (SN)"

    dark_blue_fill = PatternFill(
        fill_type="solid",
        fgColor="1F4E78"
    )

    white_bold_font = Font(
        name="Calibri",
        size=11,
        bold=True,
        color="FFFFFF"
    )

    for cell_address in (
        "A1",
        "B1",
    ):
        overview_sheet[
            cell_address
        ].fill = dark_blue_fill

        overview_sheet[
            cell_address
        ].font = white_bold_font

        overview_sheet[
            cell_address
        ].alignment = Alignment(
            horizontal="center",
            vertical="center"
        )

        overview_sheet[
            cell_address
        ].border = thin_border

    overview_row = 2

    for station in sorted_stations:
        station_label = str(
            station.get(
                "AssignedStationLabel",
                ""
            )
        )

        station_load = float(
            station.get(
                "StationLoadSeconds",
                0.0
            )
            or 0.0
        )

        overview_sheet.cell(
            row=overview_row,
            column=1,
            value=station_label
        )

        overview_sheet.cell(
            row=overview_row,
            column=2,
            value=station_load
        )

        overview_sheet.cell(
            row=overview_row,
            column=2
        ).number_format = "0.00"

        overview_sheet.cell(
            row=overview_row,
            column=1
        ).border = thin_border

        overview_sheet.cell(
            row=overview_row,
            column=2
        ).border = thin_border

        overview_row += 1

    last_overview_data_row = (
        overview_row - 1
    )

    overview_sheet.column_dimensions[
        "A"
    ].width = 26

    overview_sheet.column_dimensions[
        "B"
    ].width = 12

    # ---------------------------------------------------------
    # HAT ÖZET chart
    # One combined vertical column chart, matching the user's
    # existing factory summary format:
    #
    #   X axis : İSTASYON
    #   Y axis : TC (SN)
    #   Data labels above each column
    #   Category labels rotated -45 degrees
    # ---------------------------------------------------------
    from openpyxl.chart.text import (
        RichText,
    )
    from openpyxl.drawing.text import (
        CharacterProperties,
        Paragraph,
        ParagraphProperties,
        RichTextProperties,
    )

    chart_helper_col = 24  # X

    overview_sheet.cell(
        row=1,
        column=chart_helper_col,
        value="İSTASYON"
    )

    overview_sheet.cell(
        row=1,
        column=chart_helper_col + 1,
        value="TC (SN)"
    )

    chart_row = 2

    for station in sorted_stations:
        station_label = str(
            station.get(
                "AssignedStationLabel",
                ""
            )
        )

        station_load = float(
            station.get(
                "StationLoadSeconds",
                0.0
            )
            or 0.0
        )

        overview_sheet.cell(
            row=chart_row,
            column=chart_helper_col,
            value=station_label
        )

        overview_sheet.cell(
            row=chart_row,
            column=chart_helper_col + 1,
            value=station_load
        )

        overview_sheet.cell(
            row=chart_row,
            column=chart_helper_col + 1
        ).number_format = "0.00"

        chart_row += 1

    chart_last_row = (
        chart_row - 1
    )

    # Keep source cells outside the visible dashboard area.
    overview_sheet.column_dimensions[
        "X"
    ].width = 12

    overview_sheet.column_dimensions[
        "Y"
    ].width = 10

    chart = BarChart()

    # Vertical columns, same chart type as the user's reference.
    chart.type = "col"
    chart.style = 10
    chart.title = (
        "İstasyon Çevrim Süreleri"
    )
    chart.legend = None

    chart.height = 10.0
    chart.width = 30.0
    chart.gapWidth = 45

    data_reference = Reference(
        overview_sheet,
        min_col=
            chart_helper_col + 1,
        min_row=1,
        max_row=
            chart_last_row
    )

    category_reference = Reference(
        overview_sheet,
        min_col=
            chart_helper_col,
        min_row=2,
        max_row=
            chart_last_row
    )

    chart.add_data(
        data_reference,
        titles_from_data=True
    )

    chart.set_categories(
        category_reference
    )

    # Visual coordinates:
    # X = station categories
    # Y = station cycle time in seconds.
    chart.x_axis.title = "İSTASYON"
    chart.y_axis.title = "TC (SN)"

    chart.y_axis.scaling.min = 0

    max_station_value = max(
        [
            float(
                station.get(
                    "StationLoadSeconds",
                    0.0
                )
                or 0.0
            )
            for station in
            sorted_stations
        ]
        or [
            cycle_time
        ]
    )

    # Keep a clean 0-40 style like the user's current Excel,
    # but expand automatically if a future CT needs more room.
    chart_max = max(
        40.0,
        float(
            int(
                (
                    max(
                        max_station_value,
                        cycle_time
                    )
                    +
                    4.999
                )
                /
                5.0
            )
            *
            5
        )
    )

    chart.y_axis.scaling.max = (
        chart_max
    )

    chart.y_axis.majorUnit = 5

    # Rotate long station labels just like the user's example.
    chart.x_axis.txPr = RichText(
        bodyPr=RichTextProperties(
            rot=-2700000
        ),
        p=[
            Paragraph(
                pPr=ParagraphProperties(
                    defRPr=CharacterProperties(
                        sz=800
                    )
                )
            )
        ]
    )

    chart.x_axis.tickLblPos = "low"

    # Show only numeric TC value on top of each column.
    chart.dLbls = DataLabelList()
    chart.dLbls.showVal = True
    chart.dLbls.showCatName = False
    chart.dLbls.showSerName = False
    chart.dLbls.showLegendKey = False
    chart.dLbls.showPercent = False
    chart.dLbls.showLeaderLines = False
    chart.dLbls.dLblPos = "outEnd"
    chart.dLbls.numFmt = "0.00"

    # Match the familiar Excel blue column appearance.
    if chart.series:
        chart.series[
            0
        ].graphicalProperties.solidFill = (
            "4472C4"
        )

        chart.series[
            0
        ].graphicalProperties.line.solidFill = (
            "4472C4"
        )

    overview_sheet.add_chart(
        chart,
        "D2"
    )

    kpi_row = (
        last_overview_data_row +
        5
    )

    kpi_fill = PatternFill(
        fill_type="solid",
        fgColor="F4B183"
    )

    kpi_rows = [
        (
            "el işi (sn)",
            labor_metrics['manual_work_seconds'],
            "0.00",
        ),
        (
            "el işi ort. (sn)",
            (labor_metrics['manual_work_seconds'] / labor_metrics['manual_station_count']
             if labor_metrics['manual_station_count'] else 0.0),
            "0.00",
        ),
        (
            "tc",
            cycle_time,
            "0.00",
        ),
        (
            "el işi sat",
            (labor_metrics['manual_saturation_percent'] / 100.0
             if labor_metrics['manual_saturation_percent'] is not None else None),
            "0.00%",
        ),
        ('test makine doluluğu',
         labor_metrics['machine_saturation_percent'] / 100.0
         if labor_metrics['machine_saturation_percent'] is not None else 'Yok', '0.00%'),
        ('personel saturasyonu', staffing_plan['operator_saturation_percent'] / 100.0
         if staffing_plan['operator_saturation_percent'] is not None else 'Ölçülmedi', '0.00%'),
        (
            "maks. sat",
            (
                max_saturation_percent /
                100.0
            ),
            "0%",
        ),
        (
            "mod",
            (
                "AI Hat Dengeleme"
            ),
            "@",
        ),
    ]

    for offset, (
        label,
        value,
        number_format,
    ) in enumerate(
        kpi_rows
    ):
        row = (
            kpi_row +
            offset
        )

        overview_sheet.cell(
            row=row,
            column=1,
            value=label
        )

        overview_sheet.cell(
            row=row,
            column=2,
            value=(
                value
                if isinstance(
                    value,
                    str
                )
                else float(
                    value
                )
            )
        )

        overview_sheet.cell(
            row=row,
            column=2
        ).number_format = (
            number_format
        )

        for column in (
            1,
            2,
        ):
            cell = overview_sheet.cell(
                row=row,
                column=column
            )

            cell.fill = kpi_fill

            cell.border = thin_border

            cell.font = Font(
                name="Calibri",
                size=11,
                bold=True
            )

    overview_sheet.column_dimensions['B'].width = 22

    people_row = (
        kpi_row +
        len(
            kpi_rows
        ) +
        2
    )

    overview_sheet.merge_cells(
        start_row=people_row,
        start_column=1,
        end_row=people_row,
        end_column=2
    )

    overview_sheet.cell(
        row=people_row,
        column=1,
        value=(
            f"{staffing_plan['operator_count']} kişi | {len(station_df)} fiziksel istasyon"
        )
    )

    overview_sheet.cell(
        row=people_row,
        column=1
    ).alignment = Alignment(
        horizontal="center",
        vertical="center"
    )

    overview_sheet.cell(
        row=people_row,
        column=1
    ).font = Font(
        name="Calibri",
        size=11,
        bold=True
    )

    overview_sheet.cell(
        row=people_row,
        column=1
    ).fill = PatternFill(
        fill_type="solid",
        fgColor="D9E2F3"
    )

    overview_sheet.freeze_panes = "A2"

    workbook.save(
        output_path
    )


def _apply_pallet_context_preferences(
    ordered
):
    """
    Context-aware pallet rotation.

    Occurrence number remains useful, but it is no longer the only signal.
    For each pallet rotation, inspect the nearest non-pallet Main operation
    before and after it in the predicted process. Their learned physical
    stations define the local process neighborhood.

    The historical occurrence preference is then CLAMPED into that
    neighborhood instead of being followed blindly.
    """

    def numeric_station(
        operation
    ):
        value = operation.get(
            "PreferredPhysicalStationNumber"
        )

        if value is None:
            return None

        try:
            return float(
                value
            )
        except Exception:
            return None

    for index, operation in enumerate(
        ordered
    ):
        if not bool(
            operation.get(
                "IsPalletOrientationAnchor",
                False
            )
        ):
            continue

        previous_station = None
        next_station = None

        for previous_index in range(
            index - 1,
            -1,
            -1
        ):
            previous_operation = ordered[
                previous_index
            ]

            if (
                previous_operation.get(
                    "PredictedStationType"
                ) != "Main"
                or
                bool(
                    previous_operation.get(
                        "IsPalletOrientationAnchor",
                        False
                    )
                )
            ):
                continue

            previous_station = numeric_station(
                previous_operation
            )

            if previous_station is not None:
                break

        for next_index in range(
            index + 1,
            len(
                ordered
            )
        ):
            next_operation = ordered[
                next_index
            ]

            if (
                next_operation.get(
                    "PredictedStationType"
                ) != "Main"
                or
                bool(
                    next_operation.get(
                        "IsPalletOrientationAnchor",
                        False
                    )
                )
            ):
                continue

            next_station = numeric_station(
                next_operation
            )

            if next_station is not None:
                break

        learned_station = numeric_station(
            operation
        )

        context_station = (
            learned_station
        )

        if (
            previous_station is not None
            and
            next_station is not None
        ):
            low_station = min(
                previous_station,
                next_station
            )

            high_station = max(
                previous_station,
                next_station
            )

            if learned_station is None:
                context_station = (
                    previous_station
                    +
                    next_station
                ) / 2.0

            else:
                context_station = min(
                    high_station,
                    max(
                        low_station,
                        learned_station
                    )
                )

        elif (
            learned_station is None
            and
            previous_station is not None
        ):
            context_station = (
                previous_station
            )

        elif (
            learned_station is None
            and
            next_station is not None
        ):
            context_station = (
                next_station
            )

        operation[
            "PalletContextPreviousStationNumber"
        ] = previous_station

        operation[
            "PalletContextNextStationNumber"
        ] = next_station

        operation[
            "PalletContextPreferredStationNumber"
        ] = context_station


def _active_note_operation_triggers(
    config,
    note_operation_rules,
):
    """
    Select NOTE/MARKET rules that are active for the current product.
    Return one strongest rule per canonical operation.
    """
    active_terms = set(
        note_terms(
            config.get(
                "Not"
            ),
            max_ngram=3
        )
    )

    if not active_terms:
        return {}

    result = {}

    for rule in (
        note_operation_rules
        or []
    ):
        term = str(
            rule.get(
                "Term",
                ""
            )
        )

        if (
            not term
            or
            term not in
            active_terms
        ):
            continue

        operation_id = str(
            rule.get(
                "OperationId",
                ""
            )
        )

        if not operation_id:
            continue

        current = result.get(
            operation_id
        )

        candidate_key = (
            1
            if rule.get(
                "RuleType"
            ) ==
            "SEMANTIC_NOTE_MATCH"
            else 0,
            len(
                term.split()
            ),
            float(
                rule.get(
                    "Confidence",
                    0.0
                )
            ),
            int(
                rule.get(
                    "SupportModels",
                    0
                )
            ),
            float(
                rule.get(
                    "Lift",
                    0.0
                )
            ),
        )

        if current is None:
            result[
                operation_id
            ] = dict(
                rule
            )

            continue

        current_term = str(
            current.get(
                "Term",
                ""
            )
        )

        current_key = (
            1
            if current.get(
                "RuleType"
            ) ==
            "SEMANTIC_NOTE_MATCH"
            else 0,
            len(
                current_term.split()
            ),
            float(
                current.get(
                    "Confidence",
                    0.0
                )
            ),
            int(
                current.get(
                    "SupportModels",
                    0
                )
            ),
            float(
                current.get(
                    "Lift",
                    0.0
                )
            ),
        )

        if (
            candidate_key >
            current_key
        ):
            result[
                operation_id
            ] = dict(
                rule
            )

    return result


def _rank_similar_models(
    config,
    training_config_profiles,
    top_n=5,
):
    ranked = []

    for profile in (
        training_config_profiles
        or []
    ):
        model_no = str(
            profile.get(
                "ModelNo",
                ""
            )
        )

        if (
            not model_no
            or
            model_no ==
            str(
                config.get(
                    "ModelNo",
                    ""
                )
            )
        ):
            continue

        score = float(
            config_similarity_score(
                config,
                profile
            )
        )

        different_fields = []

        for field in CONFIG_FIELDS:
            if field == "Not":
                continue

            current = normalize_text(
                config.get(
                    field
                )
            )

            historical = normalize_text(
                profile.get(
                    field
                )
            )

            if (
                current !=
                historical
            ):
                different_fields.append(
                    field
                )

        try:
            observed_ct = float(profile.get("ConfigReferenceCycleTimeSeconds"))
            target_ct = float(config.get("ConfigReferenceCycleTimeSeconds"))
            ct_distance = abs(observed_ct - target_ct)
        except (TypeError, ValueError):
            ct_distance = float("inf")

        ranked.append({
            "ModelNo": model_no,
            "Similarity": score,
            "CycleTimeDistanceSeconds": ct_distance,
            "DifferentFieldCount":
                len(
                    different_fields
                ),
            "DifferentFields":
                ", ".join(
                    different_fields
                ),
        })

    ranked.sort(
        key=lambda item: (
            float(
                item[
                    "Similarity"
                ]
            ),
            -float(item.get("CycleTimeDistanceSeconds", float("inf"))),
            -int(
                item[
                    "DifferentFieldCount"
                ]
            ),
            item[
                "ModelNo"
            ],
        ),
        reverse=True
    )

    return ranked[
        :max(
            1,
            int(
                top_n
            )
        )
    ]


def _nearest_instance_context(
    operation_id,
    occurrence_index,
    similar_models,
    nearest_instance_history,
):
    key = (
        str(
            operation_id
        )
        +
        "#"
        +
        str(
            int(
                occurrence_index
            )
        )
    )

    observations = (
        nearest_instance_history.get(
            key,
            []
        )
    )

    if not observations:
        return None

    similarity_by_model = {
        str(
            item.get(
                "ModelNo",
                ""
            )
        ):
            float(
                item.get(
                    "Similarity",
                    0.0
                )
            )
        for item in (
            similar_models
            or []
        )
    }

    candidates = []

    for observation in observations:
        model_no = str(
            observation.get(
                "ModelNo",
                ""
            )
        )

        similarity = similarity_by_model.get(
            model_no
        )

        if similarity is None:
            continue

        item = dict(
            observation
        )

        item[
            "Similarity"
        ] = similarity

        candidates.append(
            item
        )

    if not candidates:
        return None

    candidates.sort(
        key=lambda item: (
            float(
                item.get(
                    "Similarity",
                    0.0
                )
            ),
            str(
                item.get(
                    "ModelNo",
                    ""
                )
            ),
        ),
        reverse=True
    )

    best = dict(
        candidates[
            0
        ]
    )

    best[
        "CandidateCount"
    ] = len(
        candidates
    )

    return best



def _attach_complete_reference_method(operations, similar_models, instance_history,
                                      canonical_name_map=None, canonical_component_map=None):
    """Attach one coherent training method, never a mixture of per-task models.

    Only an exact configuration match with the same operation occurrences may
    define a preserved layout. An unambiguous quantity-only grill wording may
    reuse its task slot, with an explicit data-conflict warning. Prediction
    still supplies the tasks, quantities and times.
    The held-out workbook is neither opened nor consulted here.
    """
    keys = [str(op["CanonicalOperationId"]) + "#" + str(int(op.get("OccurrenceIndex", 1)))
            for op in operations]
    if len(set(keys)) != len(keys):
        raise ValueError("Tahminde yinelenen operasyon oluşum kimliği var.")

    for candidate in similar_models or []:
        similarity = float(candidate.get("Similarity", 0.0))
        if not math.isfinite(similarity) or abs(similarity - 1.0) > 1e-9:
            continue
        model_no = str(candidate.get("ModelNo", ""))
        reference, duplicate = {}, False
        for key, observations in instance_history.items():
            for observation in observations:
                if str(observation.get("ModelNo", "")) != model_no:
                    continue
                if key in reference:
                    duplicate = True
                reference[str(key)] = observation
        if duplicate:
            continue

        reference_keys = {key: key for key in keys if key in reference}
        missing, extra = set(keys) - set(reference), set(reference) - set(keys)
        if missing or extra:
            names, components = canonical_name_map or {}, canonical_component_map or {}

            def grill_signature(key):
                operation_id, _, occurrence = key.rpartition("#")
                name = names.get(operation_id, "")
                if _quantity_loading_kind(name, components.get(operation_id, "")) != "IZGARA":
                    return None
                quantity = _explicit_quantity_in_operation(name, "IZGARA")
                if quantity is None or quantity <= 0:
                    return None
                text = re.sub(r"\b\d+\s+(?:ADET\s+)?IZGARA\b", "<QTY> IZGARA", normalize_text(name))
                return text, occurrence

            if len(missing) != len(extra):
                continue
            remaining = set(extra)
            for key in sorted(missing):
                signature = grill_signature(key)
                compatible = [other for other in remaining
                              if signature is not None and grill_signature(other) == signature]
                if len(compatible) != 1:
                    break
                reference_keys[key] = compatible[0]
                remaining.remove(compatible[0])
            if len(reference_keys) != len(keys) or remaining:
                continue

        attachments = []
        for key, operation in zip(keys, operations):
            reference_key = reference_keys[key]
            observation = reference[reference_key]
            try:
                numbers = [float(observation[field]) for field in (
                    "PhysicalStationNumber", "StationSequence", "StationOperationSequence")]
                if any(not math.isfinite(value) or value <= 0 or not value.is_integer()
                       for value in numbers):
                    break
                physical, station_sequence, within_station = map(int, numbers)
                station_type = str(observation["StationType"])
                if station_type != str(operation.get("PredictedStationType", "Main")):
                    break
                forced = operation.get("ForcedPhysicalStationNumber")
                if forced is not None and int(forced) != physical:
                    break
            except (KeyError, TypeError, ValueError, OverflowError):
                break
            attachments.append({
                "PreservedReferenceModelNo": model_no,
                "PreservedReferenceStationType": station_type,
                "PreservedReferenceStationNumber": physical,
                "PreservedReferenceStationSequence": station_sequence,
                "PreservedReferenceStationOperationSequence": within_station,
                "PreservedReferenceOriginalInstanceKey": reference_key,
                "PreservedReferenceVariant": reference_key != key,
                "PreferredPhysicalStationNumber": physical,
                "PhysicalStationPreferenceSource": "COHERENT_REFERENCE_METHOD",
                "WithinStationOrderSource": "COHERENT_REFERENCE_METHOD",
                "NearestReferenceModelNo": model_no,
                "NearestReferenceSimilarity": float(candidate["Similarity"]),
                "NearestReferenceStationSequence": station_sequence,
                "NearestReferenceStationOperationSequence": within_station,
                "NearestReferenceWithinStationPosition": observation.get("WithinStationPosition"),
                "NearestReferenceDurationSeconds": observation.get("Duration"),
            })
        if len(attachments) == len(operations):
            for operation, attachment in zip(operations, attachments):
                operation.update(attachment)
            return model_no
    return None


def _confidence_aware_note_duration(
    config,
    operation_id,
    occurrence_index,
    ml_duration,
    training_config_profiles,
    nearest_instance_history,
):
    """Return an approved-history consensus only when market context agrees.

    Single nearest-model durations never override ML. The evidence must
    consist of at least two DISTINCT previously approved model methods,
    matching at least one NOTE term and closely matching the product's
    structural configuration. Both examples must give nearly the same time.

    Only a material (>0.20 s) correction is allowed. All other operations
    retain their original ML time. No model numbers, countries, operation
    names, or durations are hard-coded here.
    """
    target_terms = set(note_terms(config.get("Not"), max_ngram=3))
    if not target_terms or not training_config_profiles:
        return None

    key = "{}#{}".format(str(operation_id), int(occurrence_index))
    observations = nearest_instance_history.get(key, [])
    if not observations:
        return None

    by_model = {}
    for profile in training_config_profiles:
        reference_model = str(profile.get("ModelNo", ""))
        if not reference_model or base_model_no(reference_model) == base_model_no(config.get("ModelNo", "")):
            continue

        shared_terms = target_terms.intersection(
            set(note_terms(profile.get("Not"), max_ngram=3))
        )
        if not shared_terms:
            continue

        structural_similarity = float(config_similarity_score(config, profile))
        if structural_similarity < 0.90:
            continue
        by_model[reference_model] = (structural_similarity, len(shared_terms))

    candidates = {}
    for observation in observations:
        model_no = str(observation.get("ModelNo", ""))
        if model_no not in by_model:
            continue
        try:
            seconds = float(observation.get("Duration"))
        except (ValueError, TypeError):
            continue
        if not math.isfinite(seconds) or seconds <= 0:
            continue
        # One independent vote per approved product model.
        candidates.setdefault(base_model_no(model_no), []).append((
            by_model[model_no][0], by_model[model_no][1], seconds))

    # A single product at two tempos cannot establish independent consensus.
    # Conflicting standards of one product must not depend on row order.
    candidates = {
        model: max(samples, key=lambda sample: (sample[0], sample[1]))
        for model, samples in candidates.items()
        if max(sample[2] for sample in samples) - min(sample[2] for sample in samples) <= 0.03
    }

    if len(candidates) < 2:
        return None

    best_similarity = max(item[0] for item in candidates.values())
    strongest = [
        item for item in candidates.values()
        if item[0] >= best_similarity - 0.065
    ]
    if len(strongest) < 2:
        return None

    # With only two examples, one must have more than a single matched
    # NOTE term. Otherwise generic market labels are too weak evidence.
    if len(strongest) == 2 and max(item[1] for item in strongest) < 2:
        return None

    durations = [item[2] for item in strongest]
    if max(durations) - min(durations) > 0.03:
        return None

    consensus = (max(durations) + min(durations)) / 2.0
    if abs(consensus - float(ml_duration)) < 0.20:
        return None

    return consensus, len(strongest)

def _unresolved_note_segments(
    config,
    known_note_segments,
    active_note_triggers,
):
    """
    Detect NOTE entries for which approved training methods contain no
    known semantic segment/rule.

    We intentionally DO NOT invent an operation, station or time from zero
    examples. Instead the output Excel raises an engineering-review warning
    so a new market/project operation can never disappear silently.
    """
    known = set(
        str(
            value
        )
        for value in (
            known_note_segments
            or []
        )
        if str(
            value
        )
    )

    triggered_terms = {
        str(
            rule.get(
                "Term",
                ""
            )
        )
        for rule in (
            active_note_triggers
            or {}
        ).values()
        if str(
            rule.get(
                "Term",
                ""
            )
        )
    }

    unresolved = []

    for segment in note_segments(
        config.get(
            "Not"
        )
    ):
        if segment in known:
            continue

        segment_tokens = set(
            segment.split()
        )

        explained = False

        for term in triggered_terms:
            term_tokens = set(
                term.split()
            )

            if (
                term_tokens
                and
                term_tokens.issubset(
                    segment_tokens
                )
            ):
                explained = True
                break

        if not explained:
            unresolved.append(
                segment
            )

    return unresolved


def _approved_market_rules(path: Path):
    """Load explicit engineer-approved rules. Never fabricate unseen tasks."""
    if not path.is_file():
        return []

    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        mandatory = {
            "Status", "NoteSegment", "OperationText", "Component",
            "StationType", "PhysicalStation", "StationOrder", "Seconds",
            "ApprovalSource",
        }
        if not reader.fieldnames or not mandatory.issubset(reader.fieldnames):
            raise ValueError(
                "Market_Operations.csv kolonları eksik. "
                "Gerekli: " + ", ".join(sorted(mandatory))
            )
        rules = []
        for line_no, row in enumerate(reader, start=2):
            if normalize_text(row.get("Status")) != "APPROVED":
                continue
            term = normalize_text(row.get("NoteSegment"))
            operation_name = str(row.get("OperationText") or "").strip()
            approval = str(row.get("ApprovalSource") or "").strip()
            if not term or not operation_name or not approval:
                raise ValueError(
                    f"Market_Operations.csv satır {line_no}: "
                    "onay kaynağı / segment / iş adı boş."
                )
            try:
                seconds = float(str(row.get("Seconds") or "").replace(",", "."))
                station = int(row.get("PhysicalStation"))
                order = int(row.get("StationOrder"))
            except (ValueError, TypeError) as exc:
                raise ValueError(
                    f"Market_Operations.csv satır {line_no}: "
                    "süre, istasyon ve sıra sayısal olmalı."
                ) from exc
            if not math.isfinite(seconds) or seconds <= 0 or station < 1 or order < 1:
                raise ValueError(f"Market_Operations.csv satır {line_no}: geçersiz değer.")
            rules.append({
                "Term": term,
                "OperationName": operation_name,
                "Component": str(row.get("Component") or "").strip(),
                "StationType": str(row.get("StationType") or "Main").strip(),
                "PhysicalStation": station,
                "StationOrder": order,
                "Seconds": seconds,
                "ApprovalSource": approval,
            })
    return rules


def _apply_approved_market_rules(
    operations, stations, config, rule_path, cycle_time, max_saturation
):
    """
    Separate approved knowledge from ML predictions.

    Only apply a catalog entry when the NOTE segment is present, its
    physical station exists, and the additional work fits within CT.
    Otherwise leave the method unchanged and request an engineering review.
    """
    rules = _approved_market_rules(rule_path)
    note_set = set(note_segments(config.get("Not")))
    added = []
    warnings = []
    pending = []
    if not rules or not note_set:
        return operations, stations, added, warnings, pending

    # Special zones may contain legitimately unnumbered workstations (EK).
    # Never int(None): they cannot match approved rules requiring a real ID.
    station_records = {
        (str(st.get("StationType", "Main")), int(st["PhysicalStationNumber"])): st
        for st in stations
        if st.get("PhysicalStationNumber") is not None
    }
    max_load = float(cycle_time) * float(max_saturation) / 100.0
    for rule in rules:
        if rule["Term"] not in note_set:
            continue
        name_key = normalize_text(rule["OperationName"])
        if any(normalize_text(item.get("CanonicalName")) == name_key
               for item in operations):
            continue
        station_key = (rule["StationType"], rule["PhysicalStation"])
        st = station_records.get(station_key)
        if st is None:
            pending.append(rule["Term"])
            warnings.append("ENGINEERING_REVIEW: " + rule["Term"] +
                            " - onaylı fiziksel istasyon tahmin düzeninde yok.")
            continue
        current_load = float(st.get("StationLoadSeconds") or 0.0)
        proposed = current_load + rule["Seconds"]
        if proposed > max_load + 0.00001:
            pending.append(rule["Term"])
            warnings.append("ENGINEERING_REVIEW: " + rule["Term"] +
                            " - ek iş hedef saturasyonu aşıyor; ekleme yapılmadı.")
            continue
        display_order = int(st["DisplayOrder"])
        current_ops = sorted(
            (op for op in operations if int(op.get("DisplayOrder", -1)) == display_order),
            key=lambda op: int(op.get("StationOperationSequence", 0))
        )
        insertion = min(max(rule["StationOrder"] - 1, 0), len(current_ops))
        # Preserve the station's existing order; insert only the approved task.
        instance_key = "APPROVED_NOTE::" + rule["Term"].replace(" ", "_")
        entry = {
            "InstanceId": instance_key + "#1",
            "CanonicalOperationId": instance_key,
            "CanonicalName": rule["OperationName"],
            "CanonicalComponent": rule["Component"],
            "OccurrenceIndex": 1,
            "EngineeringRule": "APPROVED_MARKET_CATALOG::" + rule["Term"],
            "OperationOrigin": "ENGINEERING_APPROVED_NOT_ML",
            "ApprovalSource": rule["ApprovalSource"],
            "NoteTriggerTerm": rule["Term"],
            "NoteTriggerConfidence": None,
            "NoteTriggerSupport": 0,
            "PhysicalStationNumber": rule["PhysicalStation"],
            "PreferredPhysicalStationNumber": rule["PhysicalStation"],
            "PhysicalStationPreferenceSource": "APPROVED_MARKET_CATALOG",
            "ForcedPhysicalStationNumber": rule["PhysicalStation"],
            "DisplayOrder": display_order,
            "AssignedStationLabel": st["AssignedStationLabel"],
            "AssignedStationType": st["StationType"],
            "PredictedStationType": st["StationType"],
            "StationWithinType": st.get("StationWithinType"),
            "PresenceProbability": None,
            "HistoricalPrevalence": None,
            "PredictedTimeSeconds": rule["Seconds"],
            "TimeSource": "APPROVED_ENGINEERING_CATALOG",
            "PredictedProcessPosition": None,
            "PredictedStationPosition": None,
            "PredictedWithinStationPosition": None,
            "WithinStationOrderSource": "APPROVED_ENGINEERING_CATALOG",
            "StationCycleSource": st.get("StationCycleSource"),
            "StationTypeSource": "APPROVED_ENGINEERING_CATALOG",
        }
        current_ops.insert(insertion, entry)
        for idx, operation in enumerate(current_ops, start=1):
            operation["StationOperationSequence"] = idx
            operation["StationLoadSeconds"] = proposed
            operation["StationSaturationPercent"] = proposed / cycle_time * 100.0
            operation["MaxTargetSaturationPercent"] = max_saturation
            operation["SaturationLimitExceeded"] = False
        st["StationLoadSeconds"] = proposed
        st["StationSaturationPercent"] = proposed / cycle_time * 100.0
        st["MaxTargetSaturationPercent"] = max_saturation
        st["SaturationLimitExceeded"] = False
        st["StationFeasible"] = True
        operations.append(entry)
        added.append(rule)

    # Recalculate global order AFTER all catalog insertions.
    operations.sort(key=lambda op: (
        int(op.get("DisplayOrder", 0)),
        int(op.get("StationOperationSequence", 0)),
        str(op.get("CanonicalOperationId", "")),
    ))
    for index, item in enumerate(operations, start=1):
        item["Sequence"] = index
    return operations, stations, added, warnings, pending


def _apply_approved_station_overrides(
    operations, stations, model_no, config_path, cycle_time, max_saturation
):
    """Apply model-specific, traceable station work instructions.

    This is NOT learned ML. Each correction requires a source, model number,
    physical station, and a uniquely identifiable pair of operations.
    """
    path = config_path.parent / "Engineering" / "Station_Overrides.csv"
    if not path.is_file():
        return operations, stations, [], []
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream, delimiter=";")
        required = {
            "Status", "ModelNo", "StationType", "PhysicalStation",
            "BeforeContains", "AfterContains", "AfterSeconds", "ApprovalSource",
        }
        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise ValueError("Station_Overrides.csv zorunlu kolonları eksik.")
        rows = list(reader)
    warnings = []
    accepted = []
    for line_no, row in enumerate(rows, start=2):
        if normalize_text(row.get("Status")) != "APPROVED":
            continue
        if str(row.get("ModelNo") or "").strip() != str(model_no).strip():
            continue
        approval = str(row.get("ApprovalSource") or "").strip()
        before_token = normalize_text(row.get("BeforeContains"))
        after_token = normalize_text(row.get("AfterContains"))
        if not approval or len(before_token) < 4 or len(after_token) < 4:
            raise ValueError(f"Station_Overrides.csv satır {line_no}: geçersiz onay/iş tanımı")
        try:
            station_number = int(row["PhysicalStation"])
            after_seconds = float(str(row["AfterSeconds"]).replace(",", "."))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Station_Overrides.csv satır {line_no}: sayısal alan hatası") from exc
        if not math.isfinite(after_seconds) or after_seconds <= 0:
            raise ValueError(f"Station_Overrides.csv satır {line_no}: geçersiz iş süresi")
        match_stations = [st for st in stations
                          if st.get("PhysicalStationNumber") is not None
                          and int(st["PhysicalStationNumber"]) == station_number
                          and str(st.get("StationType", "")) == str(row.get("StationType") or "Main")]
        if len(match_stations) != 1:
            warnings.append(f"ENGINEERING_REVIEW: override istasyonu bulunamadı: {station_number}")
            continue
        st = match_stations[0]
        station_index = int(st["DisplayOrder"])
        in_station = sorted(
            (op for op in operations if int(op.get("DisplayOrder", -1)) == station_index),
            key=lambda op: int(op.get("StationOperationSequence", 0)),
        )
        before_items = [op for op in in_station if before_token in normalize_text(op.get("CanonicalName"))]
        after_items = [op for op in in_station if after_token in normalize_text(op.get("CanonicalName"))]
        if len(before_items) != 1 or len(after_items) != 1 or before_items[0] is after_items[0]:
            warnings.append(f"ENGINEERING_REVIEW: override operasyon eşleşmesi belirsiz: {station_number}")
            continue
        first, second = before_items[0], after_items[0]
        old_time = second.get("PredictedTimeSeconds")
        if old_time is None:
            warnings.append(f"ENGINEERING_REVIEW: override süresi yok: {station_number}")
            continue
        current = float(st.get("StationLoadSeconds", 0.0))
        proposed = current - float(old_time) + after_seconds
        if proposed > cycle_time * max_saturation / 100.0 + 0.00001:
            warnings.append(f"ENGINEERING_REVIEW: override kapasiteyi aşıyor: {station_number}")
            continue
        second["PredictedTimeSeconds"] = after_seconds
        second["TimeSource"] = "APPROVED_ENGINEERING_TIME"
        second["ApprovalSource"] = approval
        first["WithinStationOrderSource"] = "APPROVED_ENGINEERING_ORDER"
        second["WithinStationOrderSource"] = "APPROVED_ENGINEERING_ORDER"
        # Move the before-operation directly ahead of the after-operation.
        # Leave all other work in existing relative order.
        in_station.remove(first)
        in_station.insert(in_station.index(second), first)
        for idx, op in enumerate(in_station, start=1):
            op["StationOperationSequence"] = idx
            op["StationLoadSeconds"] = proposed
            op["StationSaturationPercent"] = proposed / cycle_time * 100.0
            op["MaxTargetSaturationPercent"] = max_saturation
            op["SaturationLimitExceeded"] = False
        st["StationLoadSeconds"] = proposed
        st["StationSaturationPercent"] = proposed / cycle_time * 100.0
        st["MaxTargetSaturationPercent"] = max_saturation
        st["SaturationLimitExceeded"] = False
        st["StationFeasible"] = True
        accepted.append({"ModelNo": str(model_no), "Station": station_number,
                         "Before": first["CanonicalName"], "After": second["CanonicalName"],
                         "Seconds": after_seconds, "ApprovalSource": approval})
        warnings.append("ENGINEERING_ORDER_TIME_NOT_ML: " + str(model_no) +
                        " - istasyon " + str(station_number) + " - " + approval)
    if accepted:
        operations.sort(key=lambda op: (
            int(op.get("DisplayOrder", 0)),
            int(op.get("StationOperationSequence", 0)),
            str(op.get("CanonicalOperationId", "")),
        ))
        for index, item in enumerate(operations, start=1):
            item["Sequence"] = index
    return operations, stations, accepted, warnings


def predict_method(
    config_path: Path,
    model_no: str,
    working_hours: float,
    target_quantity: int,
    models_root: Path,
    output_path: Path,
    max_saturation_percent: float = 95.0,
    balance_mode: str = "auto",
):
    # One production workflow. Legacy callers may still pass old mode
    # names, but the input no longer changes the chosen algorithm.
    balance_mode = "auto"
    if working_hours <= 0:
        raise ValueError(
            "Net çalışma saati 0'dan büyük olmalı."
        )

    if target_quantity <= 0:
        raise ValueError(
            "Hedef üretim 0'dan büyük olmalı."
        )

    if (
        max_saturation_percent <= 0.0
        or
        max_saturation_percent > 100.0
    ):
        raise ValueError(
            "Maksimum hedef saturasyon 0 ile 100 arasında olmalıdır."
        )

    config = read_model_config(
        config_path,
        model_no
    )
    # The operator-selected target CT is the ML regressor input, NOT an
    # instruction to pick T1065 or T1330 reference model.
    requested_cycle_time = (
        float(working_hours) * 3600.0 / int(target_quantity)
    )
    config["ConfigReferenceCycleTimeSeconds"] = requested_cycle_time

    (
        bundle,
        version,
        version_dir,
    ) = _production_bundle(
        models_root
    )

    training_families = {
        str(value)
        .strip()
        .lower()
        for value in bundle.get(
            "training_family",
            []
        )
    }

    training_model_types = {
        str(value)
        .strip()
        .lower()
        for value in bundle.get(
            "training_model_types",
            []
        )
    }

    current_family = str(
        config.get(
            "CataPyro",
            ""
        )
    ).strip().lower()

    current_type = str(
        config.get(
            "ModelType",
            ""
        )
    ).strip().lower()

    if (
        training_families
        and current_family
        not in training_families
    ):
        raise ValueError(
            "Bu AI modeli henüz bu ürün ailesi için eğitilmedi. "
            "Model ailesi: " +
            str(
                config.get(
                    "CataPyro",
                    ""
                )
            )
        )

    if (
        training_model_types
        and current_type
        not in training_model_types
    ):
        raise ValueError(
            "Bu AI modeli henüz bu model tipi için eğitilmedi. "
            "Model tipi: " +
            str(
                config.get(
                    "ModelType",
                    ""
                )
            )
        )

    presence_vectorizer = bundle[
        "presence_vectorizer"
    ]

    presence_model = bundle[
        "presence_model"
    ]

    occurrence_model = bundle[
        "occurrence_model"
    ]

    instance_vectorizer = bundle[
        "instance_vectorizer"
    ]

    duration_model = bundle[
        "duration_model"
    ]

    process_position_model = bundle[
        "process_position_model"
    ]

    station_position_model = bundle[
        "station_position_model"
    ]

    within_station_position_model = bundle[
        "within_station_position_model"
    ]

    same_station_precedence_edges = (
        bundle.get(
            "same_station_precedence_edges",
            []
        )
    )

    hard_bundle_edges = (
        bundle.get(
            "hard_bundle_edges",
            []
        )
    )

    operation_block_map = (
        bundle.get(
            "operation_block_map",
            {}
        )
    )

    process_block_order_edges = (
        bundle.get(
            "process_block_order_edges",
            []
        )
    )

    note_operation_rules = (
        bundle.get(
            "note_operation_rules",
            []
        )
    )

    training_config_profiles = (
        bundle.get(
            "training_config_profiles",
            []
        )
    )

    nearest_instance_history = (
        bundle.get(
            "nearest_instance_history",
            {}
        )
    )

    known_note_segments = (
        bundle.get(
            "known_note_segments",
            []
        )
    )

    similar_models = (
        _rank_similar_models(
            config,
            training_config_profiles,
            top_n=100
        )
    )

    active_note_triggers = (
        _active_note_operation_triggers(
            config,
            note_operation_rules
        )
    )

    unresolved_note_segments = (
        _unresolved_note_segments(
            config,
            known_note_segments,
            active_note_triggers
        )
    )

    station_type_model = bundle[
        "station_type_model"
    ]

    station_type_profiles = bundle[
        "station_type_profiles"
    ]

    operation_station_profiles = (
        bundle[
            "operation_station_profiles"
        ]
    )

    canonical_component_map = (
        bundle.get(
            "canonical_component_map",
            {}
        )
    )

    canonical_ids = bundle[
        "canonical_ids"
    ]

    canonical_name_map = bundle[
        "canonical_name_map"
    ]

    prevalence = bundle[
        "prevalence"
    ]

    historical_max = bundle[
        "historical_max_occurrence"
    ]

    # CK2 COHERENT METHOD: use the trained presence classifier at the
    # requested continuous CT to score internally consistent approved
    # operation inventories. Never union tasks from different methods.
    # ML duration and balancing also remain CT-dependent.
    presence_probability_by_operation = {}
    for library_operation_id in canonical_ids:
        library_feature = pair_feature_dict(config, library_operation_id)
        library_vector = presence_vectorizer.transform([library_feature])
        presence_probability_by_operation[str(library_operation_id)] = (
            _presence_probability(presence_model, library_vector)
        )
    # Pick the reference whose fixed aggregate stations (test, ...) fit the
    # target CT BEFORE the expensive balancing starts; a reference that cannot
    # fit is skipped with a REFERENCE_FALLBACK note instead of failing late.
    _ck2_target_station_load = (
        float(requested_cycle_time) * float(max_saturation_percent) / 100.0
    )
    inventory_candidates, rejected_configs = _config_compatible_inventory_candidates(
        config,
        _rank_similar_models(config, training_config_profiles,
                             top_n=max(100, len(training_config_profiles))),
        training_config_profiles,
    )
    while True:
        try:
            coherent_method = choose_coherent_method(
                inventory_candidates,
                nearest_instance_history,
                canonical_name_map,
                presence_probabilities=presence_probability_by_operation,
                excluded_models=_ck2_reference_retry["excluded"],
            )
        except ValueError:
            if not _ck2_reference_retry["notes"]:
                raise
            raise ValueError(
                "REFERENCE_CAPACITY_UNAVAILABLE: Hedef çevrim süresine "
                "sığan onaylı referans bulunamadı. "
                + " | ".join(_ck2_reference_retry["notes"][:4])
            ) from None
        require_reference_has_hard_operations(
            coherent_method, canonical_name_map
        )
        _ck2_capacity_problem = _ck2_aggregate_capacity_problem(
            coherent_method, station_type_profiles, _ck2_target_station_load
        )
        if not _ck2_capacity_problem:
            break
        _ck2_reference_retry["excluded"].add(coherent_method.model_no)
        _ck2_reference_retry["notes"].append(
            "REFERENCE_FALLBACK: {} atlandı: {}".format(
                coherent_method.model_no, _ck2_capacity_problem
            )
        )
    _ck2_reference_retry["last"] = coherent_method.model_no
    # CRITICAL: Reference inventory and configuration-dependent alternatives
    # must operate on the SAME scope. The previous global selection scanned
    # every canonical operation across all product families and tempos, then
    # excluded an operation belonging to our chosen coherent method.
    # That produced: INVENTORY_MISMATCH Eksik=COP_0053#1.
    reference_canonical_ids = [
        operation_id for operation_id in canonical_ids
        if str(operation_id) in coherent_method.counts
    ]
    catalog_ids = {str(operation_id) for operation_id in reference_canonical_ids}
    missing_from_catalog = set(coherent_method.counts) - catalog_ids
    if missing_from_catalog:
        raise ValueError(
            "REFERENCE_CATALOG_MISSING: Referanstaki operasyon eğitim "
            "kataloğunda yok: " + ", ".join(sorted(missing_from_catalog)[:12])
            + ". Model paketi/veri seti tutarsız; işlem uydurulmuyor."
        )
    predicted_instances = []

    quantity_operation_selection = (
        _select_config_quantity_operation_variants(
            reference_canonical_ids,
            canonical_name_map,
            canonical_component_map,
            prevalence,
            config
        )
    )

    configured_quantities = {}
    for operation_id in reference_canonical_ids:
        kind = _quantity_loading_kind(canonical_name_map.get(operation_id, ''),
                                      canonical_component_map.get(str(operation_id), ''))
        selection = quantity_operation_selection.get(kind, {})
        if kind in {'TEPSI', 'IZGARA'} and selection.get('SelectedOperationId') == operation_id:
            configured_quantities[str(operation_id)] = int(selection['OccurrenceCount'])
    quantity_changes = [(key, coherent_method.counts[key], count)
                        for key, count in configured_quantities.items()
                        if coherent_method.counts[key] != count]
    coherent_method = adapt_quantity_occurrences(coherent_method, configured_quantities)

    for operation_id in canonical_ids:
        # The trained classifiers cannot union mutually exclusive operations
        # learned from different oven configurations. A single coherent
        # reference restricts the inventory; the ML models still calculate
        # each selected operation's duration and timing/station features.
        if str(operation_id) not in coherent_method.counts:
            continue
        canonical_name = (
            canonical_name_map.get(
                operation_id,
                operation_id
            )
        )

        canonical_component = (
            canonical_component_map.get(
                str(
                    operation_id
                ),
                ""
            )
        )

        quantity_kind = _quantity_loading_kind(
            canonical_name,
            canonical_component
        )

        note_trigger = (
            active_note_triggers.get(
                str(
                    operation_id
                )
            )
        )

        selected_quantity_info = (
            quantity_operation_selection.get(
                quantity_kind,
                {}
            )
            if quantity_kind
            else {}
        )

        if quantity_kind:
            selected_operation_id = (
                selected_quantity_info.get(
                    "SelectedOperationId"
                )
            )

            # A coherent historical inventory is already chosen. Never
            # discard its operation because an alternative canonical ID
            # scored higher somewhere else in the training catalog.
            # Genuine ambiguous alternatives inside a single reference
            # require explicit review rather than silently losing a task.
            if (
                quantity_kind in quantity_operation_selection
                and str(selected_operation_id) != str(operation_id)
            ):
                raise ValueError(
                    "REFERENCE_QUANTITY_AMBIGUOUS: Tek referans içinde "
                    "birden fazla {} yerleştirme operasyon tarifi var: {} ve {}. "
                    "Operasyon silinmedi; metodu doğrulayın.".format(
                        quantity_kind, selected_operation_id, operation_id
                    )
                )

        exact_config_count = (
            selected_quantity_info.get(
                "OccurrenceCount"
            )
            if quantity_kind in
            quantity_operation_selection
            else
            _config_exact_occurrence_count(
                canonical_name,
                canonical_component,
                config
            )
        )

        standard_cehennemlik_label = (
            _is_standard_cehennemlik_label_operation(
                canonical_name
            )
        )

        door_label_operation = (
            _is_door_label_operation(
                canonical_name
            )
        )

        # This label location is model/layout dependent.
        # Do not keep the old model-specific station-49 hard rule.
        rear_cover_label_operation = False

        pallet_orientation_operation = (
            _is_pallet_orientation_operation(
                canonical_name
            )
        )

        kapi_etiketi_flag = (
            _config_flag(
                config.get(
                    "KapiEtiketi"
                )
            )
        )

        feature = pair_feature_dict(
            config,
            operation_id
        )

        x_presence = (
            presence_vectorizer
            .transform([
                feature
            ])
        )

        probability = float(
            presence_probability_by_operation[str(operation_id)]
        )

        historical_prevalence = float(
            prevalence.get(
                operation_id,
                prevalence.get(
                    str(
                        operation_id
                    ),
                    0.0
                )
            )
        )

        if exact_config_count is not None:
            is_present = (
                exact_config_count > 0
            )

        elif note_trigger is not None:
            # Learned from approved method Excels:
            # current MODEL_Config.Not term strongly/semantically implies
            # this operation.
            is_present = True

        elif standard_cehennemlik_label:
            # Mühendislik kuralı:
            # Cehennemlik barkod/etiket operasyonu
            # tüm ürünlerde zorunludur.
            is_present = True

        elif (
            door_label_operation
            and
            kapi_etiketi_flag is True
        ):
            # MODEL_Config açıkça "Kapı Etiketi = var"
            # diyorsa operasyon mutlaka bulunmalıdır.
            is_present = True

        elif (
            door_label_operation
            and
            kapi_etiketi_flag is False
        ):
            # Kapı etiketi her üründe standart değildir.
            # Config "yok" ise ML tarihsel sıklığa bakarak
            # bu operasyonu tekrar ekleyemez.
            is_present = False

        else:
            is_present = (
                probability >= 0.50
                or
                historical_prevalence >=
                0.95
            )

        # The coherent, approved operation set takes priority over an
        # unreliable per-operation probability near 0.50. ML still estimates
        # durations and preferred station positions continuously.
        if not is_present and str(operation_id) not in coherent_method.counts:
            continue

        predicted_count = float(
            occurrence_model.predict(
                x_presence
            )[0]
        )

        count = max(
            1,
            int(
                round(
                    predicted_count
                )
            )
        )

        max_historical_count = int(
            historical_max.get(
                operation_id,
                historical_max.get(
                    str(
                        operation_id
                    ),
                    1
                )
            )
        )

        count = min(
            count,
            max(
                max_historical_count + 1,
                1
            )
        )

        if exact_config_count is not None:
            count = int(
                exact_config_count
            )

        elif note_trigger is not None:
            note_occurrence_mode = int(
                note_trigger.get(
                    "OccurrenceMode",
                    1
                )
                or 1
            )

            count = max(
                1,
                note_occurrence_mode
            )

        if (
            standard_cehennemlik_label
            or
            (
                door_label_operation
                and
                kapi_etiketi_flag is True
            )
        ):
            count = 1

        # Never add e.g. a second fan-motor step or the alternative bumper
        # label purely because a different model has higher occurrence count.
        count = int(coherent_method.counts[str(operation_id)])
        if exact_config_count is not None and int(exact_config_count) != count:
            raise ValueError(
                "CONFIG_OCCURRENCE_CONFLICT: {} için config={} onaylı referans={}. "
                "Yanlış parça/tepsi sayısını sessizce tahmin etmiyorum.".format(
                    canonical_name, int(exact_config_count), count))

        for occurrence_index in range(
            1,
            count + 1
        ):
            instance_feature = (
                pair_feature_dict(
                    config,
                    operation_id,
                    occurrence_index
                )
            )

            x_instance = (
                instance_vectorizer
                .transform([
                    instance_feature
                ])
            )

            operation_station_profile = (
                operation_station_profiles.get(
                    str(
                        operation_id
                    ),
                    {}
                )
            )

            occurrence_profile = (
                operation_station_profile.get(
                    "OccurrenceProfiles",
                    {}
                ).get(
                    str(
                        occurrence_index
                    ),
                    {}
                )
            )

            occurrence_profile_sample_count = int(
                occurrence_profile.get(
                    "SampleCount",
                    0
                )
                or 0
            )

            occurrence_profile_confidence = float(
                occurrence_profile.get(
                    "Confidence",
                    0.0
                )
                or 0.0
            )

            occurrence_profile_station_type = str(
                occurrence_profile.get(
                    "DominantStationType",
                    ""
                )
                or ""
            )

            nearest_context = (
                _nearest_instance_context(
                    operation_id,
                    occurrence_index,
                    similar_models,
                    nearest_instance_history
                )
            )

            nearest_model_no = ""
            nearest_model_similarity = None
            nearest_model_duration = None
            nearest_model_station_sequence = None
            nearest_model_station_order = None
            nearest_model_within_position = None

            if nearest_context is not None:
                nearest_model_no = str(
                    nearest_context.get(
                        "ModelNo",
                        ""
                    )
                )

                nearest_model_similarity = float(
                    nearest_context.get(
                        "Similarity",
                        0.0
                    )
                )

                nearest_model_duration = (
                    nearest_context.get(
                        "Duration"
                    )
                )

                nearest_model_station_sequence = (
                    nearest_context.get(
                        "StationSequence"
                    )
                )

                nearest_model_station_order = (
                    nearest_context.get(
                        "StationOperationSequence"
                    )
                )

                nearest_model_within_position = (
                    nearest_context.get(
                        "WithinStationPosition"
                    )
                )

            if standard_cehennemlik_label:
                (
                    station_type,
                    station_type_source,
                    station_type_confidence,
                ) = (
                    "Main",
                    "ENGINEERING_RULE",
                    1.0,
                )

            elif (
                door_label_operation
                and
                kapi_etiketi_flag is True
            ):
                (
                    station_type,
                    station_type_source,
                    station_type_confidence,
                ) = (
                    "Main",
                    "CONFIG_ENGINEERING_RULE",
                    1.0,
                )

            elif (
                occurrence_profile_sample_count >= 3
                and
                occurrence_profile_confidence >= 0.70
                and
                occurrence_profile_station_type
                not in {
                    "",
                    "Unknown",
                    "None",
                }
            ):
                (
                    station_type,
                    station_type_source,
                    station_type_confidence,
                ) = (
                    occurrence_profile_station_type,
                    "HISTORICAL_OCCURRENCE_PROFILE",
                    occurrence_profile_confidence,
                )

            else:
                (
                    station_type,
                    station_type_source,
                    station_type_confidence,
                ) = _choose_station_type(
                    operation_id,
                    x_instance,
                    station_type_model,
                    operation_station_profiles
                )

            # Zone is a physical process category. Keep the learned
            # approved method's zone BEFORE choosing aggregate versus
            # per-operation timing, otherwise a Visual/Test task wrongly
            # inferred as Main will inflate the total work content.
            reference_key = str(operation_id) + '#' + str(occurrence_index)
            reference_station_type = str(
                coherent_method.members[reference_key].get('StationType') or ''
            )
            if reference_station_type and reference_station_type != station_type:
                station_type = reference_station_type
                station_type_source = 'COHERENT_APPROVED_REFERENCE'
                station_type_confidence = 1.0

            station_profile = (
                station_type_profiles.get(
                    station_type,
                    {}
                )
            )

            aggregate_station_time = bool(
                station_profile.get(
                    "AggregateStationTime",
                    False
                )
            )

            if aggregate_station_time:
                duration = None

                time_source = (
                    "STATION_AGGREGATE"
                )

            else:
                duration = max(
                    0.05,
                    float(
                        duration_model.predict(
                            x_instance
                        )[0]
                    )
                )

                time_source = (
                    "ML_OPERATION_DURATION"
                )

                # Preserve the validated ML estimate unless two or more
                # independent, config-compatible approved methods agree.
                duration_consensus = _confidence_aware_note_duration(
                    config,
                    operation_id,
                    occurrence_index,
                    duration,
                    training_config_profiles,
                    nearest_instance_history,
                )
                if duration_consensus is not None:
                    duration, consensus_model_count = duration_consensus
                    time_source = (
                        "CONFIG_CONDITIONED_DURATION_CONSENSUS_N"
                        + str(consensus_model_count)
                    )

            # The approved reference carries this operation WITHOUT line time
            # and the text says another (zero) station performs it, e.g.
            # "... LAMBAYI SIFIRINCI ISTASYON TAKACAK". An ML time here would
            # inflate the station load and make the balancer split a real
            # station (the lone 6 s rack-rail station 20).
            if duration is not None:
                reference_duration = coherent_method.members[
                    reference_key
                ].get('Duration')
                try:
                    reference_has_no_time = (
                        reference_duration is None
                        or not math.isfinite(float(reference_duration))
                    )
                except (TypeError, ValueError):
                    reference_has_no_time = True
                normalized_name = (
                    str(canonical_name)
                    .replace('\u0130', 'I')
                    .replace('\u0131', 'i')
                    .upper()
                )
                if reference_has_no_time and 'SIFIRINCI ISTASYON' in normalized_name:
                    duration = 0.0
                    time_source = 'REFERENCE_NO_LINE_TIME_ZERO_STATION'

            process_position = min(
                1.0,
                max(
                    0.0,
                    float(
                        process_position_model.predict(
                            x_instance
                        )[0]
                    )
                )
            )

            station_position = min(
                1.0,
                max(
                    0.0,
                    float(
                        station_position_model.predict(
                            x_instance
                        )[0]
                    )
                )
            )

            historical_within_station_position = (
                occurrence_profile.get(
                    "MedianWithinStationRelativePosition"
                )
            )

            if (
                occurrence_profile_sample_count >= 3
                and
                historical_within_station_position
                is not None
            ):
                within_station_position = min(
                    1.0,
                    max(
                        0.0,
                        float(
                            historical_within_station_position
                        )
                    )
                )

                within_station_order_source = (
                    "HISTORICAL_OCCURRENCE_PROFILE"
                )

            else:
                within_station_position = min(
                    1.0,
                    max(
                        0.0,
                        float(
                            within_station_position_model.predict(
                                x_instance
                            )[0]
                        )
                    )
                )

                within_station_order_source = (
                    "ML_WITHIN_STATION_POSITION"
                )

            # Historical within-station ML position is the primary signal.
            # Neighbor model position stays in report for audit/review.

            occurrence_preferred_station = (
                occurrence_profile.get(
                    "PreferredPhysicalStationNumber"
                )
            )

            global_preferred_station = (
                operation_station_profile.get(
                    "PreferredPhysicalStationNumber"
                )
            )

            if (
                occurrence_profile_sample_count >= 3
                and
                occurrence_preferred_station
                is not None
            ):
                preferred_physical_station = (
                    occurrence_preferred_station
                )

                physical_station_preference_source = (
                    "HISTORICAL_OCCURRENCE_PROFILE"
                )

            elif count > 1:
                # Repeated operations must not all inherit one canonical
                # station number. Their occurrence-specific station-position
                # model is the safer fallback and the balancer will map it
                # to the nearest learned physical station.
                preferred_physical_station = None

                physical_station_preference_source = (
                    "INSTANCE_STATION_POSITION_FALLBACK"
                )

            else:
                preferred_physical_station = (
                    global_preferred_station
                )

                physical_station_preference_source = (
                    "HISTORICAL_OPERATION_PROFILE"
                )

            engineering_rule = ""
            forced_physical_station = None
            forced_main_ordinal = None

            if exact_config_count is not None:
                engineering_rule = (
                    "CONFIG_EXACT_OCCURRENCE_COUNT_"
                    +
                    str(
                        int(
                            exact_config_count
                        )
                    )
                )

            if standard_cehennemlik_label:
                # Pin the station, retaining the learned process position.
                # The body must be placed before its barcode is attached.
                station_position = 0.0
                preferred_physical_station = 1.0
                forced_physical_station = 1
                forced_main_ordinal = 1
                engineering_rule = (
                    "STANDARD_CEHENNEMLIK_LABEL_PHYSICAL_STATION_1"
                )

                physical_station_preference_source = (
                    "ENGINEERING_RULE"
                )

            elif (
                door_label_operation
                and
                kapi_etiketi_flag is True
            ):
                # Kapı etiketi standart değildir.
                # Config "var" olduğunda zorunlu hale gelir.
                # Fiziksel bölgesi tarihsel olarak 44/49 civarıdır;
                # modelin öğrenilmiş fiziksel istasyon tercihinden
                # en yakın 44/49 referansı seçilir, ancak fiziksel
                # layout uygun değilse line balancer en yakın gerçek
                # istasyonu kullanabilir.
                mode_physical_station = (
                    operation_station_profile.get(
                        "ModePhysicalStationNumber"
                    )
                )

                historical_preferred = (
                    mode_physical_station
                    if mode_physical_station is not None
                    else preferred_physical_station
                )

                try:
                    historical_preferred = float(
                        historical_preferred
                    )
                except Exception:
                    historical_preferred = 49.0

                preferred_physical_station = min(
                    [44.0, 49.0],
                    key=lambda value:
                        abs(
                            value -
                            historical_preferred
                        )
                )

                process_position = max(
                    process_position,
                    0.85
                )

                station_position = max(
                    station_position,
                    0.85
                )

                engineering_rule = (
                    "KAPI_ETIKETI_CONFIG_VAR_PHYSICAL_44_OR_49"
                )

                physical_station_preference_source = (
                    "CONFIG_ENGINEERING_RULE"
                )

            elif rear_cover_label_operation:
                process_position = max(
                    process_position,
                    0.95
                )

                station_position = max(
                    station_position,
                    0.95
                )

                preferred_physical_station = 49.0

                physical_station_preference_source = (
                    "ENGINEERING_RULE_REAR_COVER_LABEL"
                )

                engineering_rule = (
                    "REAR_COVER_CONTROL_PANEL_LABEL_PHYSICAL_STATION_49"
                )

            note_trigger_term = ""
            note_trigger_confidence = None
            note_trigger_support = None

            if note_trigger is not None:
                note_trigger_term = str(
                    note_trigger.get(
                        "Term",
                        ""
                    )
                )

                note_trigger_confidence = float(
                    note_trigger.get(
                        "Confidence",
                        0.0
                    )
                )

                note_trigger_support = int(
                    note_trigger.get(
                        "SupportModels",
                        0
                    )
                )

                note_rule_name = (
                    "NOTE_TRIGGER::"
                    +
                    note_trigger_term.replace(
                        " ",
                        "_"
                    )
                )

                engineering_rule = (
                    engineering_rule
                    +
                    (
                        ";"
                        if engineering_rule
                        else ""
                    )
                    +
                    note_rule_name
                )

            # Pallet rotation is a PROCESS-STATE anchor.
            #
            # IMPORTANT:
            # Do not hard-force it to one exact physical station here.
            # Historical occurrence profiles can contain a small local
            # non-monotonicity (for example 34 -> 33 -> 34). Exact forcing
            # would then conflict with process-order constraints and make
            # CP-SAT infeasible.
            #
            # The line balancer handles pallet anchors with:
            #   - tight local physical movement (±1 learned station slot),
            #   - preserved occurrence/process order,
            #   - anti-clustering constraints.
            is_pallet_orientation_anchor = bool(
                pallet_orientation_operation
                and
                preferred_physical_station is not None
                and
                occurrence_profile_sample_count >= 3
            )

            if is_pallet_orientation_anchor:
                anchor_rule = (
                    "PALLET_ORIENTATION_PROCESS_STATE_ANCHOR"
                )

                engineering_rule = (
                    engineering_rule
                    +
                    (
                        ";"
                        if engineering_rule
                        else ""
                    )
                    +
                    anchor_rule
                )

            predicted_instances.append({
                "InstanceId":
                    (
                        f"{operation_id}"
                        f"#{occurrence_index}"
                    ),
                "CanonicalOperationId":
                    operation_id,
                "CanonicalName":
                    canonical_name,
                "CanonicalComponent":
                    canonical_component,
                "OccurrenceIndex":
                    occurrence_index,
                "EngineeringRule":
                    engineering_rule,
                "NoteTriggerTerm":
                    note_trigger_term,
                "NoteTriggerConfidence":
                    note_trigger_confidence,
                "NoteTriggerSupport":
                    note_trigger_support,
                "NearestReferenceModelNo":
                    nearest_model_no,
                "NearestReferenceSimilarity":
                    nearest_model_similarity,
                "NearestReferenceDurationSeconds":
                    nearest_model_duration,
                "NearestReferenceStationSequence":
                    nearest_model_station_sequence,
                "NearestReferenceStationOperationSequence":
                    nearest_model_station_order,
                "NearestReferenceWithinStationPosition":
                    nearest_model_within_position,
                "PreferredPhysicalStationNumber":
                    preferred_physical_station,
                "PhysicalStationPreferenceSource":
                    physical_station_preference_source,
                "OccurrenceProfileSampleCount":
                    occurrence_profile_sample_count,
                "ForcedPhysicalStationNumber":
                    forced_physical_station,
                "ForcedMainOrdinal":
                    forced_main_ordinal,
                "IsPalletOrientationAnchor":
                    is_pallet_orientation_anchor,
                "PresenceProbability":
                    probability,
                "HistoricalPrevalence":
                    historical_prevalence,
                "PredictedTimeSeconds":
                    duration,
                "TimeSource":
                    time_source,
                "PredictedProcessPosition":
                    process_position,
                "PredictedStationPosition":
                    station_position,
                "PredictedWithinStationPosition":
                    within_station_position,
                "WithinStationOrderSource":
                    within_station_order_source,
                "PredictedStationType":
                    station_type,
                "StationTypeSource":
                    station_type_source,
                "StationTypeHistoricalConfidence":
                    station_type_confidence,
            })

    if not predicted_instances:
        raise ValueError(
            "AI bu model için hiçbir operasyon üretemedi."
        )

    _apply_tray_grid_same_station_rule(
        predicted_instances
    )

    ordered = _topological_order(
        predicted_instances,
        bundle.get(
            "precedence_edges",
            []
        )
    )
    # Set the true coherent source chronology BEFORE orientation marking.
    # This prevents palet/cehennemlik sequence synthesis from mixed models.
    ordered = attach_coherent_chronology(ordered, coherent_method)

    for index, item in enumerate(
        ordered,
        start=1
    ):
        item[
            "PredictedProcessSequence"
        ] = index

    mark_orientation_phases(ordered)

    _apply_pallet_context_preferences(
        ordered
    )

    preserved_reference = coherent_method.model_no
    # The prior helper could reattach the chronology from a DIFFERENT
    # similar model. The complete matching method was attached above.

    # In Metodu Koru use the learned reference chronology rather than
    # the 24-second physical station allocation. Recompute pallet context
    # only after the complete reference has been attached.
    mark_orientation_phases(ordered)
    if preserved_reference:
        _apply_pallet_context_preferences(reference_chronology(ordered))
    reference_rotation_profile = bundle.get("rotation_patterns_by_model", {})
    if preserved_reference and reference_rotation_profile:
        expected_pattern = reference_rotation_profile.get(
            str(preserved_reference), []
        )
        actual_pattern = [turn_kind(op.get("CanonicalName", ""))
                          for op in sorted(
                              (v for v in ordered if
                               str(v.get("PredictedStationType", "Main")) == "Main"),
                              key=lambda v: (
                                  int(v.get("PreservedReferenceStationSequence") or 0),
                                  int(v.get("PreservedReferenceStationOperationSequence") or 0),
                              ))
                          if turn_kind(op.get("CanonicalName", ""))[0]]
        if expected_pattern and actual_pattern != [
            (p["Kind"], int(p["Angle"])) for p in expected_pattern
        ]:
            raise ValueError(
                "Öğrenilmiş referansla ürün dönüş dizisi farklı. "
                "Palet/cehennemlik 90°-180° senkronu doğrulanmadan "
                "hat dengeleme yapılmayacak."
            )

    # CK2 Group ML: this is a CONTINUOUS CT-based probability model.
    # Station boundaries are suggestions only; product orientation,
    # mandatory chronology and tooling remain certified hard constraints.
    seated_fan_audit = _annotate_seated_fan_evidence(
        ordered, nearest_instance_history, canonical_name_map, model_no)
    learned_group_pairs = annotate_station_groups(ordered, config, bundle)
    learned_reorder_pairs = annotate_reorder_evidence(ordered, bundle)
    human_order_audit = {'protected_pairs': 0, 'status': 'ENDPOINT_UNCHANGED'}
    # Only the intermediate-CT correction path changes. Approved endpoint
    # outputs and their existing duration/layout calculations remain intact.
    if 24.25 < requested_cycle_time < 29.75:
        human_order_audit = annotate_human_order(
            ordered, nearest_instance_history,
            _rank_similar_models(config, training_config_profiles,
                                top_n=max(100, len(training_config_profiles))),
            model_no,
            training_profiles=training_config_profiles,
        )
    # Station mentor and product inventory are deliberately distinct.
    # Operation identity/rotation comes from coherent_method; T1065/T1330
    # real layouts only teach soft CT-conditioned grouping and station cost.
    # Inventory candidates may be restricted to top 100 for product
    # compatibility. Layout learning MUST see every approved T1065/T1330
    # method; otherwise the right-tempo reference can be silently dropped.
    tempo_layout_candidates = _rank_similar_models(
        config, training_config_profiles,
        top_n=max(100, len(training_config_profiles)),
    )
    tempo_layout_result = learn_tempo_station_layout(
        ordered, requested_cycle_time,
        tempo_layout_candidates, nearest_instance_history,
    )

    cycle_time = (
        working_hours *
        3600.0 /
        target_quantity
    )

    max_station_load_seconds = (
        cycle_time *
        max_saturation_percent /
        100.0
    )

    (
        balanced,
        station_records,
        balancer_name,
        warnings,
    ) = balance_operations(
        ordered,
        cycle_time,
        station_type_profiles,
        precedence_edges=
            bundle.get(
                "precedence_edges",
                []
            ),
        max_saturation_percent=
            max_saturation_percent,
        balance_mode=
            balance_mode,
        reference_total_station_count=None,
        same_station_precedence_edges=
            same_station_precedence_edges,
        hard_bundle_edges=
            hard_bundle_edges,
        operation_block_map=
            operation_block_map,
        process_block_order_edges=
            process_block_order_edges
    )

    group_ml_status = (bundle.get("station_group_metrics") or {}).get("status", "LEGACY")
    warnings.insert(0,
        "TEMPO_LAYOUT_LEARNING: status={}; primary={}; primary_ct={}; "
        "matched_main_ops={}; paired_ops={}; mentors={}".format(
            tempo_layout_result.get("status"),
            tempo_layout_result.get("main_mentor_model", ""),
            tempo_layout_result.get("main_mentor_ct", ""),
            tempo_layout_result.get("matched_count", 0),
            tempo_layout_result.get("learned_pairs", 0),
            ",".join("{}@{}s:{:.2f}".format(item['model'], item['ct'], item['weight'])
                     for item in tempo_layout_result.get('mentors', [])),
        )
    )
    if tempo_layout_result.get('status') != 'TEMPO_LAYOUT_TRANSFER_ACTIVE':
        warnings.insert(0, 'TEMPO_LAYOUT_LEARNING_NOT_APPLIED: '
                        '1065 istasyon bilgisi bu tahminde kullanilmadi; '
                        'egitim paketi / benzer model eslesmesini kontrol edin.')
    else:
        warnings.insert(0, 'TEMPO_LAYOUT_ML_ACTIVE: T1065/T1330 '
                        'istasyon bilgisi dogrudan dengeleyiciye aktarildi.')

    if learned_group_pairs > 0:
        warnings.insert(0,
            "STATION_GROUP_ML_ACTIVE: mode=CONTINUOUS_CYCLE_TIME; "
            f"operation_pairs={learned_group_pairs}; "
            f"training_status={group_ml_status}; "
            "constraint_type=SOFT; orientation_and_order=HARD"
        )
    else:
        warnings.insert(0,
            "STATION_GROUP_ML_UNAVAILABLE: Approved T1065/T1330 data "
            "insufficient or missing; learned station grouping was NOT used."
        )

    if not preserved_reference:
        warnings.append(
            "PRESERVE_REFERENCE_UNAVAILABLE: Özellikleri ve bütün operasyon "
            "oluşumları eşleşen tek bir eğitim referansı bulunamadı. "
            "Tahmin edilen Main proses sırası korunarak dengelendi; "
            "referans metodun birebir korunduğu varsayılmamalı."
        )

    market_catalog_path = config_path.parent / "Engineering" / "Market_Operations.csv"
    (
        balanced, station_records, added_engineering_rules,
        engineering_warnings, pending_engineering_rules,
    ) = _apply_approved_market_rules(
        balanced, station_records, config, market_catalog_path,
        cycle_time, max_saturation_percent,
    )
    warnings.append('V051_SEATED_FAN_STATION_RULE: learned_human_station_groups={}; '
                    'companions={}; minimum_distinct_training_products=2; '
                    'standing_side_panel=FORBIDDEN; target_model_excluded=True'.format(
                        seated_fan_audit['training_station_groups'],
                        seated_fan_audit['compatible_companions']))
    warnings.extend(engineering_warnings)
    (
        balanced, station_records, accepted_order_overrides,
        override_warnings,
    ) = _apply_approved_station_overrides(
        balanced, station_records, model_no, config_path,
        cycle_time, max_saturation_percent,
    )
    warnings.extend(override_warnings)
    if config.get('ProductDataCorrections'):
        warnings.append('PRODUCT_DATA_CORRECTION: ' + config['ProductDataCorrections'])
    if quantity_changes:
        warnings.append('CONFIG_QUANTITY_ADAPTATION: source={}; counts={}; '
                        'existing_operation_templates_only=True; chronology=PRESERVED'.format(
                            coherent_method.model_no, quantity_changes))
    warnings[0:0] = list(_ck2_reference_retry["notes"])
    warnings.append('V048_CONFIG_COMPATIBLE_INVENTORY: reference={}; '
                    'structured_product_fields=MATCHED; excluded_incompatible={}; '
                    'tempo_does_not_override_product_configuration=True'.format(
                        coherent_method.model_no, len(rejected_configs)))
    approved_terms = {rule["Term"] for rule in added_engineering_rules}
    unresolved_note_segments = [
        term for term in unresolved_note_segments if term not in approved_terms
    ]
    for rule in added_engineering_rules:
        warnings.append(
            "ENGINEERING_APPROVED_NOT_ML: " + rule["Term"] +
            " - kaynak: " + rule["ApprovalSource"]
        )

    for unresolved_segment in (
        unresolved_note_segments
    ):
        warnings.append(
            "UNSEEN_NOTE_SEGMENT: "
            +
            unresolved_segment
            +
            " -> Onaylı eğitim metodlarında doğrudan operasyon karşılığı "
            "bulunamadı. Mühendislik doğrulaması gerekli; sistem operasyon "
            "uydurmadı."
        )

    validate_human_order(balanced, human_order_audit)
    if human_order_audit['protected_pairs']:
        warnings.append('HUMAN_METHOD_ORDER_VALIDATED: protected_pairs={}; '
                        'source=approved_training_methods; target_model_excluded=True'.format(
                            human_order_audit['protected_pairs']))
    final_inventory_audit = post_balance_integrity(
        ordered, balanced, coherent_method)
    warnings.append(
        "COHERENT_METHOD_INVENTORY_VALIDATED: reference={}, ops={}, "
        "rotations={}, similarity={:.4f}, CT={}sec; ML duration retained".format(
            final_inventory_audit['source'],
            final_inventory_audit['operation_count'],
            final_inventory_audit['rotation_count'],
            coherent_method.similarity,
            round(cycle_time, 3)))

    # Final fail-closed validation AFTER all approved override operations.
    # No output file is issued if the product's front/back synchronisation
    # or an explicit component-turn boundary has changed.
    rotation_audit = validate_orientation(ordered, balanced)
    warnings.append(
        "ORIENTATION_SYNC_VALIDATED: pallet_turns={}, component_turns={}, "
        "all_turns={}, result={}".format(
            rotation_audit["pallet_turns"],
            rotation_audit["component_turns"],
            rotation_audit["total_turns"],
            rotation_audit["status"],
        )
    )

    staffing_plan = _operator_plan(
        station_records, _load_test_operator_override(config_path, model_no, target_quantity))
    labor_metrics = workforce_metrics(station_records, cycle_time, staffing_plan)
    staffing_plan.update(operator_saturation_percent=labor_metrics['operator_saturation_percent'],
                         operator_saturation_status=labor_metrics['operator_saturation_status'])
    if staffing_plan['test_override']:
        warnings = [w for w in warnings if not str(w).startswith((
            'SATURATION_90_NOT_ACHIEVED:', 'TARGET_CT_BALANCE:', 'TARGET_90_GAP:'))]
        warnings.append('V049_USER_CONFIRMED_TEST_OPERATORS: physical_test_stations={}; '
                        'test_operators={}; total_physical_stations={}; total_operators={}; '
                        'operator_saturation=UNKNOWN_ACTIVE_TEST_TIME'.format(
                            sum(r['StationType'] == 'Test' for r in station_records),
                            staffing_plan['operators_by_process']['Test'],
                            staffing_plan['physical_station_count'], staffing_plan['operator_count']))
    _write_prediction_excel(
        output_path=
            output_path,
        model_no=
            model_no,
        working_hours=
            working_hours,
        target_quantity=
            target_quantity,
        cycle_time=
            cycle_time,
        max_saturation_percent=
            max_saturation_percent,
        max_station_load_seconds=
            max_station_load_seconds,
        balance_mode=
            balance_mode,
        model_version=
            version,
        balancer_name=
            balancer_name,
        operations=
            balanced,
        station_records=
            station_records,
        warnings=
            warnings,
        config=
            config,
        similar_models=
            similar_models,
        unresolved_note_segments=
            unresolved_note_segments,
        tempo_layout_result=tempo_layout_result,
        operation_inventory_source=coherent_method.model_no,
        hard_bundle_edges=hard_bundle_edges,
        staffing_plan=staffing_plan,
    )

    return {
        'manual_station_saturation_percent': labor_metrics['manual_saturation_percent'],
        'machine_station_saturation_percent': labor_metrics['machine_saturation_percent'],
        'manual_work_content_seconds': labor_metrics['manual_work_seconds'],
        "operator_count": staffing_plan['operator_count'],
        "operator_saturation_percent": staffing_plan['operator_saturation_percent'],
        "operator_saturation_status": staffing_plan['operator_saturation_status'],
        "model_no":
            model_no,
        "model_version":
            version,
        "cycle_time":
            cycle_time,
        "max_saturation_percent":
            max_saturation_percent,
        "max_station_load_seconds":
            max_station_load_seconds,
        "balance_mode":
            balance_mode,
        "operation_count":
            len(
                balanced
            ),
        "station_count":
            len(
                station_records
            ),
        # Preserve actual engineering conditions in the CLI status too.
        "effective_work_content_seconds": float(sum(
            float(x.get("StationLoadSeconds", 0) or 0)
            for x in station_records)),
        "achieved_station_saturation_percent": (
            100.0 * sum(float(x.get("StationLoadSeconds", 0) or 0)
                        for x in station_records)
            / (cycle_time * len(station_records))
            if station_records else 0.0),
        "max_staff_for_90_percent": labor_metrics['max_staff_for_90_percent'],
        "balancer":
            balancer_name,
        "warning_count":
            len(
                warnings
            ),
        "top_similar_model": tempo_layout_result.get(
            'main_mentor_model', '') or (
                similar_models[0]['ModelNo'] if similar_models else ''),
        "operation_inventory_source": coherent_method.model_no,
        "tempo_layout_learning": tempo_layout_result,
        "human_method_order": human_order_audit,
        "top_similar_model_score":
            (
                similar_models[0][
                    "Similarity"
                ]
                if similar_models
                else 0.0
            ),
        "unresolved_note_segment_count":
            len(
                unresolved_note_segments
            ),
        "output_path":
            str(
                output_path
            ),
    }


# Reference fallback state (see predict_method wrapper at the end of the file).
_ck2_reference_retry = {"excluded": set(), "last": None, "notes": []}


def _ck2_aggregate_capacity_problem(coherent_method, station_type_profiles,
                                    max_station_load_seconds):
    """Return a text if a fixed aggregate station (e.g. test) of the reference
    cannot fit the target station load, else ''. Uses the same learned
    per-station times as the balancer (by station count when available)."""
    for station_type, profile in (station_type_profiles or {}).items():
        if not isinstance(profile, dict) or not profile.get(
                "AggregateStationTime", False):
            continue
        sequences = {
            observation.get("StationSequence")
            for observation in coherent_method.members.values()
            if str(observation.get("StationType") or "").strip() == station_type
            and observation.get("StationSequence") is not None
        }
        count = len(sequences)
        if not count:
            continue
        ordinals = (profile.get("StationOrdinalsByCount") or {}).get(
            str(count)) or profile.get("StationOrdinals") or []
        for ordinal in ordinals[:count]:
            seconds = float(ordinal.get("MedianCycleTimeSeconds") or 0.0)
            if seconds > max_station_load_seconds + 1e-9:
                return (
                    "{} istasyonu ({} adet) {:.1f} sn, izin verilen yük "
                    "{:.1f} sn".format(
                        station_type, count, seconds, max_station_load_seconds)
                )
    return ""


# CK2 V019 diagnostics: label remaining nullable-integer failures precisely.
_ck2_original_predict_method = predict_method


def predict_method(*args, **kwargs):
    try:
        return _ck2_original_predict_method(*args, **kwargs)
    except TypeError as error:
        if "int()" not in str(error) or "NoneType" not in str(error):
            raise
        import traceback
        frames = traceback.extract_tb(error.__traceback__)
        if not frames:
            raise
        last = frames[-1]
        raise ValueError(
            "CK2_NULL_INTEGER_FIELD: {}:{} in {}. "
            "Zorunlu istasyon/sıra alanı boş. Asıl hata: {}".format(
                Path(last.filename).name, last.lineno, last.name, error
            )
        ) from error


# Intermediate production quantities: the nearest-CT reference can be the wrong
# tempo family for the target (e.g. its single 28 s test station does not fit
# CT 27.8 s while the 3 x 22 s test layout of the other tempo does). A capacity
# violation therefore retries with the next approved reference instead of
# failing; the first error is reported if no reference fits.
_ck2_diagnosed_predict_method = predict_method


def predict_method(*args, **kwargs):
    state = _ck2_reference_retry
    state["excluded"], state["last"], state["notes"] = set(), None, []
    first_error = None
    for _attempt in range(8):
        try:
            return _ck2_diagnosed_predict_method(*args, **kwargs)
        except ValueError as error:
            message = str(error)
            if first_error is None:
                first_error = error
            tried = state["last"]
            if tried is None and "METHOD_REFERENCE_UNAVAILABLE" in message:
                raise first_error from None
            if tried is None or tried in state["excluded"] or not (
                "Kapasite ihlali" in message
                or "METODU_KORU_KAPASITE" in message
            ):
                raise
            state["excluded"].add(tried)
            state["notes"].append(
                "REFERENCE_FALLBACK: {} hedef çevrim süresine sığmadı ({}); "
                "sıradaki onaylı referans deneniyor.".format(
                    tried, message[:140])
            )
            state["last"] = None
    raise first_error
