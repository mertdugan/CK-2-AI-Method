"""Mevcut modele (yeniden egitmeden) 'Test istasyonu sayisina gore sure' bilgisini ekler.

Kullanim:
    python add_test_ordinals.py <Data klasoru> <model klasoru, ornegin ...\\Models\\V021>

Methods\\T*\\*.xlsx icindeki 'grf' sayfalarindan TEST istasyonu sayisini ve sureleri okur,
her sayi icin (1, 2, 3, 4 test istasyonu) siradaki istasyonun medyan suresini hesaplar ve
model_bundle.joblib + station_type_profiles.json dosyalarina 'StationOrdinalsByCount'
olarak yazar. Ayni islemi yeni trainer.py egitim sirasinda kendisi yapar.
"""
import glob, json, re, statistics, sys, warnings
from collections import defaultdict
from pathlib import Path

import joblib
import pandas as pd

warnings.filterwarnings("ignore")


def main(data_dir, model_dir):
    data_dir, model_dir = Path(data_dir), Path(model_dir)
    per_count = defaultdict(lambda: defaultdict(list))
    models_per_count = defaultdict(set)
    for path in glob.glob(str(data_dir / "Methods" / "T*" / "*.xlsx")):
        sheets = pd.read_excel(path, sheet_name=None, header=None)
        grf = [k for k in sheets if k.strip().endswith("grf")]
        if not grf:
            continue
        times = []
        for _, row in sheets[grf[0]].iterrows():
            name = str(row[0]).strip().upper().replace("İ", "I")
            if re.match(r"^TEST", name) and pd.notna(row[1]):
                times.append(float(row[1]))
        for ordinal, value in enumerate(times, 1):
            per_count[len(times)][ordinal].append(value)
        if times:
            models_per_count[len(times)].add(path)

    by_count = {}
    for count in sorted(per_count):
        if len(models_per_count[count]) < 3:
            continue
        by_count[str(count)] = [{
            "Ordinal": ordinal,
            "MedianRelativePosition": 0.0,
            "MedianMainAnchor": 1.0,
            "MedianCycleTimeSeconds": statistics.median(per_count[count][ordinal]),
            "MedianOperationCount": 3.0,
            "ModePhysicalStationNumber": ordinal,
            "MedianPhysicalStationNumber": float(ordinal),
        } for ordinal in range(1, count + 1)]

    bundle_path = model_dir / "model_bundle.joblib"
    bundle = joblib.load(bundle_path)
    bundle["station_type_profiles"]["Test"]["StationOrdinalsByCount"] = by_count
    joblib.dump(bundle, bundle_path)

    json_path = model_dir / "station_type_profiles.json"
    profiles = json.loads(json_path.read_text(encoding="utf-8"))
    profiles["Test"]["StationOrdinalsByCount"] = by_count
    json_path.write_text(json.dumps(profiles, ensure_ascii=False, indent=2), encoding="utf-8")
    for count, ordinals in by_count.items():
        print(count, "test istasyonu ->", [o["MedianCycleTimeSeconds"] for o in ordinals])


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
