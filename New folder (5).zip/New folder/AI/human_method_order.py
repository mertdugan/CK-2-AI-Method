
"""Conservative intermediate-CT order protection from approved human methods.

Historical consensus is a conservative planning restriction, not a new
engineering approval. Conflicting or single-tempo evidence is never promoted
to a universal precedence rule. No product-specific operation IDs are used.
"""
import math
from collections import defaultdict


def key(op):
    return str(op.get('CanonicalOperationId', '')), int(op.get('OccurrenceIndex') or 1)


def _location(row):
    try:
        values = tuple(float(row[k]) for k in ('StationSequence', 'StationOperationSequence'))
        if all(math.isfinite(x) and x > 0 and x.is_integer() for x in values):
            return values
    except (KeyError, ValueError, TypeError, OverflowError):
        pass
    return None


def annotate_human_order(operations, history, similar_models, target_model,
                        minimum_products_per_tempo=2, training_profiles=()):
    profiles = {}
    source_cts = {str(p.get('ModelNo', '')): p.get('ConfigReferenceCycleTimeSeconds')
                  for p in training_profiles}
    target_base = str(target_model).split('__T', 1)[0]
    for profile in similar_models:
        model = str(profile.get('ModelNo', ''))
        if model.split('__T', 1)[0] == target_base:
            continue
        try:
            similarity = float(profile.get('Similarity', 0))
            ct = float(profile.get('ConfigReferenceCycleTimeSeconds', source_cts.get(model)))
        except (TypeError, ValueError):
            continue
        if math.isfinite(similarity) and similarity >= .90 and math.isfinite(ct) and ct > 0:
            profiles[model] = round(ct, 6)
    anchors = set(profiles.values())
    if len(anchors) < 2:
        return {'protected_pairs': 0, 'status': 'INSUFFICIENT_TEMPO_EVIDENCE'}
    main = [o for o in operations if o.get('PredictedStationType', 'Main') == 'Main']
    indexed = {}
    for op in main:
        instance = key(op)
        entries = {}
        duplicates = set()
        for row in history.get(f'{instance[0]}#{instance[1]}', ()):
            model = str(row.get('ModelNo', ''))
            if model not in profiles or row.get('StationType') != 'Main':
                continue
            if model in entries:
                duplicates.add(model)
            entries[model] = _location(row)
        indexed[instance] = {m: loc for m, loc in entries.items()
                             if m not in duplicates and loc is not None}
    protected = []
    for first, second in zip(main, main[1:]):
        first.pop('HumanMethodOrderWithNext', None)
        a, b = indexed[key(first)], indexed[key(second)]
        products = defaultdict(set)
        methods = defaultdict(int)
        conflict = False
        for model in a.keys() & b.keys():
            if a[model] >= b[model]:
                conflict = True
                break
            ct = profiles[model]
            products[ct].add(model.split('__T', 1)[0])
            methods[ct] += 1
        if conflict or any(len(products[ct]) < minimum_products_per_tempo for ct in anchors):
            continue
        evidence = {'first': key(first), 'second': key(second),
                    'methods_by_ct': dict(sorted(methods.items())),
                    'source': 'CONSISTENT_HUMAN_METHOD_ORDER'}
        first['HumanMethodOrderWithNext'] = evidence
        protected.append(evidence)
    return {'protected_pairs': len(protected), 'status': 'HUMAN_METHOD_ORDER_ACTIVE',
            'pairs': protected}


def historically_supported_swap(first):
    """An improving numeric partition alone is not evidence of reorderability."""
    if first.get('HumanMethodOrderWithNext'):
        return False
    evidence = first.get('ObservedReorderWithNext') or {}
    try:
        return (int(evidence.get('forward_methods', 0)) >= 2
                and int(evidence.get('reverse_methods', 0)) >= 2)
    except (TypeError, ValueError, OverflowError):
        return False


def validate_human_order(operations, audit):
    locations = {key(op): (int(op['DisplayOrder']), int(op['StationOperationSequence']))
                 for op in operations}
    for pair in audit.get('pairs', ()):
        a, b = tuple(pair['first']), tuple(pair['second'])
        if a not in locations or b not in locations or locations[a] >= locations[b]:
            raise ValueError(f'HUMAN_METHOD_ORDER_VIOLATION: {a} must precede {b}')
