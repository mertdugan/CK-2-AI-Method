﻿
# -*- coding: utf-8 -*-
"""CK-2 AI Metod / adaptive cycle-time balancing upgrade.

Run once from the directory containing CK2_AI_Metod.AI or line_balancer.py:
    python CK2_Dengeleme_Guncelle.py

This update preserves the existing AI/training code and replaces only the
mode-control sections of line_balancer.py. It creates a dated backup, and
refuses to modify unrecognized versions.
"""
from __future__ import annotations

import ast
import datetime
import pathlib
import py_compile
import shutil


REFERENCE_HELPERS = '''
def _adaptive_reference_operations(operations, profiles):
    """Restore the reference's global order while allowing station regrouping.

    A coherent reference supplies *process order*, not a frozen workforce.
    Source operation durations still come from the current AI prediction.
    """
    required = (
        "PreservedReferenceModelNo",
        "PreservedReferenceStationType",
        "PreservedReferenceStationNumber",
        "PreservedReferenceStationSequence",
        "PreservedReferenceStationOperationSequence",
    )
    if not operations or not all(
        all(op.get(field) is not None for field in required)
        for op in operations
    ):
        raise ValueError("Metodu Koru: referans işlem sırası eksik.")

    model_numbers = {str(op["PreservedReferenceModelNo"]).strip() for op in operations}
    if len(model_numbers) != 1 or not next(iter(model_numbers)):
        raise ValueError("Metodu Koru: tek ve tutarlı referans model gerekiyor.")

    identities = set()
    source_stations = {}
    source_station_orders = defaultdict(set)
    copies = []

    def positive_integer(value, label):
        try:
            number = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"Referans {label} geçersiz: {value}")
        if not math.isfinite(number) or number <= 0 or not number.is_integer():
            raise ValueError(f"Referans {label} pozitif tam sayı olmalı: {value}")
        return int(number)

    for operation in operations:
        op = dict(operation)
        identity = (
            str(op["CanonicalOperationId"]),
            positive_integer(op.get("OccurrenceIndex", 1), "operasyon tekrarı"),
        )
        if identity in identities:
            raise ValueError("Referansta yinelenen operasyon oluşumu var: " + str(identity))
        identities.add(identity)

        station_type = str(op["PreservedReferenceStationType"])
        if station_type != str(op.get("PredictedStationType", "Main")):
            raise ValueError("Referans ve tahmin istasyon türü uyuşmuyor.")
        station_sequence = positive_integer(op["PreservedReferenceStationSequence"], "istasyon sırası")
        within_station = positive_integer(
            op["PreservedReferenceStationOperationSequence"], "istasyon içi sıra"
        )
        physical = positive_integer(op["PreservedReferenceStationNumber"], "fiziksel istasyon")
        key = (station_type, physical)

        if station_sequence in source_stations and source_stations[station_sequence] != key:
            raise ValueError("Referans istasyon numaraları kendi içinde çelişiyor.")
        source_stations[station_sequence] = key
        if within_station in source_station_orders[station_sequence]:
            raise ValueError("Referans istasyon içinde yinelenen işlem sırası.")
        source_station_orders[station_sequence].add(within_station)

        profile = profiles.get(station_type, {})
        known = {int(v) for v in profile.get("PhysicalStationNumbers", []) if v is not None}
        if known and physical not in known:
            raise ValueError(f"Referans istasyon öğrenilmiş fiziksel hatta yok: {key}")

        forced = op.get("ForcedPhysicalStationNumber")
        if forced is not None and int(forced) != physical:
            raise ValueError("Referans, zorunlu fiziksel istasyon kuralıyla çelişiyor.")
        copies.append(op)

    if sorted(source_stations) != list(range(1, len(source_stations) + 1)):
        raise ValueError("Referans istasyon sıraları eksik veya kesintili.")

    main_numbers = [source_stations[i][1] for i in sorted(source_stations)
                    if source_stations[i][0] == "Main"]
    if main_numbers != sorted(main_numbers) or len(main_numbers) != len(set(main_numbers)):
        raise ValueError("Referans Main istasyon sırası fiziksel akışla uyuşmuyor.")

    for source_seq, orders in source_station_orders.items():
        if sorted(orders) != list(range(1, len(orders) + 1)):
            raise ValueError(f"Referans {source_seq}: istasyon içi işlem sırası eksik.")

    copies.sort(key=lambda op: (
        int(op["PreservedReferenceStationSequence"]),
        int(op["PreservedReferenceStationOperationSequence"]),
    ))
    for i, op in enumerate(copies, start=1):
        op["PredictedProcessSequence"] = i
        op["AdaptiveReferenceSequence"] = i
    return copies, next(iter(model_numbers))


def _adaptive_restore_station_order(operations):
    """Merged reference stations keep original relative operation order."""
    by_station = defaultdict(list)
    for op in operations:
        by_station[int(op["DisplayOrder"])].append(op)
    result = []
    for station in sorted(by_station):
        items = sorted(
            by_station[station],
            key=lambda op: int(op["AdaptiveReferenceSequence"]),
        )
        for station_position, operation in enumerate(items, start=1):
            operation["StationOperationSequence"] = station_position
            operation["WithinStationOrderSource"] = "ADAPTIVE_REFERENCE_SEQUENCE"
            operation["Sequence"] = len(result) + 1
            result.append(operation)
    return result


def _adaptive_validate(operations, records, cycle_time, max_station_load):
    """Fail rather than publish a physically inconsistent predicted method."""
    stations = {int(record["DisplayOrder"]): record for record in records}
    for record in records:
        load = float(record["StationLoadSeconds"])
        if not math.isfinite(load) or load < -1e-8 or load > max_station_load + 1e-6:
            raise ValueError(
                "Kapasite sınırı ihlali: " + str(record.get("AssignedStationLabel"))
                + f" {load:.3f} sn > {max_station_load:.3f} sn"
            )
    grouped = defaultdict(list)
    for op in operations:
        station = int(op["DisplayOrder"])
        if station not in stations:
            raise ValueError("Operasyon geçersiz istasyona atandı.")
        forced = op.get("ForcedPhysicalStationNumber")
        if forced is not None and int(forced) != int(op["PhysicalStationNumber"]):
            raise ValueError("Zorunlu fiziksel istasyon ihlali: " + str(op["CanonicalName"]))
        grouped[station].append(op)
    for key, group in grouped.items():
        actual = sorted(int(op["StationOperationSequence"]) for op in group)
        if actual != list(range(1, len(group) + 1)):
            raise ValueError(f"İstasyon {key}: istasyon içi işlem sırası bozuk.")
    main = sorted(
        (op for op in operations if op.get("AssignedStationType") == "Main"),
        key=lambda op: int(op.get("PredictedProcessSequence", 0)),
    )
    physical = [int(op["PhysicalStationNumber"]) for op in main]
    if physical != sorted(physical):
        raise ValueError("Main proses sırası fiziksel yerleşimde geri gidiyor.")
    reference = [op for op in operations if "AdaptiveReferenceSequence" in op]
    if reference:
        ordered = sorted(reference, key=lambda op: int(op["AdaptiveReferenceSequence"]))
        display_orders = [int(op["DisplayOrder"]) for op in ordered]
        if display_orders != sorted(display_orders):
            raise ValueError("Metodu Koru: öğrenilmiş operasyon sırası bozuldu.")
        for op in reference:
            if int(op["StationOperationSequence"]) < 1:
                raise ValueError("Metodu Koru: operasyonun istasyon içi sıra bilgisi eksik.")
'''


def replace_exact(src: str, before: str, after: str, label: str) -> str:
    count = src.count(before)
    if count != 1:
        raise RuntimeError(f"{label}: kaynakta beklenen kalıp 1 kez bulunmalı; bulundu={count}. "
                           "Dosya sürümü farklı; güncelleme yapılmadı.")
    return src.replace(before, after, 1)


def make_updated(src: str) -> str:
    if "def _adaptive_reference_operations(" in src:
        raise RuntimeError("Bu güncelleme zaten uygulanmış. İkinci kez uygulamayın.")

    # Insert helpers immediately before the active final definition.
    position = src.rfind("\ndef balance_operations(")
    if position < 0:
        raise RuntimeError("Aktif balance_operations bulunamadı.")
    src = src[:position] + "\n" + REFERENCE_HELPERS + "\n" + src[position:]

    # A naturally feasible 35-operator layout MUST NOT short-circuit a
    # 27-operator search. Previously it returned before any optimization.
    early_return = '''    if normalized_mode == "preserve_method" and natural_feasible:
        result_operations, station_records, _ = _build_main_zone_from_assignment(
            ordered, candidates, natural_assignments, cycle_time,
            max_station_load, max_saturation_percent,
        )
        return result_operations, station_records, [
            "MAIN_PRESERVED_NATURAL_LAYOUT: "
            f"assigned_physical_stations={len(natural_used_indices)}, "
            "process_order_preserved=true, capacity_checked=true."
        ]
'''
    src = replace_exact(
        src, early_return,
        '''    # A feasible old layout is only a REFERENCE, not an optimization result.
    # Always search for fewer operators under the changed target cycle time.
''',
        "Doğal yerleşimin erken dönüşü",
    )

    # An absent optimizer must never look like an infeasible staffing plan.
    solver_start = src.index("def _solve_direct_physical_main_for_count(")
    solver_end = src.index("def _natural_main_candidate_assignments(", solver_start)
    solver_section = src[solver_start:solver_end]
    solver_section = replace_exact(
        solver_section,
        '''    pallet_anchor_radius=1,
    max_time_seconds=35.0
):
    try:
        from ortools.sat.python import (
            cp_model,
        )
    except Exception:
        return None
''',
        '''    pallet_anchor_radius=1,
    max_time_seconds=35.0,
    status_sink=None,
):
    try:
        from ortools.sat.python import cp_model
    except ImportError as exc:
        raise RuntimeError(
            "Hat dengeleme için OR-Tools kurulu değil. "
            "Python ortamında pip install ortools komutunu çalıştırın."
        ) from exc
''',
        "OR-Tools bağımlılık kontrolü",
    )
    solver_section = replace_exact(
        solver_section,
        '''    status = solver.Solve(
        model
    )

    if status not in (
''',
        '''    status = solver.Solve(model)
    if status_sink is not None:
        status_sink.append({
            "Count": int(station_count),
            "Status": solver.StatusName(status),
            "MoveRadius": max_move_candidates,
            "PalletRadius": pallet_anchor_radius,
        })

    if status not in (
''',
        "Çözücü belirsizlik kaydı",
    )
    src = src[:solver_start] + solver_section + src[solver_end:]

    stage_part_start = src.index('    # =========================================================\n    # METODU KORU',
                                 src.index('def _build_direct_physical_main_zone('))
    stage_part_end = src.index('    if solution is None:\n', stage_part_start)
    new_stages = '''    # Operator count is the PRIMARY optimization objective for BOTH modes.
    # Metodu Koru: reference task order + local moves, expanding only as needed.
    # Minimum Personel: reference placement is a soft preference; hard tooling,
    # precedence and forced-station constraints remain mandatory.
    start_count = lower_bound
    solve_stages = (
        [
            ("PRESERVE_LOCAL_2", 2, 1),
            ("PRESERVE_LOCAL_4", 4, 2),
            ("PRESERVE_PROCESS_ORDER", None, 3),
        ]
        if normalized_mode == "preserve_method"
        else [
            ("MIN_PERSONNEL_PALLET_LOCAL", None, 3),
            ("MIN_PERSONNEL_PALLET_EXTENDED", None, 7),
        ]
    )
    solution = None
    selected_stage_name = None
    attempt_status = []

    # IMPORTANT: iterate operator count OUTSIDE the locality stages.
    # The old order returned 35 operators in strict mode before testing
    # whether 27 operators were possible with a slightly wider neighborhood.
    for station_count in range(start_count, len(candidates) + 1):
        for stage_name, move_radius, pallet_radius in solve_stages:
            stage_solution = _solve_direct_physical_main_for_count(
                ordered,
                candidates,
                max_station_load,
                station_count,
                precedence_edges,
                hard_bundle_edges=hard_bundle_edges,
                operation_block_map=operation_block_map,
                process_block_order_edges=process_block_order_edges,
                max_move_candidates=move_radius,
                pallet_anchor_radius=pallet_radius,
                max_time_seconds=(18.0 if station_count == start_count else 12.0),
                status_sink=attempt_status,
            )
            if stage_solution is not None:
                solution = stage_solution
                selected_stage_name = stage_name
                break
        if solution is not None:
            break

'''
    src = src[:stage_part_start] + new_stages + src[stage_part_end:]

    # Remove fixed-workforce preserved layout routing, but DO NOT remove
    # coherent reference data. Rebase operation ordering to that reference.
    preserved_route = '''    if str(balance_mode).strip().lower() == "preserve_method" and any(
        "PreservedReferenceModelNo" in op for op in operations
    ):
        return _preserved_reference_layout(
            operations, cycle_time, station_type_profiles, max_saturation_percent
        )
'''
    preserved_new = '''    is_reference_preserved = (
        str(balance_mode).strip().lower() == "preserve_method"
        and any("PreservedReferenceModelNo" in op for op in operations)
    )
    reference_model = None
    if is_reference_preserved:
        operations, reference_model = _adaptive_reference_operations(
            operations, station_type_profiles
        )
'''
    src = replace_exact(src, preserved_route, preserved_new, "Dondurulmuş referans yerleşim")

    # Restore learned within-station chronology (not merely soft learned pairs).
    active = src.rfind("\ndef balance_operations(")
    old_order = '''    final_operations = (
        _apply_learned_within_station_order(
            final_operations,
            same_station_precedence_edges
        )
    )
'''
    new_order = '''    if is_reference_preserved:
        final_operations = _adaptive_restore_station_order(final_operations)
        warnings.insert(0, (
            "ADAPTIVE_REFERENCE_METHOD: reference=" + str(reference_model)
            + "; preserved=operations+global_order+within_station_order; "
            + "workforce=optimized_for_target_cycle_time"
        ))
    else:
        final_operations = _apply_learned_within_station_order(
            final_operations, same_station_precedence_edges
        )
'''
    before, after = src[:active], src[active:]
    after = replace_exact(after, old_order, new_order, "İstasyon içi referans sırası")
    src = before + after

    # Add a post-balance safety gate for all modes.
    active = src.rfind("\ndef balance_operations(")
    before, after = src[:active], src[active:]
    returned = '''    return (
        final_operations,
        station_records,
        "+".join(
            balancer_names
        ),
        warnings,
    )
'''
    replacement = '''    _adaptive_validate(
        final_operations, station_records, cycle_time, max_station_load
    )

''' + returned
    after = replace_exact(after, returned, replacement, "Tahmin sonrası güvenlik kontrolü")
    src = before + after

    ast.parse(src)
    return src


def find_balancer() -> pathlib.Path:
    root = pathlib.Path(__file__).resolve().parent
    candidates = [
        root / "line_balancer.py",
        root / "CK2_AI_Metod.AI" / "line_balancer.py",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(
        "line_balancer.py bulunamadı. Bu güncelleme dosyasını proje ana "
        "klasörüne veya CK2_AI_Metod.AI içine koyun."
    )


def main() -> None:
    path = find_balancer()
    original = path.read_text(encoding="utf-8-sig")
    updated = make_updated(original)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(f"line_balancer.pre_adaptive_{stamp}.bak")
    shutil.copy2(path, backup)
    path.write_text(updated, encoding="utf-8")
    try:
        py_compile.compile(str(path), doraise=True)
    except Exception:
        shutil.copy2(backup, path)
        raise
    print("SUCCESS: CT'ye duyarlı Metodu Koru ve Minimum Personel uygulandı.")
    print("Güncellenen:", path)
    print("Yedek:", backup)
    print("SONRAKI ADIM: Yapay zeka modelini yeniden eğitmeden tahmin alabilirsiniz.")
    print("NOT: Bu ortamda CP-SAT yüklü olmalı (pip install ortools).")


if __name__ == "__main__":
    main()
