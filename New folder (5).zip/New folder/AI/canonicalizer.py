﻿# -*- coding: utf-8 -*-
import re
from collections import defaultdict
from difflib import SequenceMatcher

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from common import normalize_text
from orientation_sync import turn_kind


AUTO_THRESHOLD = 0.94
REVIEW_THRESHOLD = 0.82

DIRECTION_GROUPS = [
    {"SAG", "SOL"},
    {"UST", "ALT"},
    {"ON", "ARKA"},
]


class UnionFind:
    def __init__(self, items):
        self.parent = {
            item: item
            for item in items
        }

    def find(self, item):
        if self.parent[item] != item:
            self.parent[item] = self.find(
                self.parent[item]
            )

        return self.parent[item]

    def union(self, a, b):
        root_a = self.find(a)
        root_b = self.find(b)

        if root_a != root_b:
            self.parent[root_b] = root_a


def _numbers(text):
    return tuple(
        re.findall(
            r"\b\d+(?:[.,]\d+)?\b",
            normalize_text(text)
        )
    )


def _directions(text):
    tokens = set(
        normalize_text(text).split()
    )

    result = []

    for group in DIRECTION_GROUPS:
        result.append(
            tuple(
                sorted(
                    tokens.intersection(group)
                )
            )
        )

    return tuple(result)


def _clean_station_type(value):
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    return str(value).strip()


def _conflict_reason(row_a, row_b):
    text_a = str(
        row_a["ExampleOperationText"]
    )

    text_b = str(
        row_b["ExampleOperationText"]
    )

    rotation_a = turn_kind(text_a)
    rotation_b = turn_kind(text_b)
    if rotation_a != rotation_b and (rotation_a[0] or rotation_b[0]):
        return "ROTATION_TYPE_OR_ANGLE"

    if _numbers(text_a) != _numbers(text_b):
        return "NUMBER"

    if _directions(text_a) != _directions(text_b):
        return "DIRECTION"

    type_a = _clean_station_type(
        row_a.get(
            "DominantStationType",
            ""
        )
    )

    type_b = _clean_station_type(
        row_b.get(
            "DominantStationType",
            ""
        )
    )

    if (
        type_a
        and type_b
        and type_a != type_b
    ):
        return (
            "STATION_TYPE:" +
            type_a +
            "!=" +
            type_b
        )

    return ""


def _lexical(a, b):
    return SequenceMatcher(
        None,
        normalize_text(a),
        normalize_text(b)
    ).ratio()


def _similarity_matrix(texts):
    try:
        from sentence_transformers import SentenceTransformer

        model_name = (
            "sentence-transformers/"
            "paraphrase-multilingual-mpnet-base-v2"
        )

        model = SentenceTransformer(
            model_name
        )

        vectors = model.encode(
            texts,
            normalize_embeddings=True,
            show_progress_bar=False,
            batch_size=32,
        )

        return (
            cosine_similarity(vectors),
            model_name,
        )

    except Exception:
        vectorizer = TfidfVectorizer(
            analyzer="char_wb",
            ngram_range=(3, 5),
            min_df=1,
        )

        vectors = vectorizer.fit_transform(
            [
                normalize_text(x)
                for x in texts
            ]
        )

        return (
            cosine_similarity(vectors),
            "TFIDF_CHAR_FALLBACK",
        )


def build_canonical_operations(library: pd.DataFrame):
    library = library.copy()

    library["OperationId"] = (
        library["OperationId"]
        .astype(str)
    )

    library["ExampleOperationText"] = (
        library["ExampleOperationText"]
        .fillna("")
        .astype(str)
    )

    texts = (
        library["ExampleOperationText"]
        .tolist()
    )

    similarity_matrix, embedding_engine = (
        _similarity_matrix(texts)
    )

    candidates = []

    raw_ids = (
        library["OperationId"]
        .tolist()
    )

    union_find = UnionFind(
        raw_ids
    )

    for first_index in range(
        len(library)
    ):
        for second_index in range(
            first_index + 1,
            len(library)
        ):
            semantic_similarity = float(
                similarity_matrix[
                    first_index,
                    second_index
                ]
            )

            if semantic_similarity < REVIEW_THRESHOLD:
                continue

            row_a = library.iloc[
                first_index
            ]

            row_b = library.iloc[
                second_index
            ]

            text_a = row_a[
                "ExampleOperationText"
            ]

            text_b = row_b[
                "ExampleOperationText"
            ]

            lexical_similarity = _lexical(
                text_a,
                text_b
            )

            conflict = _conflict_reason(
                row_a,
                row_b
            )

            auto_merge = (
                semantic_similarity >= AUTO_THRESHOLD
                and lexical_similarity >= 0.84
                and not conflict
            )

            if auto_merge:
                union_find.union(
                    str(
                        row_a["OperationId"]
                    ),
                    str(
                        row_b["OperationId"]
                    ),
                )

            candidates.append({
                "RawOperationId_A":
                    row_a["OperationId"],
                "OperationText_A":
                    text_a,
                "StationType_A":
                    row_a.get(
                        "DominantStationType",
                        ""
                    ),
                "RawOperationId_B":
                    row_b["OperationId"],
                "OperationText_B":
                    text_b,
                "StationType_B":
                    row_b.get(
                        "DominantStationType",
                        ""
                    ),
                "SemanticSimilarity":
                    semantic_similarity,
                "LexicalSimilarity":
                    lexical_similarity,
                "Conflict":
                    conflict,
                "AutoMerge":
                    1 if auto_merge else 0,
                "ReviewRequired":
                    0 if auto_merge else 1,
            })

    clusters = defaultdict(list)

    for raw_id in raw_ids:
        clusters[
            union_find.find(raw_id)
        ].append(raw_id)

    library_by_id = (
        library.set_index(
            "OperationId",
            drop=False
        )
    )

    cluster_records = []

    for members in clusters.values():
        rows = library_by_id.loc[
            members
        ]

        position = pd.to_numeric(
            rows[
                "AverageProcessRelativePosition"
            ],
            errors="coerce"
        ).mean()

        if pd.isna(position):
            position = 999.0

        representative = (
            rows.assign(
                _models=pd.to_numeric(
                    rows["ModelCount"],
                    errors="coerce"
                ).fillna(0),
                _occ=pd.to_numeric(
                    rows["OccurrenceCount"],
                    errors="coerce"
                ).fillna(0),
            )
            .sort_values(
                [
                    "_models",
                    "_occ",
                    "ExampleOperationText",
                ],
                ascending=[
                    False,
                    False,
                    True,
                ]
            )
            .iloc[0]
        )

        cluster_records.append({
            "members":
                sorted(members),
            "position":
                float(position),
            "name":
                str(
                    representative[
                        "ExampleOperationText"
                    ]
                ),
        })

    cluster_records.sort(
        key=lambda item: (
            item["position"],
            normalize_text(
                item["name"]
            ),
        )
    )

    mapping = {}
    canonical_rows = []

    for index, cluster in enumerate(
        cluster_records,
        start=1
    ):
        canonical_id = (
            f"COP_{index:04d}"
        )

        for raw_id in cluster[
            "members"
        ]:
            mapping[
                str(raw_id)
            ] = canonical_id

        canonical_rows.append({
            "CanonicalOperationId":
                canonical_id,
            "CanonicalName":
                cluster["name"],
            "RawOperationIds":
                "|".join(
                    cluster["members"]
                ),
            "RawOperationTypeCount":
                len(
                    cluster["members"]
                ),
            "AverageProcessRelativePosition":
                cluster["position"],
        })

    candidates_df = pd.DataFrame(
        candidates
    )

    if len(candidates_df):
        candidates_df = (
            candidates_df.sort_values(
                [
                    "AutoMerge",
                    "SemanticSimilarity",
                ],
                ascending=[
                    False,
                    False,
                ]
            )
        )

    return (
        mapping,
        pd.DataFrame(
            canonical_rows
        ),
        candidates_df,
        embedding_engine,
    )
