# -*- coding: utf-8 -*-
"""Prepare one tempo-conditional ML dataset from real T#### method workbooks.

Every ModelNo + tempo is a distinct training observation. Operations from
separate methods are NEVER concatenated as if they belong to one method.
The target cycle time is a *continuous numeric ML input* at train and predict.
"""
from pathlib import Path
import math
import os
import re

import pandas as pd

from common import normalize_model_no, normalize_text

REFERENCE_SHIFT_SECONDS = 31950.0
REQUIRED_SHEETS = (
    "Model_Config_Features", "Operation_Library_V1",
    "Operation_Sequence", "Method_Stations",
)
OPTIONAL_SHEETS = (
    "Method_Operations", "Model_Operation_Training",
)


def source_id(model_no, tempo):
    model_no = normalize_model_no(model_no)
    if not re.fullmatch(r"\d+", model_no):
        raise ValueError(f"Geçersiz model kodu: {model_no!r}")
    if model_no == "33704184":
        raise ValueError("33704184 kör test modelini eğitime alma.")
    return f"{model_no}__T{int(tempo)}"


def _validate_library_parts(libraries):
    """An OperationId may have only one normalized operation meaning."""
    unique = {}
    for tempo, df in libraries:
        for _, row in df.iterrows():
            raw_id = str(row.get("OperationId", "")).strip()
            operation_text = normalize_text(row.get("NormalizedOperationText"))
            if not raw_id or raw_id.lower() in ("nan", "none"):
                raise ValueError(f"T{tempo} operasyon kimliği eksik.")
            previous = unique.get(raw_id)
            if previous and previous != operation_text:
                raise ValueError(
                    f"T{tempo}: {raw_id} farklı operasyonlar için kullanılmış. "
                    "Kimlikler karışmadan önce OperationId üretimini düzeltin."
                )
            unique[raw_id] = operation_text


def build_joint_dataset(tempo_datasets, output_path):
    """Write a validated combined workbook, returning metadata (not ML results).

    Library entries are deduplicated by stable OperationId. Every other sheet
    uses a synthetic distinct ModelNo for each observed tempo, to prevent
    accidental occurrence multiplication or precedence mixing.
    """
    if not tempo_datasets:
        raise ValueError("Eğitim için T#### verisi bulunamadı.")

    frames = {name: [] for name in REQUIRED_SHEETS + OPTIONAL_SHEETS}
    libraries = []
    observed_tempos = set()
    approved_instances = []
    observation_models = set()
    all_samples = set()

    for tempo, raw_path in sorted(tempo_datasets):
        tempo = int(tempo)
        if tempo <= 0 or tempo in observed_tempos:
            raise ValueError(f"Tekrarlanan veya geçersiz tempo: T{tempo}")
        observed_tempos.add(tempo)
        path = Path(raw_path)
        if not path.is_file():
            raise FileNotFoundError(str(path))
        sheets = pd.read_excel(path, sheet_name=None, engine="openpyxl")
        missing = [name for name in REQUIRED_SHEETS if name not in sheets]
        if missing:
            raise ValueError(f"{path.name} eksik sayfalar: {', '.join(missing)}")

        config = sheets["Model_Config_Features"].copy()
        config["ModelNo"] = config["ModelNo"].map(normalize_model_no)
        if config["ModelNo"].duplicated().any():
            raise ValueError(f"{path.name}: Aynı model konfigürasyonu mükerrer.")
        config["ConfigReferenceTempo"] = tempo
        config["ConfigReferenceCycleTimeSeconds"] = REFERENCE_SHIFT_SECONDS / tempo
        approved = config.loc[
            pd.to_numeric(config["HasApprovedMethodData"], errors="coerce").fillna(0).eq(1),
            "ModelNo",
        ].tolist()
        if not approved:
            raise ValueError(f"{path.name}: Eğitime uygun gerçek metot yok.")
        for model_no in approved:
            if model_no == "33704184":
                raise ValueError("33704184 test modeli eğitim verisine karışmış.")
            key = source_id(model_no, tempo)
            if key in all_samples:
                raise ValueError(f"Tekrarlanan model+tempo: {key}")
            all_samples.add(key)
            observation_models.add(model_no)
            approved_instances.append(key)

        mapper = {m: source_id(m, tempo) for m in approved}
        config["ModelNo"] = config["ModelNo"].map(lambda m: mapper.get(m, m))
        # Remove configurations without approved real method from the joint
        # dataset, since those rows have no meaningful observed tempo.
        config = config.loc[config["ModelNo"].isin(all_samples)].copy()
        frames["Model_Config_Features"].append(config)

        for name in ("Operation_Sequence", "Method_Stations") + OPTIONAL_SHEETS:
            if name not in sheets:
                continue
            part = sheets[name].copy()
            if "ModelNo" not in part.columns:
                raise ValueError(f"{path.name}/{name}: ModelNo sütunu eksik.")
            part["ModelNo"] = part["ModelNo"].map(normalize_model_no)
            unapproved = set(part["ModelNo"]) - set(mapper)
            if unapproved:
                raise ValueError(
                    f"{path.name}/{name}: Onaylı metodu olmayan model: "
                    + ", ".join(sorted(unapproved)[:5])
                )
            part["ModelNo"] = part["ModelNo"].map(mapper)
            if name == "Model_Operation_Training":
                part["ConfigReferenceTempo"] = tempo
                part["ConfigReferenceCycleTimeSeconds"] = REFERENCE_SHIFT_SECONDS / tempo
            frames[name].append(part)
        libraries.append((tempo, sheets["Operation_Library_V1"].copy()))

    _validate_library_parts(libraries)
    all_library = pd.concat((f for _, f in libraries), ignore_index=True)
    all_library["OperationId"] = all_library["OperationId"].astype(str)
    # Preserve the richest representation, not the first tempo's duplicate.
    all_library = (all_library.sort_values(
        "OccurrenceCount", ascending=False, na_position="last"
    ).drop_duplicates("OperationId", keep="first"))
    frames["Operation_Library_V1"].append(all_library)

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = output_path.with_name(output_path.stem + ".temporary.xlsx")
    try:
        with pd.ExcelWriter(temp_path, engine="openpyxl") as writer:
            for name, parts in frames.items():
                if parts:
                    pd.concat(parts, ignore_index=True).to_excel(
                        writer, sheet_name=name, index=False
                    )
            pd.DataFrame({
                "Tempo": sorted(observed_tempos),
                "CycleTimeSeconds": [REFERENCE_SHIFT_SECONDS / t for t in sorted(observed_tempos)],
            }).to_excel(writer, sheet_name="Joint_Tempo_Info", index=False)
        os.replace(temp_path, output_path)
    finally:
        if temp_path.exists():
            temp_path.unlink()

    return {
        "dataset": str(output_path),
        "tempos": sorted(observed_tempos),
        "observations": len(approved_instances),
        "distinct_models": len(observation_models),
    }
