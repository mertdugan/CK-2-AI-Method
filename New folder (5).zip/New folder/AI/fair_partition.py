
"""Exact fixed-order partition: maximise weakest load, then minimise variance.

A single lexicographic DP state is insufficient for the secondary objective:
a later low-load segment can equalise different earlier bottlenecks. Separate
the max-min pass from the additive variance pass to retain the true optimum.
"""
import math


def partition(durations, count, capacity, valid=None, forbidden_cuts=(), penalty=None):
    values = [float(v) for v in durations]
    n = len(values)
    if (count <= 0 or count > n or not math.isfinite(capacity) or capacity <= 0
            or any(not math.isfinite(v) or v < 0 or v > capacity + 1e-8 for v in values)):
        return None
    prefix = [0.0]
    for value in values:
        prefix.append(prefix[-1] + value)
    forbidden = set(forbidden_cuts)  # number of operations before each cut
    legal = {}
    for group in range(count):
        for end in range(group + 1, n - count + group + 2):
            for start in range(end - 1, group - 1, -1):
                load = prefix[end] - prefix[start]
                if load > capacity + 1e-8:
                    break
                if start in forbidden or (valid is not None and not valid(group, start, end)):
                    continue
                legal[group, start, end] = load
    weakest = [[-1.0] * (n + 1) for _ in range(count + 1)]
    weakest[0][0] = float('inf')
    for group in range(1, count + 1):
        for end in range(group, n - count + group + 1):
            for start in range(group - 1, end):
                load = legal.get((group - 1, start, end))
                if load is None or weakest[group - 1][start] < 0:
                    continue
                weakest[group][end] = max(weakest[group][end], min(weakest[group - 1][start], load))
    floor = weakest[count][n]
    if floor < 0:
        return None
    ideal = prefix[-1] / count
    cost = [[None] * (n + 1) for _ in range(count + 1)]
    parent = [[None] * (n + 1) for _ in range(count + 1)]
    cost[0][0] = (0.0, 0.0)
    for group in range(1, count + 1):
        for end in range(group, n - count + group + 1):
            for start in range(group - 1, end):
                load = legal.get((group - 1, start, end))
                previous = cost[group - 1][start]
                if load is None or load < floor - 1e-8 or previous is None:
                    continue
                extra = 0.0 if penalty is None else float(penalty(group - 1, start, end))
                candidate = (previous[0] + (load - ideal) ** 2, previous[1] + extra)
                incumbent = cost[group][end]
                if (incumbent is None or candidate[0] < incumbent[0] - 1e-8
                        or (abs(candidate[0] - incumbent[0]) <= 1e-8
                            and candidate[1] < incumbent[1] - 1e-8)):
                    cost[group][end], parent[group][end] = candidate, start
    if cost[count][n] is None:
        return None
    segments = []
    end = n
    for group in range(count, 0, -1):
        start = parent[group][end]
        segments.append((start, end, prefix[end] - prefix[start]))
        end = start
    segments.reverse()
    return {'segments': segments, 'minimum_load': floor,
            'squared_deviation': cost[count][n][0], 'preference_penalty': cost[count][n][1]}
