﻿# -*- coding: utf-8 -*-
import json
import math
import re
from pathlib import Path
from typing import Dict, Any

import numpy as np
import pandas as pd


CONFIG_FIELDS = [
    "CataPyro",
    "ModelType",
    "TimerType",
    "CehennemlikType",
    "TraversSnap",
    "AstarCam",
    "Testaporta",
    "TcoBraket",
    "Limitor",
    "Tepsi",
    "Izgara",
    "Airfry",
    "Ray",
    "FanCarton",
    "KapiEtiketi",
    "Not",
]

NUMERIC_CONFIG_FIELDS = {
    "AstarCam",
    "Limitor",
    "Tepsi",
    "Izgara",
}


def normalize_model_no(value) -> str:
    if value is None:
        return ""

    text = str(value).strip()

    if text.endswith(".0"):
        text = text[:-2]

    return text


def normalize_text(value) -> str:
    if value is None:
        return ""

    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    text = str(value).upper().strip()

    table = str.maketrans({
        "İ": "I",
        "ı": "I",
        "Ş": "S",
        "ş": "S",
        "Ğ": "G",
        "ğ": "G",
        "Ü": "U",
        "ü": "U",
        "Ö": "O",
        "ö": "O",
        "Ç": "C",
        "ç": "C",
    })

    text = text.translate(table)
    text = text.replace("°", " DERECE ")
    text = re.sub(r"[^A-Z0-9]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()

    replacements = {
        "CEVIRIN": "CEVIR",
        "CEVIRINIZ": "CEVIR",
        "TAKIN": "TAK",
        "ALIN": "AL",
        "YAPISTIRIN": "YAPISTIR",
        "SABITLEYIN": "SABITLE",
    }

    for source, target in replacements.items():
        text = re.sub(
            rf"\b{source}\b",
            target,
            text
        )

    return re.sub(
        r"\s+",
        " ",
        text
    ).strip()


def note_segments(
    value,
):
    """
    Split MODEL_Config.Not into semantic segments.

    Example:
        "ukrayna, arg oven, morocco"
    ->
        ["UKRAYNA", "ARG OVEN", "MOROCCO"]

    This prevents NOTE n-grams from incorrectly crossing comma-separated
    market/project entries.
    """
    if value is None:
        return []

    try:
        if pd.isna(
            value
        ):
            return []
    except Exception:
        pass

    raw = str(
        value
    )

    parts = re.split(
        r"[,;/|]+",
        raw
    )

    result = []

    seen = set()

    for part in parts:
        normalized = normalize_text(
            part
        )

        if (
            not normalized
            or
            normalized in seen
        ):
            continue

        seen.add(
            normalized
        )

        result.append(
            normalized
        )

    return result


def note_terms(
    value,
    max_ngram=3,
):
    """
    Generate NOTE features inside each semantic segment only.

    Example:
        "ukrayna, arg oven, morocco"

    becomes:
        UKRAYNA
        ARG
        OVEN
        ARG OVEN
        MOROCCO

    It does NOT create cross-segment terms such as "UKRAYNA ARG".
    """
    result = []

    seen = set()

    max_ngram = max(
        1,
        min(
            int(
                max_ngram
            ),
            3
        )
    )

    for segment in note_segments(
        value
    ):
        tokens = [
            token
            for token in segment.split()
            if len(
                token
            ) >= 2
        ]

        for size in range(
            1,
            max_ngram + 1
        ):
            if len(
                tokens
            ) < size:
                break

            for start in range(
                0,
                len(
                    tokens
                ) - size + 1
            ):
                term = " ".join(
                    tokens[
                        start:
                        start + size
                    ]
                )

                if term in seen:
                    continue

                seen.add(
                    term
                )

                result.append(
                    term
                )

    return result


SIMILARITY_FIELD_WEIGHTS = {
    "CataPyro": 4.0,
    "ModelType": 4.0,
    "TimerType": 3.0,
    "CehennemlikType": 3.0,
    "TraversSnap": 3.0,
    "AstarCam": 2.5,
    "Testaporta": 2.5,
    "TcoBraket": 2.0,
    "Limitor": 2.5,
    "Tepsi": 2.0,
    "Izgara": 2.0,
    "Airfry": 2.0,
    "Ray": 2.5,
    "FanCarton": 1.5,
    "KapiEtiketi": 1.5,
    "Not": 0.5,
}


def config_similarity_score(
    first: Dict[str, Any],
    second: Dict[str, Any],
) -> float:
    """
    0..1 structural product-config similarity.

    The score intentionally gives NOTE only a small weight; market labels
    should not overpower the mechanical/electrical configuration when
    choosing the nearest historical method.
    """
    earned = 0.0
    total = 0.0

    numeric_scales = {
        "AstarCam": 2.0,
        "Limitor": 2.0,
        "Tepsi": 3.0,
        "Izgara": 3.0,
    }

    for field, weight in (
        SIMILARITY_FIELD_WEIGHTS.items()
    ):
        first_value = first.get(
            field
        )

        second_value = second.get(
            field
        )

        if field == "Not":
            first_segments = set(
                note_segments(
                    first_value
                )
            )

            second_segments = set(
                note_segments(
                    second_value
                )
            )

            if (
                not first_segments
                and
                not second_segments
            ):
                continue

            total += weight

            union = (
                first_segments
                |
                second_segments
            )

            if union:
                earned += (
                    weight
                    *
                    len(
                        first_segments
                        &
                        second_segments
                    )
                    /
                    len(
                        union
                    )
                )

            continue

        if field in NUMERIC_CONFIG_FIELDS:
            try:
                first_missing = (
                    first_value is None
                    or
                    pd.isna(
                        first_value
                    )
                )
            except Exception:
                first_missing = (
                    first_value is None
                )

            try:
                second_missing = (
                    second_value is None
                    or
                    pd.isna(
                        second_value
                    )
                )
            except Exception:
                second_missing = (
                    second_value is None
                )

            if (
                first_missing
                and
                second_missing
            ):
                continue

            total += weight

            if (
                first_missing
                or
                second_missing
            ):
                continue

            try:
                difference = abs(
                    float(
                        first_value
                    )
                    -
                    float(
                        second_value
                    )
                )

                scale = float(
                    numeric_scales.get(
                        field,
                        2.0
                    )
                )

                similarity = max(
                    0.0,
                    1.0 -
                    difference /
                    scale
                )

                earned += (
                    weight
                    *
                    similarity
                )

            except Exception:
                pass

            continue

        first_text = normalize_text(
            first_value
        )

        second_text = normalize_text(
            second_value
        )

        if (
            not first_text
            and
            not second_text
        ):
            continue

        total += weight

        if (
            first_text
            and
            first_text ==
            second_text
        ):
            earned += weight

    if total <= 0.0:
        return 0.0

    return min(
        1.0,
        max(
            0.0,
            earned /
            total
        )
    )



def config_to_feature_dict(
    config: Dict[str, Any]
) -> Dict[str, float]:
    features: Dict[str, float] = {}

    for field in CONFIG_FIELDS:
        value = config.get(field)

        if field in NUMERIC_CONFIG_FIELDS:
            try:
                if (
                    value is not None
                    and not pd.isna(value)
                ):
                    features[f"NUM::{field}"] = float(value)
            except Exception:
                pass
            continue

        text = normalize_text(value)

        if field == "Not":
            if text:
                terms = note_terms(
                    value,
                    max_ngram=3
                )

                for term in terms:
                    token_count = len(
                        term.split()
                    )

                    if token_count == 1:
                        prefix = "NOTE"
                    elif token_count == 2:
                        prefix = "NOTE_BIGRAM"
                    else:
                        prefix = "NOTE_TRIGRAM"

                    features[
                        f"{prefix}::{term}"
                    ] = 1.0

                features[
                    f"NOTE_FULL::{text}"
                ] = 1.0

            continue

        if text:
            features[f"CAT::{field}::{text}"] = 1.0

    # A continuous operating-point feature shared by every tempo. Training
    # observations use their REAL T#### cycle; predictions use user target CT.
    # Do not use the config's default Tempo for prediction.
    cycle = safe_float(config.get("ConfigReferenceCycleTimeSeconds"), None)
    if cycle is not None and math.isfinite(cycle) and cycle > 0:
        features["CT_SECONDS"] = float(cycle)
        features["CT_RELATIVE_TO_30S"] = float(cycle) / 30.0
        features["CT_CAPACITY_PER_WORKER"] = 30.0 / float(cycle)

    return features


def pair_feature_dict(
    config: Dict[str, Any],
    operation_id: str,
    occurrence_index: int = None,
) -> Dict[str, float]:
    result = config_to_feature_dict(config)
    result[f"OP::{operation_id}"] = 1.0

    if occurrence_index is not None:
        result["OCCURRENCE_INDEX"] = float(occurrence_index)

    return result


def safe_float(value, default=np.nan):
    try:
        if value is None or pd.isna(value):
            return default
        return float(value)
    except Exception:
        return default


def read_training_dataset(dataset_path: Path):
    sheets = pd.read_excel(
        dataset_path,
        sheet_name=None,
        engine="openpyxl"
    )

    required = [
        "Model_Config_Features",
        "Operation_Library_V1",
        "Operation_Sequence",
        "Method_Stations",
    ]

    missing = [
        name
        for name in required
        if name not in sheets
    ]

    if missing:
        raise ValueError(
            "Training dataset içinde eksik sayfa: " +
            ", ".join(missing)
        )

    config = sheets["Model_Config_Features"].copy()
    library = sheets["Operation_Library_V1"].copy()
    sequence = sheets["Operation_Sequence"].copy()
    stations = sheets["Method_Stations"].copy()

    config["ModelNo"] = config["ModelNo"].apply(normalize_model_no)
    sequence["ModelNo"] = sequence["ModelNo"].apply(normalize_model_no)
    stations["ModelNo"] = stations["ModelNo"].apply(normalize_model_no)

    return config, library, sequence, stations


def read_model_config(config_path: Path, model_no: str) -> Dict[str, Any]:
    df = pd.read_excel(
        config_path,
        sheet_name="HALİNO",
        header=1,
        engine="openpyxl"
    )

    if df.shape[1] < 19:
        raise ValueError(
            "MODEL_Config.xlsx beklenen A:S kolon yapısına sahip değil."
        )

    wanted = normalize_model_no(model_no)

    for _, row in df.iterrows():
        current = normalize_model_no(row.iloc[0])

        if current != wanted:
            continue

        return {
            "ModelNo": current,
            "CataPyro": row.iloc[1],
            "ModelType": row.iloc[2],
            "TimerType": row.iloc[3],
            "CehennemlikType": row.iloc[4],
            "TraversSnap": row.iloc[5],
            "AstarCam": row.iloc[6],
            "Testaporta": row.iloc[7],
            "TcoBraket": row.iloc[8],
            "Limitor": row.iloc[9],
            "Tepsi": row.iloc[10],
            "Izgara": row.iloc[11],
            "Airfry": row.iloc[12],
            "Ray": row.iloc[13],
            "FanCarton": row.iloc[14],
            "KapiEtiketi": row.iloc[15],
            "CalisanSayisi": row.iloc[16],
            "Not": row.iloc[17],
            "Tempo": row.iloc[18],
        }

    raise ValueError(
        f"{wanted} modeli MODEL_Config.xlsx içinde bulunamadı."
    )


def save_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8") as handle:
        json.dump(
            value,
            handle,
            ensure_ascii=False,
            indent=2
        )


def load_json(path: Path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)
