﻿
# -*- coding: utf-8 -*-
"""CK-2 AI Metod command-line entry point and prediction quality gate."""

import argparse
import csv
import json
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

from common import config_similarity_score, note_terms, read_model_config
from predictor import predict_method, _production_bundle
from trainer import train_models
from tempo_learning import build_joint_dataset


def _as_float(value, default=None):
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def _history_for_release(models_root, version):
    """Read only the approved model history embedded in the selected release."""
    model_dir = Path(models_root) / str(version)
    profiles_file = model_dir / "training_config_profiles.json"
    history_file = model_dir / "nearest_instance_history.csv"

    if not profiles_file.is_file() or not history_file.is_file():
        return None, None

    with profiles_file.open("r", encoding="utf-8-sig") as stream:
        profiles = {
            str(row["ModelNo"]): row
            for row in json.load(stream)
            if row.get("ModelNo")
        }

    history = defaultdict(dict)
    with history_file.open("r", encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            model_no = str(row.get("ModelNo", "")).strip()
            key = (
                str(row.get("CanonicalOperationId", "")),
                int(row.get("OccurrenceIndex", 1)),
            )
            if model_no in profiles and key[0]:
                history[key][model_no] = row

    return profiles, history


def _operation_rows(worksheet):
    columns = {
        cell.value: cell.column
        for cell in worksheet[1]
        if cell.value is not None
    }

    mandatory = {
        "AssignedStationLabel",
        "CanonicalOperationId",
        "OccurrenceIndex",
        "StationOperationSequence",
        "PredictedTimeSeconds",
    }

    if not mandatory.issubset(columns):
        return []

    rows = []

    for cells in worksheet.iter_rows(min_row=2):
        operation_id = cells[
            columns["CanonicalOperationId"] - 1
        ].value

        if not operation_id:
            continue

        occurrence = cells[
            columns["OccurrenceIndex"] - 1
        ].value

        try:
            occurrence = int(occurrence)
        except (TypeError, ValueError):
            continue

        def value(column):
            index = columns.get(column)
            return cells[index - 1].value if index is not None else None

        rows.append({
            "Key": (str(operation_id), occurrence),
            "Name": str(value("CanonicalName") or operation_id),
            "Station": str(value("AssignedStationLabel") or ""),
            "Physical": value("PhysicalStationNumber"),
            "Order": int(value("StationOperationSequence") or 0),
            "Duration": _as_float(value("PredictedTimeSeconds")),
            "TimeSource": str(value("TimeSource") or ""),
        })

    return rows


def _same_historical_station(first, second):
    station_a = str(first.get("StationSequence") or "")
    station_b = str(second.get("StationSequence") or "")
    return bool(station_a and station_a == station_b)


def _review_issues(config, rows, profiles, history):
    """
    Find reliable contradictory evidence without inventing a correction.

    An exceptional single historical example may require inspection,
    but it must never silently override repeated global precedent.
    """
    issues = []
    current_model = str(config.get("ModelNo", ""))
    current_note_terms = set(note_terms(config.get("Not")))

    similarity = {
        number: config_similarity_score(config, profile)
        for number, profile in profiles.items()
        if number != current_model
    }

    station_rows = defaultdict(list)

    for operation in rows:
        station_rows[operation["Station"]].append(operation)

    for station, operations in station_rows.items():
        operations.sort(key=lambda item: item["Order"])

        # Review adjacent operation pairs only.
        for first, second in zip(operations, operations[1:]):
            first_history = history.get(first["Key"], {})
            second_history = history.get(second["Key"], {})

            votes = Counter()
            dissent = []

            for number in first_history.keys() & second_history.keys():
                a = first_history[number]
                b = second_history[number]

                if not _same_historical_station(a, b):
                    continue

                order_a = _as_float(a.get("StationOperationSequence"))
                order_b = _as_float(b.get("StationOperationSequence"))

                if (
                    order_a is None
                    or order_b is None
                    or order_a == order_b
                ):
                    continue

                direction = (
                    "FORWARD"
                    if order_a < order_b
                    else "REVERSE"
                )
                votes[direction] += 1

                if direction == "REVERSE":
                    profile = profiles[number]
                    shared_notes = current_note_terms.intersection(
                        note_terms(profile.get("Not"))
                    )

                    if (
                        shared_notes
                        and similarity.get(number, 0.0) >= 0.94
                    ):
                        dissent.append((
                            number,
                            similarity[number],
                            shared_notes,
                        ))

            support = sum(votes.values())

            if support < 3:
                continue

            confidence = votes["FORWARD"] / support

            # Strong context counterexamples are reported, not copied.
            if (
                votes["REVERSE"]
                and confidence >= 0.90
                and dissent
            ):
                dissent.sort(
                    key=lambda item: (-item[1], item[0])
                )

                models = ", ".join(
                    item[0] for item in dissent[:5]
                )

                issues.append((
                    "ORDER_CONTEXT_CONFLICT",
                    station,
                    first["Name"] + " -> " + second["Name"],
                    support,
                    round(confidence * 100, 1),
                    models,
                    "Yüksek benzerlikli ve Not alanı örtüşen "
                    "karşıt metod var. Tek örnekle sıra "
                    "otomatik değiştirilmedi.",
                ))

            elif (
                0.20 < confidence < 0.80
                and min(votes.values()) >= 2
            ):
                issues.append((
                    "ORDER_UNCERTAIN",
                    station,
                    first["Name"] + " -> " + second["Name"],
                    support,
                    round(confidence * 100, 1),
                    "",
                    "Geçmiş metotlarda iki sıra da kullanılmış. "
                    "Mühendislik kontrolü gerekli.",
                ))

        # Detect duration models averaging two real standards.
        for operation in operations:
            duration = operation["Duration"]

            if (
                duration is None
                or operation["TimeSource"] != "ML_OPERATION_DURATION"
            ):
                continue

            observations = history.get(operation["Key"], {})
            buckets = Counter()

            for number, sample in observations.items():
                if number == current_model:
                    continue

                seconds = _as_float(sample.get("Duration"))

                if seconds is not None:
                    buckets[round(seconds, 2)] += 1

            strong = sorted(
                (value, count)
                for value, count in buckets.items()
                if count >= 3
            )

            if len(strong) < 2:
                continue

            lower = strong[0][0]
            upper = strong[-1][0]

            if (
                upper - lower >= 0.50
                and lower + 0.15 < duration < upper - 0.15
            ):
                issues.append((
                    "DURATION_MULTI_MODAL",
                    station,
                    operation["Name"],
                    sum(buckets.values()),
                    None,
                    "",
                    f"ML={duration:.3f} sn; geçmişte "
                    f"{lower:.2f} ve {upper:.2f} sn "
                    "standartları var. Tek yakın model "
                    "süresiyle değiştirilmedi.",
                ))

    return issues


def _append_confidence_review(
    output_path,
    config_path,
    model_no,
    models_root,
    model_version,
):
    """Add an auditable quality gate without changing predicted operations."""
    from openpyxl import load_workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    output_path = Path(output_path)

    profiles, history = _history_for_release(
        models_root,
        model_version,
    )

    if profiles is None:
        return {
            "status": "AUDIT_DATA_UNAVAILABLE",
            "issues": 0,
        }

    config = read_model_config(
        Path(config_path),
        str(model_no),
    )

    training_model_warning = str(model_no) in profiles

    wb = load_workbook(output_path)
    predicted = wb["Predicted_Method"]

    rows = _operation_rows(predicted)

    issues = _review_issues(
        config,
        rows,
        profiles,
        history,
    )

    unseen = []

    if "Unseen_Note_Review" in wb:
        sheet = wb["Unseen_Note_Review"]

        for row in sheet.iter_rows(min_row=2, values_only=True):
            if row[0]:
                unseen.append(str(row[0]))

                issues.append((
                    "UNSEEN_NOTE",
                    "MODEL",
                    str(row[0]),
                    0,
                    None,
                    "",
                    "Onaylı eğitim metodunda örnek yok. "
                    "Operasyon/süre/istasyon üretilmedi; "
                    "mühendislik doğrulaması gerekiyor.",
                ))

    if "AI_Confidence_Review" in wb:
        del wb["AI_Confidence_Review"]

    sheet = wb.create_sheet("AI_Confidence_Review")

    sheet.append((
        "ReviewType",
        "Station",
        "OperationOrPair",
        "SampleCount",
        "CurrentOrderSupportPercent",
        "CounterexampleModels",
        "Explanation",
    ))

    for issue in issues:
        sheet.append(issue)

    if not issues:
        sheet.append((
            "OK",
            "",
            "",
            "",
            "",
            "",
            "Belirlenen güvenlik eşiklerinde "
            "ek inceleme bulunmadı.",
        ))

    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions

    widths = {
        "A": 27,
        "B": 19,
        "C": 80,
        "D": 15,
        "E": 29,
        "F": 30,
        "G": 100,
    }

    for letter, width in widths.items():
        sheet.column_dimensions[letter].width = width

    for cell in sheet[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(
            "solid",
            fgColor="1F4E78",
        )

    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(
                vertical="top",
                wrap_text=True,
            )

        row[0].fill = PatternFill(
            "solid",
            fgColor=(
                "FFF2CC"
                if issues
                else "E2F0D9"
            ),
        )

    status = (
        "REVIEW_REQUIRED"
        if issues
        else "READY_FOR_REVIEW"
    )

    summary = wb["Summary"]
    summary.append(("AIQualityGate", status))
    summary.append(("AIQualityGateIssueCount", len(issues)))
    summary.append((
        "UnseenNoteSegmentCount_Validated",
        len(unseen),
    ))
    summary.append((
        "PredictionWasTrainingModel",
        training_model_warning,
    ))

    if "Warnings" in wb:
        warnings = wb["Warnings"]

        warnings.append((
            "AI_QUALITY_GATE: " + status
            + f" | confidence_issues={len(issues)}",
        ))

        for item in issues:
            warnings.append((
                f"{item[0]}: {item[1]} - {item[2]}",
            ))

    wb.save(output_path)

    return {
        "status": status,
        "issues": len(issues),
        "training_model": training_model_warning,
    }



def _tempo_training_datasets(dataset_path):
    """Discover independent tempo datasets exported by MethodDatasetService.

    Each contains ONE genuine method for each model at its own tempo.
    The old shared dataset is only a compatibility copy and is never
    combined with individual tempo datasets (no duplicate training rows).
    """
    dataset_path = Path(dataset_path)
    if re.search(r"_T\d+$", dataset_path.stem, re.IGNORECASE):
        matched = re.search(r"_T(\d+)$", dataset_path.stem, re.IGNORECASE)
        return [(int(matched.group(1)), dataset_path)]

    prefix = dataset_path.stem + "_T"
    matches = []
    for candidate in dataset_path.parent.glob(prefix + "*.xlsx"):
        match = re.fullmatch(
            re.escape(prefix) + r"(\d+)", candidate.stem,
            flags=re.IGNORECASE,
        )
        if match:
            matches.append((int(match.group(1)), candidate))

    return sorted(matches)


def main():
    parser = argparse.ArgumentParser(
        prog="CK2_AI_Metod.AI",
        description="CK-2 AI Metod Python AI Engine",
    )

    sub = parser.add_subparsers(
        dest="command",
        required=True,
    )

    train = sub.add_parser("train")
    train.add_argument("--dataset", required=True)
    train.add_argument("--models-root", required=True)

    predict = sub.add_parser("predict")
    predict.add_argument("--config", required=True)
    predict.add_argument("--model", required=True)
    predict.add_argument(
        "--hours",
        required=True,
        type=float,
    )
    predict.add_argument(
        "--target",
        required=True,
        type=int,
    )
    predict.add_argument(
        "--max-saturation",
        type=float,
        default=95.0,
    )
    # Old clients may still pass --balance-mode. This obsolete argument
    # is intentionally ignored: there is only one balancing procedure.
    predict.add_argument(
        "--balance-mode", default="auto", help=argparse.SUPPRESS
    )
    predict.add_argument("--models-root", required=True)
    predict.add_argument("--output", required=True)

    args = parser.parse_args()

    if args.command == "train":
        all_tempo_datasets = _tempo_training_datasets(Path(args.dataset))
        if all_tempo_datasets:
            # One continuous conditional ML model: all T#### observations
            # become training samples. No per-tempo models, no nearest lookup.
            joint_path = (
                Path(args.dataset).parent /
                (Path(args.dataset).stem + "_TEMPO_JOINT.xlsx")
            )
            info = build_joint_dataset(all_tempo_datasets, joint_path)
            result = train_models(joint_path, Path(args.models_root))
            print("TRAINING_MODE=CONTINUOUS_CYCLE_TIME_ML", flush=True)
            print("TRAINED_TEMPOS=" + ",".join(
                str(v) for v in info["tempos"]), flush=True)
            print("TRAINING_MODEL_TEMPO_OBSERVATIONS=" +
                  str(info["observations"]), flush=True)
        else:
            result = train_models(
                Path(args.dataset), Path(args.models_root),
            )
            print("TRAINING_MODE=LEGACY_SINGLE_TEMPO", flush=True)

        print("SUCCESS")
        print("VERSION=" + result["version"])
        print("PRODUCTION=" + str(result["is_production"]))
        print("MODEL_COUNT=" + str(result["model_count"]))
        print(
            "RAW_OPERATION_COUNT="
            + str(result["raw_operation_count"])
        )
        print(
            "CANONICAL_OPERATION_COUNT="
            + str(result["canonical_operation_count"])
        )
        print("INSTANCE_COUNT=" + str(result["instance_count"]))
        print(
            "PRESENCE_F1="
            + str(result["metrics"].get("presence_f1", ""))
        )
        print(
            "DURATION_MAE="
            + str(result["metrics"].get(
                "duration_mae_seconds", ""
            ))
        )
        print("MODEL_DIR=" + result["model_dir"])
        return

    if args.command == "predict":
        selected_root = Path(args.models_root)
        selected_tempo = None  # No selection: continuous ML sees actual CT.
        result = predict_method(
            config_path=Path(args.config),
            model_no=str(args.model).strip(),
            working_hours=float(args.hours),
            target_quantity=int(args.target),
            max_saturation_percent=float(args.max_saturation),
            balance_mode="auto",
            models_root=selected_root,
            output_path=Path(args.output),
        )

        try:
            quality = _append_confidence_review(
                output_path=args.output,
                config_path=args.config,
                model_no=args.model,
                models_root=selected_root,
                model_version=result["model_version"],
            )
        except Exception as error:
            quality = {
                "status": "AUDIT_FAILED",
                "issues": 0,
            }
            print(
                "AI_AUDIT_ERROR=" + str(error),
                file=sys.stderr,
            )

        # Report the actual bundle capability, not an assumed training mode.
        bundle, _, _ = _production_bundle(selected_root)
        actual_training_mode = bundle.get(
            "tempo_learning_mode", "LEGACY_SINGLE_TEMPO"
        )
        # Preserve the SUCCESS sentinel expected by WinForms.
        print("SUCCESS")
        print("TRAINING_MODE=" + actual_training_mode)
        print("TARGET_CT_ML_FEATURE=" +
              "{:.6f}".format(float(args.hours)*3600.0/int(args.target)))
        print("MODEL=" + result["model_no"])
        print("VERSION=" + result["model_version"])
        print(
            "CYCLE_TIME="
            + f'{result["cycle_time"]:.3f}'
        )
        print(
            "MAX_SATURATION="
            + f'{result["max_saturation_percent"]:.1f}'
        )
        print(
            "MAX_STATION_LOAD="
            + f'{result["max_station_load_seconds"]:.3f}'
        )
        print(
            "BALANCE_MODE="
            + str(result.get("balance_mode", ""))
        )
        print(
            "OPERATION_COUNT="
            + str(result["operation_count"])
        )
        print(
            "STATION_COUNT="
            + str(result["station_count"])
        )
        print("OPERATOR_COUNT=" + str(result.get('operator_count', result['station_count'])))
        print("OPERATOR_SATURATION_STATUS=" + str(result.get(
            'operator_saturation_status', 'NOT_MEASURED')))
        print("BALANCER=" + result["balancer"])
        print("CK2_ENGINE_REVISION=20261013_MULTIFILE_CT_OPTIMIZER")
        print("EFFECTIVE_WORK_SECONDS=" + "{:.3f}".format(
            result["effective_work_content_seconds"]))
        print("ACTUAL_AVG_SATURATION=" + "{:.2f}".format(
            result["achieved_station_saturation_percent"]))
        staffing_limit = result.get('max_staff_for_90_percent')
        print("MAX_STAFF_FOR_90_SATURATION=" + (
            'UNKNOWN' if staffing_limit is None else str(staffing_limit)))
        print("STAFFING_GOAL_90_STATUS=" + (
            'UNKNOWN_ACTIVE_TEST_LABOR' if staffing_limit is None else
            'ACHIEVED' if result['station_count'] <= staffing_limit else
            'NOT_ACHIEVED_ENGINEERING_REVIEW_REQUIRED'))
        print("AI_QUALITY_STATUS=" + quality["status"])
        print("AI_QUALITY_ISSUES=" + str(quality["issues"]))
        print("OUTPUT=" + result["output_path"])
        return


if __name__ == "__main__":
    # The C# launcher decodes both redirected streams as UTF-8. Windows'
    # default code page otherwise corrupts Turkish letters or prints \u escapes.
    for _engine_stream in (sys.stdout, sys.stderr):
        if hasattr(_engine_stream, 'reconfigure'):
            _engine_stream.reconfigure(encoding='utf-8', errors='backslashreplace')
    try:
        main()
    except Exception as exc:
        print("ERROR", file=sys.stderr)
        print(str(exc), file=sys.stderr)
        sys.exit(1)
