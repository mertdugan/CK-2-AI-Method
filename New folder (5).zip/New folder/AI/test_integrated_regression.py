# -*- coding: utf-8 -*-
"""Re-run on the user's real 33704184 V020 prediction workbook.

No model bundle here: validates post-ML adaptive staffing feasibility only.
"""
from pathlib import Path
import re
import sys
from collections import Counter

import openpyxl

from adaptive_reorder import propose_single_reorder
from line_balancer import _ck2_ordered_min_personnel_dp
from orientation_sync import is_pallet_turn

ROOT = Path(__file__).parent.parent
SAMPLE = ROOT / '33704184_AI_Method_20261015_152848.xlsx'
REAL = ROOT / '33704184.xlsx'


def read_operations(path):
    ws = openpyxl.load_workbook(path, read_only=True, data_only=True)['Predicted_Method']
    it=iter(ws.values)
    header=next(it)
    rows = [dict(zip(header, x)) for x in it]
    operations=[]
    for d in rows:
        if d['AssignedStationType']!='Main':
            continue
        operations.append({
            'CanonicalOperationId': d['CanonicalOperationId'],
            'CanonicalName': d['CanonicalName'],
            'OccurrenceIndex': d['OccurrenceIndex'],
            'PredictedTimeSeconds': d['PredictedTimeSeconds'],
            'PredictedProcessSequence': d['PredictedProcessSequence'],
            'PreferredPhysicalStationNumber': d['PreferredPhysicalStationNumber'],
            'PreservedReferenceStationSequence': d['NearestReferenceStationSequence'],
            'EngineeringRule': d['EngineeringRule'],
            'IsPalletOrientationAnchor': d['IsPalletOrientationAnchor'],
            'OrientationTurnKind': d['OrientationTurnKind'],
            'OrientationTurnDegrees': d['OrientationTurnDegrees'],
            'OrientationPhase': d['OrientationPhase'],
        })
    return operations


def physical_numbers(path):
    sheet=openpyxl.load_workbook(path, read_only=True, data_only=True).worksheets[0]
    result=set()
    for row in sheet.values:
        match=re.match(r'^(\d+)\.\s*[İI]STASYON',str(row[0] or ''),re.I)
        if match:
            result.add(int(match.group(1)))
    return sorted(result)


def run():
    ops=read_operations(SAMPLE)
    stations=physical_numbers(REAL)
    actual=_ck2_ordered_min_personnel_dp(ops,stations,30.0,
                                          hard_bundle_edges=[],movement_radius=None,
                                          pallet_radius=None)
    assert actual and len(actual['UsedCandidateIndices'])==23
    improved=propose_single_reorder(ops,stations,30.0,actual,
                                    _ck2_ordered_min_personnel_dp)
    assert improved is not None
    assert len(improved['UsedCandidateIndices']) == 22, improved
    assert improved['Status']=='ENGINEERING_REVIEW_REQUIRED_LEARNED_REORDER'
    idx=improved['ChangedSourcePairIndex']
    assert not is_pallet_turn(ops[idx]['CanonicalName'])
    assert not is_pallet_turn(ops[idx+1]['CanonicalName'])
    original_turns=[(x['CanonicalOperationId'],x['OccurrenceIndex'],x['OrientationTurnDegrees'])
                    for x in ops if is_pallet_turn(x['CanonicalName'])]
    result_turns=[(x['CanonicalOperationId'],x['OccurrenceIndex'],x['OrientationTurnDegrees'])
                  for x in ops if is_pallet_turn(x['CanonicalName'])]
    assert original_turns == result_turns
    assert len(original_turns)==17
    original_seconds=sum(float(x['PredictedTimeSeconds']) for x in ops)
    cap=sum(float(x['PredictedTimeSeconds']) for x in ops)
    assert abs(original_seconds-cap)<1e-8
    loads=Counter()
    for op,station in zip(ops,improved['AssignedCandidateIndices']):
        loads[station]+=float(op['PredictedTimeSeconds'])
    assert max(loads.values()) <=30+1e-6
    assert len(loads)==22
    special=6
    total_work=720.5990266666668
    print(f'33704184 30s | baseline 29 people, 82.83% | review proposal {len(loads)+special} people, {total_work / (30*(len(loads)+special))*100:.2f}%')
    print('main crew 23 -> 22; main operations 102 unchanged; pallet turns',len(original_turns))
    print('review swap:',[x['Name'] for x in improved['ReviewSwap']])
    print('max main load:', max(loads.values()))
    return ops, stations, actual, improved


if __name__=='__main__':
    run()


def run_full_main_stage():
    import line_balancer as engine
    ops, stations, baseline, proposal = run()
    for i, op in enumerate(ops):
        op['PredictedProcessPosition'] = i / len(ops)
        op['AdaptiveReferenceSequence'] = i + 1
        op['PredictedStationType'] = 'Main'
        op['PreservedReferenceModelNo'] = '33704194__T1330'
        op['PreservedReferenceStationNumber'] = op['PreferredPhysicalStationNumber']
        op['PreservedReferenceStationOperationSequence'] = i + 1
    results, records, warnings = engine._build_direct_physical_main_zone(
        ops, 30.0, 30.0, 100.0,
        {'PhysicalStationNumbers': stations}, [], hard_bundle_edges=[],
        balance_mode='preserve_method')
    print('FULL_MAIN_STAGE:', len(records), 'CREW; WARNING:',
          [w[:100] for w in warnings if 'REORDER' in w or 'LEARNED_STAFFING' in w])
    assert len(records)==22, len(records)
    assert any(str(w).startswith('REORDER_REVIEW_PAIR=') for w in warnings)
    assert all(float(record['StationLoadSeconds']) <= 30.0 + 1e-6 for record in records)
    return ops, results, warnings


def run_safety_regressions():
    from adaptive_reorder import _safe_to_propose
    # Cannot reverse a pallet turn or inspection following installation.
    assert not _safe_to_propose(
        {'CanonicalName':'paleti 180° çevirin','PreservedReferenceStationSequence':1},
        {'CanonicalName':'braketi tak','PreservedReferenceStationSequence':2},[])
    assert not _safe_to_propose(
        {'CanonicalName':'Kablo kutusunu yerine tak','PreservedReferenceStationSequence':1},
        {'CanonicalName':'soketlerin doğru takıldığını kontrol et','PreservedReferenceStationSequence':2},[])
    assert not _safe_to_propose(
        {'CanonicalName':'üst kapak 6 vida','PreservedReferenceStationSequence':1},
        {'CanonicalName':'üst kapak 3 vida','PreservedReferenceStationSequence':2},[])
    assert not _safe_to_propose(
        {'CanonicalName':'Etiketi yapıştır','PreservedReferenceStationSequence':1,
         'EngineeringRule':'STANDARD_CEHENNEMLIK_LABEL_PHYSICAL_STATION_1'},
        {'CanonicalName':'Arka vidaları sabitle','PreservedReferenceStationSequence':2},[])
    assert not _safe_to_propose(
        {'CanonicalName':'Masadan sac al', 'CanonicalOperationId':'A', 'PreservedReferenceStationSequence':1},
        {'CanonicalName':'Sac yerleştir', 'CanonicalOperationId':'B', 'PreservedReferenceStationSequence':2},
        [{'Source':'A','Target':'B','EngineeringApproved':True}])
    print('SAFETY: pallet / inspection / screw / fixed label / approved edge PASS')


if __name__=='__main__':
    run_full_main_stage()
    run_safety_regressions()
