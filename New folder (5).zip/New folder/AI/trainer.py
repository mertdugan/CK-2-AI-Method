﻿# -*- coding: utf-8 -*-
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesRegressor, RandomForestClassifier
from sklearn.feature_extraction import DictVectorizer
from sklearn.metrics import accuracy_score, f1_score, mean_absolute_error
from sklearn.model_selection import GroupShuffleSplit

from station_group_learning import fit_station_group_model
from reorder_learning import fit_reorder_evidence
from canonicalizer import build_canonical_operations
from orientation_sync import turn_kind, is_process_turn
from common import (
    CONFIG_FIELDS,
    normalize_model_no,
    normalize_text,
    note_segments,
    note_terms,
    pair_feature_dict,
    read_training_dataset,
    save_json,
)


ENGINE_SCHEMA_VERSION = 11


def _approved_configs(config_df):
    approved = config_df.copy()

    approved["HasApprovedMethodData"] = pd.to_numeric(
        approved["HasApprovedMethodData"],
        errors="coerce"
    ).fillna(0).astype(int)

    approved = approved[
        approved["HasApprovedMethodData"] == 1
    ].copy()

    approved["ModelNo"] = approved["ModelNo"].apply(
        normalize_model_no
    )

    return approved


def _config_lookup(config_df):
    result = {}

    for _, row in config_df.iterrows():
        model_no = normalize_model_no(
            row["ModelNo"]
        )

        result[model_no] = row.to_dict()

    return result


def _canonicalize_sequence(sequence, mapping):
    seq = sequence.copy()

    seq["RawOperationId"] = (
        seq["OperationId"].astype(str)
    )

    seq["CanonicalOperationId"] = (
        seq["RawOperationId"].map(mapping)
    )

    if seq["CanonicalOperationId"].isna().any():
        missing = (
            seq[
                seq["CanonicalOperationId"].isna()
            ]["RawOperationId"]
            .unique()
            .tolist()
        )

        raise ValueError(
            "Canonical map içinde bulunmayan operation id: " +
            ", ".join(missing[:10])
        )

    seq = (
        seq.sort_values(
            [
                "ModelNo",
                "OperationSequence",
                "StationSequence",
            ]
        )
        .reset_index(drop=True)
    )

    seq["OccurrenceIndex"] = (
        seq.groupby(
            [
                "ModelNo",
                "CanonicalOperationId",
            ]
        )
        .cumcount()
        + 1
    )

    seq["OccurrenceCountInModel"] = (
        seq.groupby(
            [
                "ModelNo",
                "CanonicalOperationId",
            ]
        )["CanonicalOperationId"]
        .transform("size")
    )

    # Learn the order of operations INSIDE each station as a separate
    # target. Global process order and within-station order are not the
    # same problem.
    if "StationOperationSequence" in seq.columns:
        seq["StationOperationSequenceNumeric"] = (
            pd.to_numeric(
                seq["StationOperationSequence"],
                errors="coerce"
            )
        )

        station_group_columns = [
            "ModelNo",
            "StationSequence",
        ]

        station_operation_count = (
            seq.groupby(
                station_group_columns
            )["CanonicalOperationId"]
            .transform("size")
            .astype(float)
        )

        station_order = (
            seq["StationOperationSequenceNumeric"]
            .fillna(1.0)
            .astype(float)
        )

        seq["WithinStationRelativePosition"] = np.where(
            station_operation_count > 1.0,
            (
                station_order - 1.0
            ) / (
                station_operation_count - 1.0
            ),
            0.0
        )

        seq["WithinStationRelativePosition"] = (
            seq["WithinStationRelativePosition"]
            .clip(0.0, 1.0)
        )

    else:
        seq["StationOperationSequenceNumeric"] = np.nan
        seq["WithinStationRelativePosition"] = np.nan

    return seq


def _build_presence_training(
    approved,
    sequence,
    canonical_ids
):
    lookup = _config_lookup(
        approved
    )

    grouped = (
        sequence
        .groupby(
            [
                "ModelNo",
                "CanonicalOperationId",
            ]
        )
        .size()
        .to_dict()
    )

    rows = []

    for model_no, config in lookup.items():
        for operation_id in canonical_ids:
            count = int(
                grouped.get(
                    (
                        model_no,
                        operation_id,
                    ),
                    0
                )
            )

            rows.append({
                "ModelNo":
                    model_no,
                "OperationId":
                    operation_id,
                "Feature":
                    pair_feature_dict(
                        config,
                        operation_id
                    ),
                "IsPresent":
                    1 if count > 0 else 0,
                "OccurrenceCount":
                    count,
            })

    return rows


def _build_instance_training(
    approved,
    sequence
):
    lookup = _config_lookup(
        approved
    )

    rows = []

    for _, row in sequence.iterrows():
        model_no = normalize_model_no(
            row["ModelNo"]
        )

        if model_no not in lookup:
            continue

        feature = pair_feature_dict(
            lookup[model_no],
            str(
                row["CanonicalOperationId"]
            ),
            int(
                row["OccurrenceIndex"]
            )
        )

        rows.append({
            "ModelNo":
                model_no,
            "OperationId":
                str(
                    row["CanonicalOperationId"]
                ),
            "OccurrenceIndex":
                int(
                    row["OccurrenceIndex"]
                ),
            "Feature":
                feature,
            "Duration":
                pd.to_numeric(
                    pd.Series([
                        row["OperationTimeSeconds"]
                    ]),
                    errors="coerce"
                ).iloc[0],
            "ProcessPosition":
                pd.to_numeric(
                    pd.Series([
                        row["ProcessRelativePosition"]
                    ]),
                    errors="coerce"
                ).iloc[0],
            "StationPosition":
                pd.to_numeric(
                    pd.Series([
                        row["StationRelativePosition"]
                    ]),
                    errors="coerce"
                ).iloc[0],
            "WithinStationPosition":
                pd.to_numeric(
                    pd.Series([
                        row.get(
                            "WithinStationRelativePosition",
                            np.nan
                        )
                    ]),
                    errors="coerce"
                ).iloc[0],
            "StationOperationSequence":
                pd.to_numeric(
                    pd.Series([
                        row.get(
                            "StationOperationSequenceNumeric",
                            np.nan
                        )
                    ]),
                    errors="coerce"
                ).iloc[0],
            "StationType":
                (
                    str(
                        row["StationType"]
                    )
                    if not pd.isna(
                        row["StationType"]
                    )
                    else "Unknown"
                ),
        })

    return rows


def _build_precedence(sequence):
    stats = defaultdict(
        lambda: {
            "support": 0,
            "a_before_b": 0,
            "b_before_a": 0,
            "mixed": 0,
            "same_station": 0,
        }
    )

    for _, group in sequence.groupby(
        "ModelNo",
        sort=False
    ):
        operation_info = {}

        for operation_id, operation_group in group.groupby(
            "CanonicalOperationId",
            sort=False
        ):
            positions = pd.to_numeric(
                operation_group["OperationSequence"],
                errors="coerce"
            ).dropna().to_numpy()

            stations = set(
                pd.to_numeric(
                    operation_group["StationSequence"],
                    errors="coerce"
                )
                .dropna()
                .astype(int)
                .tolist()
            )

            if len(positions) == 0:
                continue

            operation_info[
                str(operation_id)
            ] = {
                "min_position":
                    float(
                        positions.min()
                    ),
                "max_position":
                    float(
                        positions.max()
                    ),
                "stations":
                    stations,
            }

        ids = sorted(
            operation_info.keys()
        )

        for first_index in range(
            len(ids)
        ):
            operation_a = ids[
                first_index
            ]
            info_a = operation_info[
                operation_a
            ]

            for second_index in range(
                first_index + 1,
                len(ids)
            ):
                operation_b = ids[
                    second_index
                ]
                info_b = operation_info[
                    operation_b
                ]

                item = stats[
                    (
                        operation_a,
                        operation_b,
                    )
                ]

                item["support"] += 1

                if (
                    info_a["max_position"] <
                    info_b["min_position"]
                ):
                    item["a_before_b"] += 1

                elif (
                    info_b["max_position"] <
                    info_a["min_position"]
                ):
                    item["b_before_a"] += 1

                else:
                    item["mixed"] += 1

                if (
                    info_a["stations"]
                    .intersection(
                        info_b["stations"]
                    )
                ):
                    item["same_station"] += 1

    edges = []
    relations = []

    for (
        operation_a,
        operation_b
    ), item in stats.items():
        support = item["support"]

        confidence_ab = (
            item["a_before_b"] / support
            if support
            else 0.0
        )

        confidence_ba = (
            item["b_before_a"] / support
            if support
            else 0.0
        )

        relations.append({
            "OperationA":
                operation_a,
            "OperationB":
                operation_b,
            "Support":
                support,
            "ABeforeBCount":
                item["a_before_b"],
            "BBeforeACount":
                item["b_before_a"],
            "MixedCount":
                item["mixed"],
            "SameStationCount":
                item["same_station"],
            "ABeforeBConfidence":
                confidence_ab,
            "BBeforeAConfidence":
                confidence_ba,
        })

        if (
            support >= 5
            and confidence_ab >= 0.90
        ):
            edges.append(
                (
                    operation_a,
                    operation_b,
                    confidence_ab,
                    support,
                )
            )

        elif (
            support >= 5
            and confidence_ba >= 0.90
        ):
            edges.append(
                (
                    operation_b,
                    operation_a,
                    confidence_ba,
                    support,
                )
            )

    edges.sort(
        key=lambda value: (
            value[2],
            value[3],
        ),
        reverse=True
    )

    adjacency = defaultdict(set)
    accepted = []

    def has_path(start, target):
        stack = [start]
        visited = set()

        while stack:
            current = stack.pop()

            if current == target:
                return True

            if current in visited:
                continue

            visited.add(current)
            stack.extend(
                adjacency[current]
            )

        return False

    for (
        source,
        target,
        confidence,
        support
    ) in edges:
        if source == target:
            continue

        if has_path(
            target,
            source
        ):
            continue

        adjacency[source].add(
            target
        )

        accepted.append({
            "Source":
                source,
            "Target":
                target,
            "Confidence":
                confidence,
            "Support": support,
            # This evidence came from observed model co-occurrence, not
            # from an engineer-reviewed physical prerequisite.
            "ConstraintSource": "HISTORICAL_STATISTICAL",
            "EngineeringApproved": False,
        })

    return (
        pd.DataFrame(relations),
        accepted,
    )


def _median(
    values,
    default=0.0
):
    cleaned = [
        float(value)
        for value in values
        if (
            value is not None
            and not pd.isna(value)
        )
    ]

    if not cleaned:
        return float(default)

    return float(
        statistics.median(
            cleaned
        )
    )


def _mode_int(
    values,
    default=0
):
    cleaned = [
        int(value)
        for value in values
        if (
            value is not None
            and not pd.isna(value)
        )
    ]

    if not cleaned:
        return int(default)

    return int(
        Counter(cleaned)
        .most_common(1)[0][0]
    )



def _build_same_station_precedence(
    sequence
):
    """
    Learn exact operation order INSIDE a station.

    Improvements in schema 9:
      - occurrence-specific and canonical rules,
      - direct-adjacency evidence,
      - stronger priority for pairs that are repeatedly next to each other,
      - lower support threshold only when direction is highly consistent.

    This targets cases such as:
        A must be before B inside station 45
    even when only a few approved models contain both operations.
    """

    required_columns = {
        "ModelNo",
        "StationSequence",
        "CanonicalOperationId",
        "OccurrenceIndex",
        "StationOperationSequenceNumeric",
    }

    if not required_columns.issubset(
        set(
            sequence.columns
        )
    ):
        return (
            pd.DataFrame(),
            [],
        )

    def new_stats():
        return {
            "support": 0,
            "forward": 0,
            "reverse": 0,
            "forward_adjacent": 0,
            "reverse_adjacent": 0,
        }

    occurrence_stats = defaultdict(
        new_stats
    )

    canonical_stats = defaultdict(
        new_stats
    )

    grouped = sequence.groupby(
        [
            "ModelNo",
            "StationSequence",
        ],
        sort=False
    )

    for _, group in grouped:
        ordered_rows = []

        for _, row in group.iterrows():
            station_order = pd.to_numeric(
                pd.Series([
                    row.get(
                        "StationOperationSequenceNumeric",
                        np.nan
                    )
                ]),
                errors="coerce"
            ).iloc[0]

            if pd.isna(
                station_order
            ):
                continue

            global_sequence = pd.to_numeric(
                pd.Series([
                    row.get(
                        "OperationSequence",
                        0
                    )
                ]),
                errors="coerce"
            ).iloc[0]

            if pd.isna(
                global_sequence
            ):
                global_sequence = 0

            ordered_rows.append({
                "OperationId":
                    str(
                        row[
                            "CanonicalOperationId"
                        ]
                    ),
                "OccurrenceIndex":
                    int(
                        row.get(
                            "OccurrenceIndex",
                            1
                        )
                    ),
                "StationOrder":
                    float(
                        station_order
                    ),
                "GlobalSequence":
                    float(
                        global_sequence
                    ),
            })

        ordered_rows.sort(
            key=lambda item: (
                item[
                    "StationOrder"
                ],
                item[
                    "GlobalSequence"
                ],
                item[
                    "OperationId"
                ],
                item[
                    "OccurrenceIndex"
                ],
            )
        )

        for first_index in range(
            len(
                ordered_rows
            )
        ):
            first = ordered_rows[
                first_index
            ]

            for second_index in range(
                first_index + 1,
                len(
                    ordered_rows
                )
            ):
                second = ordered_rows[
                    second_index
                ]

                if (
                    first[
                        "StationOrder"
                    ] ==
                    second[
                        "StationOrder"
                    ]
                ):
                    continue

                is_adjacent = (
                    second_index ==
                    first_index + 1
                )

                # -----------------------------------------
                # Occurrence-specific pair
                # -----------------------------------------
                first_key = (
                    first[
                        "OperationId"
                    ],
                    int(
                        first[
                            "OccurrenceIndex"
                        ]
                    ),
                )

                second_key = (
                    second[
                        "OperationId"
                    ],
                    int(
                        second[
                            "OccurrenceIndex"
                        ]
                    ),
                )

                if (
                    first_key !=
                    second_key
                ):
                    if (
                        first_key <=
                        second_key
                    ):
                        pair_key = (
                            first_key,
                            second_key,
                        )

                        forward = True
                    else:
                        pair_key = (
                            second_key,
                            first_key,
                        )

                        forward = False

                    item = occurrence_stats[
                        pair_key
                    ]

                    item[
                        "support"
                    ] += 1

                    if forward:
                        item[
                            "forward"
                        ] += 1

                        if is_adjacent:
                            item[
                                "forward_adjacent"
                            ] += 1
                    else:
                        item[
                            "reverse"
                        ] += 1

                        if is_adjacent:
                            item[
                                "reverse_adjacent"
                            ] += 1

                # -----------------------------------------
                # Canonical fallback pair
                # -----------------------------------------
                first_operation = first[
                    "OperationId"
                ]

                second_operation = second[
                    "OperationId"
                ]

                if (
                    first_operation ==
                    second_operation
                ):
                    continue

                if (
                    first_operation <=
                    second_operation
                ):
                    pair_key = (
                        first_operation,
                        second_operation,
                    )

                    forward = True
                else:
                    pair_key = (
                        second_operation,
                        first_operation,
                    )

                    forward = False

                item = canonical_stats[
                    pair_key
                ]

                item[
                    "support"
                ] += 1

                if forward:
                    item[
                        "forward"
                    ] += 1

                    if is_adjacent:
                        item[
                            "forward_adjacent"
                        ] += 1
                else:
                    item[
                        "reverse"
                    ] += 1

                    if is_adjacent:
                        item[
                            "reverse_adjacent"
                        ] += 1

    relations = []
    edges = []

    def append_rules(
        stats,
        scope,
    ):
        for pair_key, item in stats.items():
            support = int(
                item[
                    "support"
                ]
            )

            if support <= 0:
                continue

            forward_confidence = (
                float(
                    item[
                        "forward"
                    ]
                )
                /
                support
            )

            reverse_confidence = (
                float(
                    item[
                        "reverse"
                    ]
                )
                /
                support
            )

            if (
                forward_confidence >=
                reverse_confidence
            ):
                direction = (
                    "forward"
                )

                confidence = (
                    forward_confidence
                )

                direct_support = int(
                    item[
                        "forward_adjacent"
                    ]
                )
            else:
                direction = (
                    "reverse"
                )

                confidence = (
                    reverse_confidence
                )

                direct_support = int(
                    item[
                        "reverse_adjacent"
                    ]
                )

            adjacent_confidence = (
                float(
                    direct_support
                )
                /
                support
            )

            if scope == "Occurrence":
                first_key, second_key = (
                    pair_key
                )

                relations.append({
                    "Scope":
                        scope,
                    "OperationA":
                        first_key[0],
                    "OccurrenceA":
                        int(
                            first_key[1]
                        ),
                    "OperationB":
                        second_key[0],
                    "OccurrenceB":
                        int(
                            second_key[1]
                        ),
                    "Support":
                        support,
                    "ForwardConfidence":
                        forward_confidence,
                    "ReverseConfidence":
                        reverse_confidence,
                    "DirectSupport":
                        direct_support,
                    "AdjacentConfidence":
                        adjacent_confidence,
                })

                if direction == "forward":
                    source_key = (
                        first_key
                    )

                    target_key = (
                        second_key
                    )
                else:
                    source_key = (
                        second_key
                    )

                    target_key = (
                        first_key
                    )

                accept = (
                    (
                        support >= 2
                        and
                        confidence >= 0.85
                    )
                    or
                    (
                        direct_support >= 2
                        and
                        confidence >= 0.75
                    )
                )

                if accept:
                    edges.append({
                        "Scope":
                            scope,
                        "Source":
                            source_key[0],
                        "SourceOccurrenceIndex":
                            int(
                                source_key[1]
                            ),
                        "Target":
                            target_key[0],
                        "TargetOccurrenceIndex":
                            int(
                                target_key[1]
                            ),
                        "Confidence":
                            float(
                                confidence
                            ),
                        "Support":
                            support,
                        "DirectSupport":
                            direct_support,
                        "AdjacentConfidence":
                            adjacent_confidence,
                    })

            else:
                (
                    first_operation,
                    second_operation,
                ) = pair_key

                relations.append({
                    "Scope":
                        scope,
                    "OperationA":
                        first_operation,
                    "OccurrenceA":
                        None,
                    "OperationB":
                        second_operation,
                    "OccurrenceB":
                        None,
                    "Support":
                        support,
                    "ForwardConfidence":
                        forward_confidence,
                    "ReverseConfidence":
                        reverse_confidence,
                    "DirectSupport":
                        direct_support,
                    "AdjacentConfidence":
                        adjacent_confidence,
                })

                if direction == "forward":
                    source_operation = (
                        first_operation
                    )

                    target_operation = (
                        second_operation
                    )
                else:
                    source_operation = (
                        second_operation
                    )

                    target_operation = (
                        first_operation
                    )

                accept = (
                    (
                        support >= 2
                        and
                        confidence >= 0.90
                    )
                    or
                    (
                        direct_support >= 2
                        and
                        confidence >= 0.85
                    )
                )

                if accept:
                    edges.append({
                        "Scope":
                            scope,
                        "Source":
                            source_operation,
                        "SourceOccurrenceIndex":
                            None,
                        "Target":
                            target_operation,
                        "TargetOccurrenceIndex":
                            None,
                        "Confidence":
                            float(
                                confidence
                            ),
                        "Support":
                            support,
                        "DirectSupport":
                            direct_support,
                        "AdjacentConfidence":
                            adjacent_confidence,
                    })

    append_rules(
        occurrence_stats,
        "Occurrence",
    )

    append_rules(
        canonical_stats,
        "Canonical",
    )

    # Directly adjacent historical pairs are strongest.
    edges.sort(
        key=lambda item: (
            1
            if item.get(
                "Scope"
            ) == "Occurrence"
            else 0,
            int(
                item.get(
                    "DirectSupport",
                    0
                )
            ),
            float(
                item.get(
                    "AdjacentConfidence",
                    0.0
                )
            ),
            float(
                item.get(
                    "Confidence",
                    0.0
                )
            ),
            int(
                item.get(
                    "Support",
                    0
                )
            ),
        ),
        reverse=True
    )

    return (
        pd.DataFrame(
            relations
        ),
        edges,
    )


def _build_hard_bundle_edges(
    sequence
):
    """
    Learn occurrence-aware operation pairs that must remain in the SAME
    physical station. This captures repeated historical co-location caused
    by the same screw gun, fixture, tooling, or tightly coupled work.

    HARD edge thresholds:
      - at least 3 approved models contain both instances,
      - same physical station >= 95%,
      - close inside-station order (distance <= 2) >= 80%.
    """

    required = {
        "ModelNo",
        "CanonicalOperationId",
        "OccurrenceIndex",
        "StationSequence",
        "StationOperationSequenceNumeric",
    }

    if not required.issubset(
        set(
            sequence.columns
        )
    ):
        return (
            pd.DataFrame(),
            [],
        )

    pair_stats = defaultdict(
        lambda: {
            "CoExistSupport": 0,
            "SameStationCount": 0,
            "AdjacentCount": 0,
        }
    )

    for _, model_group in sequence.groupby(
        "ModelNo",
        sort=False
    ):
        rows = []

        for _, row in model_group.iterrows():
            station_sequence = pd.to_numeric(
                pd.Series([
                    row.get(
                        "StationSequence",
                        np.nan
                    )
                ]),
                errors="coerce"
            ).iloc[0]

            if pd.isna(
                station_sequence
            ):
                continue

            station_order = pd.to_numeric(
                pd.Series([
                    row.get(
                        "StationOperationSequenceNumeric",
                        np.nan
                    )
                ]),
                errors="coerce"
            ).iloc[0]

            rows.append({
                "Key": (
                    str(
                        row[
                            "CanonicalOperationId"
                        ]
                    ),
                    int(
                        row.get(
                            "OccurrenceIndex",
                            1
                        )
                    ),
                ),
                "StationSequence":
                    int(
                        station_sequence
                    ),
                "StationOrder":
                    (
                        float(
                            station_order
                        )
                        if not pd.isna(
                            station_order
                        )
                        else None
                    ),
            })

        rows.sort(
            key=lambda item:
                item["Key"]
        )

        for i in range(
            len(
                rows
            )
        ):
            for j in range(
                i + 1,
                len(
                    rows
                )
            ):
                first = rows[i]
                second = rows[j]

                if (
                    first["Key"] ==
                    second["Key"]
                ):
                    continue

                pair_key = (
                    first["Key"],
                    second["Key"],
                )

                stat = pair_stats[
                    pair_key
                ]

                stat[
                    "CoExistSupport"
                ] += 1

                if (
                    first[
                        "StationSequence"
                    ] ==
                    second[
                        "StationSequence"
                    ]
                ):
                    stat[
                        "SameStationCount"
                    ] += 1

                    first_order = first[
                        "StationOrder"
                    ]

                    second_order = second[
                        "StationOrder"
                    ]

                    if (
                        first_order is not None
                        and
                        second_order is not None
                        and
                        abs(
                            first_order -
                            second_order
                        ) <= 2.0
                    ):
                        stat[
                            "AdjacentCount"
                        ] += 1

    relation_rows = []
    hard_edges = []

    for (
        source_key,
        target_key,
    ), stat in pair_stats.items():
        support = int(
            stat[
                "CoExistSupport"
            ]
        )

        same_station = int(
            stat[
                "SameStationCount"
            ]
        )

        adjacent = int(
            stat[
                "AdjacentCount"
            ]
        )

        if support <= 0:
            continue

        co_location_confidence = (
            same_station /
            support
        )

        adjacent_confidence = (
            adjacent /
            same_station
            if same_station > 0
            else 0.0
        )

        row = {
            "Source":
                source_key[0],
            "SourceOccurrenceIndex":
                int(
                    source_key[1]
                ),
            "Target":
                target_key[0],
            "TargetOccurrenceIndex":
                int(
                    target_key[1]
                ),
            "Support":
                support,
            "SameStationCount":
                same_station,
            "CoLocationConfidence":
                float(
                    co_location_confidence
                ),
            "AdjacentConfidence":
                float(
                    adjacent_confidence
                ),
        }

        relation_rows.append(
            row
        )

        if (
            support >= 3
            and
            co_location_confidence >= 0.95
            and
            adjacent_confidence >= 0.80
        ):
            hard_edges.append(
                dict(
                    row
                )
            )

    hard_edges.sort(
        key=lambda item: (
            float(
                item[
                    "CoLocationConfidence"
                ]
            ),
            float(
                item[
                    "AdjacentConfidence"
                ]
            ),
            int(
                item[
                    "Support"
                ]
            ),
        ),
        reverse=True
    )

    return (
        pd.DataFrame(
            relation_rows
        ),
        hard_edges,
    )



def _is_pallet_rotation_name(value):
    # Both pallet and component turns are process-order boundaries.
    # Only pallet turns change the product's heading.
    return is_process_turn(value)


def _instance_key_text(
    operation_id,
    occurrence_index
):
    return (
        str(
            operation_id
        )
        +
        "#"
        +
        str(
            int(
                occurrence_index
            )
        )
    )


def _build_process_block_order(
    sequence,
    hard_bundle_edges,
    canonical_name_map,
):
    """
    Build a process-block layer ABOVE individual operations.

    1) Strong same-station bundle edges create connected components.
    2) Pallet rotations are kept as independent process-state blocks.
    3) From every approved historical method, learn the LOCAL order of
       blocks (up to 4 neighboring blocks ahead).
    4) Keep only strong, repeated directions.

    Output:
      - operation_block_map:
          "CanonicalOperationId#OccurrenceIndex" -> BlockId
      - process_block_order_edges:
          SourceBlock -> TargetBlock with support/confidence
    """

    # ---------------------------------------------------------
    # Collect all Main-operation occurrence keys.
    # ---------------------------------------------------------
    all_keys = set()

    main_sequence = sequence.copy()

    if "StationType" in main_sequence.columns:
        main_sequence = main_sequence[
            main_sequence[
                "StationType"
            ].fillna(
                "Main"
            ).astype(str) == "Main"
        ].copy()

    for _, row in main_sequence.iterrows():
        all_keys.add(
            (
                str(
                    row[
                        "CanonicalOperationId"
                    ]
                ),
                int(
                    row.get(
                        "OccurrenceIndex",
                        1
                    )
                ),
            )
        )

    parent = {
        key: key
        for key in all_keys
    }

    members = {
        key: {
            key
        }
        for key in all_keys
    }

    def find_root(
        key
    ):
        if key not in parent:
            parent[
                key
            ] = key

            members[
                key
            ] = {
                key
            }

        while (
            parent[
                key
            ] !=
            key
        ):
            parent[
                key
            ] = parent[
                parent[
                    key
                ]
            ]

            key = parent[
                key
            ]

        return key

    def union_keys(
        first_key,
        second_key,
    ):
        first_root = find_root(
            first_key
        )

        second_root = find_root(
            second_key
        )

        if (
            first_root ==
            second_root
        ):
            return

        if len(
            members[
                first_root
            ]
        ) < len(
            members[
                second_root
            ]
        ):
            first_root, second_root = (
                second_root,
                first_root
            )

        parent[
            second_root
        ] = first_root

        members[
            first_root
        ].update(
            members[
                second_root
            ]
        )

        del members[
            second_root
        ]

    # ---------------------------------------------------------
    # Build global historical bundle components.
    # Pallet rotations are boundaries, never bundle members.
    # ---------------------------------------------------------
    for edge in (
        hard_bundle_edges
        or []
    ):
        source_key = (
            str(
                edge.get(
                    "Source",
                    ""
                )
            ),
            int(
                edge.get(
                    "SourceOccurrenceIndex",
                    1
                )
            ),
        )

        target_key = (
            str(
                edge.get(
                    "Target",
                    ""
                )
            ),
            int(
                edge.get(
                    "TargetOccurrenceIndex",
                    1
                )
            ),
        )

        if (
            source_key not in all_keys
            or
            target_key not in all_keys
        ):
            continue

        source_name = canonical_name_map.get(
            source_key[0],
            source_key[0]
        )

        target_name = canonical_name_map.get(
            target_key[0],
            target_key[0]
        )

        if (
            _is_pallet_rotation_name(
                source_name
            )
            or
            _is_pallet_rotation_name(
                target_name
            )
        ):
            continue

        union_keys(
            source_key,
            target_key,
        )

    # ---------------------------------------------------------
    # Stable block ids.
    # ---------------------------------------------------------
    root_to_block_id = {}

    for root, root_members in list(
        members.items()
    ):
        sorted_members = sorted(
            root_members
        )

        first_member = sorted_members[
            0
        ]

        prefix = (
            "BUNDLE"
            if len(
                sorted_members
            ) > 1
            else
            "OP"
        )

        root_to_block_id[
            root
        ] = (
            prefix
            +
            "::"
            +
            _instance_key_text(
                first_member[0],
                first_member[1]
            )
        )

    operation_block_map = {}

    for key in all_keys:
        root = find_root(
            key
        )

        operation_block_map[
            _instance_key_text(
                key[0],
                key[1]
            )
        ] = root_to_block_id[
            root
        ]

    # ---------------------------------------------------------
    # Learn LOCAL block order.
    # Pair only nearby block ranks (<= 4) to avoid turning the
    # whole line into an over-constrained global chain.
    # ---------------------------------------------------------
    pair_stats = defaultdict(
        lambda: {
            "Support": 0,
            "Forward": 0,
            "Reverse": 0,
            "RankDistanceTotal": 0.0,
        }
    )

    for _, model_group in main_sequence.groupby(
        "ModelNo",
        sort=False
    ):
        block_rows = {}

        for _, row in model_group.iterrows():
            key_text = _instance_key_text(
                row[
                    "CanonicalOperationId"
                ],
                row.get(
                    "OccurrenceIndex",
                    1
                )
            )

            block_id = operation_block_map.get(
                key_text
            )

            if not block_id:
                continue

            station_sequence = pd.to_numeric(
                pd.Series([
                    row.get(
                        "StationSequence",
                        np.nan
                    )
                ]),
                errors="coerce"
            ).iloc[0]

            operation_sequence = pd.to_numeric(
                pd.Series([
                    row.get(
                        "OperationSequence",
                        np.nan
                    )
                ]),
                errors="coerce"
            ).iloc[0]

            if pd.isna(
                station_sequence
            ):
                continue

            if pd.isna(
                operation_sequence
            ):
                operation_sequence = 0

            sort_key = (
                int(
                    station_sequence
                ),
                float(
                    operation_sequence
                ),
            )

            current = block_rows.get(
                block_id
            )

            if (
                current is None
                or
                sort_key <
                current
            ):
                block_rows[
                    block_id
                ] = sort_key

        ordered_blocks = sorted(
            block_rows.keys(),
            key=lambda block_id:
                block_rows[
                    block_id
                ]
        )

        for first_rank in range(
            len(
                ordered_blocks
            )
        ):
            max_second_rank = min(
                len(
                    ordered_blocks
                ),
                first_rank + 5
            )

            for second_rank in range(
                first_rank + 1,
                max_second_rank
            ):
                first_block = ordered_blocks[
                    first_rank
                ]

                second_block = ordered_blocks[
                    second_rank
                ]

                if (
                    first_block ==
                    second_block
                ):
                    continue

                if (
                    first_block <=
                    second_block
                ):
                    pair_key = (
                        first_block,
                        second_block,
                    )

                    forward = True

                else:
                    pair_key = (
                        second_block,
                        first_block,
                    )

                    forward = False

                stat = pair_stats[
                    pair_key
                ]

                stat[
                    "Support"
                ] += 1

                stat[
                    "RankDistanceTotal"
                ] += (
                    second_rank -
                    first_rank
                )

                if forward:
                    stat[
                        "Forward"
                    ] += 1
                else:
                    stat[
                        "Reverse"
                    ] += 1

    relation_rows = []
    order_edges = []

    for (
        first_block,
        second_block,
    ), stat in pair_stats.items():
        support = int(
            stat[
                "Support"
            ]
        )

        if support <= 0:
            continue

        forward_confidence = (
            float(
                stat[
                    "Forward"
                ]
            )
            /
            support
        )

        reverse_confidence = (
            float(
                stat[
                    "Reverse"
                ]
            )
            /
            support
        )

        average_rank_distance = (
            float(
                stat[
                    "RankDistanceTotal"
                ]
            )
            /
            support
        )

        if (
            forward_confidence >=
            reverse_confidence
        ):
            source_block = (
                first_block
            )

            target_block = (
                second_block
            )

            confidence = (
                forward_confidence
            )

        else:
            source_block = (
                second_block
            )

            target_block = (
                first_block
            )

            confidence = (
                reverse_confidence
            )

        relation_rows.append({
            "SourceBlock":
                source_block,
            "TargetBlock":
                target_block,
            "Support":
                support,
            "Confidence":
                float(
                    confidence
                ),
            "AverageRankDistance":
                average_rank_distance,
        })

        if (
            support >= 3
            and
            confidence >= 0.92
            and
            average_rank_distance <= 4.0
        ):
            order_edges.append({
                "SourceBlock":
                    source_block,
                "TargetBlock":
                    target_block,
                "Support":
                    support,
                "Confidence":
                    float(
                        confidence
                    ),
                "AverageRankDistance":
                    average_rank_distance,
            })

    order_edges.sort(
        key=lambda item: (
            float(
                item.get(
                    "Confidence",
                    0.0
                )
            ),
            int(
                item.get(
                    "Support",
                    0
                )
            ),
            -float(
                item.get(
                    "AverageRankDistance",
                    99.0
                )
            ),
        ),
        reverse=True
    )

    return (
        pd.DataFrame(
            relation_rows
        ),
        operation_block_map,
        order_edges,
    )


def _build_note_operation_rules(
    approved_configs,
    sequence,
    canonical_name_map,
):
    """
    Learn NOTE/MARKET -> OPERATION associations from approved methods.

    This is generic; there are NO hard-coded country names.

    Example:
      MODEL_Config.Not contains "UKRAYNA"
      and approved methods consistently contain an operation whose name
      also contains "UKRAYNA".

    The rule can then recover a sparse market-label operation in a holdout
    model even when the generic presence classifier is conservative.
    """

    config_by_model = {}

    for _, row in approved_configs.iterrows():
        model_no = normalize_model_no(
            row.get(
                "ModelNo"
            )
        )

        config_by_model[
            model_no
        ] = row.to_dict()

    operation_counts_by_model = defaultdict(
        Counter
    )

    for _, row in sequence.iterrows():
        model_no = normalize_model_no(
            row.get(
                "ModelNo"
            )
        )

        operation_id = str(
            row.get(
                "CanonicalOperationId",
                ""
            )
        )

        if not operation_id:
            continue

        operation_counts_by_model[
            model_no
        ][
            operation_id
        ] += 1

    approved_model_nos = [
        normalize_model_no(
            value
        )
        for value in approved_configs[
            "ModelNo"
        ].tolist()
    ]

    total_models = max(
        len(
            approved_model_nos
        ),
        1
    )

    operation_model_support = Counter()

    for model_no in approved_model_nos:
        for operation_id in (
            operation_counts_by_model.get(
                model_no,
                {}
            ).keys()
        ):
            operation_model_support[
                operation_id
            ] += 1

    models_by_term = defaultdict(
        set
    )

    for model_no in approved_model_nos:
        config = config_by_model.get(
            model_no,
            {}
        )

        for term in note_terms(
            config.get(
                "Not"
            ),
            max_ngram=3
        ):
            models_by_term[
                term
            ].add(
                model_no
            )

    rules = []

    for term, model_set in (
        models_by_term.items()
    ):
        note_model_count = len(
            model_set
        )

        if note_model_count <= 0:
            continue

        candidate_operations = set()

        for model_no in model_set:
            candidate_operations.update(
                operation_counts_by_model.get(
                    model_no,
                    {}
                ).keys()
            )

        term_tokens = set(
            normalize_text(
                term
            ).split()
        )

        for operation_id in candidate_operations:
            support_models = []

            occurrence_counts = []

            for model_no in model_set:
                count = int(
                    operation_counts_by_model.get(
                        model_no,
                        {}
                    ).get(
                        operation_id,
                        0
                    )
                )

                if count > 0:
                    support_models.append(
                        model_no
                    )

                    occurrence_counts.append(
                        count
                    )

            support = len(
                support_models
            )

            if support <= 0:
                continue

            confidence = (
                support /
                note_model_count
            )

            prevalence = (
                float(
                    operation_model_support.get(
                        operation_id,
                        0
                    )
                )
                /
                total_models
            )

            lift = (
                confidence /
                max(
                    prevalence,
                    1e-9
                )
            )

            canonical_name = (
                canonical_name_map.get(
                    operation_id,
                    operation_id
                )
            )

            operation_tokens = set(
                normalize_text(
                    canonical_name
                ).split()
            )

            semantic_match = (
                bool(
                    term_tokens
                )
                and
                term_tokens.issubset(
                    operation_tokens
                )
            )

            count_mode = (
                Counter(
                    occurrence_counts
                )
                .most_common(1)[0][0]
                if occurrence_counts
                else 1
            )

            # Sparse explicit semantic rules are allowed with only one
            # supporting approved model. Statistical-only rules require
            # stronger repeated evidence and lift.
            rule_type = None

            if (
                semantic_match
                and
                confidence >= 0.80
            ):
                rule_type = (
                    "SEMANTIC_NOTE_MATCH"
                )

            elif (
                support >= 2
                and
                confidence >= 0.90
                and
                lift >= 1.50
            ):
                rule_type = (
                    "STATISTICAL_NOTE_TRIGGER"
                )

            if rule_type is None:
                continue

            rules.append({
                "Term":
                    term,
                "OperationId":
                    operation_id,
                "CanonicalName":
                    canonical_name,
                "RuleType":
                    rule_type,
                "SupportModels":
                    support,
                "NoteModelCount":
                    note_model_count,
                "Confidence":
                    float(
                        confidence
                    ),
                "OperationPrevalence":
                    float(
                        prevalence
                    ),
                "Lift":
                    float(
                        lift
                    ),
                "OccurrenceMode":
                    int(
                        count_mode
                    ),
                "SemanticMatch":
                    bool(
                        semantic_match
                    ),
            })

    rules.sort(
        key=lambda item: (
            1
            if item.get(
                "RuleType"
            ) ==
            "SEMANTIC_NOTE_MATCH"
            else 0,
            len(
                str(
                    item.get(
                        "Term",
                        ""
                    )
                ).split()
            ),
            float(
                item.get(
                    "Confidence",
                    0.0
                )
            ),
            int(
                item.get(
                    "SupportModels",
                    0
                )
            ),
            float(
                item.get(
                    "Lift",
                    0.0
                )
            ),
        ),
        reverse=True
    )

    return rules


def _json_safe_scalar(
    value
):
    if value is None:
        return None

    try:
        if pd.isna(
            value
        ):
            return None
    except Exception:
        pass

    if isinstance(
        value,
        np.generic
    ):
        return value.item()

    if isinstance(
        value,
        (
            str,
            int,
            float,
            bool,
        )
    ):
        return value

    return str(
        value
    )


def _build_nearest_method_artifacts(
    approved_configs,
    sequence,
):
    """
    Store the approved historical configs and occurrence-level method facts
    required for nearest-similar-method context at prediction time.

    The nearest layer does NOT replace the ML. It is a high-confidence
    contextual correction for:
      - exact operation duration,
      - within-station order,
      - within-station relative position.

    Physical-station assignment remains under the existing ML + optimizer.
    """
    training_config_profiles = []

    for _, row in approved_configs.iterrows():
        model_no = normalize_model_no(
            row.get(
                "ModelNo"
            )
        )

        profile = {
            "ModelNo": model_no,
            "ConfigReferenceCycleTimeSeconds": _json_safe_scalar(
                row.get("ConfigReferenceCycleTimeSeconds")
            ),
        }

        for field in CONFIG_FIELDS:
            profile[
                field
            ] = _json_safe_scalar(
                row.get(
                    field
                )
            )

        training_config_profiles.append(
            profile
        )

    instance_history = defaultdict(
        list
    )

    history_rows = []

    for _, row in sequence.iterrows():
        operation_id = str(
            row.get(
                "CanonicalOperationId",
                ""
            )
        )

        if not operation_id:
            continue

        occurrence_index = int(
            row.get(
                "OccurrenceIndex",
                1
            )
        )

        model_no = normalize_model_no(
            row.get(
                "ModelNo"
            )
        )

        key = (
            operation_id
            +
            "#"
            +
            str(
                occurrence_index
            )
        )

        observation = {
            "ModelNo":
                model_no,
            "Duration":
                _json_safe_scalar(
                    pd.to_numeric(
                        pd.Series([
                            row.get(
                                "OperationTimeSeconds"
                            )
                        ]),
                        errors="coerce"
                    ).iloc[0]
                ),
            "WithinStationPosition":
                _json_safe_scalar(
                    pd.to_numeric(
                        pd.Series([
                            row.get(
                                "WithinStationRelativePosition"
                            )
                        ]),
                        errors="coerce"
                    ).iloc[0]
                ),
            "StationOperationSequence":
                _json_safe_scalar(
                    pd.to_numeric(
                        pd.Series([
                            row.get(
                                "StationOperationSequenceNumeric"
                            )
                        ]),
                        errors="coerce"
                    ).iloc[0]
                ),
            "StationSequence":
                _json_safe_scalar(
                    pd.to_numeric(
                        pd.Series([
                            row.get(
                                "StationSequence"
                            )
                        ]),
                        errors="coerce"
                    ).iloc[0]
                ),
            "StationType":
                (
                    None
                    if pd.isna(
                        row.get(
                            "StationType"
                        )
                    )
                    else str(
                        row.get(
                            "StationType"
                        )
                    )
                ),
            "ProcessPosition":
                _json_safe_scalar(
                    pd.to_numeric(
                        pd.Series([
                            row.get(
                                "ProcessRelativePosition"
                            )
                        ]),
                        errors="coerce"
                    ).iloc[0]
                ),
        }

        if "StationNumber" in row.index:
            observation[
                "PhysicalStationNumber"
            ] = _json_safe_scalar(
                pd.to_numeric(
                    pd.Series([
                        row.get(
                            "StationNumber"
                        )
                    ]),
                    errors="coerce"
                ).iloc[0]
            )

        instance_history[
            key
        ].append(
            observation
        )

        flat_row = {
            "InstanceKey":
                key,
            "CanonicalOperationId":
                operation_id,
            "OccurrenceIndex":
                occurrence_index,
        }

        flat_row.update(
            observation
        )

        history_rows.append(
            flat_row
        )

    known_note_segments = sorted({
        segment
        for profile in
        training_config_profiles
        for segment in
        note_segments(
            profile.get(
                "Not"
            )
        )
    })

    return (
        training_config_profiles,
        dict(
            instance_history
        ),
        known_note_segments,
        pd.DataFrame(
            history_rows
        ),
    )


def _build_station_type_profiles(
    stations,
    approved_model_set
):
    data = stations[
        stations["ModelNo"].isin(
            approved_model_set
        )
    ].copy()

    data["StationSequence"] = pd.to_numeric(
        data["StationSequence"],
        errors="coerce"
    )

    if "StationNumber" in data.columns:
        data["StationNumber"] = pd.to_numeric(
            data["StationNumber"],
            errors="coerce"
        )
    else:
        data["StationNumber"] = np.nan

    data[
        "EffectiveStationCycleTimeSeconds"
    ] = pd.to_numeric(
        data[
            "EffectiveStationCycleTimeSeconds"
        ],
        errors="coerce"
    )

    data["OperationCount"] = pd.to_numeric(
        data["OperationCount"],
        errors="coerce"
    ).fillna(0)

    data[
        "TimedOperationCount"
    ] = pd.to_numeric(
        data["TimedOperationCount"],
        errors="coerce"
    ).fillna(0)

    observations = defaultdict(list)
    type_counts = defaultdict(list)
    first_positions = defaultdict(list)
    first_main_anchor = defaultdict(list)

    # For real factory station numbering.
    # Example Main layout for this line:
    # 1, 3, 8, 9, 10 ... rather than 1, 2, 3 ...
    layouts_by_type_and_count = defaultdict(
        lambda: defaultdict(list)
    )

    for model_no, model_group in data.groupby(
        "ModelNo",
        sort=False
    ):
        model_group = (
            model_group
            .sort_values("StationSequence")
            .reset_index(drop=True)
        )

        total_station_count = len(
            model_group
        )

        main_sequences = (
            model_group[
                model_group[
                    "StationType"
                ] == "Main"
            ]["StationSequence"]
            .dropna()
            .astype(float)
            .tolist()
        )

        main_count = len(
            main_sequences
        )

        for (
            station_type,
            type_group
        ) in model_group.groupby(
            "StationType",
            sort=False
        ):
            type_group = (
                type_group
                .sort_values(
                    "StationSequence"
                )
                .reset_index(drop=True)
            )

            type_count = len(
                type_group
            )

            type_counts[
                station_type
            ].append(
                type_count
            )

            layout_numbers = []

            for (
                local_index,
                row
            ) in type_group.iterrows():
                station_sequence = float(
                    row["StationSequence"]
                )

                station_number = (
                    None
                    if pd.isna(
                        row["StationNumber"]
                    )
                    else int(
                        row["StationNumber"]
                    )
                )

                if station_number is not None:
                    layout_numbers.append(
                        station_number
                    )

                relative_position = (
                    0.0
                    if total_station_count <= 1
                    else
                    (
                        station_sequence - 1.0
                    ) /
                    (
                        total_station_count - 1.0
                    )
                )

                main_before = sum(
                    1
                    for sequence
                    in main_sequences
                    if sequence <
                    station_sequence
                )

                main_anchor = (
                    main_before / main_count
                    if main_count > 0
                    else 1.0
                )

                observations[
                    station_type
                ].append({
                    "ModelNo":
                        model_no,
                    "Ordinal":
                        local_index + 1,
                    "TypeCount":
                        type_count,
                    "RelativePosition":
                        relative_position,
                    "MainAnchor":
                        main_anchor,
                    "EffectiveCycleTime":
                        row[
                            "EffectiveStationCycleTimeSeconds"
                        ],
                    "OperationCount":
                        row[
                            "OperationCount"
                        ],
                    "TimedOperationCount":
                        row[
                            "TimedOperationCount"
                        ],
                    "StationNumber":
                        station_number,
                })

            if (
                len(layout_numbers) ==
                type_count
            ):
                layouts_by_type_and_count[
                    station_type
                ][
                    type_count
                ].append(
                    tuple(
                        layout_numbers
                    )
                )

            first_row = (
                type_group.iloc[0]
            )

            first_sequence = float(
                first_row[
                    "StationSequence"
                ]
            )

            first_relative = (
                0.0
                if total_station_count <= 1
                else
                (
                    first_sequence - 1.0
                ) /
                (
                    total_station_count - 1.0
                )
            )

            first_positions[
                station_type
            ].append(
                first_relative
            )

            main_before_first = sum(
                1
                for sequence
                in main_sequences
                if sequence <
                first_sequence
            )

            first_main_anchor[
                station_type
            ].append(
                (
                    main_before_first /
                    main_count
                    if main_count > 0
                    else 1.0
                )
            )

    profiles = {}

    for station_type in observations:
        type_observations = (
            observations[
                station_type
            ]
        )

        count_values = (
            type_counts[
                station_type
            ]
        )

        mode_count = _mode_int(
            count_values,
            1
        )

        total_timed_operations = sum(
            int(
                observation[
                    "TimedOperationCount"
                ]
            )
            for observation
            in type_observations
        )

        total_operations = sum(
            int(
                observation[
                    "OperationCount"
                ]
            )
            for observation
            in type_observations
        )

        aggregate_time = (
            total_operations > 0
            and
            total_timed_operations == 0
        )

        ordinal_profiles = []

        for ordinal in range(
            1,
            mode_count + 1
        ):
            ordinal_rows = [
                observation
                for observation
                in type_observations
                if int(
                    observation[
                        "Ordinal"
                    ]
                ) == ordinal
            ]

            station_number_values = [
                row[
                    "StationNumber"
                ]
                for row
                in ordinal_rows
                if row[
                    "StationNumber"
                ] is not None
            ]

            ordinal_profiles.append({
                "Ordinal":
                    ordinal,
                "MedianRelativePosition":
                    _median(
                        [
                            row[
                                "RelativePosition"
                            ]
                            for row
                            in ordinal_rows
                        ],
                        0.0
                    ),
                "MedianMainAnchor":
                    _median(
                        [
                            row[
                                "MainAnchor"
                            ]
                            for row
                            in ordinal_rows
                        ],
                        1.0
                    ),
                "MedianCycleTimeSeconds":
                    _median(
                        [
                            row[
                                "EffectiveCycleTime"
                            ]
                            for row
                            in ordinal_rows
                        ],
                        0.0
                    ),
                "MedianOperationCount":
                    _median(
                        [
                            row[
                                "OperationCount"
                            ]
                            for row
                            in ordinal_rows
                        ],
                        0.0
                    ),
                "ModePhysicalStationNumber":
                    (
                        _mode_int(
                            station_number_values,
                            0
                        )
                        if station_number_values
                        else None
                    ),
                "MedianPhysicalStationNumber":
                    (
                        _median(
                            station_number_values,
                            0.0
                        )
                        if station_number_values
                        else None
                    ),
            })

        physical_station_numbers = sorted({
            int(
                observation[
                    "StationNumber"
                ]
            )
            for observation
            in type_observations
            if observation[
                "StationNumber"
            ] is not None
        })

        physical_layouts = {}

        for (
            count_value,
            layouts
        ) in (
            layouts_by_type_and_count[
                station_type
            ].items()
        ):
            if not layouts:
                continue

            best_layout = (
                Counter(
                    layouts
                )
                .most_common(1)[0][0]
            )

            physical_layouts[
                str(
                    int(
                        count_value
                    )
                )
            ] = [
                int(
                    number
                )
                for number
                in best_layout
            ]

        profiles[
            str(station_type)
        ] = {
            "StationType":
                str(station_type),
            "ModelCount":
                int(
                    len(
                        set(
                            observation[
                                "ModelNo"
                            ]
                            for observation
                            in type_observations
                        )
                    )
                ),
            "CountMode":
                int(mode_count),
            "CountMin":
                int(
                    min(
                        count_values
                    )
                ),
            "CountMax":
                int(
                    max(
                        count_values
                    )
                ),
            "FixedCount":
                (
                    min(
                        count_values
                    )
                    ==
                    max(
                        count_values
                    )
                ),
            "AggregateStationTime":
                bool(
                    aggregate_time
                ),
            "BlockAnchorAfterMainFraction":
                _median(
                    first_main_anchor[
                        station_type
                    ],
                    1.0
                ),
            "HistoricalOrderRank":
                _median(
                    first_positions[
                        station_type
                    ],
                    1.0
                ),
            "PhysicalStationNumbers":
                physical_station_numbers,
            "PhysicalLayoutsByCount":
                physical_layouts,
            "StationOrdinals":
                ordinal_profiles,
            "StationOrdinalsByCount":
                _ordinals_by_count(type_observations),
        }

    return profiles


def _ordinals_by_count(type_observations):
    """Per-station learned values for each observed station COUNT.

    A layout with 3 parallel test stations (24 s CT) has other per-station
    times than a single merged test station (30 s CT); one median over both
    would be wrong for the tempo that is in the minority.
    """
    by_count = {}
    for count in sorted({int(o["TypeCount"]) for o in type_observations}):
        rows = [o for o in type_observations if int(o["TypeCount"]) == count]
        if len({o["ModelNo"] for o in rows}) < 3:
            continue
        ordinals = []
        for ordinal in range(1, count + 1):
            ordinal_rows = [o for o in rows if int(o["Ordinal"]) == ordinal]
            numbers = [o["StationNumber"] for o in ordinal_rows
                       if o["StationNumber"] is not None]
            ordinals.append({
                "Ordinal": ordinal,
                "MedianRelativePosition": _median(
                    [o["RelativePosition"] for o in ordinal_rows], 0.0),
                "MedianMainAnchor": _median(
                    [o["MainAnchor"] for o in ordinal_rows], 1.0),
                "MedianCycleTimeSeconds": _median(
                    [o["EffectiveCycleTime"] for o in ordinal_rows], 0.0),
                "MedianOperationCount": _median(
                    [o["OperationCount"] for o in ordinal_rows], 0.0),
                "ModePhysicalStationNumber": (
                    _mode_int(numbers, 0) if numbers else None),
                "MedianPhysicalStationNumber": (
                    _median(numbers, 0.0) if numbers else None),
            })
        by_count[str(count)] = ordinals
    return by_count


def _build_operation_station_profiles(
    sequence
):
    def build_profile(
        group
    ):
        values = (
            group[
                "StationType"
            ]
            .fillna(
                "Unknown"
            )
            .astype(str)
            .tolist()
        )

        counts = Counter(
            values
        )

        dominant_type, dominant_count = (
            counts.most_common(1)[0]
        )

        total = sum(
            counts.values()
        )

        station_numbers = []

        if "StationNumber" in group.columns:
            station_numbers = (
                pd.to_numeric(
                    group[
                        "StationNumber"
                    ],
                    errors="coerce"
                )
                .dropna()
                .astype(int)
                .tolist()
            )

        preferred_station_number = (
            float(
                statistics.median(
                    station_numbers
                )
            )
            if station_numbers
            else None
        )

        mode_station_number = (
            int(
                Counter(
                    station_numbers
                )
                .most_common(1)[0][0]
            )
            if station_numbers
            else None
        )

        process_positions = (
            pd.to_numeric(
                group[
                    "ProcessRelativePosition"
                ],
                errors="coerce"
            )
            .dropna()
            .astype(float)
            .tolist()
            if "ProcessRelativePosition"
            in group.columns
            else []
        )

        station_positions = (
            pd.to_numeric(
                group[
                    "StationRelativePosition"
                ],
                errors="coerce"
            )
            .dropna()
            .astype(float)
            .tolist()
            if "StationRelativePosition"
            in group.columns
            else []
        )

        within_station_positions = (
            pd.to_numeric(
                group[
                    "WithinStationRelativePosition"
                ],
                errors="coerce"
            )
            .dropna()
            .astype(float)
            .tolist()
            if "WithinStationRelativePosition"
            in group.columns
            else []
        )

        station_operation_sequences = (
            pd.to_numeric(
                group[
                    "StationOperationSequenceNumeric"
                ],
                errors="coerce"
            )
            .dropna()
            .astype(float)
            .tolist()
            if "StationOperationSequenceNumeric"
            in group.columns
            else []
        )

        return {
            "SampleCount":
                int(
                    len(
                        group
                    )
                ),
            "DominantStationType":
                dominant_type,
            "Confidence":
                (
                    float(
                        dominant_count
                    ) /
                    float(
                        total
                    )
                    if total
                    else 0.0
                ),
            "Counts":
                {
                    key:
                        int(
                            value
                        )
                    for (
                        key,
                        value
                    ) in counts.items()
                },
            "PreferredPhysicalStationNumber":
                preferred_station_number,
            "ModePhysicalStationNumber":
                mode_station_number,
            "MedianProcessRelativePosition":
                (
                    float(
                        statistics.median(
                            process_positions
                        )
                    )
                    if process_positions
                    else None
                ),
            "MedianStationRelativePosition":
                (
                    float(
                        statistics.median(
                            station_positions
                        )
                    )
                    if station_positions
                    else None
                ),
            "MedianWithinStationRelativePosition":
                (
                    float(
                        statistics.median(
                            within_station_positions
                        )
                    )
                    if within_station_positions
                    else None
                ),
            "MedianStationOperationSequence":
                (
                    float(
                        statistics.median(
                            station_operation_sequences
                        )
                    )
                    if station_operation_sequences
                    else None
                ),
        }

    result = {}

    for (
        operation_id,
        group
    ) in sequence.groupby(
        "CanonicalOperationId",
        sort=False
    ):
        profile = build_profile(
            group
        )

        occurrence_profiles = {}

        if "OccurrenceIndex" in group.columns:
            for (
                occurrence_index,
                occurrence_group
            ) in group.groupby(
                "OccurrenceIndex",
                sort=True
            ):
                occurrence_profiles[
                    str(
                        int(
                            occurrence_index
                        )
                    )
                ] = build_profile(
                    occurrence_group
                )

        profile[
            "OccurrenceProfiles"
        ] = occurrence_profiles

        result[
            str(
                operation_id
            )
        ] = profile

    return result


def _build_canonical_component_map(
    dataset_path,
    raw_library,
    mapping
):
    try:
        operations = pd.read_excel(
            dataset_path,
            sheet_name=
                "Method_Operations",
            engine=
                "openpyxl"
        )
    except Exception:
        return {}

    if (
        "OperationText"
        not in operations.columns
        or
        "Component"
        not in operations.columns
    ):
        return {}

    normalized_to_raw = {}

    for _, row in raw_library.iterrows():
        normalized = normalize_text(
            row.get(
                "NormalizedOperationText",
                ""
            )
        )

        raw_id = str(
            row.get(
                "OperationId",
                ""
            )
        )

        if (
            normalized
            and raw_id
        ):
            normalized_to_raw[
                normalized
            ] = raw_id

    component_counts = defaultdict(
        Counter
    )

    for _, row in operations.iterrows():
        component = row.get(
            "Component"
        )

        if (
            component is None
            or
            pd.isna(
                component
            )
        ):
            continue

        component_text = str(
            component
        ).strip()

        if not component_text:
            continue

        normalized_operation = (
            normalize_text(
                row.get(
                    "OperationText",
                    ""
                )
            )
        )

        raw_id = (
            normalized_to_raw.get(
                normalized_operation
            )
        )

        if not raw_id:
            continue

        canonical_id = mapping.get(
            raw_id
        )

        if not canonical_id:
            continue

        component_counts[
            str(
                canonical_id
            )
        ][
            component_text
        ] += 1

    result = {}

    for (
        canonical_id,
        counts
    ) in component_counts.items():
        if not counts:
            continue

        result[
            canonical_id
        ] = (
            counts
            .most_common(1)[0][0]
        )

    return result


def _evaluate_presence(rows):
    model_nos = np.array([
        str(row["ModelNo"]).split("__T", 1)[0]
        for row in rows
    ])

    if len(
        np.unique(model_nos)
    ) < 8:
        return {}

    splitter = GroupShuffleSplit(
        n_splits=1,
        test_size=0.20,
        random_state=42
    )

    train_index, test_index = next(
        splitter.split(
            np.zeros(
                len(rows)
            ),
            groups=model_nos
        )
    )

    vectorizer = DictVectorizer(
        sparse=True
    )

    x_train = vectorizer.fit_transform(
        [
            rows[index][
                "Feature"
            ]
            for index in train_index
        ]
    )

    x_test = vectorizer.transform(
        [
            rows[index][
                "Feature"
            ]
            for index in test_index
        ]
    )

    y_train = np.array([
        rows[index][
            "IsPresent"
        ]
        for index in train_index
    ])

    y_test = np.array([
        rows[index][
            "IsPresent"
        ]
        for index in test_index
    ])

    classifier = RandomForestClassifier(
        n_estimators=40,
        random_state=42,
        class_weight="balanced_subsample",
        n_jobs=1,
        max_depth=18,
        min_samples_leaf=1,
    )

    classifier.fit(
        x_train,
        y_train
    )

    prediction = classifier.predict(
        x_test
    )

    return {
        "presence_accuracy":
            float(
                accuracy_score(
                    y_test,
                    prediction
                )
            ),
        "presence_f1":
            float(
                f1_score(
                    y_test,
                    prediction,
                    zero_division=0
                )
            ),
    }


def _evaluate_regression(
    rows,
    target_name
):
    clean = [
        row
        for row in rows
        if not pd.isna(
            row[target_name]
        )
    ]

    if len(clean) < 30:
        return None

    model_nos = np.array([
        str(row["ModelNo"]).split("__T", 1)[0]
        for row in clean
    ])

    if len(
        np.unique(model_nos)
    ) < 8:
        return None

    splitter = GroupShuffleSplit(
        n_splits=1,
        test_size=0.20,
        random_state=42
    )

    train_index, test_index = next(
        splitter.split(
            np.zeros(
                len(clean)
            ),
            groups=model_nos
        )
    )

    vectorizer = DictVectorizer(
        sparse=True
    )

    x_train = vectorizer.fit_transform(
        [
            clean[index][
                "Feature"
            ]
            for index in train_index
        ]
    )

    x_test = vectorizer.transform(
        [
            clean[index][
                "Feature"
            ]
            for index in test_index
        ]
    )

    y_train = np.array([
        float(
            clean[index][
                target_name
            ]
        )
        for index in train_index
    ])

    y_test = np.array([
        float(
            clean[index][
                target_name
            ]
        )
        for index in test_index
    ])

    regressor = ExtraTreesRegressor(
        n_estimators=40,
        random_state=42,
        n_jobs=1,
        min_samples_leaf=1,
    )

    regressor.fit(
        x_train,
        y_train
    )

    prediction = regressor.predict(
        x_test
    )

    return float(
        mean_absolute_error(
            y_test,
            prediction
        )
    )


def _evaluate_station_type(rows):
    if len(rows) < 30:
        return None

    model_nos = np.array([
        str(row["ModelNo"]).split("__T", 1)[0]
        for row in rows
    ])

    if len(
        np.unique(model_nos)
    ) < 8:
        return None

    splitter = GroupShuffleSplit(
        n_splits=1,
        test_size=0.20,
        random_state=42
    )

    train_index, test_index = next(
        splitter.split(
            np.zeros(
                len(rows)
            ),
            groups=model_nos
        )
    )

    vectorizer = DictVectorizer(
        sparse=True
    )

    x_train = vectorizer.fit_transform(
        [
            rows[index][
                "Feature"
            ]
            for index in train_index
        ]
    )

    x_test = vectorizer.transform(
        [
            rows[index][
                "Feature"
            ]
            for index in test_index
        ]
    )

    y_train = np.array([
        rows[index][
            "StationType"
        ]
        for index in train_index
    ])

    y_test = np.array([
        rows[index][
            "StationType"
        ]
        for index in test_index
    ])

    classifier = RandomForestClassifier(
        n_estimators=40,
        random_state=42,
        n_jobs=1,
        class_weight="balanced_subsample",
    )

    classifier.fit(
        x_train,
        y_train
    )

    prediction = classifier.predict(
        x_test
    )

    return float(
        accuracy_score(
            y_test,
            prediction
        )
    )


def _next_version(models_root: Path):
    models_root.mkdir(
        parents=True,
        exist_ok=True
    )

    existing = []

    for path in models_root.glob(
        "V[0-9][0-9][0-9]"
    ):
        try:
            existing.append(
                int(
                    path.name[1:]
                )
            )
        except Exception:
            pass

    return (
        f"V{max(existing, default=0) + 1:03d}"
    )


def _production_info(models_root: Path):
    pointer = (
        models_root /
        "production.json"
    )

    if not pointer.exists():
        return None

    try:
        with open(
            pointer,
            "r",
            encoding="utf-8"
        ) as handle:
            return json.load(handle)

    except Exception:
        return None


def _overall_score(metrics):
    presence_f1 = (
        metrics.get(
            "presence_f1",
            0.0
        )
        or 0.0
    )

    duration_mae = metrics.get(
        "duration_mae_seconds",
        99.0
    )

    process_position_mae = metrics.get(
        "process_position_mae",
        1.0
    )

    station_type_accuracy = (
        metrics.get(
            "station_type_accuracy",
            0.0
        )
        or 0.0
    )

    return (
        float(presence_f1)
        + 0.15 *
        float(
            station_type_accuracy
        )
        - min(
            float(duration_mae),
            20.0
        ) / 100.0
        - min(
            float(
                process_position_mae
            ),
            1.0
        ) * 0.20
    )


def train_models(
    dataset_path: Path,
    models_root: Path
):
    if not dataset_path.exists():
        raise FileNotFoundError(
            "Training dataset bulunamadı: " +
            str(dataset_path)
        )

    (
        config,
        raw_library,
        raw_sequence,
        raw_stations,
    ) = read_training_dataset(
        dataset_path
    )

    approved = _approved_configs(
        config
    )

    approved_model_set = set(
        approved["ModelNo"].tolist()
    )

    (
        mapping,
        canonical_seed,
        review,
        embedding_engine,
    ) = build_canonical_operations(
        raw_library
    )

    sequence = _canonicalize_sequence(
        raw_sequence,
        mapping
    )

    sequence = sequence[
        sequence["ModelNo"].isin(
            approved_model_set
        )
    ].copy()

    stations = raw_stations[
        raw_stations["ModelNo"].isin(
            approved_model_set
        )
    ].copy()

    station_group_estimator, station_group_metrics = fit_station_group_model(
        sequence, approved
    )

    canonical_ids = sorted(
        sequence[
            "CanonicalOperationId"
        ]
        .dropna()
        .astype(str)
        .unique()
        .tolist()
    )

    station_type_profiles = (
        _build_station_type_profiles(
            stations,
            approved_model_set
        )
    )

    operation_station_profiles = (
        _build_operation_station_profiles(
            sequence
        )
    )

    canonical_component_map = (
        _build_canonical_component_map(
            dataset_path,
            raw_library,
            mapping
        )
    )

    aggregate_station_types = {
        station_type
        for (
            station_type,
            profile
        ) in station_type_profiles.items()
        if profile[
            "AggregateStationTime"
        ]
    }

    presence_rows = (
        _build_presence_training(
            approved,
            sequence,
            canonical_ids
        )
    )

    instance_rows = (
        _build_instance_training(
            approved,
            sequence
        )
    )

    metrics = _evaluate_presence(
        presence_rows
    )

    duration_training_rows = [
        row
        for row in instance_rows
        if (
            row["StationType"]
            not in aggregate_station_types
        )
    ]

    duration_mae = (
        _evaluate_regression(
            duration_training_rows,
            "Duration"
        )
    )

    if duration_mae is not None:
        metrics[
            "duration_mae_seconds"
        ] = duration_mae

    process_mae = (
        _evaluate_regression(
            instance_rows,
            "ProcessPosition"
        )
    )

    if process_mae is not None:
        metrics[
            "process_position_mae"
        ] = process_mae

    station_mae = (
        _evaluate_regression(
            instance_rows,
            "StationPosition"
        )
    )

    if station_mae is not None:
        metrics[
            "station_position_mae"
        ] = station_mae

    within_station_mae = (
        _evaluate_regression(
            instance_rows,
            "WithinStationPosition"
        )
    )

    if within_station_mae is not None:
        metrics[
            "within_station_position_mae"
        ] = within_station_mae

    station_type_accuracy = (
        _evaluate_station_type(
            instance_rows
        )
    )

    if station_type_accuracy is not None:
        metrics[
            "station_type_accuracy"
        ] = station_type_accuracy

    presence_vectorizer = DictVectorizer(
        sparse=True
    )

    x_presence = (
        presence_vectorizer.fit_transform(
            [
                row["Feature"]
                for row in presence_rows
            ]
        )
    )

    y_presence = np.array([
        row["IsPresent"]
        for row in presence_rows
    ])

    presence_model = RandomForestClassifier(
        n_estimators=60,
        random_state=42,
        class_weight="balanced_subsample",
        n_jobs=1,
        max_depth=20,
    )

    presence_model.fit(
        x_presence,
        y_presence
    )

    occurrence_model = ExtraTreesRegressor(
        n_estimators=60,
        random_state=42,
        n_jobs=1,
    )

    occurrence_model.fit(
        x_presence,
        np.array([
            row["OccurrenceCount"]
            for row in presence_rows
        ], dtype=float)
    )

    instance_vectorizer = DictVectorizer(
        sparse=True
    )

    x_instance = (
        instance_vectorizer.fit_transform(
            [
                row["Feature"]
                for row in instance_rows
            ]
        )
    )

    duration_row_indices = [
        index
        for (
            index,
            row
        ) in enumerate(
            instance_rows
        )
        if (
            row["StationType"]
            not in aggregate_station_types
            and not pd.isna(
                row["Duration"]
            )
        )
    ]

    if not duration_row_indices:
        raise ValueError(
            "Süre modeli için geçerli operasyon süresi bulunamadı."
        )

    duration_model = ExtraTreesRegressor(
        n_estimators=60,
        random_state=42,
        n_jobs=1,
    )

    duration_model.fit(
        x_instance[
            duration_row_indices
        ],
        np.array([
            float(
                instance_rows[index][
                    "Duration"
                ]
            )
            for index in
            duration_row_indices
        ])
    )

    process_indices = [
        index
        for (
            index,
            row
        ) in enumerate(
            instance_rows
        )
        if not pd.isna(
            row["ProcessPosition"]
        )
    ]

    process_position_model = (
        ExtraTreesRegressor(
            n_estimators=60,
            random_state=42,
            n_jobs=1,
        )
    )

    process_position_model.fit(
        x_instance[
            process_indices
        ],
        np.array([
            float(
                instance_rows[index][
                    "ProcessPosition"
                ]
            )
            for index in
            process_indices
        ])
    )

    station_indices = [
        index
        for (
            index,
            row
        ) in enumerate(
            instance_rows
        )
        if not pd.isna(
            row["StationPosition"]
        )
    ]

    station_position_model = (
        ExtraTreesRegressor(
            n_estimators=60,
            random_state=42,
            n_jobs=1,
        )
    )

    station_position_model.fit(
        x_instance[
            station_indices
        ],
        np.array([
            float(
                instance_rows[index][
                    "StationPosition"
                ]
            )
            for index in
            station_indices
        ])
    )

    within_station_indices = [
        index
        for (
            index,
            row
        ) in enumerate(
            instance_rows
        )
        if not pd.isna(
            row[
                "WithinStationPosition"
            ]
        )
    ]

    if not within_station_indices:
        raise ValueError(
            "İstasyon içi sıra modeli için eğitim verisi bulunamadı."
        )

    within_station_position_model = (
        ExtraTreesRegressor(
            n_estimators=100,
            random_state=42,
            n_jobs=1,
        )
    )

    within_station_position_model.fit(
        x_instance[
            within_station_indices
        ],
        np.array([
            float(
                instance_rows[index][
                    "WithinStationPosition"
                ]
            )
            for index in
            within_station_indices
        ])
    )

    station_type_model = (
        RandomForestClassifier(
            n_estimators=60,
            random_state=42,
            n_jobs=1,
            class_weight="balanced_subsample",
        )
    )

    station_type_model.fit(
        x_instance,
        np.array([
            row["StationType"]
            for row in instance_rows
        ])
    )

    (
        relations_df,
        precedence_edges,
    ) = _build_precedence(
        sequence
    )

    (
        same_station_relations_df,
        same_station_precedence_edges,
    ) = _build_same_station_precedence(
        sequence
    )

    (
        hard_bundle_relations_df,
        hard_bundle_edges,
    ) = _build_hard_bundle_edges(
        sequence
    )

    prevalence = (
        sequence
        .groupby(
            "CanonicalOperationId"
        )["ModelNo"]
        .nunique()
        /
        max(
            len(approved),
            1
        )
    ).to_dict()

    historical_max_occurrence = (
        sequence
        .groupby(
            [
                "ModelNo",
                "CanonicalOperationId",
            ]
        )
        .size()
        .groupby(
            "CanonicalOperationId"
        )
        .max()
        .to_dict()
    )

    canonical_name_map = (
        canonical_seed
        .set_index(
            "CanonicalOperationId"
        )["CanonicalName"]
        .to_dict()
    )

    note_operation_rules = (
        _build_note_operation_rules(
            approved,
            sequence,
            canonical_name_map,
        )
    )

    (
        process_block_relations_df,
        operation_block_map,
        process_block_order_edges,
    ) = _build_process_block_order(
        sequence,
        hard_bundle_edges,
        canonical_name_map,
    )

    (
        training_config_profiles,
        nearest_instance_history,
        known_note_segments,
        nearest_history_df,
    ) = _build_nearest_method_artifacts(
        approved,
        sequence,
    )

    canonical_rows = []

    for (
        operation_id,
        group
    ) in sequence.groupby(
        "CanonicalOperationId"
    ):
        times = pd.to_numeric(
            group[
                "OperationTimeSeconds"
            ],
            errors="coerce"
        ).dropna()

        station_profile = (
            operation_station_profiles.get(
                str(operation_id),
                {}
            )
        )

        canonical_rows.append({
            "CanonicalOperationId":
                operation_id,
            "CanonicalName":
                canonical_name_map.get(
                    operation_id,
                    operation_id
                ),
            "ModelCount":
                int(
                    group[
                        "ModelNo"
                    ].nunique()
                ),
            "OccurrenceCount":
                int(
                    len(group)
                ),
            "Prevalence":
                float(
                    prevalence.get(
                        operation_id,
                        0.0
                    )
                ),
            "MedianTimeSeconds":
                (
                    float(
                        times.median()
                    )
                    if len(times)
                    else np.nan
                ),
            "AverageTimeSeconds":
                (
                    float(
                        times.mean()
                    )
                    if len(times)
                    else np.nan
                ),
            "HistoricalMaxOccurrence":
                int(
                    historical_max_occurrence.get(
                        operation_id,
                        1
                    )
                ),
            "DominantStationType":
                station_profile.get(
                    "DominantStationType",
                    "Unknown"
                ),
            "StationTypeConfidence":
                station_profile.get(
                    "Confidence",
                    0.0
                ),
        })

    canonical_library = (
        pd.DataFrame(
            canonical_rows
        )
        .sort_values(
            [
                "Prevalence",
                "CanonicalOperationId",
            ],
            ascending=[
                False,
                True,
            ]
        )
    )

    version = _next_version(
        models_root
    )

    version_dir = (
        models_root /
        version
    )

    version_dir.mkdir(
        parents=True,
        exist_ok=False
    )

    # Source-approved rotation patterns are MODEL SPECIFIC. Do not copy
    # 33704217's pallet/cehennemlik sequence blindly to other models.
    approved_rotation_patterns = {}
    for source_model, group in sequence.groupby("ModelNo", sort=False):
        ordered_rows = group.sort_values(
            ["OperationSequence", "StationSequence"]
        )
        pattern = []
        for _, source_row in ordered_rows.iterrows():
            if str(source_row.get("StationType", "Main")) != "Main":
                continue
            op_id = str(source_row["CanonicalOperationId"])
            kind, angle = turn_kind(canonical_name_map.get(op_id, ""))
            if kind is None:
                continue
            pattern.append({
                "OperationId": op_id,
                "OccurrenceIndex": int(source_row.get("OccurrenceIndex", 1)),
                "Kind": kind,
                "Angle": angle,
                "OperationSequence": int(source_row["OperationSequence"]),
                "PhysicalStationNumber": (
                    int(source_row["StationNumber"])
                    if "StationNumber" in ordered_rows.columns and
                    not pd.isna(source_row.get("StationNumber")) else None
                ),
            })
        approved_rotation_patterns[str(source_model)] = pattern

    reorder_evidence, reorder_metrics = fit_reorder_evidence(
        sequence, approved, canonical_name_map
    )

    bundle = {
        "reorder_evidence": reorder_evidence,
        "reorder_metrics": reorder_metrics,
        "engine_schema_version": ENGINE_SCHEMA_VERSION,
        "tempo_learning_mode": (
            "CONTINUOUS_CYCLE_TIME_ML"
            if any("__T" in str(m) for m in approved["ModelNo"])
            else "LEGACY_SINGLE_TEMPO"
        ),
        "observed_cycle_times_seconds": sorted(set(
            round(float(x), 5) for x in
            pd.to_numeric(approved.get("ConfigReferenceCycleTimeSeconds"),
                          errors="coerce").dropna().tolist()
            if float(x) > 0
        )) if "ConfigReferenceCycleTimeSeconds" in approved else [],
        "rotation_patterns_by_model": approved_rotation_patterns,
        "station_group_estimator": station_group_estimator,
        "station_group_metrics": station_group_metrics,
        "version":
            version,
        "config_fields":
            CONFIG_FIELDS,
        "canonical_ids":
            canonical_ids,
        "canonical_name_map":
            canonical_name_map,
        "prevalence":
            prevalence,
        "historical_max_occurrence":
            historical_max_occurrence,
        "presence_vectorizer":
            presence_vectorizer,
        "presence_model":
            presence_model,
        "occurrence_model":
            occurrence_model,
        "instance_vectorizer":
            instance_vectorizer,
        "duration_model":
            duration_model,
        "process_position_model":
            process_position_model,
        "station_position_model":
            station_position_model,
        "within_station_position_model":
            within_station_position_model,
        "station_type_model":
            station_type_model,
        "station_type_profiles":
            station_type_profiles,
        "operation_station_profiles":
            operation_station_profiles,
        "canonical_component_map":
            canonical_component_map,
        "precedence_edges":
            precedence_edges,
        "same_station_precedence_edges":
            same_station_precedence_edges,
        "hard_bundle_edges":
            hard_bundle_edges,
        "operation_block_map":
            operation_block_map,
        "process_block_order_edges":
            process_block_order_edges,
        "note_operation_rules":
            note_operation_rules,
        "training_config_profiles":
            training_config_profiles,
        "nearest_instance_history":
            nearest_instance_history,
        "known_note_segments":
            known_note_segments,
        "training_family":
            sorted(
                set(
                    str(value)
                    for value in approved[
                        "CataPyro"
                    ].dropna()
                )
            ),
        "training_model_types":
            sorted(
                set(
                    str(value)
                    for value in approved[
                        "ModelType"
                    ].dropna()
                )
            ),
    }

    joblib.dump(
        bundle,
        version_dir /
        "model_bundle.joblib",
        compress=1
    )

    save_json(version_dir / "station_group_metrics.json", station_group_metrics)

    canonical_library.to_csv(
        version_dir /
        "canonical_operation_library.csv",
        index=False,
        encoding="utf-8-sig"
    )

    relations_df.to_csv(
        version_dir /
        "precedence_relations.csv",
        index=False,
        encoding="utf-8-sig"
    )

    pd.DataFrame(
        precedence_edges
    ).to_csv(
        version_dir /
        "precedence_edges.csv",
        index=False,
        encoding="utf-8-sig"
    )

    same_station_relations_df.to_csv(
        version_dir /
        "same_station_precedence_relations.csv",
        index=False,
        encoding="utf-8-sig"
    )

    pd.DataFrame(
        same_station_precedence_edges
    ).to_csv(
        version_dir /
        "same_station_precedence_edges.csv",
        index=False,
        encoding="utf-8-sig"
    )

    hard_bundle_relations_df.to_csv(
        version_dir /
        "hard_bundle_relations.csv",
        index=False,
        encoding="utf-8-sig"
    )

    pd.DataFrame(
        hard_bundle_edges
    ).to_csv(
        version_dir /
        "hard_bundle_edges.csv",
        index=False,
        encoding="utf-8-sig"
    )

    process_block_relations_df.to_csv(
        version_dir /
        "process_block_order_relations.csv",
        index=False,
        encoding="utf-8-sig"
    )

    pd.DataFrame(
        process_block_order_edges
    ).to_csv(
        version_dir /
        "process_block_order_edges.csv",
        index=False,
        encoding="utf-8-sig"
    )

    save_json(
        version_dir /
        "operation_block_map.json",
        operation_block_map
    )

    pd.DataFrame(
        note_operation_rules
    ).to_csv(
        version_dir /
        "note_operation_rules.csv",
        index=False,
        encoding="utf-8-sig"
    )

    save_json(
        version_dir /
        "note_operation_rules.json",
        note_operation_rules
    )

    save_json(
        version_dir /
        "training_config_profiles.json",
        training_config_profiles
    )

    save_json(
        version_dir /
        "known_note_segments.json",
        known_note_segments
    )

    nearest_history_df.to_csv(
        version_dir /
        "nearest_instance_history.csv",
        index=False,
        encoding="utf-8-sig"
    )

    sequence.to_csv(
        version_dir /
        "training_operation_instances.csv",
        index=False,
        encoding="utf-8-sig"
    )

    save_json(
        version_dir /
        "station_type_profiles.json",
        station_type_profiles
    )

    save_json(
        version_dir /
        "operation_station_profiles.json",
        operation_station_profiles
    )

    station_profile_rows = []

    for (
        station_type,
        profile
    ) in station_type_profiles.items():
        for station_profile in profile[
            "StationOrdinals"
        ]:
            station_profile_rows.append({
                "StationType":
                    station_type,
                "CountMode":
                    profile["CountMode"],
                "FixedCount":
                    profile["FixedCount"],
                "AggregateStationTime":
                    profile[
                        "AggregateStationTime"
                    ],
                "BlockAnchorAfterMainFraction":
                    profile[
                        "BlockAnchorAfterMainFraction"
                    ],
                "HistoricalOrderRank":
                    profile[
                        "HistoricalOrderRank"
                    ],
                "Ordinal":
                    station_profile["Ordinal"],
                "MedianRelativePosition":
                    station_profile[
                        "MedianRelativePosition"
                    ],
                "MedianMainAnchor":
                    station_profile[
                        "MedianMainAnchor"
                    ],
                "MedianCycleTimeSeconds":
                    station_profile[
                        "MedianCycleTimeSeconds"
                    ],
                "MedianOperationCount":
                    station_profile[
                        "MedianOperationCount"
                    ],
            })

    if review is None:
        review = pd.DataFrame()

    with pd.ExcelWriter(
        version_dir /
        "Canonical_Review.xlsx",
        engine="openpyxl"
    ) as writer:
        review.to_excel(
            writer,
            sheet_name=
                "Similarity_Review",
            index=False
        )

        canonical_library.to_excel(
            writer,
            sheet_name=
                "Canonical_Library",
            index=False
        )

        relations_df.head(
            5000
        ).to_excel(
            writer,
            sheet_name=
                "Precedence",
            index=False
        )

        pd.DataFrame(
            station_profile_rows
        ).to_excel(
            writer,
            sheet_name=
                "Station_Profiles",
            index=False
        )

    metrics[
        "overall_score"
    ] = _overall_score(
        metrics
    )

    save_json(
        version_dir /
        "metrics.json",
        metrics
    )

    manifest = {
        "engine_schema_version":
            ENGINE_SCHEMA_VERSION,
        "version":
            version,
        "dataset":
            str(dataset_path),
        "model_count":
            int(
                len(approved)
            ),
        "raw_operation_count":
            int(
                len(raw_library)
            ),
        "canonical_operation_count":
            int(
                len(canonical_ids)
            ),
        "instance_count":
            int(
                len(sequence)
            ),
        "embedding_engine":
            embedding_engine,
        "station_type_profiles":
            station_type_profiles,
        "metrics":
            metrics,
    }

    save_json(
        version_dir /
        "manifest.json",
        manifest
    )

    current = _production_info(
        models_root
    )

    promote = False

    if current is None:
        promote = True

    elif int(
        current.get(
            "engine_schema_version",
            1
        )
    ) < ENGINE_SCHEMA_VERSION:
        promote = True

    else:
        old_score = float(
            current.get(
                "overall_score",
                -999.0
            )
        )

        if (
            metrics[
                "overall_score"
            ] >= old_score
        ):
            promote = True

    if promote:
        save_json(
            models_root /
            "production.json",
            {
                "engine_schema_version":
                    ENGINE_SCHEMA_VERSION,
                "version":
                    version,
                "overall_score":
                    metrics[
                        "overall_score"
                    ],
                "model_dir":
                    str(
                        version_dir
                    ),
            }
        )

    return {
        "version":
            version,
        "is_production":
            promote,
        "model_count":
            int(
                len(approved)
            ),
        "raw_operation_count":
            int(
                len(raw_library)
            ),
        "canonical_operation_count":
            int(
                len(canonical_ids)
            ),
        "instance_count":
            int(
                len(sequence)
            ),
        "metrics":
            metrics,
        "model_dir":
            str(
                version_dir
            ),
    }