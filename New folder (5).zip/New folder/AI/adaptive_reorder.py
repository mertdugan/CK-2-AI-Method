# -*- coding: utf-8 -*-
"""CT-first staff improvement search, with a tightly audited single inversion.

The proposal retains ALL operations, pallet angles and rotation chronology.
Changing even one pair of manufacturing operations requires shopfloor review;
this module explicitly refuses to label its proposals production-approved.
"""
from __future__ import annotations

import math


def _turn(op):
    name = str(op.get("CanonicalName") or "").lower()
    kind = str(op.get("OrientationTurnKind") or "").upper()
    return (kind in {"PALLET", "PALLET_TURN"} or
            (("palet" in name or "cehennemli" in name) and
             ("çevir" in name or "cevir" in name or "döndür" in name)))


def _protected(op):
    rule = str(op.get("EngineeringRule") or "").upper()
    return (op.get("ForcedPhysicalStationNumber") is not None
            or "STANDARD_CEHENNEMLIK_LABEL" in rule
            or "KAPI_ETIKETI_CONFIG" in rule)


def _approved_edge(a, b, edges):
    ai, bi = str(a.get("CanonicalOperationId")), str(b.get("CanonicalOperationId"))
    for edge in edges or ():
        source = str(edge.get("ConstraintSource") or edge.get("RuleSource") or "").upper()
        if edge.get("EngineeringApproved") is True or edge.get("IsApproved") is True or source in {
            "ENGINEERING_APPROVED", "HARD_TOOLING", "PHYSICAL_FIXTURE", "PHYSICAL_PROCESS", "SAFETY"
        }:
            if str(edge.get("Source")) == ai and str(edge.get("Target")) == bi:
                return True
    return False


def _safe_to_propose(a, b, edges):
    if _turn(a) or _turn(b) or _protected(a) or _protected(b):
        return False
    if a.get("AdaptiveMandatoryBoundaryAfter"):
        return False
    sa = a.get("PreservedReferenceStationSequence")
    sb = b.get("PreservedReferenceStationSequence")
    if sa is not None and sa == sb:
        return False  # real within-station order is non-negotiable
    if _approved_edge(a, b, edges):
        return False
    name_a = str(a.get("CanonicalName") or "").lower()
    name_b = str(b.get("CanonicalName") or "").lower()
    # Never reverse an inspection after its own assembly, or the direction
    # of a screw-gun sequence. This screen is conservative, not a safety proof.
    if any(word in name_b for word in ("kontrol", "test et", "doğrula")):
        return False
    if "vida" in name_a and "vida" in name_b:
        return False
    if "düğme" in name_b and ("termostat" in name_a or "testata" in name_a):
        return False
    return True


def propose_single_reorder(operations, candidates, max_station_load, incumbent,
                            ordered_dp, precedence_edges=None, hard_bundle_edges=None):
    """Return only a STRICTLY SMALLER feasible crew proposal or None.

    The DP is the existing approved physical station allocator. The operation
    content/time never changes. Each result is rescored against the current
    incumbent; a swap suggestion is never equivalent to production approval.
    """
    if not incumbent or len(operations) < 2:
        return None
    current = len(incumbent.get("UsedCandidateIndices") or [])
    best = None
    for i in range(len(operations) - 1):
        a, b = operations[i], operations[i + 1]
        if not _safe_to_propose(a, b, precedence_edges):
            continue
        # Keep the same orientation phase and forbid a cross-process jump.
        if (a.get("OrientationPhase") is not None and
            b.get("OrientationPhase") is not None and
            a["OrientationPhase"] != b["OrientationPhase"]):
            continue
        swapped = list(operations)
        swapped[i], swapped[i+1] = swapped[i+1], swapped[i]
        candidate = ordered_dp(swapped, candidates, max_station_load,
                               hard_bundle_edges=hard_bundle_edges,
                               movement_radius=None, pallet_radius=None)
        if not candidate:
            continue
        crew = len(candidate.get("UsedCandidateIndices") or [])
        if crew >= current:
            continue
        permuted_positions = candidate["AssignedCandidateIndices"]
        if len(permuted_positions) != len(operations):
            continue
        # Map physical station assignments back to source operation identity.
        slots = list(permuted_positions)
        slots[i], slots[i+1] = slots[i+1], slots[i]
        # No inverted assignment except exactly the proposed adjacent pair.
        violations = [(j, j+1) for j in range(len(slots)-1)
                      if slots[j] > slots[j+1]]
        if violations != [(i, i+1)]:
            continue
        if any(_turn(op) and slots[j] != permuted_positions[j]
               for j, op in enumerate(operations) if j not in (i, i+1)):
            continue
        if any(not math.isfinite(float(op.get("PredictedTimeSeconds") or 0))
               for op in operations):
            continue
        # Independent physical allocation audit, including per-station load.
        loads = {}
        for j, op in enumerate(operations):
            physical = candidates[slots[j]]
            if op.get("ForcedPhysicalStationNumber") is not None and int(
                op["ForcedPhysicalStationNumber"]) != int(physical):
                break
            loads[slots[j]] = loads.get(slots[j], 0.0) + float(op.get("PredictedTimeSeconds") or 0)
        else:
            if any(x > max_station_load + 1e-6 for x in loads.values()):
                continue
            used = sorted(loads)
            if len(used) != crew:
                continue
            evidence = a.get("ObservedReorderWithNext") or {}
            probability = a.get("LearnedSameStationWithNextProbability")
            try:
                grouping = float(probability) if probability is not None else 0.5
            except (TypeError, ValueError):
                grouping = 0.5
            # A recorded reversal from real methods improves ranking, not safety.
            support = int(evidence.get("source_count", 0))
            key = (crew, -int(bool(evidence.get("cross_tempo_same_model"))),
                   -support, grouping, i)
            if best is not None and key >= best[0]:
                continue
            result = dict(candidate)
            result["AssignedCandidateIndices"] = slots
            result["UsedCandidateIndices"] = used
            result["Status"] = "ENGINEERING_REVIEW_REQUIRED_LEARNED_REORDER"
            result["CrossOrderChanges"] = 1
            result["ReviewSwap"] = [
                {"Id": str(op.get("CanonicalOperationId")),
                 "Name": str(op.get("CanonicalName")),
                 "Occurrence": int(op.get("OccurrenceIndex") or 1)}
                for op in (a, b)
            ]
            result["LearnedOrderEvidence"] = evidence
            result["ChangedSourcePairIndex"] = i
            best = (key, result)
    return best[1] if best else None
