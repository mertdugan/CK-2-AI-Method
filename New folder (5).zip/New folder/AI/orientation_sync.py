# -*- coding: utf-8 -*-
"""CK-2 AI Metod: physically safe rotation synchronisation.

A PALLET turn changes the oven's orientation. A CEHENNEMLIK turn is
classified as COMPONENT handling until an engineer confirms otherwise.
Neither is allowed to cross the operations before/after the turn.

The station number may change after line balancing. The PROCESS position
of a turn relative to the tasks that require its before/after state cannot.
"""
from __future__ import annotations

from collections import Counter
import re
from typing import Iterable, Mapping, MutableMapping, Sequence


def normalise(value):
    text = str(value or "").upper().translate(str.maketrans({
        "İ": "I", "ı": "I", "Ş": "S", "ş": "S",
        "Ğ": "G", "ğ": "G", "Ü": "U", "ü": "U",
        "Ö": "O", "ö": "O", "Ç": "C", "ç": "C",
    }))
    text = text.replace("°", " DERECE ")
    return re.sub(r"\s+", " ", text).strip()


def turn_kind(name):
    """Return (kind, degrees). No inference from generic 'çevir' wording."""
    text = normalise(name)
    if not re.search(r"\b(?:CEVIR\w*|DONDUR\w*)\b", text):
        return None, None
    match = re.search(r"(?<!\d)(90|180)(?!\d)(?:\s*DERECE)?", text)
    if not match:
        return None, None
    degrees = int(match.group(1))
    if "PALET" in text:
        return "PALLET", degrees
    if "CEHENNEMLI" in text:
        return "COMPONENT", degrees
    return None, None


def is_pallet_turn(name):
    return turn_kind(name)[0] == "PALLET"


def is_process_turn(name):
    return turn_kind(name)[0] in {"PALLET", "COMPONENT"}


def identity(operation):
    instance = operation.get("InstanceId")
    if instance:
        return str(instance)
    return "{}#{}".format(
        operation.get("CanonicalOperationId", ""),
        int(operation.get("OccurrenceIndex") or 1),
    )


def _reference_key(op):
    return (
        int(op.get("PreservedReferenceStationSequence") or 0),
        int(op.get("PreservedReferenceStationOperationSequence") or 0),
    )


def reference_chronology(operations):
    ops = list(operations)
    main = [op for op in ops if str(op.get("PredictedStationType", "Main")) == "Main"]
    if not main:
        return []
    keys = [_reference_key(op) for op in main]
    has_ref = all(a > 0 and b > 0 for a, b in keys)
    if has_ref:
        if len(set(keys)) != len(keys):
            raise ValueError("Yön senkronu: referans istasyon/işlem sıra numaraları çakışıyor.")
        main.sort(key=_reference_key)
    else:
        main.sort(key=lambda op: (
            int(op.get("PredictedProcessSequence") or 0),
            float(op.get("PredictedProcessPosition") or 0.0),
            identity(op),
        ))
    return main


def mark_orientation_phases(operations):
    """Mark ALL physical rotations independent of historical sample count."""
    ordered = reference_chronology(operations)
    phase = 0
    oven_heading = 0
    turn_index = 0
    component_index = 0
    found = Counter()
    for op in ordered:
        kind, degrees = turn_kind(op.get("CanonicalName", ""))
        op["OrientationPhase"] = phase
        op["OrientationBeforeDegrees"] = oven_heading
        if kind:
            phase += 1
            op["OrientationPhase"] = phase
            op["OrientationTurnKind"] = kind
            op["OrientationTurnDegrees"] = degrees
            op["OrientationSyncAnchor"] = True
            if kind == "PALLET":
                turn_index += 1
                oven_heading = (oven_heading + degrees) % 360
                op["IsPalletOrientationAnchor"] = True
                op["PalletTurnIndex"] = turn_index
            else:
                component_index += 1
                op["IsComponentRotationAnchor"] = True
                op["ComponentTurnIndex"] = component_index
                op["IsPalletOrientationAnchor"] = False
            op["OrientationAfterDegrees"] = oven_heading
            rule = "ROTATION_SYNC_{}_{}".format(kind, degrees)
            existing_rule = str(op.get("EngineeringRule") or "")
            if rule not in existing_rule.split(";"):
                op["EngineeringRule"] = (
                    existing_rule + (";" if existing_rule else "") + rule
                )
            found[(kind, degrees)] += 1
        else:
            op["OrientationSyncAnchor"] = False
            op["IsPalletOrientationAnchor"] = False
            op["IsComponentRotationAnchor"] = False
            op["OrientationAfterDegrees"] = oven_heading
    return ordered, found


def orientation_phases(operations):
    """Boundaries immediately BEFORE and AFTER each turn, including components."""
    if not operations:
        return []
    phases, pending = [], []
    for index, op in enumerate(operations):
        kind, degrees = turn_kind(op.get("CanonicalName", ""))
        if kind:
            if pending:
                phases.append(pending)
            phases.append([index])  # This operation is the physical transition.
            pending = []
        else:
            pending.append(index)
        if op.get("AdaptiveMandatoryBoundaryAfter"):
            if pending:
                phases.append(pending)
                pending = []
    if pending:
        phases.append(pending)
    return phases


def _placed_key(op):
    order = op.get("DisplayOrder", op.get("AssignedStation"))
    within = op.get("StationOperationSequence")
    if order is None or within is None:
        raise ValueError("Yön senkronu: istasyon veya istasyon içi sıra eksik.")
    return int(order), int(within)


def validate_orientation(before, after):
    """Fail closed if rotating the product out of sequence becomes possible."""
    source_main = reference_chronology(before)
    actual_main = [op for op in after if str(
        op.get("AssignedStationType", op.get("PredictedStationType", "Main"))) == "Main"]
    by_id = {identity(op): op for op in actual_main}
    if len(by_id) != len(actual_main):
        raise ValueError("Yön senkronu: tahminde tekrarlanan operasyon kimliği var.")
    missing = [identity(op) for op in source_main if identity(op) not in by_id]
    if missing:
        raise ValueError("Yön senkronu: operasyonda kayıp var: " + ", ".join(missing[:5]))
    # Structural order: every operation before a rotation is physically
    # before that rotation, and every operation after is physically after it.
    barriers = [i for i, op in enumerate(source_main)
                if is_process_turn(op.get("CanonicalName"))]
    bad = []
    for barrier_index in barriers:
        turning = source_main[barrier_index]
        turn_actual = by_id[identity(turning)]
        pivot = _placed_key(turn_actual)
        for op in source_main[:barrier_index]:
            if _placed_key(by_id[identity(op)]) > pivot:
                bad.append((identity(op), identity(turning), "BEFORE"))
        for op in source_main[barrier_index + 1:]:
            if _placed_key(by_id[identity(op)]) < pivot:
                bad.append((identity(op), identity(turning), "AFTER"))
        if bad:
            break
    if bad:
        task, anchor, side = bad[0]
        raise ValueError(
            "YÖN SENKRONU BOZULDU: {} işlemi, {} dönüşünün {} "
            "tarafına geçmiş. İşlem/istasyon sırası düzeltilmeden "
            "bu metod üretime sunulamaz.".format(task, anchor, side)
        )
    expected = [(identity(op), turn_kind(op.get("CanonicalName")))
                for op in source_main if is_process_turn(op.get("CanonicalName"))]
    actual = [(identity(op), turn_kind(op.get("CanonicalName")))
              for op in sorted(actual_main, key=_placed_key)
              if is_process_turn(op.get("CanonicalName"))]
    if expected != actual:
        raise ValueError("YÖN SENKRONU BOZULDU: 90/180 dönüş sırası veya adedi değişti.")
    return {
        "pallet_turns": sum(kind == "PALLET" for _, (kind, _) in expected),
        "component_turns": sum(kind == "COMPONENT" for _, (kind, _) in expected),
        "total_turns": len(expected),
        "status": "PRESERVED",
    }
