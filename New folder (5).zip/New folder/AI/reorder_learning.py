# -*- coding: utf-8 -*-
"""Evidence from real, approved methods that two operations may trade places.

This is observational ML evidence, NEVER an engineering authorization.
It is collected from REAL methods and contributes a ranking to the controlled
staffing improvement proposal. Different models' operation inventories and
pallet orientation sequences must not be copied into the target model.
"""
from __future__ import annotations

from collections import defaultdict
from itertools import combinations
import re


def _model_base(value):
    return re.sub(r"__T\d+$", "", str(value), flags=re.I)


def _instance(row):
    return (str(row.get("CanonicalOperationId") or ""),
            int(row.get("OccurrenceIndex") or 1))


def _turn(name):
    text = str(name or "").lower()
    return (("palet" in text or "cehennemli" in text)
            and ("çevir" in text or "cevir" in text or "döndür" in text))


def fit_reorder_evidence(sequence, approved, canonical_name_map):
    """Capture opposite REAL orders only inside the same orientation segment.

    Keeping source-model identity lets the learner distinguish independence
    evidence across tempo from purely different model configurations. A turn
    is a segment barrier, irrespective of 90 / 180 degrees.
    """
    approved_keys = set(approved["ModelNo"].astype(str))
    observations = defaultdict(list)
    seen_method = set()
    for key, group in sequence.groupby("ModelNo", sort=False):
        if str(key) not in approved_keys:
            continue
        main = group[group["StationType"].astype(str).str.lower() == "main"]
        main = main.sort_values(["OperationSequence", "StationSequence"])
        segment = []
        def flush():
            if not segment:
                return
            # Short-range evidence only: distant operations coexisting in a
            # phase does not prove that changing order is safe.
            for a, b in combinations(range(len(segment)), 2):
                if b - a > 10:
                    continue
                left, right = segment[a], segment[b]
                ka, kb = _instance(left), _instance(right)
                if ka == kb or not all([ka[0], kb[0]]):
                    continue
                pair = tuple(sorted((ka, kb)))
                sign = 1 if pair[0] == ka else -1
                observations[pair].append((str(key), _model_base(key), sign))
        for row in main.to_dict("records"):
            name = canonical_name_map.get(str(row.get("CanonicalOperationId")), "")
            if _turn(name):
                flush()
                segment = []
                continue
            segment.append(row)
        flush()
        seen_method.add(str(key))
    result = {}
    for pair, examples in observations.items():
        directions = {1: set(), -1: set()}
        models = {1: set(), -1: set()}
        for key, base, sign in examples:
            directions[sign].add(key)
            models[sign].add(base)
        if not directions[1] or not directions[-1]:
            continue
        # Different actual method examples show reversal. This remains a
        # review proposal unless physical engineering confirms independence.
        signature = "|".join(f"{a[0]}#{a[1]}" for a in pair)
        result[signature] = {
            "forward_methods": len(directions[1]),
            "reverse_methods": len(directions[-1]),
            "cross_tempo_same_model": bool(models[1] & models[-1]),
            "source_count": len(directions[1] | directions[-1]),
        }
    return result, {
        "method_count": len(seen_method),
        "observed_reversible_pairs": len(result),
        "status": "OBSERVATIONAL_NOT_ENGINEERING_APPROVED",
    }


def annotate_reorder_evidence(operations, bundle):
    evidence = bundle.get("reorder_evidence") or {}
    n = 0
    main = [op for op in operations
            if str(op.get("PredictedStationType", "Main")) == "Main"]
    for a, b in zip(main, main[1:]):
        pair = sorted((_instance(a), _instance(b)))
        key = "|".join(f"{x[0]}#{x[1]}" for x in pair)
        found = evidence.get(key)
        if not found:
            continue
        a["ObservedReorderWithNext"] = dict(found)
        n += 1
    return n
