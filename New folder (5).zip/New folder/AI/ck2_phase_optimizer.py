# -*- coding: utf-8 -*-
"""CK-2: real station-reassignment search, with audited rotation chronology.

This is NOT a time-reduction simulation. It preserves the input operation
inventory and recorded durations. A layout reversing any operation precedence
is flagged ENGINEERING_REVIEW_REQUIRED, never silently certified for production.

SciPy/HiGHS is required (already listed in CK-2's requirements.txt).
"""
from __future__ import annotations

import math
from collections import defaultdict


def _float(value, default=None):
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (ValueError, TypeError, OverflowError):
        return default


def _key(operation):
    return (str(operation.get('CanonicalOperationId') or ''),
            int(operation.get('OccurrenceIndex') or 1))


def _certified(edge):
    source = str(edge.get('ConstraintSource') or edge.get('RuleSource') or '').upper()
    return (edge.get('EngineeringApproved') is True
            or edge.get('IsApproved') is True
            or source in {'ENGINEERING_APPROVED', 'HARD_TOOLING',
                          'PHYSICAL_FIXTURE', 'PHYSICAL_PROCESS', 'SAFETY'})


def _station_candidates(operations, current_stations, target_count, removed_station=None):
    """Keep actual physical numbers, particularly 1 and the final door label."""
    from collections import Counter
    if len(current_stations) <= target_count:
        return None
    if len(current_stations) != target_count + 1:
        return None  # one real physical workstation at a time
    fixed = {int(x['ForcedPhysicalStationNumber']) for x in operations
             if x.get('ForcedPhysicalStationNumber') is not None}
    for op in operations:
        rule = str(op.get('EngineeringRule') or '').upper()
        physical = _float(op.get('PhysicalStationNumber'))
        if physical is not None and ('STANDARD_CEHENNEMLIK_LABEL' in rule
                                    or 'KAPI_ETIKETI_CONFIG' in rule):
            fixed.add(int(physical))
    turns = Counter(int(_float(op.get('PhysicalStationNumber'), -1))
                    for op in operations if op.get('IsPalletOrientationAnchor'))
    loads = defaultdict(float)
    for op in operations:
        number = _float(op.get('PhysicalStationNumber'))
        if number is not None:
            loads[int(number)] += max(0, _float(op.get('PredictedTimeSeconds'), 0))
    possible = [num for num in current_stations
                if num not in fixed and num != current_stations[0]
                and num != current_stations[-1] and turns[num] == 0]
    if not possible:
        possible = [num for num in current_stations
                    if num not in fixed and num not in (current_stations[0], current_stations[-1])]
    if not possible:
        return None
    if removed_station is not None and removed_station not in possible:
        return None
    remove = removed_station if removed_station is not None else min(possible, key=lambda num:(loads[num], num))
    return [num for num in current_stations if num != remove], remove


def _ordered_exact_dp(items, candidates, removed, max_load,
                      precedence_edges=None, hard_bundle_edges=None):
    """Exact ordered segmentation: no solver timeout, no operation reorder.

    This is a STRICT solver: it permits no backwards reassignment and
    refuses unsupported certified precedence/bundling conflicts.
    """
    from collections import defaultdict
    from line_balancer import _first_station_pallet_limit
    first_turn_limit = _first_station_pallet_limit(items)
    n, k = len(items), len(candidates)
    if not n or not k:
        return None
    times = [_float(op.get('PredictedTimeSeconds')) for op in items]
    if any(t is None or t < 0 or t > max_load + 1e-7 for t in times):
        return None
    sums = [0.0]
    turns = [0]
    for t, op in zip(times, items):
        sums.append(sums[-1] + t)
        turns.append(turns[-1] + int(bool(op.get('IsPalletOrientationAnchor'))))

    # Never separate approved co-location bundles, repeated screw work,
    # or tray/grill loading; a boundary index b separates b-1 from b.
    unsplittable = set()
    ids = defaultdict(list)
    occurrences = {}
    for i, op in enumerate(items):
        oid = str(op.get('CanonicalOperationId') or '')
        ids[oid].append(i)
        occurrences[_key(op)] = i
    for oid, positions in ids.items():
        for a, b in zip(positions, positions[1:]):
            name = str(items[a].get('CanonicalName') or '').lower()
            if (b == a + 1 and 'vida' in name
                    and name == str(items[b].get('CanonicalName') or '').lower()
                    and items[a].get('PhysicalStationNumber') == items[b].get('PhysicalStationNumber')):
                unsplittable.update(range(a+1,b+1))
    tray = [i for i, op in enumerate(items)
            if ('tepsi' in str(op.get('CanonicalName') or '').lower()
                or 'ızgara' in str(op.get('CanonicalName') or '').lower())
            and ('yerleştir' in str(op.get('CanonicalName') or '').lower()
                 or 'koy' in str(op.get('CanonicalName') or '').lower())]
    if tray:
        unsplittable.update(range(min(tray)+1,max(tray)+1))
    for edge in hard_bundle_edges or ():
        if not _certified(edge):
            continue
        a = occurrences.get((str(edge.get('Source') or ''),int(edge.get('SourceOccurrenceIndex') or 1)))
        b = occurrences.get((str(edge.get('Target') or ''),int(edge.get('TargetOccurrenceIndex') or 1)))
        if a is None or b is None:
            return None
        unsplittable.update(range(min(a,b)+1,max(a,b)+1))
    for edge in precedence_edges or ():
        if not _certified(edge):
            continue
        aa=ids.get(str(edge.get('Source') or ''), [])
        bb=ids.get(str(edge.get('Target') or ''), [])
        if aa and bb and aa[-1] > bb[0]:
            return None

    forced = {}
    for i, op in enumerate(items):
        value = op.get('ForcedPhysicalStationNumber')
        rule = str(op.get('EngineeringRule') or '').upper()
        if value is None and 'STANDARD_CEHENNEMLIK_LABEL' in rule:
            value = 1
        if value is None and 'KAPI_ETIKETI_CONFIG' in rule:
            value = op.get('PhysicalStationNumber')
        if value is None:
            continue
        try:
            value = int(value)
        except (TypeError,ValueError):
            return None
        if value not in candidates:
            return None
        forced[i] = value

    # Explicit orientation phase boundaries cannot be crossed backwards.
    phases=[]
    current=0
    for op in items:
        phase=op.get('OrientationPhase')
        if phase is None:
            if op.get('IsPalletOrientationAnchor'):
                current+=1
            phase=current
        try:
            phase=int(phase)
        except (ValueError,TypeError):
            return None
        phases.append(phase)
    if any(a>b for a,b in zip(phases,phases[1:])):
        return None

    # DP state: station index, operation prefix. Find the most balanced
    # feasible partition, without changing any duration or operation order.
    dp=[{0:(0.0,None)}]
    for station_index, number in enumerate(candidates):
        prev=dp[-1]
        next_states={}
        for start, (score, _) in prev.items():
            for end in range(start+1,n+1):
                load=sums[end]-sums[start]
                if load>max_load+1e-6:
                    break
                if end in unsplittable or start in unsplittable:
                    continue
                if turns[end]-turns[start]>(first_turn_limit if number==1 else 2):
                    continue
                if any(not (start <= ix < end) for ix,v in forced.items() if v==number):
                    continue
                if any(start <= ix < end for ix,v in forced.items() if v!=number):
                    continue
                if any(op.get('IsPalletOrientationAnchor') and
                       _float(op.get('PhysicalStationNumber')) is not None and
                       abs(number-float(op['PhysicalStationNumber']))>18
                       for op in items[start:end]):
                    continue
                if n-end < k-station_index-1:
                    continue
                # Do not split source order or install tray/grill separately.
                newscore=score+(max_load-load)**2
                old=next_states.get(end)
                if old is None or newscore<old[0]:
                    next_states[end]=(newscore,start)
        dp.append(next_states)
        if not next_states:
            return None
    if n not in dp[-1]:
        return None
    ranges=[]
    end=n
    for j in range(k,0,-1):
        start=dp[j][end][1]
        ranges.append((start,end))
        end=start
    if end!=0:
        return None
    ranges.reverse()
    assignment=[None]*n
    loads=[]
    for (start,end),number in zip(ranges,candidates):
        for ix in range(start,end):
            assignment[ix]=number
        loads.append(sums[end]-sums[start])
    if len(set(assignment)) != k or any(t>max_load+1e-6 for t in loads):
        return None
    return {
        'assigned_physical_numbers':assignment,
        'used_physical_numbers':candidates,
        'removed_physical_number':removed,
        'loads':loads,
        'inversions_for_review':[],
        'status':'STRICT_ORDERED_DP_FEASIBLE',
        'engine':'CK2_EXACT_ORDERED_DP',
    }


def solve_one_fewer_main_station(operations, physical_numbers, max_load,
                                  precedence_edges=None, hard_bundle_edges=None,
                                  time_limit=12.0, removed_station=None):
    """Find 1-fewer real stations, without inventing operation times.

    Returns None on infeasible/unsupported/no certified physical mapping.
    Any changed operation order is explicitly returned as a review issue.
    """
    try:
        import numpy as np
        from scipy.optimize import milp, Bounds, LinearConstraint
        from scipy.sparse import coo_matrix
    except ImportError as exc:
        raise RuntimeError('CK2_PHASE_OPTIMIZER_SCIPY_REQUIRED: pip install scipy') from exc

    items = list(operations)
    from line_balancer import _first_station_pallet_limit
    first_turn_limit = _first_station_pallet_limit(items)
    n = len(items)
    old = sorted(set(int(x) for x in physical_numbers))
    if n < 3 or len(old) < 2:
        return None
    target = len(old) - 1
    layout = _station_candidates(items, old, target, removed_station=removed_station)
    if layout is None:
        return None
    candidates, removed = layout
    exact = _ordered_exact_dp(items, candidates, removed, max_load,
                              precedence_edges=precedence_edges,
                              hard_bundle_edges=hard_bundle_edges)
    if exact is not None:
        return exact
    k = len(candidates)
    if k != target:
        return None
    capacity = int(round(float(max_load) * 1000))
    if capacity <= 0:
        return None
    times = []
    for op in items:
        sec = _float(op.get('PredictedTimeSeconds'))
        if sec is None or sec < 0 or sec > max_load + 1e-7:
            return None
        times.append(int(round(sec * 1000)))
    if sum(times) > k * capacity:
        return None

    rows, cols, vals, low, high = [], [], [], [], []
    def add(terms, lo=-math.inf, hi=math.inf):
        r = len(low)
        low.append(lo); high.append(hi)
        for c, value in terms:
            if value:
                rows.append(r); cols.append(c); vals.append(value)

    for i in range(n):
        add([(i*k+s, 1) for s in range(k)], 1, 1)
    for s in range(k):
        add([(i*k+s, times[i]) for i in range(n)], hi=capacity)
        add([(i*k+s, 1) for i in range(n)], lo=1)

    phases = []
    phase_cursor = 0
    for op in items:
        try:
            phase = int(op.get('OrientationPhase'))
        except (TypeError, ValueError):
            if op.get('IsPalletOrientationAnchor'):
                phase_cursor += 1
            phase = phase_cursor
        phases.append(phase)
    if any(b < a for a, b in zip(phases, phases[1:])):
        return None

    def before(i, j, strict=False):
        add([(i*k+s, s) for s in range(k)] +
            [(j*k+s, -s) for s in range(k)], hi=(-1 if strict else 0))

    # One phase may be rebalanced; an orientation transition never moves
    # ahead of its predecessor or behind downstream operations.
    for i in range(n-1):
        if phases[i] != phases[i+1] or items[i].get('IsPalletOrientationAnchor'):
            before(i, i+1)
        if items[i].get('AdaptiveMandatoryBoundaryAfter'):
            before(i, i+1, strict=True)
    for i, op in enumerate(items):
        if not op.get('IsPalletOrientationAnchor'):
            continue
        for j in range(i+1, n):
            if phases[j] != phases[i]:
                break
            before(i, j)

    # HARD PROCESS RULE: preserve the exact chronological order.
    # All original operations (including every pallet/component rotation)
    # remain in nondecreasing physical station order. Within each station,
    # the output builder preserves this source order.
    for i in range(n - 1):
        before(i, i + 1)

    # The physical pallet validator requires EVERY operation in orientation
    # phase p to precede EVERY operation in phase p+1, not just one boundary
    # operation. Otherwise one later task can slip behind a rotation.
    grouped_phases = defaultdict(list)
    for index, phase in enumerate(phases):
        grouped_phases[phase].append(index)
    phase_names = list(grouped_phases)
    for pa, pb in zip(phase_names, phase_names[1:]):
        for i in grouped_phases[pa]:
            for j in grouped_phases[pb]:
                before(i, j)

    # Operations already ordered within one real reference workstation cannot
    # be reversed. Their historical station boundary itself remains SOFT.
    for i in range(n - 1):
        sa = items[i].get("PreservedReferenceStationSequence")
        sb = items[i+1].get("PreservedReferenceStationSequence")
        if sa is None or sb is None:
            sa = items[i].get("StationWithinType")
            sb = items[i+1].get("StationWithinType")
        if sa is not None and sa == sb:
            before(i, i+1)

    # Explicit certified dependencies are always hard; historical co-location
    # statistics are not certified engineering rules.
    ids = defaultdict(list)
    by_key = {}
    for i, op in enumerate(items):
        ids[str(op.get('CanonicalOperationId') or '')].append(i)
        by_key[_key(op)] = i
    # A repeated occurrence may not be moved ahead of its own earlier
    # occurrence. Exact repeated screw-gun operations originally performed
    # together also remain together.
    for same_id, positions in ids.items():
        if len(positions) < 2:
            continue
        for a, b in zip(positions, positions[1:]):
            before(a, b)
            na = str(items[a].get('CanonicalName') or '').lower()
            nb = str(items[b].get('CanonicalName') or '').lower()
            old_a = items[a].get('PreservedReferenceStationSequence')
            old_b = items[b].get('PreservedReferenceStationSequence')
            if old_a is None or old_b is None:
                old_a = items[a].get('StationWithinType')
                old_b = items[b].get('StationWithinType')
            if old_a == old_b and 'vida' in na and na == nb:
                for st in range(k):
                    add([(a*k+st, 1), (b*k+st, -1)], 0, 0)

    # CK-2 hard method rule: tray and grill are installed at the same
    # physical station. Do not separate the group just to reduce headcount.
    tray_group = [i for i, op in enumerate(items)
                  if ('tepsi' in str(op.get('CanonicalName') or '').lower()
                      or 'ızgara' in str(op.get('CanonicalName') or '').lower())
                  and ('yerleştir' in str(op.get('CanonicalName') or '').lower()
                       or 'koy' in str(op.get('CanonicalName') or '').lower())]
    if len(tray_group) >= 2:
        for a, b in zip(tray_group, tray_group[1:]):
            for st in range(k):
                add([(a*k+st, 1), (b*k+st, -1)], 0, 0)

    for e in precedence_edges or ():
        if not _certified(e):
            continue
        ia = ids.get(str(e.get('Source') or ''), [])
        ib = ids.get(str(e.get('Target') or ''), [])
        if ia and ib:
            before(ia[-1], ib[0])
    for e in hard_bundle_edges or ():
        if not _certified(e):
            continue
        a = by_key.get((str(e.get('Source') or ''), int(e.get('SourceOccurrenceIndex') or 1)))
        b = by_key.get((str(e.get('Target') or ''), int(e.get('TargetOccurrenceIndex') or 1)))
        if a is None or b is None or a == b:
            continue
        for s in range(k):
            add([(a*k+s, 1), (b*k+s, -1)], 0, 0)

    for i, op in enumerate(items):
        forced = op.get('ForcedPhysicalStationNumber')
        rule = str(op.get('EngineeringRule') or '').upper()
        if forced is None and 'STANDARD_CEHENNEMLIK_LABEL' in rule:
            forced = 1
        if forced is None and 'KAPI_ETIKETI_CONFIG' in rule:
            forced = op.get('PhysicalStationNumber')
        if forced is not None:
            if int(forced) not in candidates:
                return None
            expected = candidates.index(int(forced))
            for s in range(k):
                if s != expected:
                    add([(i*k+s, 1)], hi=0)

    turn_idx = [i for i, op in enumerate(items) if op.get('IsPalletOrientationAnchor')]
    for s in range(k):
        add([(i*k+s, 1) for i in turn_idx], hi=(first_turn_limit if candidates[s] == 1 else 2))

    # ML target-tempo station priors influence the *actual optimisation*.
    # Hard rules are unaffected. The source station is only the fallback.
    cost = np.zeros(n*k, dtype=float)
    for i, op in enumerate(items):
        learned = _float(op.get('TempoLayoutPreferredPhysicalStationNumber'))
        historical = _float(op.get('PhysicalStationNumber'))
        if learned is None or learned <= 0:
            learned = historical
        if learned is None:
            learned = candidates[min(k-1, int((i/max(1,n-1))*(k-1)))]
        for s, number in enumerate(candidates):
            cost[i*k+s] = 0.000001 * abs(number-learned)
        if op.get('IsPalletOrientationAnchor') and historical is not None:
            for s, number in enumerate(candidates):
                if abs(number - historical) > 18:
                    add([(i*k+s, 1)], hi=0)

    matrix = coo_matrix((vals, (rows, cols)), shape=(len(low), n*k)).tocsr()
    answer = milp(cost, integrality=np.ones(n*k, dtype=np.uint8),
                  bounds=Bounds(np.zeros(n*k), np.ones(n*k)),
                  constraints=LinearConstraint(matrix, np.array(low), np.array(high)),
                  options={'time_limit': float(time_limit), 'mip_rel_gap':0.03,
                           'disp':False})
    if answer.x is None:
        return None
    prob = answer.x.reshape(n, k)
    assignment = [int(np.argmax(prob[i])) for i in range(n)]
    if any(prob[i,slot] < 1.0-1e-5 for i,slot in enumerate(assignment)):
        return None
    loads = [sum(float(items[i]['PredictedTimeSeconds'])
                 for i in range(n) if assignment[i] == s) for s in range(k)]
    if any(load > max_load + 1e-6 or load <= 0 for load in loads):
        return None
    if any(assignment[a] > assignment[b]
           for a,b in zip(turn_idx,turn_idx[1:])):
        return None
    if any(sum(assignment[i]==s for i in turn_idx) > (first_turn_limit if candidates[s]==1 else 2)
           for s in range(k)):
        return None
    inversions = []
    for i in range(n-1):
        if assignment[i] > assignment[i+1]:
            if phases[i] != phases[i+1]:
                return None
            inversions.append({'source': _key(items[i]), 'target': _key(items[i+1]),
                               'source_name':items[i].get('CanonicalName'),
                               'target_name':items[i+1].get('CanonicalName')})
    # Defensive guard: never return an unapproved resequencing proposal.
    if inversions:
        return None
    return {
        'assigned_physical_numbers': [candidates[s] for s in assignment],
        'used_physical_numbers': candidates,
        'removed_physical_number': removed,
        'loads': loads,
        'inversions_for_review': inversions,
        'status': 'ORDER_PRESERVED',
        'engine': 'SCIPY_HIGHS_STRICT_CHRONOLOGY',
    }
